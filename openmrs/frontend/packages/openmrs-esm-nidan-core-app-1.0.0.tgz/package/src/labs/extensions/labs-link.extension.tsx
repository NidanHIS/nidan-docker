import React from 'react';
import { externalAppUrls } from '../../external-app-urls';
import './labs-dashboard-link.scss';

const LabsDashboardLink = () => {
    return (
        <a href={externalAppUrls.lab} className="labsMenuItem" target="blank">
            <span className="labsMenuContent">
                <span>Labs</span>
            </span>
        </a>
    );
};

export default LabsDashboardLink;
