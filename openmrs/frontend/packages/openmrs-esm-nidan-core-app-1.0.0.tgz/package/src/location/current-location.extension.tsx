import React from 'react';
import { useTranslation } from 'react-i18next';
import { HeaderGlobalAction } from '@carbon/react';
import { LocationIcon, useSession } from '@openmrs/esm-framework';
import styles from './current-location.scss';

const CurrentLocation: React.FC = () => {
  const { t } = useTranslation();
  const session = useSession();
  const currentLocation = session?.sessionLocation?.display;

  return (
    <div
      aria-label={t('currentLocation', 'Current location')}
      className={styles.currentLocation}
    >
      <LocationIcon size={16} />
      <span className={styles.currentLocationText}>
        {currentLocation}
      </span>
    </div>
  );
};

export default CurrentLocation;
