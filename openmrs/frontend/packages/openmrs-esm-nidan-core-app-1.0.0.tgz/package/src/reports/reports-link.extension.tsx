import React from 'react';
import { ConfigurableLink } from '@openmrs/esm-framework';
import { useTranslation } from 'react-i18next';

export const spaRoot = window['getOpenmrsSpaBase'];
export const basePath = '/reports';
export const spaBasePath = `${window.spaBase}${basePath}`;

export default function SystemAdminAppMenuLink() {
    const { t } = useTranslation();
    return <ConfigurableLink to={spaBasePath}>{t('reportsApp', 'Reports')}</ConfigurableLink>;
}