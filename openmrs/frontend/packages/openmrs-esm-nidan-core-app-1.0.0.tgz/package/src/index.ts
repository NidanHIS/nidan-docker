/**
 * This is the entrypoint file of the application. It communicates the
 * important features of this microfrontend to the app shell.
 */

import { defineConfigSchema, getAsyncLifecycle, getSyncLifecycle } from '@openmrs/esm-framework';
import { registerPostSubmissionAction } from '@openmrs/esm-form-engine-lib';
import { configSchema } from './config-schema';
import CurrentLocation from './location/current-location.extension';

const moduleName = '@openmrs/esm-nidan-core-app';

const options = {
  featureName: 'nidan-core',
  moduleName,
};

/**
 * Translation loader
 */
export const importTranslation = require.context('../translations', false, /\.json$/, 'lazy');

/**
 * App startup
 */
export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
  console.log('running');

  // Register post-submission action for transitioning queue entries to "completed"
  // when the Disposition note form (UUID: 55fcfbee-6510-3abb-b2da-dbd0d5353b2e) is submitted.
  registerPostSubmissionAction({
    name: 'QueueTransitionAction',
    load: () => import('./post-submission-actions/queue-transition-action'),
  });

  registerPostSubmissionAction({
    name: 'DeathNoteAction',
    load: () => import('./post-submission-actions/death-note-action'),
  });
}


function createLifecycleOptions(featureName: string) {
  return {
    featureName,
    moduleName,
  };
}


export const orthancDashboardLink = getAsyncLifecycle(
  () => import('./Orthanc/extensions/orthanc-link.extesnion'),
  createLifecycleOptions('orthanc-dashboard-link'),
);

export const labsDashboardLink = getAsyncLifecycle(
  () => import('./labs/extensions/labs-link.extension'),
  createLifecycleOptions('labs-dashboard-link'),
);

export const odooDashboardLink = getAsyncLifecycle(
  () => import('./billing/extensions/odoo-dashboard-link.extension'),
  createLifecycleOptions('odoo-dashboard-link'),
);

export const reportsAppMenuLink = getAsyncLifecycle(
  () => import('./reports/reports-link.extension'),
  createLifecycleOptions('reports-app-menu-link'),
);

export const currentLocationComponent = getSyncLifecycle(CurrentLocation, options);

export const loginOverrideHelper = getSyncLifecycle(() => null, options);