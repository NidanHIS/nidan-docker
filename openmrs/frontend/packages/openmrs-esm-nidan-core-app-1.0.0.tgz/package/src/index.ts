/**
 * This is the entrypoint file of the application. It communicates the
 * important features of this microfrontend to the app shell.
 */

import { defineConfigSchema, getAsyncLifecycle, getSyncLifecycle } from '@openmrs/esm-framework';
import { configSchema } from './config-schema';
import CurrentLocation from './location/current-location.extension';

const moduleName = '@openmrs/esm-nidan-core-app';

const options = {
  featureName: 'nidan-core',
  moduleName,
};

/**
 * Translation loader
 */
export const importTranslation = require.context('../translations', false, /\.json$/, 'lazy');

/**
 * App startup
 */
export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

function createLifecycleOptions(featureName: string) {
  return {
    featureName,
    moduleName,
  };
}


export const orthancDashboardLink = getAsyncLifecycle(
  () => import('./Orthanc/extensions/orthanc-link.extesnion'),
  createLifecycleOptions('orthanc-dashboard-link'),
);

export const labsDashboardLink = getAsyncLifecycle(
  () => import('./labs/extensions/labs-link.extension'),
  createLifecycleOptions('labs-dashboard-link'),
);

export const odooDashboardLink = getAsyncLifecycle(
  () => import('./billing/extensions/odoo-dashboard-link.extension'),
  createLifecycleOptions('odoo-dashboard-link'),
);

export const reportsAppMenuLink = getAsyncLifecycle(
  () => import('./reports/reports-link.extension'),
  createLifecycleOptions('reports-app-menu-link'),
);

export const currentLocationComponent = getSyncLifecycle(CurrentLocation, options);