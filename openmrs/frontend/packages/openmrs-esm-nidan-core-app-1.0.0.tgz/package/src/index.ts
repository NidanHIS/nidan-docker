/**
 * This is the entrypoint file of the application. It communicates the
 * important features of this microfrontend to the app shell.
 */

import { defineConfigSchema, getAsyncLifecycle } from '@openmrs/esm-framework';
import { configSchema } from './config-schema';

const moduleName = '@openmrs/esm-nidan-core-app';

/**
 * Translation loader
 */
export const importTranslation = require.context('../translations', false, /\.json$/, 'lazy');

/**
 * App startup
 */
export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

function createLifecycleOptions(featureName: string) {
  return {
    featureName,
    moduleName,
  };
}


export const orthancDashboardLink = getAsyncLifecycle(
  () => import('./Orthanc/extensions/orthanc-link.extesnion'),
  createLifecycleOptions('orthanc-dashboard-link'),
);

export const labsDashboardLink = getAsyncLifecycle(
  () => import('./labs/extensions/labs-link.extension'),
  createLifecycleOptions('labs-dashboard-link'),
);

export const odooDashboardLink = getAsyncLifecycle(
  () => import('./billing/extensions/odoo-dashboard-link.extension'),
  createLifecycleOptions('odoo-dashboard-link'),
);
