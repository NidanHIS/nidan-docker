/**
 * QueueTransitionAction - PostSubmissionAction for OpenMRS Form Engine
 * 
 * This action automatically transitions a patient's active queue entry to "completed" status
 * when a form is submitted. It is designed for the Disposition note form.
 * 
 * ## How it works:
 * 1. After form submission, fetches all active queue entries for the patient
 * 2. Filters out entries already in "completed" status (UUID: b559fb77-4e1e-4285-b9b7-1d03e0ba983f)
 * 3. Selects the most recent queue entry (sorted by dateCreated descending)
 * 4. Transitions that entry to the "completed" status
 * 5. Shows success/error notifications
 * 
 * ## Configuration in form schema:
 * Add this to the form's postSubmissionActions array:
 * 
 * ```json
 * {
 *   "name": "Disposition Note Form",
 *   "uuid": "55fcfbee-6510-3abb-b2da-dbd0d5353b2e",
 *   "postSubmissionActions": [
 *     {
 *       "actionId": "QueueTransitionAction",
 *       "enabled": "true"
 *     }
 *   ],
 *   "pages": [...]
 * }
 * ```
 * 
 * ## Testing:
 * 1. Submit the Disposition note form for a patient with an active queue entry
 * 2. Verify the queue entry status changes to "completed" in the queue management UI
 * 3. Check that a success notification appears
 * 4. Test with a patient who has no queue entries (should complete silently)
 * 5. Test with a patient whose queue entry is already completed (should skip)
 */

import { showSnackbar } from '@openmrs/esm-framework';
import type { PostSubmissionAction } from '@openmrs/esm-form-engine-lib';
import { fetchActiveQueueEntries, transitionQueueEntry } from '../api/queue';

// Universal "completed" status UUID
const COMPLETED_STATUS_UUID = 'b559fb77-4e1e-4285-b9b7-1d03e0ba983f';
console.log('hello');

const QueueTransitionAction: PostSubmissionAction = {
  
  applyAction: async ({ patient, encounters, sessionMode }, config) => {
    // Guard 1: skip view / embedded-view modes — form is read-only
    if (sessionMode === 'view' || sessionMode === 'embedded-view') {
      return;
    }

    // Guard 2: ensure we have a valid patient ID
    if (!patient?.id) {
      return;
    }

    try {
      // Step 1: Fetch active queue entries for the patient
      const queueData = await fetchActiveQueueEntries(patient.id);

      if (!queueData.results || queueData.results.length === 0) {
        // No active queue entries - this is normal, exit silently
        return;
      }

      // Step 2: Filter out entries already in "completed" status
      const entriesToTransition = queueData.results.filter(
        (entry) => entry.status?.uuid !== COMPLETED_STATUS_UUID,
      );

      if (entriesToTransition.length === 0) {
        // All queue entries are already completed - exit silently
        return;
      }

      // Step 3: Transition all active queue entries to completed status in parallel
      await Promise.all(
        entriesToTransition.map((entry) => transitionQueueEntry(entry.uuid, COMPLETED_STATUS_UUID)),
      );

      // Step 4: Show success notification
      showSnackbar({
        kind: 'success',
        title: 'Queue status updated',
        subtitle: 'Patient queue entry marked as completed',
        isLowContrast: true,
      });
    } catch (err: any) {
      // Show error notification if queue transition fails
      showSnackbar({
        kind: 'error',
        title: "Couldn't update queue status",
        subtitle: err?.message ?? 'Unknown error occurred',
        isLowContrast: false,
      });
      
      // Log the error for debugging but don't throw - form submission has already succeeded
      console.error('QueueTransitionAction error:', err);
    }
  },
};

export default QueueTransitionAction;
