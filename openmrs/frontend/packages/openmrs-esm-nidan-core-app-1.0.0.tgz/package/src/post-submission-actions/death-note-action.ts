import { showSnackbar } from '@openmrs/esm-framework';
import type { PostSubmissionAction } from '@openmrs/esm-form-engine-lib';
import { markPersonDeceased } from '../api/death-note';

const DeathNoteAction: PostSubmissionAction = {
  applyAction: async ({ patient, encounters, sessionMode }, config) => {
    // Guard 1: skip view / embedded-view modes — form is read-only
    console.log('running')
    if (sessionMode === 'view' || sessionMode === 'embedded-view') return;

    // Guard 2: skip if the patient is already marked as deceased
    if ((patient as any).deceasedBoolean || (patient as any).deceasedDateTime) return;
    console.log('till now')

    const encounter = encounters?.[0];
    if (!encounter) return;
    console.log('encounter', encounter);

    // Extract obs values by matching the field IDs supplied in the form schema config.
    // Each saved obs has a formFieldPath shaped like "rfe-forms-<fieldId>".
    const deathDateObs = encounter.obs?.find((obs: any) =>
      obs.formFieldPath?.includes(config?.deathDateFieldId),
    );
    const causeObs = encounter.obs?.find((obs: any) =>
      obs.formFieldPath?.includes(config?.causeOfDeathFieldId),
    );

    // Guard 3: only proceed when both required fields were filled in
    if (!deathDateObs?.value || !causeObs?.value) return;

    try {
      await markPersonDeceased(patient.id, {
        dead: true,
        deathDate: deathDateObs.value,
        causeOfDeathNonCoded: String(causeObs.value),
      });

      showSnackbar({
        kind: 'success',
        title: 'Patient marked as deceased',
        isLowContrast: true,
      });
    } catch (err: any) {
      showSnackbar({
        kind: 'error',
        title: 'Error marking patient as deceased',
        subtitle: err?.message ?? 'Unknown error',
        isLowContrast: false,
      });
    }
  },
};

export default DeathNoteAction;
