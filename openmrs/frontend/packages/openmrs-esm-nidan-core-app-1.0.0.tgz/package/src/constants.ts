export const moduleName = '@openmrs/esm-nidan-core-app';
