import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export interface PersonDeceasedPayload {
  dead: boolean;
  deathDate: string; // ISO 8601 string e.g. "2026-08-29T18:15:00.000Z"
  causeOfDeathNonCoded: string; // free-text, NOT a concept UUID
}

/**
 * POSTs to ws/rest/v1/person/{patientUuid} to mark the patient as deceased.
 * `openmrsFetch` automatically prepends the base URL and attaches the session cookie.
 */
export function markPersonDeceased(patientUuid: string, payload: PersonDeceasedPayload) {
  return openmrsFetch(`${restBaseUrl}/person/${patientUuid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}
