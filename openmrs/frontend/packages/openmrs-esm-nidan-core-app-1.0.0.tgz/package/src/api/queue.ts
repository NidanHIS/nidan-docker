import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export interface QueueEntryStatus {
  uuid: string;
}

export interface QueueEntry {
  uuid: string;
  status: QueueEntryStatus;
  dateCreated: string;
}

export interface QueueEntriesResponse {
  results: QueueEntry[];
  totalCount?: number;
}

export interface QueueTransitionPayload {
  queueEntryToTransition: string;
  newStatus: string;
}

/**
 * Fetches active (not ended) queue entries for a specific patient.
 * Returns queue entries with uuid, status.uuid, and dateCreated for sorting.
 * 
 * @param patientUuid - The UUID of the patient
 * @returns Promise resolving to the queue entries response
 */
export async function fetchActiveQueueEntries(patientUuid: string): Promise<QueueEntriesResponse> {
  const response = await openmrsFetch(
    `${restBaseUrl}/queue-entry?v=custom:(uuid,status:(uuid),dateCreated)&totalCount=true&patient=${patientUuid}&isEnded=false`,
    {
      method: 'GET',
    },
  );
  return response.data;
}

/**
 * Transitions a queue entry to a new status.
 * POSTs to ws/rest/v1/queue-entry/transition to change the status of a queue entry.
 * 
 * @param queueEntryUuid - The UUID of the queue entry to transition
 * @param newStatusUuid - The UUID of the new status
 * @returns Promise resolving when the transition is complete
 */
export function transitionQueueEntry(queueEntryUuid: string, newStatusUuid: string) {
  const payload: QueueTransitionPayload = {
    queueEntryToTransition: queueEntryUuid,
    newStatus: newStatusUuid,
  };

  return openmrsFetch(`${restBaseUrl}/queue-entry/transition`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}
