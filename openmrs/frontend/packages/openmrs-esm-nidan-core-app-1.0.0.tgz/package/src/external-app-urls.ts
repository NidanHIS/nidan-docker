const fallbackHost = 'localhost';
const fallbackProtocol = 'http:';

function getCurrentHost() {
  if (typeof window === 'undefined') {
    return fallbackHost;
  }

  return window.location.hostname || fallbackHost;
}

function getCurrentProtocol() {
  if (typeof window === 'undefined') {
    return fallbackProtocol;
  }

  return window.location.protocol || fallbackProtocol;
}

export const externalAppUrls = {
  lab: '/openelis',
  orthanc: '/orthanc-container/ui/app/index.html#/',
  pharmacy: `${getCurrentProtocol()}//${getCurrentHost()}:8069`,
};
