import { useEffect } from 'react';
import { interpolateUrl, navigate, setUserLanguage, useConfig, useConnectivity, useSession } from '@openmrs/esm-framework';
import { clearHistory } from '@openmrs/esm-framework/src/internal';
import { type ConfigSchema } from '../config-schema';
import { performLogout } from './logout.resource';

// Nidan (KC-35-02): a full page load to the oauth2login logout URL, so the gateway and Keycloak sessions end too and
// the next person at this computer gets the login form, not the previous user's session. That URL also ends the
// OpenMRS session, so the REST logout is skipped: ending it first made the SPA see "logged out" and navigate to
// its own login, which could cancel this navigation before the gateway cookie was cleared.
function endSingleSignOn(config: ConfigSchema) {
  if (config.provider.logoutUrl) {
    window.location.assign(interpolateUrl(config.provider.logoutUrl));
    return true;
  }
  return false;
}

const RedirectLogout: React.FC = () => {
  const config = useConfig<ConfigSchema>();
  const isLoginEnabled = useConnectivity();
  const session = useSession();

  useEffect(() => {
    clearHistory();
    if (config.provider.type === 'oauth2' && isLoginEnabled && endSingleSignOn(config)) {
      return;
    }
    if (!session.authenticated || !isLoginEnabled) {
      if (config.provider.type === 'custom') {
        navigate({ to: config.provider.loginUrl });
      } else if (config.provider.type === 'oauth2') {
        endSingleSignOn(config);
      } else {
        navigate({ to: '${openmrsSpaBase}/login' });
      }
    } else {
      performLogout()
        .then(() => {
          const defaultLanguage = document.documentElement.getAttribute('data-default-lang');

          setUserLanguage({
            locale: defaultLanguage,
            authenticated: false,
            sessionId: '',
          });

          if (config.provider.type === 'custom') {
            navigate({ to: config.provider.loginUrl });
          } else if (config.provider.type === 'oauth2') {
            endSingleSignOn(config);
          } else {
            navigate({ to: '${openmrsSpaBase}/login' });
          }
        })
        .catch((error) => {
          console.error('Logout failed:', error);
        });
    }
  }, [config, isLoginEnabled, session]);

  return null;
};

export default RedirectLogout;
