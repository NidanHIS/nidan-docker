import { type Location } from '@openmrs/esm-framework';
import { type Encounter } from '../src/types';
import { mockPatientAlice } from './patient.mock';
import { mockVisitAlice } from './visits.mock';

const mockLocationSurgery: Location = {
  uuid: 'b1a8b05e-3542-4037-bbd3-998ee9c40575',
  display: 'Surgery',
  name: 'Surgery',
};

export const mockEncounterAlice: Encounter = {
  uuid: 'asdf',
  encounterDatetime: '2024-06-27T19:40:16.000+0000',
  patient: mockPatientAlice,
  location: mockLocationSurgery,
  encounterType: {
    uuid: 'asdf',
    description: 'admission',
  },
  obs: [],
  visit: mockVisitAlice,
};
