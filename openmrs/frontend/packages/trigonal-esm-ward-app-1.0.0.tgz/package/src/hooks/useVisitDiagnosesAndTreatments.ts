import React, { useMemo, useEffect, useState } from 'react';
import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type { Encounter, Observation } from '../types';

export interface DiagnosisItem {
  diagnosis: string;
  order: string;
}

export interface OrderItem {
  order: any;
  provider: {
    name: string;
    role: string;
  };
}

export function useVisitDiagnosesAndTreatments(patientUuid: string, providedVisitUuid?: string) {
  const [encounters, setEncounters] = useState<Encounter[] | null>(null);
  const [medications, setMedications] = useState<any[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    const fetchData = async () => {
      try {
        let visitUuidToUse = providedVisitUuid;
        
        // Auto-resolve active visit if not provided
        if (!visitUuidToUse && patientUuid) {
          const activeVisitsRes: any = await openmrsFetch(`${restBaseUrl}/visit?patient=${patientUuid}&includeInactive=false`);
          if (activeVisitsRes.data?.results?.length > 0) {
            visitUuidToUse = activeVisitsRes.data.results[0].uuid;
          }
        }

        const promises = [];

        // 1. Fetch diagnoses from the visit endpoint
        if (visitUuidToUse) {
          const visitRepresentation = 'custom:(uuid,encounters:(uuid,encounterDatetime,diagnoses:(uuid,display,rank,voided,diagnosis:(coded:(uuid,display),nonCoded))))';
          promises.push(openmrsFetch(`${restBaseUrl}/visit/${visitUuidToUse}?v=${visitRepresentation}`).then(res => {
            if (isMounted) {
              setEncounters((res.data as any)?.encounters || []);
            }
          }));
        } else {
          setEncounters([]);
        }

        // 2. Fetch treatments from the order endpoint
        if (patientUuid) {
          const orderCareSetting = '6f0c9a92-6f24-11e3-af88-005056821db0';
          const orderType = '131168f4-15f5-102d-96e4-000c29c2a5d7';
          const orderRepresentation = 'custom:(uuid,dateActivated,dateStopped,autoExpireDate,action,asNeeded,drug:(display,strength),dose,doseUnits:ref,frequency:ref,route:ref,instructions,orderNumber,orderer:(display))';
          const orderUrl = `${restBaseUrl}/order?patient=${patientUuid}&careSetting=${orderCareSetting}&orderTypes=${orderType}&excludeDiscontinueOrders=true&v=${orderRepresentation}`;
          
          promises.push(openmrsFetch(orderUrl).then(res => {
            if (isMounted) {
              setMedications((res.data as any)?.results || []);
            }
          }));
        } else {
          setMedications([]);
        }

        await Promise.all(promises);
      } catch (err: any) {
        if (isMounted) {
          setError(err);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [patientUuid, providedVisitUuid]);

  const processedData = useMemo(() => {
    const diags: Array<DiagnosisItem> = [];
    const activeMeds: Array<OrderItem> = [];
    const stoppedMeds: Array<OrderItem> = [];

    if (encounters) {
      encounters.forEach((enc: any) => {
        if (enc.diagnoses && enc.diagnoses.length > 0) {
          enc.diagnoses.forEach((diag: any) => {
            if (!diag.voided) {
              let diagnosisText = diag.diagnosis?.display || diag.display || '';
              let orderText = diag.rank === 1 ? 'Primary' : (diag.rank === 2 ? 'Secondary' : '');
              diags.push({
                diagnosis: diagnosisText,
                order: orderText,
              });
            }
          });
        }
      });
    }

    if (medications) {
      const now = new Date();
      medications.forEach((order: any) => {
        const isStopped = order.dateStopped !== null || (order.autoExpireDate && new Date(order.autoExpireDate) < now);
        const item: OrderItem = {
          order,
          provider: {
            name: order.orderer?.display || '',
            role: '', // Orderer display often contains name/role
          },
        };

        if (isStopped) {
          stoppedMeds.push(item);
        } else {
          activeMeds.push(item);
        }
      });
    }

    return { diagnoses: diags, activeMedications: activeMeds, stoppedMedications: stoppedMeds };
  }, [encounters, medications]);

  return { ...processedData, error, isLoading };
}
