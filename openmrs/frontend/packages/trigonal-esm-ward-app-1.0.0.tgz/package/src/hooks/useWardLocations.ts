import { type FetchResponse, openmrsFetch, restBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useMemo } from 'react';
import type { WardConfigObject } from '../config-schema';

export interface WardLocation {
  uuid: string;
  display: string;
}

interface LocationResponse {
  results: Array<WardLocation>;
}

/**
 * Fetches all locations tagged as admission locations.
 * These are rendered as ward tabs at the top of the ward view.
 */
export function useWardLocations() {
  const { admissionLocationTagName } = useConfig<WardConfigObject>();
  const apiUrl = admissionLocationTagName
    ? `${restBaseUrl}/location?tag=${encodeURIComponent(admissionLocationTagName)}&v=default`
    : null;

  const { data, error, isLoading } = useSWR<FetchResponse<LocationResponse>, Error>(apiUrl, openmrsFetch);

  const wardLocations = useMemo(() => data?.data?.results ?? [], [data]);

  return {
    wardLocations,
    isLoading,
    error,
  };
}

export function useWardLocation(q?: string) {
  const { admissionLocationTagName } = useConfig<WardConfigObject>();
  const apiUrl = admissionLocationTagName
    ? `${restBaseUrl}/location?tag=${encodeURIComponent(admissionLocationTagName)}&v=default${
        q ? `&q=${encodeURIComponent(q)}` : ''
      }`
    : null;

  const { data, error, isLoading } = useSWR<FetchResponse<LocationResponse>, Error>(apiUrl, openmrsFetch);

  const wardLocations = useMemo(() => data?.data?.results ?? [], [data]);

  return {
    wardLocations,
    isLoading,
    error,
  };
}
