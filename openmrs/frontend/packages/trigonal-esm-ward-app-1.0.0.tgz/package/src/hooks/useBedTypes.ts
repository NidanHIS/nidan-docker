import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useMemo } from 'react';
import { type BedType } from '../types';

interface BedTypeResponse {
  results: Array<BedType>;
}

export function useBedTypes() {
  const apiUrl = `${restBaseUrl}/bedtype`;

  const { data, error, isLoading } = useSWR<FetchResponse<BedTypeResponse>, Error>(apiUrl, openmrsFetch);

  const bedTypes = useMemo(() => data?.data?.results ?? [], [data]);

  return {
    bedTypes,
    isLoading,
    error,
  };
}
