import React from 'react';
import styles from './ward-bed.scss';
import wardPatientCardStyles from '../ward-patient-card/ward-patient-card.scss';
import { type Bed } from '../types';
import { useTranslation } from 'react-i18next';

import { Add } from '@carbon/react/icons';

interface EmptyBedProps {
  bed: Bed;
}

const EmptyBed: React.FC<EmptyBedProps> = ({ bed }) => {
  const { t } = useTranslation();

  return (
    <div
      className={styles.emptyBed}
      style={{
        '--grid-row': bed.row,
        '--grid-column': bed.column,
      } as React.CSSProperties}>
      <span className={`${wardPatientCardStyles.wardPatientBedNumber} ${wardPatientCardStyles.empty}`}>
        {bed.bedNumber}
      </span>
      <p className={styles.emptyBedText}>
        <Add size={16} />
        {t('emptyBed', 'Empty bed')}
      </p>
    </div>
  );
};

export default EmptyBed;
