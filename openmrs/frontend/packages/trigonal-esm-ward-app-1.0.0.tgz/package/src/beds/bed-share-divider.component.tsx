import { SkeletonText, Tag } from '@carbon/react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './bed-share-divider.scss';

interface BedShareDividerProps {
  isLoading?: boolean;
}

const BedShareDivider: React.FC<BedShareDividerProps> = ({ isLoading }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.bedDivider}>
      <div className={styles.bedDividerLine}></div>
      {isLoading ? <SkeletonText /> : <span className={styles.bedDividerText}>{t('bedShare', 'Bed share')}</span>}
      <div className={styles.bedDividerLine}></div>
    </div>
  );
};

export default BedShareDivider;
