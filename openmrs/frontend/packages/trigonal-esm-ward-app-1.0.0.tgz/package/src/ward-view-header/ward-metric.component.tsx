import React from 'react';
import { SkeletonPlaceholder } from '@carbon/react';
import styles from './ward-metric.scss';

interface WardMetricProps {
  metricName: string;
  metricValue: string;
  isLoading: boolean;
  icon?: React.ReactNode;
}
const WardMetric: React.FC<WardMetricProps> = ({ metricName, metricValue, isLoading, icon }) => {
  return (
    <div className={styles.metric}>
      <div className={styles.metricHeader}>
        {icon && <div className={styles.metricIcon}>{icon}</div>}
        <span className={styles.metricName}>{metricName}</span>
      </div>
      {isLoading ? (
        <SkeletonPlaceholder className={styles.skeleton} />
      ) : (
        <span className={styles.metricValue}>{metricValue}</span>
      )}
    </div>
  );
};

export default WardMetric;
