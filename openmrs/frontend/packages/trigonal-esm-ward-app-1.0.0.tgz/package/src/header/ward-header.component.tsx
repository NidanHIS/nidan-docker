import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Add } from '@carbon/react/icons';
import {
  PageHeader,
  PageHeaderContent,
  launchWorkspace2,
  ExtensionSlot,
  useLayoutType,
  InPatientPictogram,
} from '@openmrs/esm-framework';
import { Button } from '@carbon/react';
import styles from './ward-header.scss';

export const WardPageHeader: React.FC = () => {
  const { t } = useTranslation();
  const responseSize = useLayoutType() === 'tablet' ? 'sm' : 'md';

  const launchAddImagingOrderWorkspace = useCallback(() => {
    launchWorkspace2('search-patient-workspace');
  }, []);

  return (
    <div className={styles.pageHeader}>
      <PageHeader className={styles.PageHeader} data-testid="patient-queue-header">
        <PageHeaderContent illustration={<InPatientPictogram />} title={t('radiologyAndImaging', 'Ward')} />{' '}
        <div className={styles.pageHeaderActions}>
          <ExtensionSlot className={styles.providerBannerInfoSlot} name="provider-banner-info-slot" />
        </div>
      </PageHeader>
    </div>
  );
};
