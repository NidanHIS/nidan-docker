export const moduleName = '@trigonal/esm-ward-app';
