import React from 'react';
import { type Patient, navigate } from '@openmrs/esm-framework';
import styles from '../ward-patient-card.scss';

export interface WardPatientNameProps {
  patient: Patient;
}

const WardPatientName: React.FC<WardPatientNameProps> = ({ patient }) => {
  const url = `/openmrs/spa/patient/${patient?.uuid}/chart/ipd-summary`;

  return (
    <div className={styles.wardPatientName}>
      <a
        href={url}
        onClick={(e) => {
          e.preventDefault();
          navigate({ to: url });
        }}
        className={styles.patientLink}>
        {patient?.person?.preferredName?.display}
      </a>
    </div>
  );
};

export default WardPatientName;
