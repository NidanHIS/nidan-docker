import React from 'react';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import relativeTime from 'dayjs/plugin/relativeTime';
import { useTranslation } from 'react-i18next';
import { type Encounter } from '../../types';

import { Time } from '@carbon/react/icons';
import styles from './row-elements.scss';

dayjs.extend(duration);
dayjs.extend(relativeTime);

export interface WardPatientTimeSinceAdmissionProps {
  firstAdmissionOrTransferEncounter: Encounter;
}

const WardPatientTimeSinceAdmission: React.FC<WardPatientTimeSinceAdmissionProps> = ({
  firstAdmissionOrTransferEncounter,
}) => {
  const { t } = useTranslation();

  if (!firstAdmissionOrTransferEncounter) {
    return null;
  }

  const timeSinceAdmission = dayjs(firstAdmissionOrTransferEncounter.encounterDatetime).fromNow();

  return (
    <div className={styles.rowElement} title={t('admitted', 'Admitted')}>
      <Time size={16} /> {timeSinceAdmission}
    </div>
  );
};

export default WardPatientTimeSinceAdmission;
