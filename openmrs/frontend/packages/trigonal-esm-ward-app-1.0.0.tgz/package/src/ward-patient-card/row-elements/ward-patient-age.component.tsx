import { age, type Patient } from '@openmrs/esm-framework';
import React from 'react';
import { Calendar } from '@carbon/react/icons';
import styles from './row-elements.scss';

export interface WardPatientAgeProps {
  patient: Patient;
}

const WardPatientAge: React.FC<WardPatientAgeProps> = ({ patient }) => {
  return patient.person?.birthdate ? (
    <div className={styles.rowElement}>
      <Calendar size={16} /> {age(patient.person.birthdate)}
    </div>
  ) : null;
};

export default WardPatientAge;
