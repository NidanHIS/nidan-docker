import { type Patient } from '@openmrs/esm-framework';
import { type TFunction } from 'i18next';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { GenderMale, GenderFemale } from '@carbon/react/icons';
import styles from './row-elements.scss';

const WardPatientGender: React.FC<{ patient: Patient }> = ({ patient }) => {
  const { t } = useTranslation();

  return <div className={styles.rowElement}>{getGender(t, patient?.person?.gender)}</div>;
};

export const getGender = (t: TFunction, gender: string): React.ReactNode => {
  switch (gender) {
    case 'M':
      return (
        <>
          <GenderMale size={16} /> {t('male', 'Male')}
        </>
      );
    case 'F':
      return (
        <>
          <GenderFemale size={16} /> {t('female', 'Female')}
        </>
      );
    case 'O':
      return t('other', 'Other');
    case 'unknown':
      return t('unknown', 'Unknown');
    default:
      return gender;
  }
};

export default WardPatientGender;
