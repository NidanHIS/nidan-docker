import React from 'react';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import { useTranslation } from 'react-i18next';
import { type Encounter } from '@openmrs/esm-framework';

import { Timer } from '@carbon/react/icons';
import styles from './row-elements.scss';

dayjs.extend(duration);

export interface WardPatientTimeOnWardProps {
  encounterAssigningToCurrentInpatientLocation: Encounter;
}

const WardPatientTimeOnWard: React.FC<WardPatientTimeOnWardProps> = ({
  encounterAssigningToCurrentInpatientLocation,
}) => {
  const { t } = useTranslation();

  if (!encounterAssigningToCurrentInpatientLocation?.encounterDatetime) {
    return null;
  }

  const dur = dayjs.duration(dayjs().diff(encounterAssigningToCurrentInpatientLocation.encounterDatetime));
  const days = Math.floor(dur.asDays());
  const hours = dur.hours();
  const minutes = dur.minutes();
  const seconds = dur.seconds();

  const parts = [];

  if (days > 0) {
    parts.push(
      t('days', {
        count: days,
        defaultValue_one: '{{count}} d',
        defaultValue_other: '{{count}} d',
      }),
    );
  }
  if (hours > 0) {
    parts.push(
      t('hours', {
        count: hours,
        defaultValue_one: '{{count}} h',
        defaultValue_other: '{{count}} h',
      }),
    );
  }
  if (minutes > 0) {
    parts.push(
      t('minutes', {
        count: minutes,
        defaultValue_one: '{{count}} m',
        defaultValue_other: '{{count}} m',
      }),
    );
  }
  if (seconds > 0 && parts.length === 0) {
    parts.push(
      t('seconds', {
        count: seconds,
        defaultValue_one: '{{count}} s',
        defaultValue_other: '{{count}} s',
      }),
    );
  }

  if (parts.length === 0) {
    return null;
  }

  return (
    <div className={styles.rowElement} title={t('timeOnWardLabel', 'Time on ward')}>
      <Timer size={16} /> {parts.join(' ')}
    </div>
  );
};

export default WardPatientTimeOnWard;
