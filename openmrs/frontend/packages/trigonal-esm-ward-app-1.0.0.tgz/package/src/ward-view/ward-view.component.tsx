import { InlineNotification } from '@carbon/react';
import { ExtensionSlot, useDefineAppContext, useSession, type Location } from '@openmrs/esm-framework';
import classNames from 'classnames';
import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useWardConfig } from './ward-view.resource';
import { useWardLocations } from '../hooks/useWardLocations';
import WardTabs from './ward-tabs.component';
import styles from './ward-view.scss';

export interface WardLocationContext {
  location: Location;
}

const WardView: React.FC<{}> = () => {
  const { t } = useTranslation();
  const { sessionLocation } = useSession();
  const { wardLocations, isLoading: isLoadingLocations } = useWardLocations();
  const [selectedLocation, setSelectedLocation] = useState<Location>(sessionLocation);

  // When the login location is not among the admission locations,
  // default to the first admission location so the bed component
  // matches the active tab.
  useEffect(() => {
    if (!isLoadingLocations && wardLocations.length > 0) {
      const sessionIsAdmissionLocation = wardLocations.some((loc) => loc.uuid === sessionLocation?.uuid);
      if (!sessionIsAdmissionLocation) {
        setSelectedLocation(wardLocations[0] as unknown as Location);
      }
    }
  }, [isLoadingLocations, wardLocations, sessionLocation]);

  // Broadcast the selected location via app context so hooks inside
  // extensions (which don't share BrowserRouter) can read it
  useDefineAppContext<WardLocationContext>('ward-location-context', {
    location: selectedLocation,
  });

  const locationUuid = selectedLocation?.uuid;
  const wardConfig = useWardConfig(locationUuid);

  const handleLocationChange = useCallback((location: Location) => {
    setSelectedLocation(location);
  }, []);

  if (!selectedLocation) {
    return <InlineNotification kind="error" title={t('invalidLocationSpecified', 'Invalid location specified')} />;
  }

  const wardId = wardConfig.id;

  return (
    <div className={classNames(styles.wardView, styles.verticalTiling)}>
      <WardTabs selectedLocation={selectedLocation} onLocationChange={handleLocationChange} />
      <ExtensionSlot name={wardId} />
    </div>
  );
};

export default WardView;
