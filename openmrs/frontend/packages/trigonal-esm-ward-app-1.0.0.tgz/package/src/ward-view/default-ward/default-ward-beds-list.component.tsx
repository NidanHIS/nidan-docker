import React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableHeader, TableRow, Tag } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import DefaultWardPatientCard from './default-ward-patient-card.component';
import styles from './default-ward-beds-list.scss';

interface DefaultWardBedsListProps {
  wardPatients: any[];
}

const DefaultWardBedsList: React.FC<DefaultWardBedsListProps> = ({ wardPatients }) => {
  const { t } = useTranslation();

  return (
    <div className={styles.bedsListContainer}>
      <TableContainer title="" className={styles.tableContainer}>
        <Table size="lg" useZebraStyles className={styles.bedsTable}>
          <TableHead>
            <TableRow>
              <TableHeader>{t('bed', 'Bed')}</TableHeader>
              <TableHeader>{t('patient', 'Patient')}</TableHeader>
              <TableHeader>{t('gender', 'Gender')}</TableHeader>
              <TableHeader>{t('age', 'Age')}</TableHeader>
              <TableHeader>{t('admissionDate', 'Admission Date')}</TableHeader>
              <TableHeader>{t('actions', 'Actions')}</TableHeader>
            </TableRow>
          </TableHead>
          <TableBody>
            {wardPatients.map((wardPatient, index) => (
              <TableRow key={wardPatient.patient?.uuid || `empty-${wardPatient.bed.uuid}-${index}`}>
                <TableCell className={styles.bedNumberCell}>
                  <span className={styles.bedBadge}>{wardPatient.bed.bedNumber}</span>
                </TableCell>
                <TableCell>
                  {wardPatient.patient ? (
                    <div className={styles.patientInfo}>
                      <span className={styles.patientName}>{wardPatient.patient.display}</span>
                      <span className={styles.patientId}>{wardPatient.patient.identifiers?.[0]?.identifier}</span>
                    </div>
                  ) : (
                    <Tag type="green" size="sm" className={styles.availableTag}>
                      {t('available', 'Available')}
                    </Tag>
                  )}
                </TableCell>
                <TableCell>{wardPatient.patient?.person.gender === 'M' ? t('male', 'Male') : wardPatient.patient?.person.gender === 'F' ? t('female', 'Female') : '-'}</TableCell>
                <TableCell>{wardPatient.patient?.person.age || '-'}</TableCell>
                <TableCell>
                  {wardPatient.inpatientAdmission?.encounterAssigningToCurrentInpatientLocation?.encounterDatetime 
                    ? new Date(wardPatient.inpatientAdmission.encounterAssigningToCurrentInpatientLocation.encounterDatetime).toLocaleDateString() 
                    : '-'}
                </TableCell>
                <TableCell>
                   {wardPatient.patient && <DefaultWardPatientCard wardPatient={wardPatient} isListView />}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default DefaultWardBedsList;
