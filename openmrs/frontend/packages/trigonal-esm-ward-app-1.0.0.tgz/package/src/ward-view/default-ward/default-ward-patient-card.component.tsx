import React from 'react';
import { type WardPatientCardType } from '../../types';
import AdmissionRequestNoteRow from '../../ward-patient-card/card-rows/admission-request-note-row.component';
import PendingItemsRow from '../../ward-patient-card/card-rows/pending-items-row.component';
import WardPatientCard from '../../ward-patient-card/ward-patient-card.component';
import styles from '../../ward-patient-card/ward-patient-card.scss';
import DefaultWardPatientCardHeader from './default-ward-patient-card-header.component';
import IncorrectAdmissionWarningRow from '../../ward-patient-card/card-rows/incorrect-admission-warning-row.component';

import { launchWorkspace2, navigate } from '@openmrs/esm-framework';
import { OverflowMenu, OverflowMenuItem } from '@carbon/react';
import { useTranslation } from 'react-i18next';

const DefaultWardPatientCard: React.FC<{ wardPatient: any; isListView?: boolean }> = ({ wardPatient, isListView }) => {
  const { t } = useTranslation();
  const { bed } = wardPatient;

  const handleOpenWorkspace = () => {
    launchWorkspace2(
      'ward-patient-workspace',
      {},
      {},
      {
        wardPatient,
      },
    );
  };

  if (isListView) {
    return (
      <OverflowMenu flipped size="sm" aria-label={t('patientActions', 'Patient actions')}>
        <OverflowMenuItem itemText={t('viewDetails', 'View Details')} onClick={handleOpenWorkspace} />
        <OverflowMenuItem
          itemText={t('ipdDashboard', 'IPD Dashboard')}
          onClick={() => navigate({ to: `/openmrs/spa/patient/${wardPatient.patient.uuid}/chart/ipd-summary` })}
        />
      </OverflowMenu>
    );
  }

  const card = (
    <WardPatientCard wardPatient={wardPatient}>
      <DefaultWardPatientCardHeader {...{ wardPatient }} />
      <IncorrectAdmissionWarningRow wardPatient={wardPatient} />
      <PendingItemsRow id={'pending-items'} wardPatient={wardPatient} />
      <AdmissionRequestNoteRow id={'admission-request-note'} wardPatient={wardPatient} />
    </WardPatientCard>
  );

  if (bed) {
    return card;
  } else {
    return (
      <div className={styles.unassignedPatient}>
        <div key={'unassigned-bed-pt-' + wardPatient.patient.uuid}>{card}</div>
      </div>
    );
  }
};

export default DefaultWardPatientCard;
