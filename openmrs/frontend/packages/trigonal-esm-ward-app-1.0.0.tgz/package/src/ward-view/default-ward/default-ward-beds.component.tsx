import { useAppContext } from '@openmrs/esm-framework';
import React from 'react';
import WardBed from '../../beds/ward-bed.component';
import { type WardPatient, type WardViewContext } from '../../types';
import { bedLayoutToBed } from '../ward-view.resource';
import DefaultWardPatientCard from './default-ward-patient-card.component';
import DefaultWardBedsList from './default-ward-beds-list.component';
import { type WardLocationContext } from '../ward-view.component';

function DefaultWardBeds() {
  const { wardPatientGroupDetails } = useAppContext<WardViewContext>('ward-view-context') ?? {};
  const { viewMode } = useAppContext<WardLocationContext & { viewMode: string }>('ward-location-context') ?? {};
  const { bedLayouts, wardAdmittedPatientsWithBed, inpatientAdmissionsByPatientUuid } = wardPatientGroupDetails ?? {};

  const allWardBeds: any[] = [];

  const wardBeds = bedLayouts?.map((bedLayout) => {
    const { patients } = bedLayout;
    const bed = bedLayoutToBed(bedLayout);

    if (patients.length === 0) {
      allWardBeds.push({ bed, patient: null });
    } else {
      patients.forEach((patient) => {
        const inpatientAdmission = wardAdmittedPatientsWithBed?.get(patient.uuid);
        const patientData = {
          patient,
          visit: inpatientAdmission?.visit || inpatientAdmissionsByPatientUuid.get(patient.uuid)?.visit,
          bed,
          inpatientAdmission: inpatientAdmission || inpatientAdmissionsByPatientUuid.get(patient.uuid),
          inpatientRequest: inpatientAdmission?.currentInpatientRequest || null,
        };
        allWardBeds.push(patientData);
      });
    }

    const wardPatients: WardPatient[] = patients.map((patient): WardPatient => {
      const inpatientAdmission = wardAdmittedPatientsWithBed?.get(patient.uuid);
      return {
        patient,
        visit: inpatientAdmission?.visit || inpatientAdmissionsByPatientUuid.get(patient.uuid)?.visit,
        bed,
        inpatientAdmission: inpatientAdmission || inpatientAdmissionsByPatientUuid.get(patient.uuid),
        inpatientRequest: inpatientAdmission?.currentInpatientRequest || null,
      };
    });

    const patientCards = wardPatients.map((wardPatient) => (
      <DefaultWardPatientCard key={wardPatient.patient.uuid} {...{ wardPatient }} />
    ));
    return <WardBed key={bed.uuid} bed={bed} patientCards={patientCards} />;
  });

  if (viewMode === 'list') {
    return <DefaultWardBedsList wardPatients={allWardBeds} />;
  }

  return <>{wardBeds}</>;
}

export default DefaultWardBeds;
