import React, { useCallback, useMemo } from 'react';
import { ContentSwitcher, Switch, Tab, TabList, Tabs, TabsSkeleton, IconSwitch } from '@carbon/react';
import { Copy, Table } from '@carbon/react/icons';
import { type Location } from '@openmrs/esm-framework';
import { useTranslation } from 'react-i18next';
import { useWardLocations } from '../hooks/useWardLocations';
import styles from './ward-tabs.scss';

interface WardViewTabsProps {
  selectedLocation: Location;
  onLocationChange: (location: Location) => void;
  viewMode: 'card' | 'list';
  onViewModeChange: (viewMode: 'card' | 'list') => void;
}

const WardViewTabs: React.FC<WardViewTabsProps> = ({ selectedLocation, onLocationChange, viewMode, onViewModeChange }) => {
  const { t } = useTranslation();
  const { wardLocations, isLoading, error } = useWardLocations();

  const selectedIndex = useMemo(() => {
    if (!selectedLocation || !wardLocations.length) return 0;
    const index = wardLocations.findIndex((loc) => loc.uuid === selectedLocation.uuid);
    return index >= 0 ? index : 0;
  }, [selectedLocation, wardLocations]);

  const handleTabChange = useCallback(
    (evt: { selectedIndex: number }) => {
      const selectedWard = wardLocations[evt.selectedIndex];
      if (selectedWard && selectedWard.uuid !== selectedLocation?.uuid) {
        // Pass the selected ward as a Location object to update the app context
        onLocationChange(selectedWard as unknown as Location);
      }
    },
    [wardLocations, selectedLocation, onLocationChange],
  );

  if (error) {
    return null;
  }

  if (isLoading) {
    return (
      <div className={styles.wardTabsContainer}>
        <TabsSkeleton />
      </div>
    );
  }

  return (
    <div className={styles.wardTabsContainer}>
      <div className={styles.wardTabs}>
        <Tabs selectedIndex={selectedIndex} onChange={handleTabChange}>
          <TabList className={styles.wardTabList} aria-label={t('wardTabs', 'Ward tabs')} contained>
            {wardLocations.map((ward) => (
              <Tab key={ward.uuid}>{ward.display}</Tab>
            ))}
          </TabList>
        </Tabs>
      </div>
      <div className={styles.viewToggleContainer}>
        <ContentSwitcher
          size="sm"
          selectedIndex={viewMode === 'card' ? 0 : 1}
          onChange={(data) => onViewModeChange(data.name as 'card' | 'list')}>
          <IconSwitch name="card" text={t('cardView', 'Card')}>
            <Copy size={16} />
          </IconSwitch>
          <IconSwitch name="list" text={t('listView', 'List')}>
            <Table size={16} />
          </IconSwitch>
        </ContentSwitcher>
      </div>
    </div>
  );
};

export default WardViewTabs;
