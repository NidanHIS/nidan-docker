import React, { useCallback, useMemo } from 'react';
import { ContentSwitcher, Switch, Tab, TabList, Tabs, TabsSkeleton, IconSwitch, Select, SelectItem } from '@carbon/react';
import { Copy, Table } from '@carbon/react/icons';
import { type Location } from '@openmrs/esm-framework';
import { useTranslation } from 'react-i18next';
import { useWardLocations } from '../hooks/useWardLocations';
import { useBedTypes } from '../hooks/useBedTypes';
import { useWardPatientGrouping } from '../hooks/useWardPatientGrouping';
import styles from './ward-tabs.scss';

interface WardViewTabsProps {
  selectedLocation: Location;
  onLocationChange: (location: Location) => void;
  viewMode: 'card' | 'list';
  onViewModeChange: (viewMode: 'card' | 'list') => void;
  selectedBedType: string;
  onBedTypeChange: (bedType: string) => void;
}

const WardViewTabs: React.FC<WardViewTabsProps> = ({
  selectedLocation,
  onLocationChange,
  viewMode,
  onViewModeChange,
  selectedBedType,
  onBedTypeChange,
}) => {
  const { t } = useTranslation();
  const { wardLocations, isLoading, error } = useWardLocations();
  const { bedTypes } = useBedTypes();
  const { bedLayouts } = useWardPatientGrouping();

  const { totalCounts, bedTypeCounts } = useMemo(() => {
    const typeCounts = new Map<string, { occupied: number; total: number }>();
    let totalOccupied = 0;
    let totalBeds = 0;

    bedLayouts?.forEach((bl) => {
      const isOccupied = bl.patients?.length > 0;
      totalBeds++;
      if (isOccupied) {
        totalOccupied++;
      }

      const typeUuid = bl.bedType?.uuid;
      if (typeUuid) {
        const current = typeCounts.get(typeUuid) || { occupied: 0, total: 0 };
        typeCounts.set(typeUuid, {
          occupied: current.occupied + (isOccupied ? 1 : 0),
          total: current.total + 1,
        });
      }
    });

    return {
      totalCounts: { occupied: totalOccupied, total: totalBeds },
      bedTypeCounts: typeCounts,
    };
  }, [bedLayouts]);

  const selectedIndex = useMemo(() => {
    if (!selectedLocation || !wardLocations.length) return 0;
    const index = wardLocations.findIndex((loc) => loc.uuid === selectedLocation.uuid);
    return index >= 0 ? index : 0;
  }, [selectedLocation, wardLocations]);

  const handleTabChange = useCallback(
    (evt: { selectedIndex: number }) => {
      const selectedWard = wardLocations[evt.selectedIndex];
      if (selectedWard && selectedWard.uuid !== selectedLocation?.uuid) {
        // Pass the selected ward as a Location object to update the app context
        onLocationChange(selectedWard as unknown as Location);
      }
    },
    [wardLocations, selectedLocation, onLocationChange],
  );

  if (error) {
    return null;
  }

  if (isLoading) {
    return (
      <div className={styles.wardTabsContainer}>
        <TabsSkeleton />
      </div>
    );
  }

  return (
    <div className={styles.wardTabsContainer}>
      <div className={styles.wardTabs}>
        <Tabs selectedIndex={selectedIndex} onChange={handleTabChange}>
          <TabList className={styles.wardTabList} aria-label={t('wardTabs', 'Ward tabs')} contained>
            {wardLocations.map((ward) => (
              <Tab key={ward.uuid}>{ward.display}</Tab>
            ))}
          </TabList>
        </Tabs>
      </div>
      <div className={styles.controlsContainer}>
        <div className={styles.bedTypeSelector}>
          <Select
            id="bed-type-select"
            labelText={t('bedType', 'Bed Type')}
            hideLabel
            size="sm"
            value={selectedBedType}
            onChange={(evt) => onBedTypeChange(evt.target.value)}>
            <SelectItem
              value="all"
              text={`${t('allBedTypes', 'All Bed Types')} (${totalCounts.occupied}/${totalCounts.total})`}
            />
            {bedTypes.map((type) => {
              const count = bedTypeCounts.get(type.uuid) || { occupied: 0, total: 0 };
              return (
                <SelectItem
                  key={type.uuid}
                  value={type.uuid}
                  text={`${type.displayName || type.name} (${count.occupied}/${count.total})`}
                />
              );
            })}
          </Select>
        </div>
        <div className={styles.viewToggleContainer}>
          <ContentSwitcher
            size="sm"
            selectedIndex={viewMode === 'card' ? 0 : 1}
            onChange={(data) => onViewModeChange(data.name as 'card' | 'list')}>
            <IconSwitch name="card" text={t('cardView', 'Card')}>
              <Copy size={16} />
            </IconSwitch>
            <IconSwitch name="list" text={t('listView', 'List')}>
              <Table size={16} />
            </IconSwitch>
          </ContentSwitcher>
        </div>
      </div>
    </div>
  );
};

export default WardViewTabs;
