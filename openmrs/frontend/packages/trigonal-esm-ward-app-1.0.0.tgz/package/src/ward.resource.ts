import { openmrsFetch, type OpenmrsResource, type Patient, restBaseUrl, useSession } from '@openmrs/esm-framework';
import type { DispositionType, Encounter, ObsPayload, TransferVisitResponse } from './types';
import useEmrConfiguration from './hooks/useEmrConfiguration';
import useWardLocation from './hooks/useWardLocation';

export function useCreateEncounter() {
  const { location } = useWardLocation();
  const { currentProvider } = useSession();
  const { emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration } = useEmrConfiguration();

  const createEncounter = (
    patient: Patient,
    encounterType: OpenmrsResource,
    visitUuid: string,
    obs: ObsPayload[] = [],
  ) => {
    const encounterPayload = {
      patient: patient.uuid,
      encounterType: encounterType?.uuid,
      location: location?.uuid,
      encounterProviders: [
        {
          provider: currentProvider?.uuid,
          encounterRole: emrConfiguration?.clinicianEncounterRole?.uuid,
        },
      ],
      obs,
      visit: visitUuid,
    };

    return openmrsFetch<Encounter>(`${restBaseUrl}/encounter`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
      },
      body: encounterPayload,
    });
  };

  return { createEncounter, emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration };
}

export function deleteEncounter(encounterUuid: string) {
  return openmrsFetch(`${restBaseUrl}/encounter/${encounterUuid}`, {
    method: 'DELETE',
  });
}

export function useAdmitPatient() {
  const { createEncounter, emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration } =
    useCreateEncounter();

  const admitPatient = (patient: Patient, dispositionType: DispositionType, visitUuid: string) => {
    const encounterType =
      dispositionType === 'ADMIT'
        ? emrConfiguration.admissionEncounterType
        : dispositionType === 'TRANSFER'
          ? emrConfiguration.transferWithinHospitalEncounterType
          : null;
    return createEncounter(patient, encounterType, visitUuid);
  };

  return { admitPatient, emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration };
}

export function assignPatientToBed(bedUuid: number, patientUuid: string, encounterUuid: string) {
  return openmrsFetch(`${restBaseUrl}/beds/${bedUuid}`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: {
      patientUuid,
      encounterUuid,
    },
  });
}

export function removePatientFromBed(bedId: number, patientUuid: string) {
  return openmrsFetch(`${restBaseUrl}/beds/${bedId}?patientUuid=${patientUuid}`, {
    method: 'DELETE',
  });
}

export function createVisit(
  patientUuid: string,
  locationUuid: string,
  visitTypeUuid: string,
  startDatetime?: string,
) {
  return openmrsFetch(`${restBaseUrl}/visit`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: {
      patient: patientUuid,
      location: locationUuid,
      visitType: visitTypeUuid,
      startDatetime: startDatetime ?? new Date().toISOString(),
    },
  });
}

export function transferVisit(payload: {
  currentVisitUuid: string;
  patientUuid: string;
  newVisitTypeUuid: string;
  newLocationUuid: string;
  admissionEncounterTypeUuid?: string;
  encounterProviders?: Array<{ provider: string; encounterRole: string }>;
  bedId?: number;
  visitProviderUuid?: string;
}) {
  return openmrsFetch<TransferVisitResponse>(`${restBaseUrl}/nidanVisitTransfer`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: payload,
  });
}
export function fetchLatestEncounterByForm(patientUuid: string, formUuid: string) {
  const v = 'custom:(uuid,display,encounterDatetime,form:(uuid,display,name),obs:(uuid,concept:(uuid,display),value,obsDatetime))';
  return openmrsFetch(
    `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${v}&order=desc&limit=100`,
  );
}
