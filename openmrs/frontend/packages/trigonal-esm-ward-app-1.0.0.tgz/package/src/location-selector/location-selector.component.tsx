import React, { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { RadioButton, RadioButtonGroup, RadioButtonSkeleton, Search } from '@carbon/react';
import { type ControllerRenderProps } from 'react-hook-form';
import { type RadioButtonGroupProps } from '@carbon/react/lib/components/RadioButtonGroup/RadioButtonGroup';
import { isDesktop, ResponsiveWrapper, useDebounce, useLayoutType, type Location as FhirLocation } from '@openmrs/esm-framework';
import { useWardLocation, type WardLocation } from '../hooks/useWardLocations';
import styles from './location-selector.scss';

interface LocationSelectorProps extends RadioButtonGroupProps {

  /**
   * a list of locations that should be filtered from the location selector
   */
  excludeLocations?: Array<WardLocation | FhirLocation>;

  field: ControllerRenderProps<
    {
      note?: string;
      location?: string;
      transferType?: string;
    },
    'location'
  >;
}

export default function LocationSelector({ excludeLocations: locationsToFilter, field }: LocationSelectorProps) {
  const { t } = useTranslation();
  const isTablet = !isDesktop(useLayoutType());
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm);
  const { wardLocations: locations, isLoading } = useWardLocation(debouncedSearchTerm);

  const filteredLocations = locations?.filter(
    (l) => !locationsToFilter?.some((fl) => (fl as any).uuid === l.uuid || (fl as any).id === l.uuid),
  );

  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(event.target.value);
    },
    [setSearchTerm],
  );

  return (
    <div className={styles.locationSelector}>
      <ResponsiveWrapper>
        <Search
          labelText={t('searchLocations', 'Search locations')}
          onChange={handleSearch}
          value={searchTerm}
          placeholder={t('searchLocations', 'Search locations')}
          size={isTablet ? 'lg' : 'md'}
        />
      </ResponsiveWrapper>
      {isLoading ? (
        <div className={styles.radioButtonGroup}>
          <RadioButtonSkeleton />
          <RadioButtonSkeleton />
          <RadioButtonSkeleton />
          <RadioButtonSkeleton />
          <RadioButtonSkeleton />
        </div>
      ) : (
        <ResponsiveWrapper>
          <RadioButtonGroup {...field} className={styles.radioButtonGroup} orientation="vertical">
            {filteredLocations?.length > 0 ? (
              filteredLocations?.map((location) => (
                <RadioButton key={location.uuid} labelText={location.display} value={location.uuid} />
              ))
            ) : (
              <span className={styles.bodyShort01}>{t('noLocationsFound', 'No locations found')}</span>
            )}
          </RadioButtonGroup>
        </ResponsiveWrapper>
      )}
    </div>
  );
}
