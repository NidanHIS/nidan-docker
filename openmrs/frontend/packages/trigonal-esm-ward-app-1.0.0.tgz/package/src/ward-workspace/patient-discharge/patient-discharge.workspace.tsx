import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button, ButtonSet, InlineNotification } from '@carbon/react';
import { Exit } from '@carbon/react/icons';
import {
  closeWorkspaceGroup2,
  ExtensionSlot,
  fetchCurrentPatient,
  showSnackbar,
  useAppContext,
  useConfig,
  Workspace2,
} from '@openmrs/esm-framework';
import { type WardPatientWorkspaceDefinition, type WardViewContext } from '../../types';
import { type WardConfigObject } from '../../config-schema';
import { fetchLatestEncounterByForm, removePatientFromBed, useCreateEncounter } from '../../ward.resource';
import WardPatientWorkspaceBanner from '../patient-banner/patient-banner.component';
import styles from './patient-discharge.scss';


export default function PatientDischargeWorkspace({
  groupProps: { wardPatient },
  closeWorkspace,
}: WardPatientWorkspaceDefinition) {
  const { t } = useTranslation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fhirPatient, setFhirPatient] = useState(null);
  const { createEncounter, emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration } =
    useCreateEncounter();
  const { wardPatientGroupDetails } = useAppContext<WardViewContext>('ward-view-context') ?? {};
  const { dischargeNoteFormUuid, maternalDischargeNoteFormUuid } = useConfig<WardConfigObject>();
  const [encounterUuid, setEncounterUuid] = useState('');
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [maternalEncounterUuid, setMaternalEncounterUuid] = useState('');
  const [maternalFormMode, setMaternalFormMode] = useState<'add' | 'edit'>('add');
  const [activeFormType, setActiveFormType] = useState<'general' | 'maternal' | null>(null);

  // Fetch the FHIR patient resource (required by the form engine)
  useEffect(() => {
    if (wardPatient?.patient?.uuid) {
      fetchCurrentPatient(wardPatient.patient.uuid).then((patient) => {
        setFhirPatient(patient);
      });
    }
  }, [wardPatient?.patient?.uuid]);

  useEffect(() => {
    if (wardPatient?.patient?.uuid && dischargeNoteFormUuid) {
      fetchLatestEncounterByForm(wardPatient.patient.uuid, dischargeNoteFormUuid).then((response) => {
        if (response?.data?.filteredCount > 0) {
          const results = response.data.results;
          setEncounterUuid(results[results.length - 1].uuid);
          setFormMode('edit');
        } else {
          setEncounterUuid('');
          setFormMode('add');
        }
      });
    }
  }, [wardPatient?.patient?.uuid, dischargeNoteFormUuid]);

  useEffect(() => {
    if (wardPatient?.patient?.uuid && maternalDischargeNoteFormUuid && wardPatient.patient.person.gender === 'F') {
      fetchLatestEncounterByForm(wardPatient.patient.uuid, maternalDischargeNoteFormUuid).then((response) => {
        if (response?.data?.filteredCount > 0) {
          const results = response.data.results;
          setMaternalEncounterUuid(results[results.length - 1].uuid);
          setMaternalFormMode('edit');
        } else {
          setMaternalEncounterUuid('');
          setMaternalFormMode('add');
        }
      });
    }
  }, [wardPatient?.patient?.uuid, maternalDischargeNoteFormUuid]);

  const handlePostResponse = useCallback(
    (encounter) => {
      if (encounter?.uuid) {
        showSnackbar({
          title: t('dischargeNoteSaved', 'Discharge note saved successfully'),
          kind: 'success',
        });
        setActiveFormType(null);
      }
    },
    [t],
  );

  const submitDischarge = useCallback(() => {
    setIsSubmitting(true);

    createEncounter(wardPatient?.patient, emrConfiguration.exitFromInpatientEncounterType, wardPatient?.visit?.uuid)
      .then((response) => {
        if (response?.ok) {
          if (wardPatient?.bed?.id) {
            return removePatientFromBed(wardPatient.bed.id, wardPatient?.patient?.uuid);
          }
          return response;
        }
      })
      .then((response) => {
        if (response?.ok) {
          showSnackbar({
            title: t('patientWasDischarged', 'Patient was discharged'),
            kind: 'success',
          });

          closeWorkspace({ discardUnsavedChanges: true });
          closeWorkspaceGroup2();
        }
      })
      .catch((err) => {
        // TODO: better way to handle / display error messages
        // https://openmrs.atlassian.net/browse/O3-5423
        showSnackbar({
          title: t('errorDischargingPatient', 'Error discharging patient'),
          subtitle: err?.responseBody?.error?.globalErrors?.[0]?.message ?? err.message,
          kind: 'error',
        });
      })
      .finally(() => {
        setIsSubmitting(false);
        wardPatientGroupDetails?.mutate?.();
      });
  }, [createEncounter, wardPatient, emrConfiguration, t, closeWorkspace, wardPatientGroupDetails]);

  if (!wardPatientGroupDetails) {
    return null;
  }

  return (
    <Workspace2 title={t('discharge', 'Discharge')}>
      <div className={styles.workspaceContent}>
        <div className={styles.patientWorkspaceBanner}>
          <WardPatientWorkspaceBanner wardPatient={wardPatient} />
        </div>
        <div className={styles.workspaceForm}>
          <div>
            {errorFetchingEmrConfiguration && (
              <div className={styles.formError}>
                <InlineNotification
                  kind="error"
                  title={t('somePartsOfTheFormDidntLoad', "Some parts of the form didn't load")}
                  subtitle={t(
                    'fetchingEmrConfigurationFailed',
                    'Fetching EMR configuration failed. Try refreshing the page or contact your system administrator.',
                  )}
                  lowContrast
                  hideCloseButton
                />
              </div>
            )}
          </div>
          <ExtensionSlot name="ward-patient-discharge-slot" />
          <div className={styles.buttonContainer}>
            <ButtonSet className={styles.buttonSet}>
              <Button
                size="sm"
                kind="ghost"
                onClick={() => setActiveFormType((prev) => (prev === 'general' ? null : 'general'))}>
                {activeFormType === 'general'
                  ? t('hideDischargeNote', 'Hide discharge note')
                  : formMode === 'add'
                    ? t('addDischargeNote', 'Add discharge note')
                    : t('editDischargeNote', 'Edit discharge note')}
              </Button>
              {wardPatient?.patient?.person?.gender === 'F' && (
                <Button
                  size="sm"
                  kind="ghost"
                  onClick={() => setActiveFormType((prev) => (prev === 'maternal' ? null : 'maternal'))}>
                  {activeFormType === 'maternal'
                    ? t('hideMaternalDischargeNote', 'Hide maternal discharge note')
                    : maternalFormMode === 'add'
                      ? t('addMaternalDischargeNote', 'Add maternal discharge note')
                      : t('editMaternalDischargeNote', 'Edit maternal discharge note')}
                </Button>
              )}
            </ButtonSet>
            <ButtonSet className={styles.buttonSet}>
              <Button
                size="sm"
                kind="ghost"
                renderIcon={(props) => <Exit size={16} {...props} />}
                disabled={
                  isLoadingEmrConfiguration || isSubmitting || errorFetchingEmrConfiguration || !wardPatient?.patient
                }
                onClick={submitDischarge}>
                {t('proceedWithPatientDischarge', 'Proceed with patient discharge')}
              </Button>
            </ButtonSet>
          </div>

          {/* Discharge Note Form - rendered via form-widget-slot */}
          {activeFormType && wardPatient?.patient?.uuid && fhirPatient && (
            <div className={styles.formContainer}>
              <ExtensionSlot
                name="form-widget-slot"
                state={{
                  view: 'form',
                  formUuid: activeFormType === 'general' ? dischargeNoteFormUuid : maternalDischargeNoteFormUuid,
                  visitUuid: wardPatient?.visit?.uuid ?? '',
                  patientUuid: wardPatient.patient.uuid,
                  patient: fhirPatient,
                  encounterUuid: activeFormType === 'general' ? encounterUuid : maternalEncounterUuid,
                  additionalProps: {
                    mode: activeFormType === 'general' ? formMode : maternalFormMode,
                  },
                  closeWorkspace: () => setActiveFormType(null),
                  handlePostResponse,
                  showDiscardSubmitButtons: false,
                  hideControls: false,
                }}
              />
            </div>
          )}
        </div>
      </div>
    </Workspace2>
  );
}
