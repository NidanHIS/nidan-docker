import React from 'react';
import { useTranslation } from 'react-i18next';
import { Tag, SkeletonText } from '@carbon/react';
import classNames from 'classnames';
import { useVisitDiagnosesAndTreatments } from '../../hooks/useVisitDiagnosesAndTreatments';
import styles from './diagnoses-treatments-summary.scss';

interface DiagnosesAndTreatmentsSummaryProps {
  patientUuid: string;
  visitUuid?: string;
}

const DiagnosesAndTreatmentsSummary: React.FC<DiagnosesAndTreatmentsSummaryProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { diagnoses, activeMedications, stoppedMedications, isLoading, error } = useVisitDiagnosesAndTreatments(
    patientUuid,
    visitUuid,
  );

  if (error) {
    return (
      <div className={styles.summaryContainer}>
        <p className={styles.errorText}>{t('errorLoadingDiagnoses', 'Failed to load diagnoses and treatments.')}</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className={styles.summaryContainer}>
        <SkeletonText width="30%" />
        <SkeletonText width="50%" />
        <SkeletonText width="40%" />
      </div>
    );
  }

  return (
    <div className={styles.summaryContainer}>
      <div className={styles.section}>
        <p className={styles.sectionLabel}><strong>{t('diagnoses', 'Diagnoses')}</strong></p>
        <div className={styles.diagnosesList}>
          {diagnoses && diagnoses.length > 0 ? (
            diagnoses.map((diagnosis, i) => (
              <Tag key={i} type={diagnosis.order === 'Primary' ? 'blue' : 'red'}>
                {diagnosis.diagnosis}
              </Tag>
            ))
          ) : (
            <p className={classNames(styles.bodyLong01, styles.emptyText)}>
              {t('noDiagnosesFound', 'No diagnoses found')}
            </p>
          )}
        </div>
      </div>

      <div className={styles.section}>
        <p className={styles.sectionLabel}>
          <strong>{t('treatments', 'Treatments (Medications)')}</strong>
        </p>
        <div className={styles.medicationsList}>
          {activeMedications && activeMedications.length > 0 && (
            <>
              <p className={styles.subSectionLabel}>{t('activeMedications', 'Active')}</p>
              <ul className={styles.list}>
                {activeMedications.map((medication, i) => (
                  <li key={i} className={styles.listItem}>
                    {medication.order.drug?.display || medication.order.concept?.display} - {medication.order.dose}{' '}
                    {medication.order.doseUnits?.display} {medication.order.frequency?.display}
                    {medication.order.asNeeded && (
                      <Tag type="warm-gray" size="sm" className={styles.prnTag}>
                        {t('prn', 'PRN')}
                      </Tag>
                    )}
                  </li>
                ))}
              </ul>
            </>
          )}

          {stoppedMedications && stoppedMedications.length > 0 && (
            <>
              <p className={styles.subSectionLabel}>{t('stoppedMedications', 'Stopped')}</p>
              <ul className={styles.list}>
                {stoppedMedications.map((medication, i) => (
                  <li key={i} className={styles.listItem}>
                    <span className={styles.stoppedText}>
                      {medication.order.drug?.display || medication.order.concept?.display} - {medication.order.dose}{' '}
                      {medication.order.doseUnits?.display} {medication.order.frequency?.display}
                    </span>
                    {medication.order.asNeeded && (
                      <Tag type="warm-gray" size="sm" className={styles.prnTag}>
                        {t('prn', 'PRN')}
                      </Tag>
                    )}
                  </li>
                ))}
              </ul>
            </>
          )}

          {(!activeMedications || activeMedications.length === 0) &&
            (!stoppedMedications || stoppedMedications.length === 0) && (
              <p className={classNames(styles.bodyLong01, styles.emptyText)}>
                {t('noTreatmentsFound', 'No treatments found')}
              </p>
            )}
        </div>
      </div>
    </div>
  );
};

export default DiagnosesAndTreatmentsSummary;
