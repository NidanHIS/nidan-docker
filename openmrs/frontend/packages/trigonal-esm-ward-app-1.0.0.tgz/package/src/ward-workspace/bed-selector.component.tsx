import React from 'react';
import { Dropdown, InlineNotification, RadioButton, RadioButtonGroup, RadioButtonSkeleton } from '@carbon/react';
import { type Control, type FieldError } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { type Patient } from '@openmrs/esm-framework';
import { type BedLayout } from '../types';
import useWardLocation from '../hooks/useWardLocation';
import styles from './bed-selector.scss';
import classNames from 'classnames';

interface BedSelectorProps {
  beds: BedLayout[];
  isLoadingBeds: boolean;
  currentPatient: Patient;
  selectedBedId: number;
  error: FieldError;
  onChange(bedId: number): void;
  control: Control<{ bedId?: number }>;
  minBedCountToUseDropdown?: number;
}

interface BedDropdownItem {
  bedId: number;
  label: string;
  disabled: boolean;
  row?: number;
  column?: number;
  isCurrentPatientBed?: boolean;
  isOccupiedByOther?: boolean;
}

const BedSelector: React.FC<BedSelectorProps> = ({
  selectedBedId,
  beds,
  isLoadingBeds,
  error,
  onChange,
  currentPatient,
  control,
  minBedCountToUseDropdown = 32, // Increase default to favor grid view
}) => {
  const { location } = useWardLocation();
  const { t } = useTranslation();

  const getBedRepresentation = (bedLayout: BedLayout) => {
    return bedLayout.bedNumber;
  };

  const bedDropdownItems: BedDropdownItem[] = [
    { bedId: 0, label: t('noBed', 'No bed'), disabled: false, row: 0, column: 0 },
    ...beds.map((bed) => {
      const isCurrentPatientBed = bed.patients.some((bedPatient) => bedPatient.uuid === currentPatient.uuid);
      const isOccupiedByOther = bed.patients.length > 0 && !isCurrentPatientBed;
      return {
        bedId: bed.bedId,
        label: getBedRepresentation(bed),
        disabled: isCurrentPatientBed, // Disable only current bed
        row: bed.rowNumber + 1,
        column: bed.columnNumber,
        isCurrentPatientBed,
        isOccupiedByOther,
      };
    }),
  ];
  const selectedItem = bedDropdownItems.find((bed) => bed.bedId === selectedBedId);

  const useDropdown = beds.length >= minBedCountToUseDropdown;

  if (isLoadingBeds) {
    return (
      <RadioButtonGroup className={styles.radioButtonGroup} name="bedId" value={selectedBedId}>
        <RadioButtonSkeleton />
        <RadioButtonSkeleton />
        <RadioButtonSkeleton />
      </RadioButtonGroup>
    );
  }
  if (!beds.length) {
    return (
      <InlineNotification
        kind="error"
        title={t('noBedsConfiguredForLocation', 'No beds configured for {{location}} location', {
          location: location?.display,
        })}
        lowContrast
        hideCloseButton
      />
    );
  }
  if (useDropdown) {
    return (
      <Dropdown
        id="default"
        titleText=""
        helperText=""
        label={!selectedItem && t('chooseAnOption', 'Choose an option')}
        items={bedDropdownItems}
        itemToString={(bedDropdownItem: BedDropdownItem) => bedDropdownItem.label}
        selectedItem={selectedItem}
        onChange={(data) => {
          const selectedDropdownItem = data.selectedItem as BedDropdownItem;
          if (selectedDropdownItem) {
            onChange(selectedDropdownItem.bedId);
          }
        }}
        invalid={!!error}
        invalidText={error?.message}
      />
    );
  } else {
    return (
      <div className={styles.scrollContainer}>
        <div className={styles.bedTileGrid} role="radiogroup" aria-label={t('selectBed', 'Select a bed')}>
          {bedDropdownItems.map(({ bedId, label, disabled, row, column, isCurrentPatientBed, isOccupiedByOther }) => (
            <button
              type="button"
              key={bedId}
              disabled={disabled}
              onClick={() => onChange(bedId)}
              className={classNames(styles.bedTile, {
                [styles.selected]: bedId === selectedBedId,
                [styles.occupied]: isOccupiedByOther,
                [styles.currentBed]: isCurrentPatientBed,
                [styles.noBed]: bedId === 0,
              })}
              style={{
                '--grid-row': row + 1,
                '--grid-column': column + 1,
              } as React.CSSProperties}
              aria-checked={bedId === selectedBedId}
              role="radio">
              <span className={styles.bedNumber}>{label}</span>
              {isOccupiedByOther && <span className={styles.statusLabel}>{t('occupied', 'Occupied')}</span>}
              {isCurrentPatientBed && <span className={styles.statusLabel}>{t('current', 'Current')}</span>}
              {bedId === 0 && !disabled && !isCurrentPatientBed && (
                <span className={styles.statusLabel}>{t('unassigned', 'Unassigned')}</span>
              )}
            </button>
          ))}
        </div>
        {!!error && <p className={styles.errorMessage}>{error.message}</p>}
      </div>
    );
  }
};

export default BedSelector;
