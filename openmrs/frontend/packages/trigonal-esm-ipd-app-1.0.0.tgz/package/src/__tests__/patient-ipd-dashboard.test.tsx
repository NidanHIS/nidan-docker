import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { useConfig, usePatient, useVisit, launchWorkspace2 } from '@openmrs/esm-framework';
import PatientIpdDashboard from '../features/patient-ipd/patient-ipd-dashboard.component';
import { useMedicationSchedule, useNursingTasks, usePatientAllergies, usePatientBed } from '../features/patient-ipd/use-ipd-patient';

import userEvent from '@testing-library/user-event';

/** ─── Mocks ─────────────────────────────────────────────────────────────── */
jest.mock('@openmrs/esm-framework', () => ({
  ...jest.requireActual('@openmrs/esm-framework/mock'),
  useConfig: jest.fn(),
  usePatient: jest.fn(),
  useVisit: jest.fn(),
  launchWorkspace2: jest.fn(),
  ExtensionSlot: ({ name }: { name: string }) => (
    <div data-testid={`extension-slot-${name}`} />
  ),
  useExtensionSlotMeta: jest.fn().mockReturnValue({}),
}));

jest.mock('../features/patient-ipd/use-ipd-patient', () => ({
  useMedicationSchedule: jest.fn(),
  useNursingTasks: jest.fn(),
  usePatientAllergies: jest.fn(),
  usePatientBed: jest.fn(),
}));

/** ─── Fixtures ──────────────────────────────────────────────────────────── */
const PATIENT_UUID = 'test-patient-uuid';
const VISIT_UUID = 'test-visit-uuid';

const mockPatient = {
  uuid: PATIENT_UUID,
  display: 'Jane Smith',
  person: { display: 'Jane Smith', age: 32, gender: 'F' },
  identifiers: [{ preferred: true, identifier: 'IPD-002', identifierType: { uuid: 't', display: 'ID' } }],
};

const mockVisit = {
  uuid: VISIT_UUID,
  visitType: { uuid: 'vt', display: 'IPD Visit' },
  startDatetime: '2026-03-01T08:00:00',
  location: { uuid: 'loc', display: 'Ward A' },
};

const mockConfig = {
  admissionLocationTagUuid: 'tag',
  admissionEncounterTypeUuid: 'adm',
  dischargeEncounterTypeUuid: 'dis',
  showMedicationChart: true,
  showNursingTasks: true,
  ipdDashboardSections: [
    { componentKey: 'AL', title: 'Allergies', displayOrder: 1 },
    { componentKey: 'VT', title: 'Vitals', displayOrder: 2 },
    { componentKey: 'NT', title: 'Nursing Tasks', displayOrder: 3 },
    { componentKey: 'DC', title: 'Drug Chart', displayOrder: 4 },
  ],
  patientSearchMinChars: 3,
};

function renderDashboard() {
  return render(
    <MemoryRouter initialEntries={[`/patient/${PATIENT_UUID}/chart/ipd-summary`]}>
      <Routes>
        <Route path="/patient/:patientUuid/chart/ipd-summary" element={<PatientIpdDashboard />} />
      </Routes>
    </MemoryRouter>,
  );
}

/** ─── Tests ─────────────────────────────────────────────────────────────── */
describe('PatientIpdDashboard', () => {
  beforeEach(() => {
    (useConfig as jest.Mock).mockReturnValue(mockConfig);
    (usePatient as jest.Mock).mockReturnValue({ patient: mockPatient, isLoading: false });
    (useVisit as jest.Mock).mockReturnValue({ currentVisit: mockVisit, isLoading: false });
    (useMedicationSchedule as jest.Mock).mockReturnValue({
      medicationSchedules: [],
      isLoading: false,
      mutate: jest.fn(),
    });
    (useNursingTasks as jest.Mock).mockReturnValue({ tasks: [], isLoading: false, mutate: jest.fn() });
    (usePatientAllergies as jest.Mock).mockReturnValue({ allergies: [], isLoading: false, error: null });
    (usePatientBed as jest.Mock).mockReturnValue({ bed: { uuid: 'bed-1' }, isLoading: false });
  });


  afterEach(() => jest.clearAllMocks());

  it('renders all configured accordion sections', () => {
    renderDashboard();

    expect(screen.getByText('Allergies')).toBeInTheDocument();
    expect(screen.getByText('Vitals')).toBeInTheDocument();
    expect(screen.getByText('Nursing Tasks')).toBeInTheDocument();
    expect(screen.getByText('Drug Chart')).toBeInTheDocument();
  });

  it('renders the bed assignment banner extension slot', () => {
    renderDashboard();
    expect(screen.getByTestId('extension-slot-patient-ipd-banner-slot')).toBeInTheDocument();
  });

  it('renders vitals section as an ExtensionSlot', () => {
    renderDashboard();
    expect(screen.getByTestId('extension-slot-ipd-VT-slot')).toBeInTheDocument();
  });

  it('shows skeleton while patient, visit or bed is loading', () => {
    (usePatient as jest.Mock).mockReturnValue({ patient: null, isLoading: true });

    const { container } = renderDashboard();

    expect(container.querySelector('.cds--skeleton')).toBeInTheDocument();
  });

  it('shows error notification when patient is not found', () => {
    (usePatient as jest.Mock).mockReturnValue({ patient: null, isLoading: false });
    renderDashboard();

    expect(screen.getByText('Patient not found')).toBeInTheDocument();
  });

  it('shows warning when there is no active visit', () => {
    (useVisit as jest.Mock).mockReturnValue({ currentVisit: null, isLoading: false });
    renderDashboard();

    expect(screen.getByText('No active visit')).toBeInTheDocument();
  });

  it('shows "No allergies recorded" when allergy list is empty', () => {
    renderDashboard();
    expect(screen.getByText('No allergies recorded')).toBeInTheDocument();
  });

  it('shows "No active nursing tasks" when task list is empty', () => {
    renderDashboard();
    expect(screen.getByText('No active nursing tasks')).toBeInTheDocument();
  });

  it('shows "No medications scheduled" when drug chart is empty', () => {
    renderDashboard();
    expect(screen.getByText('No medications scheduled')).toBeInTheDocument();
  });

  it('renders nursing tasks when tasks are present', () => {
    (useNursingTasks as jest.Mock).mockReturnValue({
      tasks: [
        {
          uuid: 'task-1',
          name: 'Turn patient q2h',
          status: 'REQUESTED',
          description: '',
          intent: 'order',
          patient: { uuid: PATIENT_UUID },
        },
      ],
      isLoading: false,
      mutate: jest.fn(),
    });

    renderDashboard();
    expect(screen.getByText('Turn patient q2h')).toBeInTheDocument();
  });

  it('renders drug chart date navigator when schedules are present', () => {
    (useMedicationSchedule as jest.Mock).mockReturnValue({
      medicationSchedules: [
        {
          uuid: 'med-1',
          drug: { uuid: 'd1', name: 'Paracetamol', display: 'Paracetamol' },
          dose: 500,
          doseUnits: { uuid: 'mg', display: 'mg' },
          frequency: { uuid: 'bd', display: 'Twice daily' },
          route: { uuid: 'oral', display: 'Oral' },
          startDate: '2026-03-01',
          slots: [],
        },
      ],
      isLoading: false,
      mutate: jest.fn(),
    });

    renderDashboard();
    expect(screen.getByRole('button', { name: 'Previous day' })).toBeInTheDocument();
    expect(screen.getByText('Paracetamol')).toBeInTheDocument();
  });

  it('launches the add-medication workspace when clicking Add Medication', async () => {
    const user = userEvent.setup();
    renderDashboard();

    await user.click(screen.getByText('Add Medication'));

    expect(launchWorkspace2).toHaveBeenCalledWith('add-ipd-medication', {});
  });

  it('hides Drug Chart when showMedicationChart is false', () => {
    (useConfig as jest.Mock).mockReturnValue({ ...mockConfig, showMedicationChart: false });
    renderDashboard();

    expect(screen.queryByText('Drug Chart')).not.toBeInTheDocument();
  });

  it('hides Nursing Tasks when showNursingTasks is false', () => {
    (useConfig as jest.Mock).mockReturnValue({ ...mockConfig, showNursingTasks: false });
    renderDashboard();

    expect(screen.queryByText('Nursing Tasks')).not.toBeInTheDocument();
  });

  it('renders sections in config-defined displayOrder', () => {
    renderDashboard();

    const headings = screen
      .getAllByRole('button')
      .filter((b) => ['Allergies', 'Vitals', 'Nursing Tasks', 'Drug Chart'].includes(b.textContent ?? ''))
      .map((b) => b.textContent);

    expect(headings).toEqual(['Allergies', 'Vitals', 'Nursing Tasks', 'Drug Chart']);
  });
});