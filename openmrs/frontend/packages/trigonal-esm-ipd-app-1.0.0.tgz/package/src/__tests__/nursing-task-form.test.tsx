import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { closeWorkspace, showSnackbar } from '@openmrs/esm-framework';
import NursingTaskFormWorkspace from '../features/nursing-tasks/nursing-task-form.workspace';
import * as resource from '../features/nursing-tasks/nursing-tasks-resource';

jest.mock('@openmrs/esm-framework', () => ({
  ...jest.requireActual('@openmrs/esm-framework/mock'),
  closeWorkspace: jest.fn(),
  showSnackbar: jest.fn(),
}));

jest.mock('../features/nursing-tasks/nursing-tasks-resource', () => ({
  createNursingTask: jest.fn(),
}));

const defaultProps = {
  groupProps: {
    patient: { id: 'p-uuid' },
    visitContext: { uuid: 'v-uuid' },
  },
  workspaceProps: {
    mutateTaskList: jest.fn(),
  },
  closeWorkspace: jest.fn(),
};

describe('NursingTaskFormWorkspace', () => {
  beforeEach(() => jest.clearAllMocks());

  it('renders all form fields', () => {
    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    expect(screen.getByLabelText('Task Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Description')).toBeInTheDocument();
    expect(screen.getByText('Priority')).toBeInTheDocument();
    expect(screen.getByLabelText('Due Date')).toBeInTheDocument();
  });

  it('shows validation error when task name is empty', async () => {
    const user = userEvent.setup();
    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.click(screen.getByRole('button', { name: 'Save Task' }));

    await waitFor(() => {
      expect(screen.getByText(/task name is required/i)).toBeInTheDocument();
    });
  });

  it('shows validation error when task name is too short', async () => {
    const user = userEvent.setup();
    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.type(screen.getByLabelText('Task Name'), 'AB');
    await user.click(screen.getByRole('button', { name: 'Save Task' }));

    await waitFor(() => {
      expect(
        screen.getByText(/task name must be at least 3 characters/i),
      ).toBeInTheDocument();
    });
  });

  it('submits the form with valid data', async () => {
    const user = userEvent.setup();
    (resource.createNursingTask as jest.Mock).mockResolvedValueOnce({ uuid: 'new-task' });

    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.type(screen.getByLabelText('Task Name'), 'Turn patient q2h');
    await user.click(screen.getByRole('button', { name: 'Save Task' }));

    await waitFor(() => {
      expect(resource.createNursingTask).toHaveBeenCalledWith(
        expect.objectContaining({
          name: 'Turn patient q2h',
          status: 'REQUESTED',
          patient: { uuid: 'p-uuid' },
        }),
      );
    });

    expect(showSnackbar).toHaveBeenCalledWith(
      expect.objectContaining({ kind: 'success' }),
    );
    expect(defaultProps.workspaceProps.mutateTaskList).toHaveBeenCalledTimes(1);
    expect(defaultProps.closeWorkspace).toHaveBeenCalled();
  });

  it('shows error snackbar when submission fails', async () => {
    const user = userEvent.setup();
    (resource.createNursingTask as jest.Mock).mockRejectedValueOnce(
      new Error('Server error'),
    );

    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.type(screen.getByLabelText('Task Name'), 'Administer oxygen');
    await user.click(screen.getByRole('button', { name: 'Save Task' }));

    await waitFor(() => {
      expect(showSnackbar).toHaveBeenCalledWith(
        expect.objectContaining({ kind: 'error', subtitle: 'Server error' }),
      );
    });
  });

  it('closes workspace when Cancel is clicked', async () => {
    const user = userEvent.setup();
    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(defaultProps.closeWorkspace).toHaveBeenCalled();
  });

  it('selects Urgent priority correctly', async () => {
    const user = userEvent.setup();
    render(<NursingTaskFormWorkspace {...(defaultProps as any)} />);

    await user.click(screen.getByLabelText('Urgent'));
    await user.type(screen.getByLabelText('Task Name'), 'Urgent task');
    (resource.createNursingTask as jest.Mock).mockResolvedValueOnce({ uuid: 'new-task' });
    await user.click(screen.getByRole('button', { name: 'Save Task' }));

    await waitFor(() => {
      expect(resource.createNursingTask).toHaveBeenCalledWith(
        expect.objectContaining({ priority: 'urgent' }),
      );
    });
  });
});
