import { publishAuditEvent, IPD_AUDIT_EVENT_TOPIC, type IpdAuditEventPayload } from '../utils/audit-event';

describe('publishAuditEvent', () => {
  let dispatchSpy: jest.SpyInstance;

  beforeEach(() => {
    dispatchSpy = jest.spyOn(window, 'dispatchEvent');
  });

  afterEach(() => {
    dispatchSpy.mockRestore();
  });

  const getLastPayload = (): IpdAuditEventPayload => {
    const event = dispatchSpy.mock.calls[0][0] as CustomEvent<IpdAuditEventPayload>;
    return event.detail;
  };

  it('dispatches a CustomEvent with the correct topic', () => {
    publishAuditEvent('TEST_EVENT', 'patient-uuid', 'visit-uuid');

    expect(dispatchSpy).toHaveBeenCalledTimes(1);
    const event = dispatchSpy.mock.calls[0][0] as CustomEvent;
    expect(event.type).toBe(IPD_AUDIT_EVENT_TOPIC);
  });

  it('includes eventType in the payload', () => {
    publishAuditEvent('TEST_EVENT', 'patient-uuid', 'visit-uuid');
    expect(getLastPayload()).toMatchObject({ eventType: 'TEST_EVENT' });
  });

  it('includes patientUuid and visitUuid in the payload', () => {
    publishAuditEvent('VIEWED_WARD', 'p-1', 'v-1');
    expect(getLastPayload()).toMatchObject({ patientUuid: 'p-1', visitUuid: 'v-1' });
  });

  it('includes a timestamp in the payload', () => {
    publishAuditEvent('VIEWED_WARD');
    const payload = getLastPayload();
    expect(payload).toHaveProperty('timestamp');
    expect(typeof payload.timestamp).toBe('string');
  });

  it('uses the default module label when none is provided', () => {
    publishAuditEvent('VIEWED_WARD');
    expect(getLastPayload()).toMatchObject({ moduleLabel: 'MODULE_LABEL_CLINICAL_KEY' });
  });

  it('uses a custom module label when provided', () => {
    publishAuditEvent('VIEWED_WARD', undefined, undefined, 'MODULE_LABEL_INPATIENT_KEY');
    expect(getLastPayload()).toMatchObject({ moduleLabel: 'MODULE_LABEL_INPATIENT_KEY' });
  });
});
