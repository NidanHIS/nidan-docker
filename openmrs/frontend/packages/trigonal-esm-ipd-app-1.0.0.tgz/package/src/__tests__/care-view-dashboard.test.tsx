import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useConfig, useSession } from '@openmrs/esm-framework';
import CareViewDashboard from '../features/care-view/care-view-dashboard.component';
import { useWards, useWardSummary, useAdmittedPatients } from '../features/care-view/use-ward-patients';

/** ─── Mock @openmrs/esm-framework ─────────────────────────────────────────── */
jest.mock('@openmrs/esm-framework', () => ({
  ...jest.requireActual('@openmrs/esm-framework/mock'),
  useConfig: jest.fn(),
  useSession: jest.fn(),
  ConfigurableLink: ({ children, to }: { children: React.ReactNode; to: string }) => (
    <a href={to}>{children}</a>
  ),
}));

/** ─── Mock SWR hooks ────────────────────────────────────────────────────── */
jest.mock('../features/care-view/use-ward-patients', () => ({
  useWards: jest.fn(),
  useWardSummary: jest.fn(),
  useAdmittedPatients: jest.fn(),
}));

/** ─── Fixtures ──────────────────────────────────────────────────────────── */
const mockWards = [
  { uuid: 'ward-1', display: 'Medical Ward' },
  { uuid: 'ward-2', display: 'Surgical Ward' },
];

const mockPatients = [
  {
    patient: {
      uuid: 'patient-1',
      display: 'John Doe',
      person: { display: 'John Doe', age: 45, gender: 'M' },
      identifiers: [{ preferred: true, identifier: 'IPD-001', identifierType: { uuid: 't1', display: 'ID' } }],
    },
    bed: { uuid: 'bed-1', bedNumber: '1A', bedType: { uuid: 'bt', display: 'Regular' }, status: 'OCCUPIED' as const, location: { uuid: 'l1', display: 'L1' } },
    visit: { uuid: 'v1', visitType: { uuid: 'vt', display: 'IPD' }, startDatetime: '2026-03-01T08:00:00', location: { uuid: 'l1', display: 'L1' } },
    currentAdmission: null,
  },
];

const mockConfig = {
  admissionLocationTagUuid: 'tag-uuid',
  admissionEncounterTypeUuid: 'admission-uuid',
  dischargeEncounterTypeUuid: 'discharge-uuid',
  showMedicationChart: true,
  showNursingTasks: true,
  ipdDashboardSections: [],
  patientSearchMinChars: 3,
};

/** ─── Tests ─────────────────────────────────────────────────────────────── */
describe('CareViewDashboard', () => {
  beforeEach(() => {
    (useConfig as jest.Mock).mockReturnValue(mockConfig);
    (useSession as jest.Mock).mockReturnValue({ user: { uuid: 'provider-1', display: 'Dr. Test' } });
    (useWards as jest.Mock).mockReturnValue({ wards: mockWards, isLoading: false, error: null });
    (useWardSummary as jest.Mock).mockReturnValue({
      summary: { totalPatients: 10, myPatients: 3 },
      isLoading: false,
      error: null,
    });
    (useAdmittedPatients as jest.Mock).mockReturnValue({
      patients: mockPatients,
      isLoading: false,
      error: null,
    });
  });

  afterEach(() => jest.clearAllMocks());

  it('renders the ward selector with all wards', () => {
    render(<CareViewDashboard />);

    expect(screen.getByText('Select Ward')).toBeInTheDocument();
    expect(screen.getByText('Medical Ward')).toBeInTheDocument();
    expect(screen.getByText('Surgical Ward')).toBeInTheDocument();
  });

  it('shows a loading skeleton while wards are loading', () => {
    (useWards as jest.Mock).mockReturnValue({ wards: [], isLoading: true, error: null });
    const { container } = render(<CareViewDashboard />);

    expect(container.querySelector('.cds--skeleton')).toBeInTheDocument();
  });

  it('shows an error notification when wards fail to load', () => {
    (useWards as jest.Mock).mockReturnValue({
      wards: [],
      isLoading: false,
      error: new Error('Network error'),
    });

    render(<CareViewDashboard />);

    expect(screen.getByText('Failed to load wards')).toBeInTheDocument();
  });

  it('shows summary tiles when a ward is selected', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));

    expect(screen.getByText('Total Patients')).toBeInTheDocument();
    expect(screen.getByText('My Patients')).toBeInTheDocument();
    expect(screen.getByText('10')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
  });

  it('renders admitted patient rows in the table after ward selection', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));

    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('IPD-001')).toBeInTheDocument();
    expect(screen.getByText('1A')).toBeInTheDocument();
  });

  it('renders "View IPD" action button for each patient', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));

    expect(screen.getByText('View IPD')).toBeInTheDocument();
  });

  it('does not show patient table when no ward is selected', () => {
    render(<CareViewDashboard />);

    expect(screen.queryByText('View IPD')).not.toBeInTheDocument();
  });

  it('highlights the active ward chip', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    const medicalWardChip = screen.getByText('Medical Ward');
    await user.click(medicalWardChip);

    expect(medicalWardChip.closest('.cds--tag')).toHaveClass('cds--tag--blue');
  });

  it('shows search input after ward selection', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));

    expect(screen.getByRole('searchbox')).toBeInTheDocument();
  });

  it('does not trigger search below the minimum char threshold', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));
    await user.type(screen.getByRole('searchbox'), 'Jo');

    // useAdmittedPatients is called with empty searchQuery
    const lastCall = (useAdmittedPatients as jest.Mock).mock.calls.at(-1);
    expect(lastCall?.[2]).toBe('');
  });

  it('triggers search when query meets the minimum char threshold', async () => {
    const user = userEvent.setup();
    render(<CareViewDashboard />);

    await user.click(screen.getByText('Medical Ward'));
    await user.type(screen.getByRole('searchbox'), 'Joh');

    const lastCall = (useAdmittedPatients as jest.Mock).mock.calls.at(-1);
    expect(lastCall?.[2]).toBe('Joh');
  });
});
