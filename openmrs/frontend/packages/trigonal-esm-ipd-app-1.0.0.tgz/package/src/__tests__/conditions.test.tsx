import React from 'react';
import { render, screen } from '@testing-library/react';
import Conditions from '../features/conditions/conditions.component';
import { usePatientConditions } from '../features/conditions/use-patient-conditions';
import type { FhirCondition } from '../features/conditions/use-patient-conditions';

jest.mock('@openmrs/esm-framework', () => ({
  formatDate: jest.fn(() => 'Jun 23, 2026'),
  parseDate: jest.fn((value: string) => value),
}));

jest.mock('../features/conditions/use-patient-conditions', () => ({
  usePatientConditions: jest.fn(),
}));

const mockCondition: FhirCondition = {
  id: 'condition-1',
  resourceType: 'Condition',
  clinicalStatus: {
    coding: [{ code: 'active' }],
  },
  category: [
    {
      coding: [{ code: 'problem-list-item', display: 'Problem List Item' }],
    },
  ],
  code: {
    coding: [
      {
        code: 'e6358fa4-b095-4fc5-b7d7-408b03146924',
        display: '6A21.1Z - Schizoaffective disorder, multiple episodes, unspecified',
      },
    ],
    text: '6A21.1Z - Schizoaffective disorder, multiple episodes, unspecified',
  },
  subject: { reference: 'Patient/p-uuid', display: 'Ram R (OpenMRS ID: PAT-000001)' },
  onsetDateTime: '2026-06-23T18:15:00+00:00',
  recordedDate: '2026-07-02T11:20:18+00:00',
  recorder: { reference: 'Practitioner/82f18b44-6814-11e8-923f-e9a88dcb533f', display: 'Super User' },
};

describe('Conditions', () => {
  afterEach(() => jest.clearAllMocks());

  it('shows skeleton while loading', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [],
      isLoading: true,
      error: null,
    });

    const { container } = render(<Conditions patientUuid="p-uuid" />);
    expect(container.querySelector('.cds--skeleton')).toBeInTheDocument();
  });

  it('shows error notification on load failure', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [],
      isLoading: false,
      error: new Error('FHIR error'),
    });

    render(<Conditions patientUuid="p-uuid" />);
    expect(screen.getByText('Failed to load conditions')).toBeInTheDocument();
  });

  it('shows empty state when no conditions', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [],
      isLoading: false,
      error: null,
    });

    render(<Conditions patientUuid="p-uuid" />);
    expect(screen.getByText('No conditions recorded')).toBeInTheDocument();
  });

  it('renders condition name in the table', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [mockCondition],
      isLoading: false,
      error: null,
    });

    render(<Conditions patientUuid="p-uuid" />);
    expect(
      screen.getByText('6A21.1Z - Schizoaffective disorder, multiple episodes, unspecified'),
    ).toBeInTheDocument();
  });

  it('renders clinical status tag', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [mockCondition],
      isLoading: false,
      error: null,
    });

    render(<Conditions patientUuid="p-uuid" />);
    expect(screen.getByText('active')).toBeInTheDocument();
  });

  it('renders recorder name', () => {
    (usePatientConditions as jest.Mock).mockReturnValue({
      conditions: [mockCondition],
      isLoading: false,
      error: null,
    });

    render(<Conditions patientUuid="p-uuid" />);
    expect(screen.getByText('Super User')).toBeInTheDocument();
  });
});
