import { type DashboardLinkConfig } from '@openmrs/esm-patient-common-lib';

export const dashboardMeta: DashboardLinkConfig & { slot: string } = {
  slot: 'patient-chart-ipd-dashboard-slot',
  path: 'ipd-summary',
  title: 'IPD Summary',
  icon: 'omrs-icon-hospital-bed',
};

export const homeDashboardMeta = {
  path: 'ipd',
  slot: 'ward-dashboard-slot',
  title: 'IPD',
  basePath: `${window.spaBase}/home`,
} as const;

export const notificationDashboardMeta = {
  path: 'notification',
  slot: 'notification-dashboard-slot',
  title: 'Notifications',
  basePath: `${window.spaBase}/home`,
} as const;

