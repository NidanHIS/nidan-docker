import React, { useState, useCallback } from 'react';
import useSWR from 'swr';
import {
  openmrsFetch,
  restBaseUrl,
  useSession,
  showSnackbar,
  navigate
} from '@openmrs/esm-framework';
import {
  Button,
  TextArea,
  Stack,
  InlineLoading,
  InlineNotification,
  Accordion,
  AccordionItem,
  DataTableSkeleton,
} from '@carbon/react';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { groupBy } from 'lodash-es';
import { acknowledgeNursingTask } from './features/nursing-tasks/nursing-tasks-resource';
import { resolveDisplayName } from './features/nursing-tasks/nursing-tasks.utils';
import styles from './notification.component.scss';

interface AcknowledgementItem {
  identifier: string;
  name: string;
  gender: string;
  patient_uuid: string;
  date_of_birth: number;
  medication_administration_uuid: string;
  administered_date_time: number;
  administered_drug_name: string;
  administered_dose: number;
  administered_dose_units: string;
  administered_route: string;
  performer: {
    medication_administration_performer_uuid: string;
    provider_uuid: string;
    display: string;
  };
  visit_uuid: string;
}

// const MOCK_DATA: AcknowledgementItem[] = [
//   {
//     identifier: 'PAT-000009',
//     name: 'Mario M',
//     gender: 'M',
//     patient_uuid: '0adc5a1e-95fb-4aa1-8621-a9b9886258bd',
//     date_of_birth: 1081987200000,
//     medication_administration_uuid: '48908571-6ac8-42e0-adbd-d5c41f88fae4',
//     administered_date_time: 1776246840000,
//     administered_drug_name: 'Paracetamol- 500 mg (FREE)',
//     administered_dose: 1.0,
//     administered_dose_units: 'Tablet',
//     administered_route: 'Oral',
//     performer: {
//       medication_administration_performer_uuid: 'cc5d2df6-8d5d-4a60-9d27-a631a308cee1',
//       provider_uuid: 'c3d1108f-ffc2-4de8-89a7-e3b2d1c87381',
//       display: 'Neha Anand',
//     },
//     visit_uuid: '00dfe5cf-664c-45fc-88b1-5d15959ebd3d',
//   },
// ];

const PatientTasksAccordionItem: React.FC<{
  patient: any;
  handlePatientClick: (uuid: string) => void;
  notes: { [key: string]: string };
  setNotes: React.Dispatch<React.SetStateAction<{ [key: string]: string }>>;
  submitting: { [key: string]: boolean };
  setSubmitting: React.Dispatch<React.SetStateAction<{ [key: string]: boolean }>>;
  calculateExactAge: (dob: number) => string;
  formatGender: (gender: string) => string;
}> = ({
  patient,
  handlePatientClick,
  notes,
  setNotes,
  submitting,
  setSubmitting,
  calculateExactAge,
  formatGender,
}) => {
    const { t } = useTranslation();
    const patientUuid = patient.patient.uuid;
    const {
      data: taskData,
      isLoading,
      mutate,
    } = useSWR<any>(
      patientUuid ? `${restBaseUrl}/ipd/tasks?status=COMPLETED&patient=${patientUuid}` : null,
      openmrsFetch,
    );

    const tasks = taskData?.data?.results || [];

    const handleAcknowledgeTask = useCallback(
      async (taskUuid: string) => {
        setSubmitting((prev) => ({ ...prev, [taskUuid]: true }));
        try {
          const noteText = notes[taskUuid] || 'Acknowledged';
          await acknowledgeNursingTask(taskUuid, noteText);
          showSnackbar({
            title: 'Task Acknowledged',
            kind: 'success',
          });
          mutate();
        } catch (err) {
          showSnackbar({
            title: 'Failed to acknowledge task',
            subtitle: err instanceof Error ? err.message : String(err),
            kind: 'error',
          });
        } finally {
          setSubmitting((prev) => ({ ...prev, [taskUuid]: false }));
        }
      },
      [notes, mutate, setSubmitting],
    );

    if (isLoading) {
      return (
        <AccordionItem title={patient.patient.display} disabled>
          <InlineLoading description="Loading tasks..." />
        </AccordionItem>
      );
    }

    if (tasks.length === 0) {
      return null;
    }

    const p = patient.patient;
    const dob = p.person?.birthdate ? new Date(p.person.birthdate).getTime() : 0;

    const patientTitle = (
      <div className={styles.titleContent}>
        <span
          className={styles.patientLink}
          onClick={(e) => {
            e.stopPropagation();
            handlePatientClick(patientUuid);
          }}
        >
          {p.display}
        </span>
        <span className={styles.patientMeta}>
          {formatGender(p.person?.gender)}, {calculateExactAge(dob)}
          <span className={styles.pendingCount}> ({tasks.length} tasks)</span>
        </span>
      </div>
    );

    return (
      <AccordionItem key={patientUuid} title={patientTitle}>
        <div className={styles.patientMedicationsList}>
          {tasks.map((task: any) => (
            <div key={task.uuid} className={styles.medicationBlock}>
              <div className={styles.notificationItemContent}>
                <div className={styles.detailsRow}>
                  <div className={styles.dateInfo}>
                    {task.executionPeriod?.start
                      ? dayjs(task.executionPeriod.start).format('DD/MM/YYYY HH:mm')
                      : 'N/A'}
                  </div>
                  <div className={styles.drugName}>{resolveDisplayName(task.name)}</div>
                </div>

                <div className={styles.noteField}>
                  <TextArea
                    id={`notes-${task.uuid}`}
                    labelText="Note"
                    placeholder="Enter Acknowledgment Notes"
                    value={notes[task.uuid] || ''}
                    onChange={(e) => setNotes((prev) => ({ ...prev, [task.uuid]: e.target.value }))}
                    rows={2}
                  />
                </div>

                <div className={styles.actions}>
                  <Button
                    size="sm"
                    onClick={() => handleAcknowledgeTask(task.uuid)}
                    disabled={submitting[task.uuid]}
                  >
                    {submitting[task.uuid] ? (
                      <InlineLoading description="Acknowledging..." />
                    ) : (
                      'Acknowledge'
                    )}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </AccordionItem>
    );
  };

const NotificationComponent: React.FC = () => {
  const session = useSession();
  const providerUuid = session?.currentProvider?.uuid || '';
  const {
    data,
    error,
    isLoading: medsLoading,
    mutate,
  } = useSWR<AcknowledgementItem[]>(
    providerUuid
      ? `${restBaseUrl}/ipd/emergencyMedicationsToAcknowledge?provider_uuid=${providerUuid}`
      : null,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );

  const [activeTab, setActiveTab] = useState<'meds' | 'tasks'>('meds');

  const { data: admissionsData, isLoading: admissionsLoading } = useSWR<any>(
    activeTab === 'tasks'
      ? `${restBaseUrl}/emrapi/inpatient/admission?v=custom:(patient:(uuid,display,person:(gender,age,birthdate,preferredName)))`
      : null,
    openmrsFetch,
  );

  const [notes, setNotes] = useState<{ [key: string]: string }>({});
  const [submitting, setSubmitting] = useState<{ [key: string]: boolean }>({});

  const calculateExactAge = (dob: number) => {
    const birthDate = dayjs(dob);
    const now = dayjs();

    let tempDate = birthDate;
    const years = now.diff(tempDate, 'year');
    tempDate = tempDate.add(years, 'year');

    const months = now.diff(tempDate, 'month');
    tempDate = tempDate.add(months, 'month');

    const days = now.diff(tempDate, 'day');

    return `${years}y ${months}m ${days}d`;
  };

  const formatGender = (gender: string) => {
    switch (gender?.toUpperCase()) {
      case 'M':
        return 'Male';
      case 'F':
        return 'Female';
      default:
        return gender || '';
    }
  };

  const formatDate = (val: number) => {
    return dayjs(val).format('DD/MM/YYYY');
  };

  const handlePatientClick = useCallback(
    (patient_uuid: string) =>
      navigate({
        to: `${window.location.origin}${window.getOpenmrsSpaBase()}patient/${patient_uuid}/chart/ipd-summary`,
      }),
    [],
  );

  const handleAcknowledge = useCallback(
    async (item: AcknowledgementItem) => {
      const uuid = item.medication_administration_uuid;
      setSubmitting((prev) => ({ ...prev, [uuid]: true }));

      try {
        const userUuid = session?.user?.uuid;
        const noteText = notes[uuid] || 'Acknowledge note';

        const payload = {
          providers: [
            {
              providerUuid: providerUuid,
              function: 'Verifier',
            },
          ],
          notes: [
            {
              authorUuid: providerUuid,
              text: noteText,
            },
          ],
        };

        await openmrsFetch(`${restBaseUrl}/ipd/adhocMedicationAdministrations/${uuid}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        showSnackbar({
          title: 'Acknowledgment Successful',
          kind: 'success',
        });

        mutate();
      } catch (err) {
        showSnackbar({
          title: 'Failed to acknowledge',
          subtitle: err instanceof Error ? err.message : String(err),
          kind: 'error',
        });
      } finally {
        setSubmitting((prev) => ({ ...prev, [uuid]: false }));
      }
    },
    [session, notes, mutate, providerUuid],
  );

  if (activeTab === 'meds' && medsLoading && !data) {
    return (
      <div className={styles.loading}>
        <DataTableSkeleton columnCount={1} rowCount={3} />
      </div>
    );
  }

  const items = data || [];

  // Group items by patient
  const groupedItems = groupBy(items, 'patient_uuid');
  const patientGroups = Object.keys(groupedItems).map((patientUuid) => {
    const patientMeds = groupedItems[patientUuid];
    return {
      patientUuid,
      identifier: patientMeds[0].identifier,
      name: patientMeds[0].name,
      gender: patientMeds[0].gender,
      date_of_birth: patientMeds[0].date_of_birth,
      medications: patientMeds,
    };
  });

  const admittedPatients = admissionsData?.data?.results || [];

  return (
    <div className={styles.notificationContainer}>
      <div className={styles.headerRow}>
        <h4 className={styles.title}>{activeTab === 'meds' ? 'Emergency Medications' : 'Nursing Tasks'}</h4>
        <div className={styles.tabButtons}>
          <Button
            kind={activeTab === 'meds' ? 'primary' : 'ghost'}
            onClick={() => setActiveTab('meds')}
            size="sm"
          >
            Emergency Medications
          </Button>
          <Button
            kind={activeTab === 'tasks' ? 'primary' : 'ghost'}
            onClick={() => setActiveTab('tasks')}
            size="sm"
          >
            Nursing Tasks
          </Button>
        </div>
      </div>

      {activeTab === 'meds' && (
        <Accordion>
          {patientGroups.length === 0 ? (
            <p className={styles.emptyState}>No pending medication acknowledgments.</p>
          ) : (
            patientGroups.map((patient) => {
              const patientTitle = (
                <div className={styles.titleContent}>
                  <span
                    className={styles.patientLink}
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePatientClick(patient.patientUuid);
                    }}
                  >
                    ({patient.identifier})
                  </span>
                  <span className={styles.patientName}>{patient.name}</span>
                  <span className={styles.patientMeta}>
                    {formatGender(patient.gender)}, {calculateExactAge(patient.date_of_birth)}
                    <span className={styles.pendingCount}> ({patient.medications.length} pending)</span>
                  </span>
                </div>
              );

              return (
                <AccordionItem key={patient.patientUuid} title={patientTitle}>
                  <div className={styles.patientMedicationsList}>
                    {patient.medications.map((item) => (
                      <div key={item.medication_administration_uuid} className={styles.medicationBlock}>
                        <div className={styles.notificationItemContent}>
                          <div className={styles.detailsRow}>
                            <div className={styles.dateInfo}>{formatDate(item.administered_date_time)}</div>
                            <div className={styles.drugName}>{item.administered_drug_name}</div>
                          </div>

                          <div className={styles.noteField}>
                            <TextArea
                              id={`notes-${item.medication_administration_uuid}`}
                              labelText="Note *"
                              placeholder="Enter Notes"
                              value={notes[item.medication_administration_uuid] || ''}
                              onChange={(e) =>
                                setNotes((prev) => ({ ...prev, [item.medication_administration_uuid]: e.target.value }))
                              }
                              rows={2}
                            />
                          </div>

                          <div className={styles.actions}>
                            <Button
                              size="sm"
                              onClick={() => handleAcknowledge(item)}
                              disabled={submitting[item.medication_administration_uuid]}
                            >
                              {submitting[item.medication_administration_uuid] ? (
                                <InlineLoading description="Acknowledging..." />
                              ) : (
                                'Acknowledge'
                              )}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionItem>
              );
            })
          )}
        </Accordion>
      )}

      {activeTab === 'tasks' && (
        <div className={styles.tasksView}>
          {admissionsLoading ? (
            <DataTableSkeleton columnCount={1} rowCount={3} />
          ) : (
            <Accordion>
              {admittedPatients.length === 0 ? (
                <p className={styles.emptyState}>No admitted patients found.</p>
              ) : (
                admittedPatients.map((patient: any) => (
                  <PatientTasksAccordionItem
                    key={patient.patient.uuid}
                    patient={patient}
                    handlePatientClick={handlePatientClick}
                    notes={notes}
                    setNotes={setNotes}
                    submitting={submitting}
                    setSubmitting={setSubmitting}
                    calculateExactAge={calculateExactAge}
                    formatGender={formatGender}
                  />
                ))
              )}
            </Accordion>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationComponent;
