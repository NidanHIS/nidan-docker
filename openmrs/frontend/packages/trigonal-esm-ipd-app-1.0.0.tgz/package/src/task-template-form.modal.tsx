import React, { useCallback, useState } from 'react';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import {
  Modal,
  TextInput,
  TextArea,
  Select,
  SelectItem,
  Toggle,
  Stack,
  DatePicker,
  DatePickerInput,
  NumberInput,
  Button,
  Form,
  Checkbox,
} from '@carbon/react';
import { Add, TrashCan } from '@carbon/react/icons';
import useSWR from 'swr';
import useSWRImmutable from 'swr/immutable';
import {
  openmrsFetch,
  restBaseUrl,
  useConfig,
  showSnackbar,
} from '@openmrs/esm-framework';
import type { IpdConfig } from './config-schema';

interface TaskTemplateFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialValues?: any;
}

const recurrenceSchema = z.object({
  type: z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'ONCE']).optional(),
  interval: z.number().min(1).optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional().nullable(),
  activeTimes: z.array(z.object({ value: z.string().min(1, 'Time is required') })).optional(),
  daysOfWeek: z.array(z.number()).optional(),
});

const taskTemplateSchema = z.object({
  name: z.string()
    .min(3, 'Name is required')
    .max(100, 'Name must be at most 100 characters')
    .regex(/^[a-zA-Z0-9\s\-_.,()[\]]+$/, 'Name contains invalid characters'),
  description: z.string().max(500, 'Description must be at most 500 characters').optional().or(z.literal('')),
  taskTypeUuid: z.string().min(1, 'Task type is required'),
  priority: z.enum(['ROUTINE', 'URGENT', 'STAT']),
  wardUuid: z.string().optional().or(z.literal('')),
  active: z.boolean().default(true),
  estimatedDurationMinutes: z.number().int().min(0).optional().nullable(),
  recurrence: recurrenceSchema.optional().nullable(),
});

type TaskTemplateFormValues = z.infer<typeof taskTemplateSchema>;

const TaskTemplateFormModal: React.FC<TaskTemplateFormModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialValues,
}) => {
  const { t } = useTranslation();
  const config = useConfig<IpdConfig>();

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
    reset,
    watch,
  } = useForm<TaskTemplateFormValues>({
    resolver: zodResolver(taskTemplateSchema),
    defaultValues: {
      active: true,
      recurrence: {
        type: 'DAILY',
        interval: 1,
        activeTimes: [{ value: '09:00' }],
        daysOfWeek: [],
      },
    },
  });

  const convertToLocal = (utcTime: string) => {
    const [hours, minutes] = utcTime.split(':').map(Number);
    const date = new Date();
    date.setUTCHours(hours, minutes, 0, 0);
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  };

  React.useEffect(() => {
    if (isOpen) {
      if (initialValues) {
        reset({
          ...initialValues,
          description: initialValues.description || '',
          wardUuid: initialValues.ward?.uuid || initialValues.wardUuid || '',
          estimatedDurationMinutes: initialValues.estimatedDurationMinutes || undefined,
          taskTypeUuid: initialValues.taskType?.uuid || initialValues.taskTypeUuid,
          recurrence: initialValues.recurrence ? {
            ...initialValues.recurrence,
            startDate: initialValues.recurrence.startDate?.split('T')[0] || '',
            endDate: initialValues.recurrence.endDate?.split('T')[0] || '',
            activeTimes: initialValues.recurrence?.activeTimes?.map((t: string) => ({ value: convertToLocal(t) })) || [{ value: '09:00' }],
            daysOfWeek: initialValues.recurrence?.daysOfWeek || [],
          } : {
            type: 'DAILY',
            interval: 1,
            activeTimes: [{ value: '09:00' }],
            daysOfWeek: [],
          },
        });
      } else {
        reset({
          name: '',
          description: '',
          taskTypeUuid: '',
          priority: 'ROUTINE',
          wardUuid: '',
          active: true,
          estimatedDurationMinutes: undefined,
          recurrence: {
            type: 'DAILY',
            interval: 1,
            activeTimes: [{ value: '09:00' }],
            daysOfWeek: [],
          },
        });
      }
    }
  }, [isOpen, initialValues, reset]);

  const recurrenceType = watch('recurrence.type');

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'recurrence.activeTimes',
  });

  // Fetch Wards
  const { data: wardsData } = useSWR<{ results: any[] }>(
    `${restBaseUrl}/location?tag=Admission%20Location&v=default`,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );
  const wards = wardsData?.results || [];

  // Fetch Task Types
  const taskTypesConceptUuid = config.concepts.nursingTaskTypesConceptSetUuid;
  const { data: taskTypesConcept } = useSWRImmutable<any>(
    taskTypesConceptUuid
      ? `${restBaseUrl}/concept/${taskTypesConceptUuid}?v=custom:(uuid,display,setMembers:(uuid,display))`
      : null,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );
  const taskTypes = taskTypesConcept?.setMembers || [];

  const onSubmit = useCallback(
    async (values: TaskTemplateFormValues) => {
      try {
        const convertToUtc = (localTime: string) => {
          const [hours, minutes] = localTime.split(':').map(Number);
          const date = new Date();
          date.setHours(hours, minutes, 0, 0);
          return `${date.getUTCHours().toString().padStart(2, '0')}:${date.getUTCMinutes().toString().padStart(2, '0')}`;
        };

        const formatDateTime = (dateStr?: string | null) => {
          if (!dateStr) return undefined;
          if (dateStr.includes('T')) return dateStr.split('.')[0].replace('Z', '');
          const now = new Date();
          const pad = (n: number) => n.toString().padStart(2, '0');
          return `${dateStr}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        };

        const payload = {
          ...values,
          description: values.description || undefined,
          wardUuid: values.wardUuid || undefined,
          estimatedDurationMinutes: values.estimatedDurationMinutes || undefined,
          recurrence: values.recurrence?.type ? {
            ...values.recurrence,
            startDate: formatDateTime(values.recurrence.startDate),
            endDate: formatDateTime(values.recurrence.endDate),
            activeTimes: values.recurrence.activeTimes?.map(t => convertToUtc(t.value)),
            // Only include daysOfWeek if it's weekly and has values
            daysOfWeek: values.recurrence.type === 'WEEKLY' ? values.recurrence.daysOfWeek : undefined,
          } : undefined
        };

        const url = initialValues?.uuid
          ? `${restBaseUrl}/ipd/task-templates/${initialValues.uuid}`
          : `${restBaseUrl}/ipd/task-templates`;

        await openmrsFetch(url, {
          method: initialValues?.uuid ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        showSnackbar({
          title: initialValues?.uuid
            ? t('templateUpdated', 'Task template updated successfully')
            : t('templateCreated', 'Task template created successfully'),
          kind: 'success',
        });

        onSuccess();
        reset();
        onClose();
      } catch (error) {
        showSnackbar({
          title: t('saveError', 'Error saving task template'),
          subtitle: error instanceof Error ? error.message : String(error),
          kind: 'error',
        });
      }
    },
    [onSuccess, onClose, reset, t, initialValues],
  );

  return (
    <Modal
      open={isOpen}
      modalHeading={initialValues ? t('editTaskTemplate', 'Edit Task Template') : t('createTaskTemplate', 'Create Task Template')}
      primaryButtonText={t('save', 'Save')}
      secondaryButtonText={t('cancel', 'Cancel')}
      onRequestClose={onClose}
      onRequestSubmit={handleSubmit(onSubmit)}
      primaryButtonDisabled={isSubmitting}
    >
      <Form>
        <Stack gap={6}>
          <TextInput
            id="name"
            labelText={t('name', 'Name')}
            invalid={!!errors.name}
            invalidText={errors.name?.message}
            {...register('name')}
          />

          <TextArea
            id="description"
            labelText={t('description', 'Description')}
            invalid={!!errors.description}
            invalidText={errors.description?.message}
            {...register('description')}
          />

          <div style={{ display: 'flex', gap: '1rem' }}>
            <Select
              id="taskTypeUuid"
              labelText={t('taskType', 'Task Type')}
              invalid={!!errors.taskTypeUuid}
              invalidText={errors.taskTypeUuid?.message}
              {...(register('taskTypeUuid') as any)}
              defaultValue=""
              style={{ flex: 1 }}
            >
              <SelectItem value="" text={t('selectTaskType', 'Select Task Type')} disabled />
              {taskTypes.map((type: any) => (
                <SelectItem key={type.uuid} value={type.uuid} text={type.display} />
              ))}
            </Select>

            <Select
              id="priority"
              labelText={t('priority', 'Priority')}
              invalid={!!errors.priority}
              invalidText={errors.priority?.message}
              {...(register('priority') as any)}
              defaultValue="ROUTINE"
              style={{ flex: 1 }}
            >
              <SelectItem value="ROUTINE" text="Routine" />
              <SelectItem value="URGENT" text="Urgent" />
              <SelectItem value="STAT" text="Stat" />
            </Select>
          </div>

          <div style={{ display: 'flex', gap: '1rem' }}>
            <Select
              id="wardUuid"
              labelText={t('ward', 'Ward')}
              invalid={!!errors.wardUuid}
              invalidText={errors.wardUuid?.message}
              {...(register('wardUuid') as any)}
              defaultValue=""
              style={{ flex: 1 }}
            >
              <SelectItem value="" text={t('selectWard', 'Select Ward')} disabled />
              {wards.map((ward) => (
                <SelectItem key={ward.uuid} value={ward.uuid} text={ward.display} />
              ))}
            </Select>

            <Controller
              name="estimatedDurationMinutes"
              control={control}
              render={({ field }) => (
                <NumberInput
                  id="estimatedDurationMinutes"
                  label={t('estimatedDurationMinutes', 'Estimated Duration (mins)')}
                  value={field.value}
                  onChange={(_, { value }) => field.onChange(value)}
                  min={0}
                  invalid={!!errors.estimatedDurationMinutes}
                  invalidText={errors.estimatedDurationMinutes?.message}
                  style={{ flex: 1 }}
                />
              )}
            />
          </div>

          <Controller
            name="active"
            control={control}
            render={({ field }) => (
              <Toggle
                id="active"
                labelA={t('inactive', 'Inactive')}
                labelB={t('active', 'Active')}
                labelText={t('status', 'Status')}
                toggled={field.value}
                onToggle={(val) => field.onChange(val)}
                size="sm"
              />
            )}
          />

          <section>
            <h5 style={{ marginBottom: '1rem' }}>{t('recurrence', 'Recurrence')}</h5>
            <Stack gap={5}>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <Select
                  id="recurrenceType"
                  labelText={t('recurrenceType', 'Recurrence Type')}
                  {...(register('recurrence.type') as any)}
                  style={{ flex: 1 }}
                >
                  <SelectItem value="DAILY" text="Daily" />
                  <SelectItem value="WEEKLY" text="Weekly" />
                  <SelectItem value="MONTHLY" text="Monthly" />
                  <SelectItem value="ONCE" text="Once" />
                </Select>

                <Controller
                  name="recurrence.interval"
                  control={control}
                  render={({ field }) => (
                    <NumberInput
                      id="recurrenceInterval"
                      label={t('recurrenceInterval', 'Interval')}
                      value={field.value}
                      onChange={(_, { value }) => field.onChange(value)}
                      min={1}
                      invalid={!!errors.recurrence?.interval}
                      invalidText={errors.recurrence?.interval?.message}
                      style={{ flex: 1 }}
                      disabled={recurrenceType === 'ONCE'}
                    />
                  )}
                />
              </div>

              {recurrenceType === 'WEEKLY' && (
                <div>
                  <label className="cds--label" style={{ display: 'block', marginBottom: '0.5rem' }}>
                    {t('daysOfWeek', 'Days of Week')}
                  </label>
                  <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                    {[
                      { label: t('mon', 'Mon'), value: 1 },
                      { label: t('tue', 'Tue'), value: 2 },
                      { label: t('wed', 'Wed'), value: 3 },
                      { label: t('thu', 'Thu'), value: 4 },
                      { label: t('fri', 'Fri'), value: 5 },
                      { label: t('sat', 'Sat'), value: 6 },
                      { label: t('sun', 'Sun'), value: 7 },
                    ].map((day) => (
                      <Controller
                        key={day.value}
                        name="recurrence.daysOfWeek"
                        control={control}
                        render={({ field }) => {
                          const isChecked = field.value?.includes(day.value);
                          return (
                            <Checkbox
                              id={`day-${day.value}`}
                              labelText={day.label}
                              checked={isChecked}
                              onChange={(_, { checked }) => {
                                const newValue = checked
                                  ? [...(field.value || []), day.value]
                                  : (field.value || []).filter((v) => v !== day.value);
                                field.onChange(newValue);
                              }}
                            />
                          );
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: '1rem' }}>
                <Controller
                  name="recurrence.startDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      datePickerType="single"
                      dateFormat="Y-m-d"
                      onChange={([date]) => field.onChange(date ? date.toISOString().split('T')[0] : '')}
                    >
                      <DatePickerInput
                        id="startDate"
                        labelText={t('startDate', 'Start Date')}
                        placeholder="yyyy-mm-dd"
                        invalid={!!errors.recurrence?.startDate}
                        invalidText={errors.recurrence?.startDate?.message}
                      />
                    </DatePicker>
                  )}
                />
                <Controller
                  name="recurrence.endDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      datePickerType="single"
                      dateFormat="Y-m-d"
                      onChange={([date]) => field.onChange(date ? date.toISOString().split('T')[0] : '')}
                    >
                      <DatePickerInput
                        id="endDate"
                        labelText={t('endDate', 'End Date')}
                        placeholder="yyyy-mm-dd"
                        invalid={!!errors.recurrence?.endDate}
                        invalidText={errors.recurrence?.endDate?.message}
                        disabled={recurrenceType === 'ONCE'}
                      />
                    </DatePicker>
                  )}
                />
              </div>

              <div>
                <label className="cds--label" style={{ display: 'block', marginBottom: '0.5rem' }}>
                  {t('activeTimes', 'Active Times')}
                </label>
                <Stack gap={4}>
                  {fields.map((field, index) => (
                    <div key={field.id} style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-end' }}>
                      <TextInput
                        id={`time-${index}`}
                        type="time"
                        labelText=""
                        {...register(`recurrence.activeTimes.${index}.value` as const)}
                        style={{ width: '150px' }}
                      />
                      {fields.length > 1 && (
                        <Button
                          kind="ghost"
                          hasIconOnly
                          renderIcon={TrashCan}
                          iconDescription={t('remove', 'Remove')}
                          onClick={() => remove(index)}
                          size="sm"
                        />
                      )}
                    </div>
                  ))}
                  <Button
                    kind="ghost"
                    size="sm"
                    renderIcon={Add}
                    onClick={() => append({ value: '' })}
                    style={{ width: 'fit-content' }}
                  >
                    {t('addTime', 'Add Time')}
                  </Button>
                </Stack>
                {errors.recurrence?.activeTimes && (
                  <div className="cds--form-requirement" style={{ color: '#da1e28', marginTop: '0.5rem' }}>
                    {errors.recurrence.activeTimes.message as string}
                  </div>
                )}
              </div>
            </Stack>
          </section>
        </Stack>
      </Form>
    </Modal>
  );
};

export default TaskTemplateFormModal;
