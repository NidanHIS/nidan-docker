import { defineConfigSchema, getSyncLifecycle, getAsyncLifecycle } from '@openmrs/esm-framework';
import { moduleName } from './constants';
import { configSchema } from './config-schema';
import Root from './root.component';
import { createIPDDashboardLink } from './ipd-dashboard-link.component';
import PatientIpdDashboard from './features/patient-ipd/patient-ipd-dashboard.component';
import BedAssignmentBanner from './features/bed-assignment/bed-assignment-banner.component';
import NursingTaskFormWorkspace from './features/nursing-tasks/nursing-task-form.workspace';
import RecordTaskWorkspace from './features/nursing-tasks/record-task.workspace';
import DrugChartWorkspace from './features/treatments/drug-chart.workspace';
import IntakeOutputFormWorkspace from './features/intake-output/intake-output-form.workspace';
import TaskTemplateSelectionWorkspace from './features/nursing-tasks/task-template-selection.workspace';
import PatientConditionalDashboardLink from './features/patient-ipd/patient-conditional-dashboard-link.component';
import { homeDashboardMeta, notificationDashboardMeta } from './dashboard.meta';
import { bedTagBadge } from './features/bed-assignment/bed-assignment-banner.component';
// import VisitAttributeTags from './features/bed-assignment/patient-visit-type-badge.component';
import { useSession } from '@openmrs/esm-framework';
import NotificationComponent from './notification.component';
import NotificationNav from './notification-nav.component';

const options = {
  featureName: 'esm-ipd-app',
  moduleName,
};



/**
 * Lazy-load translation bundles from the /translations directory.
 * The `lazy` webpack magic comment keeps each locale as a separate chunk.
 */
// export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

// ── Pages ────────────────────────────────────────────────────────────────────

/**
 * root — the full-page ward/care-view dashboard mounted at /home/ipd
 * Registered as a `page` in routes.json.
 */
export const root = getSyncLifecycle(Root, options);

export const notificationComponent = getSyncLifecycle(NotificationComponent, options);

export const taskTemplatePage = getAsyncLifecycle(
  () => import('./task-template.page'),
  options,
);
// ── Homepage extensions ──────────────────────────────────────────────────────

/**
 * ipdDashboardLink — appears in the main homepage left-panel navigation.
 * Clicking navigates to /home/ipd (the ward-level care view dashboard).
 * Slot: homepage-dashboard-slot
 */
export const ipdDashboardLink = getSyncLifecycle(
  createIPDDashboardLink(homeDashboardMeta),
  options,
);

export const notificationDashboardLink = getSyncLifecycle(
  createIPDDashboardLink(notificationDashboardMeta),
  options,
);

// ── Patient chart extensions ─────────────────────────────────────────────────

/**
 * patientIpdLink — appears in every patient chart's left-panel navigation.
 * Clicking navigates to /patient/{uuid}/chart/ipd-summary.
 * Slot: patient-chart-dashboard-slot
 */

export const ipddDashboardLink = getSyncLifecycle(PatientConditionalDashboardLink, options);

/**
 * patientIpdDashboard — the full patient IPD view (medications, nursing tasks,
 * drug chart, allergies, vitals, etc.) rendered inside the patient chart.
 * Slot: patient-ipd-slot
 */
export const patientIpdDashboard = getSyncLifecycle(PatientIpdDashboard, options);

/**
 * bedAssignmentBanner — IPD-05
 * Displayed at the top of the patient IPD view.
 * Slot: patient-ipd-banner-slot
 */
export const bedAssignmentBanner = getSyncLifecycle(BedAssignmentBanner, options);

// ── Workspaces ───────────────────────────────────────────────────────────────

export const addIpdTaskWorkspace = getSyncLifecycle(NursingTaskFormWorkspace, options);
export const recordIpdTaskWorkspace = getSyncLifecycle(RecordTaskWorkspace, options);
export const addIpdMedicationWorkspace = getSyncLifecycle(DrugChartWorkspace, options);
export const addIntakeOutputWorkspace = getSyncLifecycle(IntakeOutputFormWorkspace, options);
export const selectTaskTemplateWorkspace = getSyncLifecycle(TaskTemplateSelectionWorkspace, options);

export const bedTag = getSyncLifecycle(bedTagBadge, options);
// export const visitTypeTag = getSyncLifecycle(VisitAttributeTags, options);

export const notificationNavLink = getSyncLifecycle(NotificationNav, options);

export const taskTemplateAdminLink = getAsyncLifecycle(
  () => import('./task-template-admin.component'),
  options,
);

export const taskTemplatePageLink = getAsyncLifecycle(
  () => import('./task-template.page'),
  options,
);