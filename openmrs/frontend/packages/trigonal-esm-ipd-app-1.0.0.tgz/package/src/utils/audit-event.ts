/**
 * IPD audit event topic — dispatched as a browser CustomEvent on window so that
 * any module can subscribe via `window.addEventListener(IPD_AUDIT_EVENT_TOPIC, …)`.
 *
 * Replaces the legacy Bahmni `handleAuditEvent()` approach. The `publish` helper
 * was removed in @openmrs/esm-framework v9; browser CustomEvent is the portable
 * O3-compatible alternative for custom cross-module events.
 */
export const IPD_AUDIT_EVENT_TOPIC = 'bahmni.ipd.audit';

export interface IpdAuditEventPayload {
  /** e.g. 'VIEWED_WARD_LEVEL_DASHBOARD', 'VIEWED_NURSING_TASK_FORM' */
  eventType: string;
  patientUuid?: string;
  visitUuid?: string;
  /** Module label forwarded to the audit log (matches legacy MODULE_LABEL_ constants) */
  moduleLabel?: string;
  timestamp: string;
}

/**
 * Publishes an IPD audit event to the OpenMRS Global Event Bus.
 *
 * Any module can subscribe via:
 * ```ts
 * window.addEventListener(IPD_AUDIT_EVENT_TOPIC, (e: Event) => {
 *   const payload = (e as CustomEvent<IpdAuditEventPayload>).detail;
 * });
 * ```
 *
 * Migration note: replaces `hostApi.handleAuditEvent(patientUuid, eventType, …)`
 * which required the Bahmni shell to pass the host API as a prop.
 * The Event Bus is framework-level — no prop drilling required.
 */
export function publishAuditEvent(
  eventType: string,
  patientUuid?: string,
  visitUuid?: string,
  moduleLabel = 'MODULE_LABEL_CLINICAL_KEY',
): void {
  const payload: IpdAuditEventPayload = {
    eventType,
    patientUuid,
    visitUuid,
    moduleLabel,
    timestamp: new Date().toISOString(),
  };

  window.dispatchEvent(new CustomEvent(IPD_AUDIT_EVENT_TOPIC, { detail: payload }));
}
