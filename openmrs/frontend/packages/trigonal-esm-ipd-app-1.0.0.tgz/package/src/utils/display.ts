/**
 * Safely resolves a display name from either a string or an OpenMRS resource object.
 * Prevents React error #31 ("Objects are not valid as a React child").
 */
export function resolveDisplayName(value: any): string {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'object') {
    if (value.display) return value.display;
    if (value.name) return resolveDisplayName(value.name); // recursively handle name objects
    if (value.uuid) return value.uuid;
  }
  return String(value);
}
