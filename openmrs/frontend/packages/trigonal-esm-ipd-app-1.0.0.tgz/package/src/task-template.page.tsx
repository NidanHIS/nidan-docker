import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import useSWR from 'swr';
import { showSnackbar, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import {
  Button,
  Select,
  SelectItem,
  Toggle,
  Tile,
  Layer,
  Tag,
  IconButton,
  Modal,
  TextArea,
  Loading,
  ContentSwitcher,
  Switch,
  IconSwitch,
  DataTable,
  DataTableHeader,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TableExpandHeader,
  TableExpandRow,
  TableExpandedRow,
  Search,
  Pagination,
} from '@carbon/react';
import {
  Add,
  Events,
  Location,
  Time,
  Renew,
  Edit,
  Copy,
  TrashCan,
  ChevronDown,
  Table as TableIcon,
  List,
} from '@carbon/react/icons';
import classNames from 'classnames';
import TaskTemplateFormModal from './task-template-form.modal';

import styles from './task-template.page.scss';

// Interface based on the provided JSON payload
interface TaskTemplate {
  uuid: string;
  name: string;
  description: string;
  taskType: {
    display: string;
    uuid: string;
  };
  ward: {
    display: string;
    uuid: string;
  };
  priority: string;
  estimatedDurationMinutes: number | null;
  defaultAssigneeRole: string | null;
  active: boolean;
  recurrence: Recurrence
}

type RecurrenceType = "DAILY" | "WEEKLY" | "MONTHLY";

interface Recurrence {
  type: RecurrenceType;
  interval: number;
  startDate: string | null;
  endDate: string | null;
  activeTimes: string[];
  daysOfWeek: number[] | null;
}

const fetcher = (url: string) => openmrsFetch(url).then(({ data }) => data);

const TaskTemplatePage: React.FC = () => {
  const { t } = useTranslation();
  const [isFormOpen, setIsFormOpen] = useState(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [templateToDelete, setTemplateToDelete] = useState<TaskTemplate | null>(null);
  const [templateToEdit, setTemplateToEdit] = useState<TaskTemplate | null>(null);
  const [stopReason, setStopReason] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [searchQuery, setSearchQuery] = useState('');
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Fetching data
  const { data, error, isLoading, mutate } = useSWR<{
    results: TaskTemplate[];
    pageNumber: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
  }>(
    `${restBaseUrl}/ipd/task-templates?searchQuery=${searchQuery}&pageNumber=${pageNumber}&pageSize=${pageSize}`,
    fetcher,
  );

  const templates = data?.results || [];

  // Use templates directly since search is handled by the backend
  const filteredTemplates = templates;


  const handleDelete = async () => {
    if (!templateToDelete) return;

    setIsDeleting(true);
    try {
      await openmrsFetch(`${restBaseUrl}/ipd/task-templates/${templateToDelete.uuid}?reason=${encodeURIComponent(stopReason)}`, {
        method: 'DELETE',
      });

      showSnackbar({
        title: t('templateDeleted', 'Task template deleted successfully'),
        kind: 'success',
      });

      mutate();
      setShowDeleteModal(false);
      setTemplateToDelete(null);
      setStopReason('');
    } catch (err) {
      showSnackbar({
        title: t('deleteError', 'Error deleting task template'),
        subtitle: err instanceof Error ? err.message : String(err),
        kind: 'error',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const getPriorityTagClass = (priority: string) => {
    switch (priority.toUpperCase()) {
      case 'ROUTINE':
        return styles.tagRoutine;
      case 'URGENT':
        return styles.tagUrgent;
      case 'STAT':
        return styles.tagStat;
      default:
        return styles.tagRoutine;
    }
  };

  return (
    <div className={styles.pageContainer}>
      <div className={styles.header}>
        <h3>{t('taskTemplates', 'Task Templates')}</h3>
        <div className={styles.headerActions}>
          {/* <Button kind="secondary" size="md">
            {t('createTaskFromTemplate', 'Create Task from Template')}
          </Button> */}
          <ContentSwitcher
            onChange={(data) => setViewMode(data.name as 'card' | 'list')}
            selectedIndex={viewMode === 'card' ? 0 : 1}
            className={styles.viewSwitcher}
            size="md"
          >
            <IconSwitch name="card" text={t('cardView', 'Card View')}><Copy size={16} /></IconSwitch>
            <IconSwitch name="list" text={t('tableView', 'Table View')} ><TableIcon size={16} /></IconSwitch>
          </ContentSwitcher>
          <Button
            // renderIcon={ChevronDown}
            // iconDescription="Options"
            size="md"
            onClick={() => {
              setTemplateToEdit(null);
              setIsFormOpen(true);
            }}
          >
            {t('createTemplate', 'Create Template')}
          </Button>
        </div>
      </div>

      <TaskTemplateFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setTemplateToEdit(null);
        }}
        onSuccess={() => mutate()}
        initialValues={templateToEdit}
      />

      <Layer>
        <div className={styles.filterBar} style={{ display: 'flex', gap: '1rem', alignItems: 'center', marginBottom: '1.5rem' }}>
          <Search
            size="md"
            labelText={t('searchTemplates', 'Search templates')}
            placeholder={t('searchTemplates', 'Search templates')}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPageNumber(1); // Reset to first page on search
            }}
            style={{ maxWidth: '400px' }}
          />
        </div>
      </Layer>

      {isLoading ? (
        <Loading description="Loading task templates..." withOverlay={false} />
      ) : error ? (
        <div className={styles.errorState}>{t('errorLoading', 'Error loading templates')}</div>
      ) : (
        <>
          {viewMode === 'card' ? (
            <div className={styles.grid}>
              {filteredTemplates.map((template) => (
                <Tile key={template.uuid} className={styles.templateTile}>
                  <div className={styles.cardContent}>
                    <div className={styles.cardHeader}>
                      <h3>{template.name}</h3>
                      <Tag className={classNames(styles.priorityTag, getPriorityTagClass(template.priority))}>
                        {template.priority}
                      </Tag>
                    </div>
                    <div className={styles.cardDescription}>{template.description}</div>

                    <div className={styles.cardDetails}>
                      <div className={styles.detailRow}>
                        <Events size={16} />
                        <span>{template.taskType?.display || 'N/A'}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <Location size={16} />
                        <span>{template.ward?.display || 'Inpatient (IPD)'}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <Time size={16} />
                        <span>
                          {t('duration', 'Duration:')} {template.estimatedDurationMinutes ? `${template.estimatedDurationMinutes}m` : '—'}
                        </span>
                      </div>
                      <div className={styles.detailRow}>
                        <Renew size={16} />
                        <span>{t('recurrence', 'Recurrence:')} {template.recurrence?.type ? `${template.recurrence?.type}` : '—'}</span>
                      </div>
                    </div>
                  </div>

                  <div className={styles.cardFooter}>
                    <div className={styles.activeToggle}>
                      <Toggle
                        id={`toggle-${template.uuid}`}
                        labelA=""
                        labelB=""
                        labelText={template.active ? t('active', 'Active') : t('inactive', 'Inactive')}
                        toggled={template.active}
                        onToggle={() => { }}
                        size="sm"
                        hideLabel
                      />
                    </div>
                    <div className={styles.footerActions}>
                      <Button
                        kind="ghost"
                        size="sm"
                        renderIcon={Edit}
                        iconDescription={t('edit', 'Edit')}
                        onClick={() => {
                          setTemplateToEdit(template);
                          setIsFormOpen(true);
                        }}
                      >
                        {t('edit', 'Edit')}
                      </Button>
                      <Button
                        kind="ghost"
                        size="sm"
                        onClick={() => {
                          setTemplateToDelete(template);
                          setShowDeleteModal(true);
                        }}
                        className={styles.deleteButton}
                      >
                        {t('delete', 'Delete')}
                      </Button>
                    </div>
                  </div>
                </Tile>
              ))}
            </div>
          ) : (
            <div className={styles.listView}>
              <DataTable
                rows={filteredTemplates.map((t) => ({
                  ...t,
                  id: t.uuid,
                  taskTypeDisplay: t.taskType?.display || 'N/A',
                  wardDisplay: t.ward?.display || 'Inpatient (IPD)',
                }))}
                headers={[
                  { key: 'name', header: t('name', 'Name') },
                  { key: 'taskTypeDisplay', header: t('type', 'Type') },
                  { key: 'wardDisplay', header: t('ward', 'Ward') },
                  { key: 'priority', header: t('priority', 'Priority') },
                  { key: 'active', header: t('status', 'Status') },
                  { key: 'actions', header: '' },
                ]}
              >
                {({ rows, headers, getHeaderProps, getRowProps }) => (
                  <Table size="lg">
                    <TableHead>
                      <TableRow>
                        <TableExpandHeader />
                        {headers.map((header) => (
                          <TableHeader {...getHeaderProps({ header })} key={header.key}>
                            {header.header}
                          </TableHeader>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {rows.map((row) => (
                        <React.Fragment key={row.id}>
                          <TableExpandRow {...getRowProps({ row })}>
                            {row.cells.map((cell) => {
                              if (cell.info.header === 'priority') {
                                return (
                                  <TableCell key={cell.id}>
                                    <Tag className={classNames(styles.priorityTag, getPriorityTagClass(cell.value as string))}>
                                      {cell.value}
                                    </Tag>
                                  </TableCell>
                                );
                              }
                              if (cell.info.header === 'active') {
                                return (
                                  <TableCell key={cell.id}>
                                    <Toggle
                                      id={`list-toggle-${row.id}`}
                                      labelA=""
                                      labelB=""
                                      labelText={cell.value ? t('active', 'Active') : t('inactive', 'Inactive')}
                                      toggled={cell.value as boolean}
                                      onToggle={() => { }}
                                      size="sm"
                                      hideLabel
                                    />
                                  </TableCell>
                                );
                              }
                              if (cell.info.header === 'actions') {
                                return (
                                  <TableCell key={cell.id}>
                                    <div className={styles.tableActions}>
                                      <IconButton
                                        kind="ghost"
                                        label={t('edit', 'Edit')}
                                        onClick={(e: any) => {
                                          e.stopPropagation();
                                          const template = filteredTemplates.find((t) => t.uuid === row.id);
                                          if (template) {
                                            setTemplateToEdit(template);
                                            setIsFormOpen(true);
                                          }
                                        }}
                                        size="sm"
                                        align="bottom-right"
                                      >
                                        <Edit size={16} />
                                      </IconButton>
                                      <IconButton
                                        kind="ghost"
                                        label={t('delete', 'Delete')}
                                        onClick={(e: any) => {
                                          e.stopPropagation();
                                          const template = filteredTemplates.find((t) => t.uuid === row.id);
                                          if (template) {
                                            setTemplateToDelete(template);
                                            setShowDeleteModal(true);
                                          }
                                        }}
                                        size="sm"
                                        align="bottom-right"
                                        className={styles.deleteButton}
                                      >
                                        <TrashCan size={16} />
                                      </IconButton>
                                    </div>
                                  </TableCell>
                                );
                              }
                              return <TableCell key={cell.id}>{cell.value as React.ReactNode}</TableCell>;
                            })}
                          </TableExpandRow>
                          {row.isExpanded && (
                            <TableExpandedRow colSpan={headers.length + 1} className={styles.expandedRow}>
                              <div className={styles.expandedContent}>
                                <div className={styles.expandedSection}>
                                  <h5>{t('description', 'Description')}</h5>
                                  <p>{filteredTemplates.find((t) => t.uuid === row.id)?.description || t('noDescription', 'No description provided.')}</p>
                                </div>
                                <div className={styles.expandedDetails}>
                                  <div className={styles.expandedDetailItem}>
                                    <strong>{t('estimatedDuration', 'Estimated Duration')}:</strong>
                                    <span>
                                      {filteredTemplates.find((t) => t.uuid === row.id)?.estimatedDurationMinutes
                                        ? `${filteredTemplates.find((t) => t.uuid === row.id)?.estimatedDurationMinutes} ${t('minutes', 'minutes')}`
                                        : '—'}
                                    </span>
                                  </div>
                                  <div className={styles.expandedDetailItem}>
                                    <strong>{t('defaultAssignee', 'Default Assignee')}:</strong>
                                    <span>{filteredTemplates.find((t) => t.uuid === row.id)?.defaultAssigneeRole || '—'}</span>
                                  </div>
                                </div>
                              </div>
                            </TableExpandedRow>
                          )}
                        </React.Fragment>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </DataTable>
            </div>
          )}

          <Pagination
            page={pageNumber}
            pageSize={pageSize}
            pageSizes={[10, 20, 50, 100]}
            totalItems={data?.totalCount || 0}
            onChange={({ page, pageSize }) => {
              setPageNumber(page);
              setPageSize(pageSize);
            }}
            className={styles.pagination}
          />
        </>
      )}

      {/* Delete Confirmation Modal */}
      <Modal
        open={showDeleteModal}
        danger
        modalHeading={t('deleteTemplate', 'Delete Task Template')}
        primaryButtonText={t('delete', 'Delete')}
        secondaryButtonText={t('cancel', 'Cancel')}
        onRequestClose={() => {
          setShowDeleteModal(false);
          setTemplateToDelete(null);
          setStopReason('');
        }}
        onRequestSubmit={handleDelete}
        primaryButtonDisabled={!stopReason || isDeleting}
      >
        <p style={{ marginBottom: '1rem' }}>
          {t('deleteConfirmation', 'Are you sure you want to delete the template "{{name}}"? This action cannot be undone.', {
            name: templateToDelete?.name,
          })}
        </p>
        <TextArea
          id="stop-reason"
          labelText={
            <>
              {t('stopReason', 'Stop Reason')}
              <span className={styles.requiredIndicator}>*</span>
            </>
          }
          placeholder={t('enterStopReason', 'Enter a reason for deleting this template...')}
          value={stopReason}
          onChange={(e) => setStopReason(e.target.value)}
          rows={3}
        />
      </Modal>
    </div>
  );
};

export default TaskTemplatePage;
