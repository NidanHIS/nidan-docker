import React from 'react';
import { useTranslation } from 'react-i18next';
import { Layer, ClickableTile } from '@carbon/react';
import { ArrowRight } from '@carbon/react/icons';

const TaskTemplateLink: React.FC = () => {
  const { t } = useTranslation();
  const header = t('manageTaskTemplate', 'Manage Task Templates');
  return (
    <Layer>
      <ClickableTile href={`${window.spaBase}/task-template`} rel="noopener noreferrer">
        <div>
          <div className="heading">{header}</div>
          <div className="content">{t('taskTemplates', 'Task Templates')}</div>
        </div>
        <div className="iconWrapper">
          <ArrowRight size={16} />
        </div>
      </ClickableTile>
    </Layer>
  );
};

export default TaskTemplateLink;
