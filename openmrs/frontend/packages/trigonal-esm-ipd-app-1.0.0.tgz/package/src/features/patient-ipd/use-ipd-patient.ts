import useSWR from 'swr';
import useSWRImmutable from 'swr/immutable';
import { type FetchResponse, openmrsFetch, fhirBaseUrl, restBaseUrl } from '@openmrs/esm-framework';
import type {
  MedicationSchedule,
  NursingTask,
  RestApiResult,
} from '../../types';

/**
 * Fetches all scheduled medication slots for a patient visit.
 *
 * Endpoint: GET /ws/rest/v1/ipdVisit/{visitUuid}/medication?includes=emergencyMedications
 */
export function useMedicationSchedule(visitUuid: string | undefined) {
  const url = visitUuid
    ? `${restBaseUrl}/ipdVisit/${visitUuid}/medication?includes=emergencyMedications`
    : null;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<{ results: MedicationSchedule[] }>, Error>(
    url,
    openmrsFetch,
  );

  return {
    medicationSchedules: data?.data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches nursing tasks for a patient visit.
 *
 * Endpoint: GET /ws/rest/v1/ipd/tasks?patient={patientUuid}&status=REQUESTED,IN_PROGRESS
 */
export function useNursingTasks(patientUuid: string | undefined) {
  const url = patientUuid
    ? `${restBaseUrl}/ipd/tasks?patient=${patientUuid}&status=REQUESTED,IN_PROGRESS`
    : null;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<RestApiResult<NursingTask>>, Error>(
    url,
    openmrsFetch,
  );

  return {
    tasks: data?.data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/** FHIR R4 AllergyIntolerance resource — minimal subset used in the UI */
export interface FhirAllergyIntolerance {
  id: string;
  resourceType: 'AllergyIntolerance';
  clinicalStatus?: {
    coding: Array<{ code: string; display?: string }>;
  };
  verificationStatus?: {
    coding: Array<{ code: string; display?: string }>;
  };
  category?: string[];
  criticality?: 'low' | 'high' | 'unable-to-assess';
  code?: {
    coding: Array<{ code: string; display?: string; system?: string }>;
    text?: string;
  };
  patient: { reference: string; display?: string };
  onsetDateTime?: string;
  reaction?: Array<{
    substance?: { coding: Array<{ display?: string }>; text?: string };
    manifestation: Array<{ coding: Array<{ display?: string }>; text?: string }>;
    severity?: 'mild' | 'moderate' | 'severe';
    onset?: string;
  }>;
  note?: Array<{ text: string }>;
}

type AllergyBundle = { entry?: Array<{ resource: FhirAllergyIntolerance }> };

/**
 * Fetches FHIR AllergyIntolerance resources for a patient.
 *
 * Uses `useSWRImmutable` because allergy data is effectively static during
 * a session and does not need automatic revalidation.
 */
export function usePatientAllergies(patientUuid: string | undefined) {
  const url = patientUuid
    ? `${fhirBaseUrl}/AllergyIntolerance?patient=${patientUuid}&_sort=-date`
    : null;

  const { data, error, isLoading } = useSWRImmutable<FetchResponse<AllergyBundle>, Error>(
    url,
    openmrsFetch,
  );

  return {
    allergies: data?.data?.entry?.map((e) => e.resource) ?? [],
    isLoading,
    error,
  };
}

/**
 * Fetches the bed assignment for a patient visit.
 *
 * Endpoint: GET /ws/rest/v1/beds?patientUuid={uuid}
 */
export function usePatientBed(patientUuid: string | undefined) {
  const url = patientUuid ? `${restBaseUrl}/beds?patientUuid=${patientUuid}` : null;

  const { data, isLoading, mutate } = useSWR<FetchResponse<RestApiResult<unknown>>, Error>(
    url,
    openmrsFetch,
  );

  return {
    bed: data?.data?.results?.[0] ?? null,
    isLoading,
    mutate,
  };
}
