import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { DashboardExtension, usePatient, useSession } from '@openmrs/esm-framework';
import { usePatientChartStore } from '@openmrs/esm-patient-common-lib';
import { dashboardMeta } from '../../dashboard.meta';
import { usePatientBed } from './use-ipd-patient';


const PatientConditionalDashboardLink: React.FC<{ basePath: string; patientUuid?: string }> = ({
  basePath,
  patientUuid: patientUuidFromProps,
}) => {
  const { patientUuid: patientUuidFromHook } = usePatient();
  const patientUuid = patientUuidFromProps ?? patientUuidFromHook ?? '';
  const { visitContext } = usePatientChartStore(patientUuid);
  const { bed, isLoading: bedLoading } = usePatientBed(patientUuid);
  const session = useSession();

  if (!visitContext || bedLoading) {
    return null;
  }

  const isIPDVisit =
    visitContext.visitType?.display === 'IPD Visit' || visitContext.visitType?.name === 'IPD Visit';

  if (!bed) {
    return null;
  }


  const roles = session?.user?.roles ?? [];
  const hasAccess = roles.some(
    (role: any) =>
      role.name === 'Privilege Level: Full' ||
      role.name === 'Organizational: Nurse' ||
      role.name === 'Organizational: Doctor',
  );

  if (!hasAccess) {
    return null;
  }

  return (
    <BrowserRouter>
      <DashboardExtension
        basePath={basePath}
        title={dashboardMeta.title}
        path={dashboardMeta.path}
        icon={dashboardMeta.icon}
      />
    </BrowserRouter>
  );
};

export default PatientConditionalDashboardLink;