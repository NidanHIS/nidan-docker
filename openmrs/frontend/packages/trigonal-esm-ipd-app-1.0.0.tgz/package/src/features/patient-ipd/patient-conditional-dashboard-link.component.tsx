import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { DashboardExtension, usePatient, useSession } from '@openmrs/esm-framework';
import { usePatientChartStore } from '@openmrs/esm-patient-common-lib';
import { dashboardMeta } from '../../dashboard.meta';
import { usePatientBed } from './use-ipd-patient';


const PatientConditionalDashboardLink: React.FC<{ basePath: string; patientUuid?: string }> = ({
  basePath,
  patientUuid: patientUuidFromProps,
}) => {
  const { patientUuid: patientUuidFromHook } = usePatient();
  const patientUuid = patientUuidFromProps ?? patientUuidFromHook ?? '';
  const { visitContext } = usePatientChartStore(patientUuid);
  const { bed, isLoading: bedLoading } = usePatientBed(patientUuid);
  const session = useSession();

  if (!visitContext || bedLoading) {
    return null;
  }

  const isIPDVisit =
    visitContext.visitType?.display === 'IPD Visit' || visitContext.visitType?.name === 'IPD Visit';

  if (!bed) {
    return null;
  }


  const privileges = session?.user?.privileges ?? [];
  const hasIpdAccess = privileges.some((p: any) => p.display === 'IPD Summary');

  if (!hasIpdAccess) {
    return null;
  }

  return (
    <BrowserRouter>
      <DashboardExtension
        basePath={basePath}
        title={dashboardMeta.title}
        path={dashboardMeta.path}
        icon={dashboardMeta.icon}
      />
    </BrowserRouter>
  );
};

export default PatientConditionalDashboardLink;