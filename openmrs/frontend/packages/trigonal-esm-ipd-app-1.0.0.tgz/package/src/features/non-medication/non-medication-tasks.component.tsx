import React, { useMemo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  DataTable,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  Button,
  DataTableSkeleton,
  Tag,
  InlineNotification,
  Dropdown,
} from '@carbon/react';
import { Checkmark, Close, ChevronLeft, ChevronRight, Stamp } from '@carbon/react/icons';
import useSWR from 'swr';
import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import {
  Modal,
  TextArea,
} from '@carbon/react';
import type { NursingTask, RestApiResult } from '../../types';
import { updateNursingTask, acknowledgeNursingTask } from '../nursing-tasks/nursing-tasks-resource';
import { resolveDisplayName } from '../nursing-tasks/nursing-tasks.utils';
import styles from './non-medication-tasks.scss';

interface NonMedicationTasksProps {
  patientUuid: string;
}

const HOURS_PER_SHIFT = 8;
const SHIFT_MILI = HOURS_PER_SHIFT * 60 * 60 * 1000;

const FILTERS = [
  { id: 'allTasks', text: 'All Tasks' },
  { id: 'pending', text: 'Pending' },
  { id: 'completed', text: 'Completed' },
  { id: 'skipped', text: 'Skipped/Not Done' },
];

const NonMedicationTasks: React.FC<NonMedicationTasksProps> = ({ patientUuid }) => {
  const { t } = useTranslation();

  // Shift Management State
  const [shiftStart, setShiftStart] = useState<number>(() => {
    const now = new Date();
    const hours = now.getHours();
    const alignedHour = Math.floor(hours / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
    const shiftStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), alignedHour, 0, 0);
    return shiftStart.getTime();
  });

  const [filterValue, setFilterValue] = useState(FILTERS[1]);
  const [isAcknowledgeModalOpen, setIsAcknowledgeModalOpen] = useState(false);
  const [selectedTaskUuid, setSelectedTaskUuid] = useState<string | null>(null);
  const [acknowledgeNotes, setAcknowledgeNotes] = useState('Acknowledged');

  const apiStatus = useMemo(() => {
    if (filterValue.id === 'pending') return 'REQUESTED,IN_PROGRESS';
    if (filterValue.id === 'completed') return 'completed';
    if (filterValue.id === 'skipped') return 'Cancelled';
    return undefined;
  }, [filterValue.id]);

  let tasksUrl = `${restBaseUrl}/ipd/tasks?patient=${patientUuid}`;
  if (apiStatus) {
    tasksUrl += `&status=${apiStatus}`;
  }

  const { data, error, isLoading, mutate } = useSWR<any, Error>(tasksUrl, openmrsFetch);
  const tasks: NursingTask[] = data?.data?.results ?? [];

  const handleStatusUpdate = async (uuid: string, status: 'COMPLETED' | 'CANCELLED') => {
    try {
      await updateNursingTask(uuid, {
        status,
        executionEndTime: new Date().toISOString(),
      });
      mutate();
    } catch (err) {
      console.error('Failed to update task status', err);
    }
  };

  const handleAcknowledgeClick = (uuid: string) => {
    setSelectedTaskUuid(uuid);
    setAcknowledgeNotes('Acknowledged');
    setIsAcknowledgeModalOpen(true);
  };

  const handleAcknowledgeSubmit = async () => {
    if (selectedTaskUuid) {
      try {
        await acknowledgeNursingTask(selectedTaskUuid, acknowledgeNotes);
        setIsAcknowledgeModalOpen(false);
        mutate();
      } catch (err) {
        console.error('Failed to acknowledge task', err);
      }
    }
  };

  const shiftEnd = shiftStart + SHIFT_MILI;

  const rows = useMemo(() => {
    return tasks
      .filter((task) => {
        const startStr = task.executionPeriod?.start;
        if (!startStr) return false;
        const taskTime = new Date(startStr).getTime();
        return taskTime >= shiftStart && taskTime < shiftEnd;
      })
      .map((task) => ({
        id: task.uuid,
        name: resolveDisplayName(task.name),
        scheduledTime: task.executionPeriod?.start
          ? new Date(task.executionPeriod.start).toLocaleString()
          : t('notScheduled', 'Not Scheduled'),
        status: task.status,
        actions: task.status,
      }));
  }, [tasks, t, shiftStart, shiftEnd]);

  const handleNextShift = () => setShiftStart((prev) => prev + SHIFT_MILI);
  const handlePrevShift = () => setShiftStart((prev) => prev - SHIFT_MILI);
  const handleCurrentShift = () => {
    const now = new Date();
    const hours = now.getHours();
    const alignedHour = Math.floor(hours / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
    const shiftStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), alignedHour, 0, 0);
    setShiftStart(shiftStart.getTime());
  };

  const headers = [
    { key: 'name', header: t('taskName', 'Task Name') },
    { key: 'scheduledTime', header: t('scheduledTime', 'Scheduled Time') },
    { key: 'status', header: t('status', 'Status') },
    { key: 'actions', header: t('actions', 'Actions') },
  ];

  if (error) {
    return <InlineNotification kind="error" title={t('error', 'Error')} subtitle={error.message} />;
  }

  const shiftStartStr = new Date(shiftStart).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const shiftEndStr = new Date(shiftEnd).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className={styles.container}>
      <div className={styles.filtersWrapper}>
        <div className={styles.shiftControls}>
          <Button kind="tertiary" size="sm" onClick={handleCurrentShift}>
            {t('currentShift', 'Current Shift')}
          </Button>
          <div className={styles.shiftButtons}>
            <Button
              kind="tertiary"
              renderIcon={ChevronLeft}
              hasIconOnly
              size="sm"
              onClick={handlePrevShift}
              iconDescription={t('previousShift', 'Previous Shift')}
            />
            <Button
              kind="tertiary"
              renderIcon={ChevronRight}
              hasIconOnly
              size="sm"
              onClick={handleNextShift}
              iconDescription={t('nextShift', 'Next Shift')}
            />
          </div>
          <div className={styles.shiftTime}>
            <strong>{shiftStartStr}</strong> - <strong>{shiftEndStr}</strong>
          </div>
        </div>
        <div className={styles.statusFilter}>
          <Dropdown
            id="task-filter"
            titleText={t('filterTasks', 'Filter Tasks')}
            hideLabel
            label={t('filterTasks', 'Filter Tasks')}
            items={FILTERS}
            itemToString={(item: any) => item.text}
            selectedItem={filterValue}
            onChange={({ selectedItem }) => selectedItem && setFilterValue(selectedItem)}
            size="sm"
          />
        </div>
      </div>

      {isLoading ? (
        <DataTableSkeleton rowCount={5} columnCount={headers.length} />
      ) : (
        <DataTable rows={rows} headers={headers}>
          {({ rows, headers, getHeaderProps, getTableProps, getTableContainerProps }) => (
            <TableContainer {...getTableContainerProps()}>
              <Table {...getTableProps()} size="sm">
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader {...getHeaderProps({ header })} key={header.key}>
                        {header.header}
                      </TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={headers.length} className={styles.emptyCell}>
                        {t('noTasksForFilter', 'No active tasks for this filter in the current shift')}
                      </TableCell>
                    </TableRow>
                  ) : (
                    rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => {
                          if (cell.info.header === 'status') {
                            const status = cell.value;
                            let type: any = 'neutral';
                            if (status === 'COMPLETED' || status === 'completed') type = 'green';
                            if (status === 'CANCELLED' || status === 'Cancelled') type = 'red';
                            if (status === 'REQUESTED' || status === 'IN_PROGRESS') type = 'blue';
                            return (
                              <TableCell key={cell.id}>
                                <Tag type={type}>{status}</Tag>
                              </TableCell>
                            );
                          }
                          if (cell.info.header === 'actions') {
                            const status = cell.value;
                            return (
                              <TableCell key={cell.id}>
                                <div className={styles.actionButtons}>
                                  {(status === 'REQUESTED' || status === 'IN_PROGRESS') && (
                                    <>
                                      <Button
                                        kind="ghost"
                                        hasIconOnly
                                        renderIcon={Checkmark}
                                        iconDescription={t('complete', 'Complete')}
                                        size="sm"
                                        onClick={() => handleStatusUpdate(row.id, 'COMPLETED')}
                                      />
                                      <Button
                                        kind="ghost"
                                        hasIconOnly
                                        renderIcon={Close}
                                        iconDescription={t('cancel', 'Cancel')}
                                        size="sm"
                                        onClick={() => handleStatusUpdate(row.id, 'CANCELLED')}
                                      />
                                    </>
                                  )}
                                  {(status === 'COMPLETED' || status === 'completed') && (
                                    <Button
                                      kind="ghost"
                                      hasIconOnly
                                      renderIcon={Stamp}
                                      iconDescription={t('acknowledge', 'Acknowledge')}
                                      size="sm"
                                      onClick={() => handleAcknowledgeClick(row.id)}
                                    />
                                  )}
                                </div>
                              </TableCell>
                            );
                          }
                          return <TableCell key={cell.id}>{cell.value}</TableCell>;
                        })}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>
      )}

      <Modal
        open={isAcknowledgeModalOpen}
        modalHeading={t('acknowledgeTask', 'Acknowledge Task')}
        primaryButtonText={t('acknowledge', 'Acknowledge')}
        secondaryButtonText={t('cancel', 'Cancel')}
        onRequestClose={() => setIsAcknowledgeModalOpen(false)}
        onRequestSubmit={handleAcknowledgeSubmit}
        size="xs"
      >
        <TextArea
          id="acknowledge-notes"
          labelText={t('notes', 'Notes')}
          value={acknowledgeNotes}
          onChange={(e) => setAcknowledgeNotes(e.target.value)}
          rows={3}
        />
      </Modal>
    </div>
  );
};

export default NonMedicationTasks;
