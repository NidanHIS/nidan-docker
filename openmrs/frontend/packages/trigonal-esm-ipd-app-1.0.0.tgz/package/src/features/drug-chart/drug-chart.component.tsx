import React, { useMemo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  DataTable,
  InlineLoading,
  OverflowMenu,
  OverflowMenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  Tooltip,
} from '@carbon/react';
import { Add, ChevronLeft, ChevronRight, Time, WarningAlt } from '@carbon/react/icons';
import { launchWorkspace2, useConfig } from '@openmrs/esm-framework';
import type { IpdConfig } from '../../config-schema';
import dayjs from 'dayjs';
import { useRtl } from '../../utils/use-rtl';
import { resolveDisplayName } from '../../utils/display';
import type { MedicationSchedule, MedicationSlot } from '../../types';
import styles from './drug-chart.scss';

type ShiftDetails = Record<string, { shiftStartTime: string; shiftEndTime: string }>;

const DEFAULT_SHIFTS: ShiftDetails = {
  '1': { shiftStartTime: '08:00', shiftEndTime: '19:00' },
  '2': { shiftStartTime: '19:00', shiftEndTime: '08:00' },
};

function parseHHMM(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

function computeShiftEnd(shiftStart: number, shiftDetails: ShiftDetails): number {
  const d = new Date(shiftStart);
  const startMinsOfDay = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    if (parseHHMM(shiftStartTime) === startMinsOfDay) {
      const endMins = parseHHMM(shiftEndTime);
      const endDate = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(endMins / 60), endMins % 60, 0);
      if (endDate.getTime() <= shiftStart) endDate.setDate(endDate.getDate() + 1);
      return endDate.getTime();
    }
  }
  return shiftStart + 12 * 60 * 60 * 1000; // fallback 12h
}

function computeCurrentShiftStart(now: number, shiftDetails: ShiftDetails): number {
  const d = new Date(now);
  const nowMins = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    const startMins = parseHHMM(shiftStartTime);
    const endMins = parseHHMM(shiftEndTime);
    if (endMins > startMins) {
      // Normal shift (no midnight crossing)
      if (nowMins >= startMins && nowMins < endMins) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
    } else {
      // Overnight shift (e.g. 19:00 → 08:00)
      if (nowMins >= startMins) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
      if (nowMins < endMins) {
        const prev = new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1);
        return new Date(prev.getFullYear(), prev.getMonth(), prev.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
    }
  }
  // Fallback: first shift start today
  const first = Object.values(shiftDetails)[0];
  const sm = parseHHMM(first.shiftStartTime);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(sm / 60), sm % 60, 0).getTime();
}

function computePrevShiftStart(currentShiftStart: number, shiftDetails: ShiftDetails): number {
  const d = new Date(currentShiftStart);
  const currentStartMins = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    if (parseHHMM(shiftEndTime) === currentStartMins) {
      const prevStartMins = parseHHMM(shiftStartTime);
      let prevStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(prevStartMins / 60), prevStartMins % 60, 0).getTime();
      if (prevStart >= currentShiftStart) prevStart -= 24 * 60 * 60 * 1000;
      return prevStart;
    }
  }
  // Fallback: step back by current shift duration
  return currentShiftStart - (computeShiftEnd(currentShiftStart, shiftDetails) - currentShiftStart);
}

/** Colour coding for slot administration status */
const STATUS_TAG_TYPE: Record<string, 'green' | 'blue' | 'red' | 'gray'> = {
  COMPLETED: 'green',
  ADMINISTERED: 'green',
  // ADMINISTERED_LATE: 'red',
  SCHEDULED: 'blue',
  MISSED: 'red',
  NOT_DONE: 'gray',
  STOPPED: 'red'
};

interface SlotCellProps {
  slots: MedicationSlot[];
  hour: string;
  schedule: MedicationSchedule;
  patientUuid: string;
  visitUuid: string;
  mutateTaskList?: () => void;
  className?: string;
}

const renderTag = (
  slot: MedicationSlot,
  patientUuid: string,
  visitUuid: string,
  schedule: MedicationSchedule,
  t: any,
  mutateTaskList?: () => void,
) => {
  const tagType = STATUS_TAG_TYPE[slot.status] ?? 'gray';
  const labelKey = `slotStatus${slot.status.charAt(0) + slot.status.slice(1).toLowerCase().replace(/_([a-z])/g, (_, c) => c.toUpperCase())}`;

  return (
    <Tooltip
      key={slot.uuid}
      label={
        slot.administeredDateTime
          ? `${t(labelKey, slot.status)} — ${dayjs(slot.administeredDateTime).format('HH:mm')} by ${slot.administeredBy?.display ?? '—'}`
          : t(labelKey, slot.status)
      }
      align="bottom"
    >
      <Tag
        type={tagType as any}
        size="sm"
        className={styles.slotTag}
        onClick={
          slot.status === 'SCHEDULED'
            ? () => {
              const sortedSlots = [...(schedule.slots || [])].sort((a, b) => dayjs(a.scheduledDate).valueOf() - dayjs(b.scheduledDate).valueOf());
              const nextSlot = sortedSlots.find((s) => dayjs(s.scheduledDate).valueOf() > dayjs(slot.scheduledDate).valueOf());
              launchWorkspace2('record-ipd-task', {
                tasks: [{
                  ...slot,
                  orderUuid: schedule.uuid,
                  name: schedule.drug.name || (schedule.drug as any).display || 'Medication',
                  dosage:
                    schedule.dose && schedule.doseUnits ? `${schedule.dose} ${schedule.doseUnits.display}` : undefined,
                  dose: schedule.dose,
                  doseUnitsUuid: schedule.doseUnits?.uuid,
                  route: schedule.route?.display,
                  status: slot.status,
                  isMedication: true,
                  scheduledTime: slot.scheduledDate,
                  nextScheduledTime: nextSlot?.scheduledDate,
                }],
                mutateTaskList,
              });
            }
            : undefined
        }
      >
        {slot.status === 'SCHEDULED' ? '+' : slot.status.charAt(0)}
      </Tag>
    </Tooltip>
  );
};

const SlotCell: React.FC<SlotCellProps> = ({ slots, hour, schedule, patientUuid, visitUuid, mutateTaskList, className }) => {
  const { t } = useTranslation();

  if (!slots || slots.length === 0) {
    return <TableCell key={hour} className={className} />;
  }

  return (
    <TableCell className={className}>
      <div className={styles.cellContent}>
        {slots.map((s) => renderTag(s, patientUuid, visitUuid, schedule, t, mutateTaskList))}
      </div>
    </TableCell>
  );
};

interface DrugChartProps {
  schedules: MedicationSchedule[];
  patientUuid: string;
  visitUuid: string;
  isLoading?: boolean;
  onAddMedication: () => void;
  mutateTaskList?: () => void;
}

/**
 * DrugChartSection — IPD-01
 *
 * Renders a scrollable 24-hour timeline grid.
 *
 * Layout:
 *   Column 1 (sticky): Drug name + dose/route/frequency
 *   Columns 2-25:      Each hour of the currently viewed day
 *
 * The user can page between days with the chevron buttons.
 * Slot cells are clickable when SCHEDULED — they open the
 * "record-ipd-task" workspace.
 *
 * Migration note: replaces the legacy `Calendar.jsx` + `CalendarRow.jsx` +
 * `CalendarHeader.jsx` which used a custom Swiper-based horizontal scroll
 * and manually managed window resize listeners.
 */
const DrugChart: React.FC<DrugChartProps> = ({
  schedules,
  patientUuid,
  visitUuid,
  isLoading,
  onAddMedication,
  mutateTaskList,
}) => {
  const { t } = useTranslation();
  const isRtl = useRtl();
  const config = useConfig<IpdConfig>();
  const shiftDetails: ShiftDetails = config?.shiftDetails ?? DEFAULT_SHIFTS;

  // Shift Management State — initialised from config shift windows
  const [shiftStart, setShiftStart] = useState<number>(() => computeCurrentShiftStart(Date.now(), shiftDetails));

  const shiftEnd = computeShiftEnd(shiftStart, shiftDetails);

  const handleNextShift = () => setShiftStart((prev) => computeShiftEnd(prev, shiftDetails));
  const handlePrevShift = () => setShiftStart((prev) => computePrevShiftStart(prev, shiftDetails));
  const handleCurrentShift = () => setShiftStart(computeCurrentShiftStart(Date.now(), shiftDetails));

  useEffect(() => {
    const handleRefresh = () => mutateTaskList?.();
    window.addEventListener('ipd:medication-refresh', handleRefresh);
    return () => window.removeEventListener('ipd:medication-refresh', handleRefresh);
  }, [mutateTaskList]);

  /*
   * In RTL layouts the visual "left" is the document's inline-end side,
   * so the chevron icons are swapped to match reading direction.
   * ChevronLeft visually points toward the past in LTR but toward the
   * future in RTL — so we reverse them when dir="rtl".
   */
  const PrevIcon = isRtl ? ChevronRight : ChevronLeft;
  const NextIcon = isRtl ? ChevronLeft : ChevronRight;

  const shiftHours = useMemo(() => {
    const hours = [];
    for (let t = shiftStart; t < shiftEnd; t += 30 * 60 * 1000) {
      hours.push({
        key: dayjs(t).format('hh:mm A'),
        timestamp: t,
      });
    }
    return hours;
  }, [shiftStart, shiftEnd]);

  /**
   * For each schedule, build a lookup map: hourString → MedicationSlot
   * so the grid render is O(1) per cell.
   */
  const slotsByScheduleAndHour = useMemo(() => {
    return schedules.map((schedule) => {
      const hourMap = new Map<string, MedicationSlot[]>();
      schedule.slots?.forEach((slot) => {
        if (slot.serviceType === 'AsNeededPlaceholder' || (slot.status === 'SCHEDULED' && slot.order?.asNeeded)) return;

        const slotTime = dayjs(slot.scheduledDate).valueOf();
        if (slotTime >= shiftStart && slotTime < shiftEnd) {
          const minutes = dayjs(slot.scheduledDate).minute();
          const bucketMin = minutes >= 30 ? '30' : '00';
          const hourKey = dayjs(slot.scheduledDate).format(`hh:${bucketMin} A`);
          if (!hourMap.has(hourKey)) hourMap.set(hourKey, []);
          hourMap.get(hourKey)!.push(slot);
        }
      });
      return { schedule, hourMap };
    });
  }, [schedules, shiftStart, shiftEnd]);

  const drugHeaders = [
    { key: 'drug', header: t('drug', 'Drug') },
    ...shiftHours.map((h) => {
      const [time, period] = h.key.split(' ');
      return {
        key: h.key,
        header: (
          <div className={styles.hourText}>
            <div>{time}</div>
            <div>{period}</div>
          </div>
        )
      };
    }),
  ];

  const rows = slotsByScheduleAndHour.map(({ schedule, hourMap }) => {
    const adminSlots = schedule.slots?.filter((s) => {
      const isStatusValid = ['COMPLETED'].includes((s as any).status);
      const adminTime = dayjs(s.administeredDateTime || s.scheduledDate).valueOf();
      return isStatusValid && adminTime >= shiftStart && adminTime < shiftEnd;
    }) || [];

    return {
      id: schedule.uuid,
      drug: (
        <div className={styles.drugCell}>
          <span className={styles.drugName}>{resolveDisplayName(schedule.drug.name)}</span>
          <span className={styles.drugMeta}>
            {resolveDisplayName(schedule.dose)} {resolveDisplayName(schedule.doseUnits?.display)} · {resolveDisplayName(schedule.route?.display)} ·{' '}
            {resolveDisplayName(schedule.frequency?.display)}
          </span>
          {adminSlots.length > 0 && (
            <div className={styles.adminHistory}>
              <Time size={16} />
              {adminSlots.map((s, idx) => {
                const isLate = (s as any).status === 'ADMINISTERED_LATE' || dayjs(s.administeredDateTime).diff(s.scheduledDate, 'minute') > 30;
                const timeStr = dayjs(s.administeredDateTime || s.scheduledDate).format('HH:mm');
                return (
                  <span key={s.uuid} className={isLate ? styles.lateAdmin : styles.adminTime}>
                    {timeStr}{idx !== adminSlots.length - 1 ? ',' : ''}
                  </span>
                );
              })}
            </div>
          )}
        </div>
      ),
      ...Object.fromEntries(shiftHours.map((h) => [h.key, { slots: hourMap.get(h.key) || [], hour: h.key, timestamp: h.timestamp }])),
    };
  });

  const shiftEndStr = new Date(shiftEnd).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const shiftStartStr = new Date(shiftStart).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  
  const isNotCurrentShift = shiftStart !== computeCurrentShiftStart(Date.now(), shiftDetails);

  if (isLoading) {
    return <InlineLoading description={t('loadingDrugChart', 'Loading drug chart…')} />;
  }

  if (schedules.length === 0) {
    return (
      <div className={styles.emptyState}>
        <p>{t('noMedications', 'No medications scheduled')}</p>
        {/* <Button kind="ghost" size="sm" renderIcon={Add} onClick={onAddMedication}>
          {t('addMedication', 'Add Medication')}
        </Button> */}
      </div>
    );
  }

  return (
    <div className={styles.drugChart}>
      {/* ── Date navigator ─────────────────────────────────────────── */}
      <div className={styles.dateNav}>
        <div className={styles.shiftControls}>
          <Button kind="tertiary" size="sm" onClick={handleCurrentShift}>
            {t('currentShift', 'Current Shift')}
          </Button>
          <div className={styles.shiftButtons}>
            <Button kind="tertiary" renderIcon={PrevIcon} hasIconOnly size="sm" onClick={handlePrevShift} iconDescription={t('previousShift', 'Previous Shift')} />
            <Button kind="tertiary" renderIcon={NextIcon} hasIconOnly size="sm" onClick={handleNextShift} iconDescription={t('nextShift', 'Next Shift')} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', fontSize: '0.85rem' }}>
            {isNotCurrentShift && (
              <span style={{ color: '#da1e28', marginBottom: '0.25rem' }}>
                <WarningAlt size={10} />{t('notCurrentShiftWarning', " You're not viewing the current shift")}
              </span>
            )}
            <div>
              <strong>{shiftStartStr}</strong> - <strong>{shiftEndStr}</strong>
            </div>
          </div>
        </div>
        <div className={styles.dateNavSpacer} />
      </div>

      {/* ── Legend ────────────────────────────────────────────────── */}
      <div className={styles.legend}>
        {(Object.entries(STATUS_TAG_TYPE) as Array<[MedicationSlot['status'], string]>).map(
          ([status, tagType]) => (
            <Tag key={status} type={tagType as 'green' | 'blue' | 'red' | 'gray'} size="sm">
              {t(`slotStatus${status.charAt(0) + status.slice(1).toLowerCase()}`, status)}
            </Tag>
          ),
        )}
      </div>

      {/* ── Timeline grid ─────────────────────────────────────────── */}
      <div className={styles.tableWrapper}>
        <DataTable key={shiftStart} rows={rows} headers={drugHeaders}>
          {({ rows: tableRows, headers, getTableProps, getHeaderProps, getRowProps }) => (
            <TableContainer>
              <Table {...getTableProps()} className={styles.timelineTable}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => {
                      const { onClick, ...rest } = getHeaderProps({ header });
                      const shiftHour = shiftHours.find(sh => sh.key === header.key);
                      const isCurrent = shiftHour ? Date.now() >= shiftHour.timestamp && Date.now() < shiftHour.timestamp + 30 * 60 * 1000 : false;
                      const isHalfHour = header.key.includes(':30');

                      let headerClass = header.key === 'drug' ? styles.stickyCol : styles.hourHeader;
                      if (header.key !== 'drug') {
                        headerClass = `${headerClass} ${isHalfHour ? styles.halfHour : styles.fullHour}`;
                      }

                      return (
                        <TableHeader
                          {...rest}
                          className={headerClass}
                          onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                        >
                          {header.header}
                        </TableHeader>
                      );
                    })}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tableRows.map((row) => {
                    const schedule = schedules.find((s) => s.uuid === row.id)!;
                    return (
                      <TableRow {...getRowProps({ row })} key={row.id}>
                        {row.cells.map((cell) => {
                          if (cell.info.header === 'drug') {
                            return (
                              <TableCell key={cell.id} className={styles.stickyCol}>
                                {cell.value}
                              </TableCell>
                            );
                          }
                          const { slots, hour, timestamp } = cell.value as { slots: MedicationSlot[]; hour: string; timestamp: number };
                          const isCurrent = Date.now() >= timestamp && Date.now() < timestamp + 30 * 60 * 1000;
                          const isHalfHour = hour.includes(':30');
                          const cellClass = `${styles.slotCell} ${isCurrent ? styles.currentCol : ''} ${isHalfHour ? styles.halfHour : styles.fullHour}`;

                          return (
                            <SlotCell
                              key={cell.id}
                              slots={slots}
                              hour={hour}
                              schedule={schedule}
                              patientUuid={patientUuid}
                              visitUuid={visitUuid}
                              mutateTaskList={mutateTaskList}
                              className={cellClass}
                            />
                          );
                        })}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>
      </div>
    </div>
  );
};

export default DrugChart;
