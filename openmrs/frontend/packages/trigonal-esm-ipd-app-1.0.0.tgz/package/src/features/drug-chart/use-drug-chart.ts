import { useMemo } from 'react';
import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import type { MedicationSchedule, MedicationSlot } from '../../types';

/* ──────────────────────────────────────────────────────────────────────────────
 * API 1: Medication Orders response types
 * GET /ws/rest/v1/ipdVisit/{visitUuid}/medication?includes=emergencyMedications
 * ──────────────────────────────────────────────────────────────────────────── */

interface DrugOrderScheduleInfo {
  firstDaySlotsStartTime: number[] | null;
  dayWiseSlotsStartTime: number[] | null;
  remainingDaySlotsStartTime: number[] | null;
  slotStartTime: number | null;
  medicationAdministrationStarted: boolean;
  pendingSlotsAvailable: boolean;
  allSlotsAttended: boolean;
  notes: string | null;
}

interface IpdDrugOrder {
  orderUuid: string;
  drugName: string;
  dose: number;
  doseUnitsName: string;
  routeName: string;
  durationUnitsName: string;
  duration: number;
  quantity: number;
  quantityUnitsName: string;
  frequency: string;
  asNeeded: boolean;
  action: string;
  orderSetUuid: string | null;
  providerUuid: string;
  providerName: string;
  drugOrderSchedule: DrugOrderScheduleInfo;
}

interface EmergencyMedication {
  uuid: string;
  patientUuid: string;
  drug: { uuid: string; display: string };
  dose: number;
  doseUnits: string | null;
  route: string | null;
  administeredDateTime: number; // unix milliseconds
  status: string;
  notes: Array<{
    uuid: string;
    text: string;
    author: { uuid: string; display: string };
    recordedTime: number;
  }>;
  providers: Array<{
    uuid: string;
    provider: { uuid: string; display: string };
    function: string | null;
  }>;
  dosingInstructions: string | null;
  site: string | null;
}

interface MedicationOrdersResponse {
  ipdDrugOrders: IpdDrugOrder[];
  emergencyMedications: EmergencyMedication[];
}

/* ──────────────────────────────────────────────────────────────────────────────
 * API 2: Drug Chart Slots response types
 * GET /ws/rest/v1/ipd/schedule/type/medication?patientUuid=...&startTime=...&endTime=...&view=drugChart&visitUuid=...
 * ──────────────────────────────────────────────────────────────────────────── */

interface DrugChartSlotOrder {
  uuid: string;
  drug?: { uuid: string; display: string };
  dose?: number;
  doseUnits?: { uuid: string; display: string };
  route?: { uuid: string; display: string };
  frequency?: { uuid: string; display: string };
  dateActivated?: string;
  autoExpireDate?: string;
  display?: string;
  orderer?: { uuid: string; display: string };
}

interface SlotMedicationAdministration {
  uuid: string;
  administeredDateTime?: string;
  provider?: { uuid: string; display: string };
  status?: string;
}

interface DrugChartSlot {
  id: number;
  uuid: string;
  serviceType: string;
  status: string;
  startTime: number; // unix seconds
  order: DrugChartSlotOrder;
  medicationAdministration: SlotMedicationAdministration | null;
  notes: string | null;
}

/* ──────────────────────────────────────────────────────────────────────────────
 * Mapping helpers
 * ──────────────────────────────────────────────────────────────────────────── */

/**
 * Convert an API slot into the `MedicationSlot` shape consumed by `DrugChart`.
 * `startTime` from the schedule API is in **unix seconds**.
 */
function mapSlotToMedicationSlot(slot: DrugChartSlot): MedicationSlot {
  const scheduledDate = new Date(slot.startTime * 1000).toISOString();

  return {
    uuid: slot.uuid,
    scheduledDate,
    status: slot.status as MedicationSlot['status'],
    administeredDateTime: slot.medicationAdministration?.administeredDateTime ?? undefined,
    administeredBy: slot.medicationAdministration?.provider
      ? {
          uuid: slot.medicationAdministration.provider.uuid,
          display: slot.medicationAdministration.provider.display,
        }
      : undefined,
    notes: slot.notes ?? undefined,
  };
}

/**
 * Build `MedicationSchedule[]` following the legacy `mapDrugOrdersAndSlots` pattern:
 *
 *   1. Create a `medicationLookup` map from API 1 `ipdDrugOrders` keyed by `orderUuid`.
 *      Only orders with a `drugOrderSchedule` are eligible (same as legacy).
 *   2. Iterate through each slot from API 2 and push it into the matching order's
 *      slot list via `medicationLookup`.  **Orders without any matching slots are
 *      excluded** — this is the critical difference from the prior implementation.
 *   3. Emit only orders that ended up with ≥ 1 slot, sorted by first slot time.
 *   4. Append emergency medications as single-slot administered entries (unchanged).
 */
function buildMedicationSchedules(
  drugOrders: IpdDrugOrder[],
  emergencyMeds: EmergencyMedication[],
  slots: DrugChartSlot[],
): MedicationSchedule[] {
  // ── Step 1: Build medicationLookup from API 1 ────────────────────────────
  // Each entry stores the order metadata + an initially empty `mappedSlots` array.
  const medicationLookup = new Map<
    string,
    { order: IpdDrugOrder; mappedSlots: MedicationSlot[]; firstSlotTime: number }
  >();

  drugOrders.forEach((order) => {
    // Legacy guard: only orders with a drugOrderSchedule are chart-eligible
    if (order.drugOrderSchedule) {
      medicationLookup.set(order.orderUuid, {
        order,
        mappedSlots: [],
        firstSlotTime:
          order.drugOrderSchedule.slotStartTime ??
          order.drugOrderSchedule.firstDaySlotsStartTime?.[0] ??
          order.drugOrderSchedule.dayWiseSlotsStartTime?.[0] ??
          Infinity,
      });
    }
  });

  // ── Step 2: Walk API 2 slots and push each into its matching order ───────
  slots.forEach((slot) => {
    const orderUuid = slot.order?.uuid;
    if (!orderUuid) return;

    const entry = medicationLookup.get(orderUuid);
    if (entry) {
      // Matching order found in the lookup → attach this slot
      entry.mappedSlots.push(mapSlotToMedicationSlot(slot));
    }
    // Slots whose order is NOT in the lookup are intentionally skipped
    // (they belong to orders that have no drugOrderSchedule / are irrelevant).
  });

  // ── Step 3: Emit only orders that ended up with ≥ 1 slot ────────────────
  const schedules: MedicationSchedule[] = [];

  const entries = Array.from(medicationLookup.values())
    .filter((e) => e.mappedSlots.length > 0)
    .sort((a, b) => a.firstSlotTime - b.firstSlotTime);

  entries.forEach(({ order, mappedSlots }) => {
    schedules.push({
      uuid: order.orderUuid,
      drug: {
        uuid: order.orderUuid,
        name: order.drugName,
        display: order.drugName,
      },
      dose: order.dose,
      doseUnits: { uuid: '', display: order.doseUnitsName },
      frequency: { uuid: '', display: order.frequency },
      route: { uuid: '', display: order.routeName },
      startDate: '',
      slots: mappedSlots,
    });
  });

  // ── Step 4: Append emergency medications (always shown) ──────────────────
  emergencyMeds.forEach((med) => {
    const adminTime = med.administeredDateTime
      ? new Date(med.administeredDateTime).toISOString()
      : '';
    const providerDisplay =
      med.providers?.find((p) => p.provider)?.provider?.display ?? '';

    schedules.push({
      uuid: med.uuid,
      drug: {
        uuid: med.drug?.uuid ?? med.uuid,
        name: med.drug?.display ?? 'Unknown',
        display: med.drug?.display ?? 'Unknown',
      },
      dose: med.dose ?? 0,
      doseUnits: { uuid: '', display: med.doseUnits ?? '' },
      frequency: { uuid: '', display: 'Emergency' },
      route: { uuid: '', display: med.route ?? '' },
      startDate: adminTime,
      slots: [
        {
          uuid: med.uuid,
          scheduledDate: adminTime,
          status: 'COMPLETED' as const,
          administeredDateTime: adminTime || undefined,
          administeredBy: providerDisplay
            ? { uuid: '', display: providerDisplay }
            : undefined,
          notes: med.notes?.map((n) => n.text).join('; ') || undefined,
        },
      ],
    });
  });

  return schedules;
}

/* ──────────────────────────────────────────────────────────────────────────────
 * useDrugChart — main data-fetching hook
 * ──────────────────────────────────────────────────────────────────────────── */

/**
 * Fetches medication orders + scheduled drug-chart slots for a patient visit
 * and returns a unified `MedicationSchedule[]` for the `DrugChart` component.
 *
 * @param patientUuid – Patient UUID (required for slots API)
 * @param visitUuid   – Active visit UUID (required for both APIs)
 */
export function useDrugChart(
  patientUuid: string | undefined,
  visitUuid: string | undefined,
) {
  // ── API 1: Medication Orders ─────────────────────────────────────────────
  const medicationUrl = visitUuid
    ? `${restBaseUrl}/ipdVisit/${visitUuid}/medication?includes=emergencyMedications`
    : null;

  const {
    data: medicationResponse,
    error: medicationError,
    isLoading: medicationLoading,
    mutate: mutateMedications,
  } = useSWR<FetchResponse<MedicationOrdersResponse>, Error>(
    medicationUrl,
    openmrsFetch,
  );

  const medicationData = medicationResponse?.data;

  // ── API 2: Drug Chart Slots ──────────────────────────────────────────────
  // Wide range spanning ±30 days from today; the DrugChart component filters
  // by the user-selected day internally.
  const startTime = useMemo(() => dayjs().subtract(30, 'day').startOf('day').unix(), []);
  const endTime = useMemo(() => dayjs().add(30, 'day').endOf('day').unix(), []);

  const slotsUrl =
    patientUuid && visitUuid
      ? `${restBaseUrl}/ipd/schedule/type/medication` +
        `?patientUuid=${patientUuid}` +
        `&startTime=${startTime}` +
        `&endTime=${endTime}` +
        `&view=drugChart` +
        `&visitUuid=${visitUuid}`
      : null;

  // The schedule API can return either:
  //   a) A wrapped format: [{ slots: DrugChartSlot[], startDate?: number }]
  //      (legacy format, as seen in DrugChartUtils.js line 121)
  //   b) A flat array: DrugChartSlot[]
  // We handle both by inspecting the response shape.
  const {
    data: slotsData,
    error: slotsError,
    isLoading: slotsLoading,
    mutate: mutateSlots,
  } = useSWR<DrugChartSlot[], Error>(
    slotsUrl,
    (u: string) =>
      openmrsFetch<any>(u).then((r) => {
        const raw = r.data;

        // Wrapped format: [{ slots: [...] }]
        if (Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0]?.slots)) {
          return raw[0].slots as DrugChartSlot[];
        }
        // Flat array of slot objects
        if (Array.isArray(raw)) {
          return raw as DrugChartSlot[];
        }
        // Unexpected — return empty
        return [] as DrugChartSlot[];
      }),
  );

  // ── Combine both responses ───────────────────────────────────────────────
  const schedules = useMemo(() => {
    if (!medicationData) return [];

    return buildMedicationSchedules(
      medicationData.ipdDrugOrders ?? [],
      medicationData.emergencyMedications ?? [],
      slotsData ?? [],
    );
  }, [medicationData, slotsData]);

  return {
    schedules,
    isLoading: medicationLoading || slotsLoading,
    error: medicationError || slotsError,
    mutate: () => {
      mutateMedications();
      mutateSlots();
    },
  };
}
