import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export interface PatientDiagnosis {
  uuid: string;
  diagnosisDateTime?: string;
  certainty?: string;
  order?: string;
  status?: string;
  diagnosis?: {
    display?: string;
    codedAnswer?: {
      name?: string;
      display?: string;
    };
    freeTextAnswer?: string;
  };
  encounter?: {
    encounterDatetime?: string;
  };
  [key: string]: any;
}

/**
 * Fetches the patient's existing diagnoses from the REST API.
 * Uses the standard context path `/ws/rest/v1/encounter` with embedded diagnoses.
 * @param patientUuid - The UUID of the patient
 */
export function usePatientDiagnoses(patientUuid: string) {
  const customRep = 'custom:(uuid,encounterDatetime,diagnoses:(uuid,display,rank,diagnosis,certainty,voided))';
  const url = patientUuid ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRep}&order=desc` : null;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<{ results: any[] }>, Error>(
    url,
    openmrsFetch,
  );

  const encounters = data?.data?.results || [];

  // Flatten out all diagnoses embedded inside encounters
  const extractedDiagnoses: PatientDiagnosis[] = [];

  encounters.forEach((enc) => {
    if (enc.diagnoses && Array.isArray(enc.diagnoses)) {
      enc.diagnoses.forEach((diag: any) => {
        if (diag.voided) return;

        extractedDiagnoses.push({
          ...diag,
          id: diag.uuid,
          diagnosis: {
            display: diag.diagnosis?.display || diag.display || diag.diagnosis || 'Unknown Diagnosis',
          },
          order: diag.rank === 1 || diag.rank?.toString()?.toLowerCase() === 'primary' ? 'Primary' : (diag.rank === 2 || diag.rank?.toString()?.toLowerCase() === 'secondary' ? 'Secondary' : diag.rank),
          diagnosisDateTime: enc.encounterDatetime,
          encounter: { encounterDatetime: enc.encounterDatetime },
          status: 'Active',
        });
      });
    }
  });

  return {
    diagnoses: extractedDiagnoses,
    isLoading,
    error,
    mutate,
  };
}

