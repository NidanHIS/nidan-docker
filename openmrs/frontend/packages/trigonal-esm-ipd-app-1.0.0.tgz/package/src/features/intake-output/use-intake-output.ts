import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import type { RestApiResult } from '../../types';

const CONCEPTS = {
  DATE_TIME: '258e22bc-c936-4775-95c7-eecaf95d4e6b',
  INTAKE_TYPE: '425a3515-c65f-4915-adf1-c0a4ffdbcf24',
  INTAKE_VOLUME: 'ddf0f3b3-f6bf-4cb3-a47d-d7bd3e56373f',
  RYLES_FEEDING: 'a7e226fa-b6fb-4c73-837b-c5abb6292d0f',
  RYLES_ASPIRATED: 'dc760ec9-60b7-4a4c-938c-902eb766069d',
  URINE_OUTPUT: 'ef7950ea-c6ad-4ecd-82df-f0063f66e194',
  DRAIN_OUTPUT: '280c0703-7bc0-49c5-bd20-2b0e767f15ff',
};

export interface IntakeOutputRecord {
  uuid: string;
  date: string;
  time: string;
  dateTime: string;
  fluidIntakeType: string;
  intakeVolume: number;
  rylesFeeding: number;
  rylesAspirated: number;
  urineOutput: number;
  drainOutput: number;
  totalInput: number;
  totalOutput: number;
}

export function useIntakeOutput(patientUuid: string) {
  const customRepresentation = 'custom:(uuid,display,encounterDatetime,form:(uuid,display,name),obs:(uuid,concept:(uuid,display),value,obsDatetime))';
  const url = `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=de010f04-2eb5-3a9c-afec-587868f3c2fa&v=${customRepresentation}&order=desc&limit=100`;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<RestApiResult<any>>, Error>(url, openmrsFetch);

  const records: IntakeOutputRecord[] = (data?.data?.results || [])
    .map((encounter: any) => {
      const dateTimeObs = encounter.obs?.find((o: any) => o.concept?.uuid === CONCEPTS.DATE_TIME);
      const rawDateTime = dateTimeObs?.value || encounter.encounterDatetime;
      const dt = dayjs(rawDateTime);

      const obsValues: any = {};
      encounter.obs?.forEach((obs: any) => {
        obsValues[obs.concept?.uuid] = obs.value;
      });

      const intakeVolume = parseFloat(obsValues[CONCEPTS.INTAKE_VOLUME]) || 0;
      const rylesFeeding = parseFloat(obsValues[CONCEPTS.RYLES_FEEDING]) || 0;
      const rylesAspirated = parseFloat(obsValues[CONCEPTS.RYLES_ASPIRATED]) || 0;
      const urineOutput = parseFloat(obsValues[CONCEPTS.URINE_OUTPUT]) || 0;
      const drainOutput = parseFloat(obsValues[CONCEPTS.DRAIN_OUTPUT]) || 0;

      return {
        uuid: encounter.uuid,
        date: dt.format('MMM D'),
        time: dt.format('HH:mm'),
        dateTime: dt.toISOString(),
        fluidIntakeType: obsValues[CONCEPTS.INTAKE_TYPE] || '-',
        intakeVolume,
        rylesFeeding,
        rylesAspirated,
        urineOutput,
        drainOutput,
        totalInput: intakeVolume + rylesFeeding,
        totalOutput: rylesAspirated + urineOutput + drainOutput,
      };
    });

  return {
    records,
    isLoading,
    error,
    mutate,
  };
}
