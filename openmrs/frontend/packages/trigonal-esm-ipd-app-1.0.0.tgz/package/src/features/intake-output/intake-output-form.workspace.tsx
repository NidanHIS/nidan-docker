import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  ExtensionSlot,
  useConfig,
  Workspace2,
  type Workspace2DefinitionProps,
} from '@openmrs/esm-framework';
import type { IpdConfig } from '../../config-schema';

export interface IntakeOutputFormProps {
  patientUuid: string;
  visitUuid?: string;
}

const IntakeOutputFormWorkspace: React.FC<Workspace2DefinitionProps<IntakeOutputFormProps>> = ({
  closeWorkspace,
  workspaceProps: { patientUuid, visitUuid },
}) => {
  const { t } = useTranslation();
  const config = useConfig<IpdConfig>();

  return (
    <Workspace2
      title={t('recordIntakeOutput', 'Record Intake/Output')}
    >
      <ExtensionSlot
        name="form-widget-slot"
        state={{
          view: 'form',
          formUuid: config.intakeOutputFormUuid,
          patientUuid,
          visitUuid,
          closeWorkspaceWithSavedChanges: () => {
            closeWorkspace({ discardUnsavedChanges: true });
            // In a real scenario, we might trigger a refresh here:
            // window.dispatchEvent(new CustomEvent('ipd:intake-output-refresh'));
          },
        }}
      />
    </Workspace2>
  );
};

export default IntakeOutputFormWorkspace;
