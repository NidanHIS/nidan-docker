import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  DataTable,
  DataTableSkeleton,
  InlineNotification,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
} from '@carbon/react';
import { usePatientAllergies, type FhirAllergyIntolerance } from '../patient-ipd/use-ipd-patient';
import { resolveDisplayName } from '../../utils/display';
import styles from './allergies.scss';

const CRITICALITY_TAG: Record<NonNullable<FhirAllergyIntolerance['criticality']>, 'red' | 'green' | 'gray'> = {
  high: 'red',
  low: 'green',
  'unable-to-assess': 'gray',
};

type Severity = NonNullable<
  NonNullable<FhirAllergyIntolerance['reaction']>[number]['severity']
>;


const SEVERITY_TAG: Record<Severity, 'red' | 'green' | 'gray'> = {
  severe: 'red',
  mild: 'green',
  moderate: 'gray',
};

const HEADERS = [
  { key: 'allergen', header: 'Allergen' },
  { key: 'category', header: 'Category' },
  { key: 'criticality', header: 'Criticality' },
  // { key: 'severity', header: 'Severity' },
  { key: 'reactions', header: 'Reactions' },
  { key: 'onset', header: 'Onset' },
];

function formatReactions(allergy: FhirAllergyIntolerance): string {
  if (!allergy.reaction?.length) return '—';
  return allergy.reaction
    .flatMap((r) => r.manifestation.map((m) => m.coding?.[0]?.display ?? m.text ?? ''))
    .filter(Boolean)
    .join(', ');
}

interface AllergiesProps {
  patientUuid: string;
}

/**
 * AllergiesSection — IPD-03
 *
 * Renders a full FHIR R4 AllergyIntolerance DataTable.
 *
 * Columns: Allergen | Category | Criticality | Reactions | Onset
 *
 * Migration note: replaces `Allergies.jsx` which rendered a plain
 * ordered list from a non-standard Bahmni response. This component
 * uses the FHIR R4 standard endpoint directly via `usePatientAllergies`.
 *
 * Criticality colouring:
 *   high → red tag, low → yellow tag, unable-to-assess → gray tag.
 */
const Allergies: React.FC<AllergiesProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const { allergies, isLoading, error } = usePatientAllergies(patientUuid);

  if (isLoading) {
    return <DataTableSkeleton columnCount={HEADERS.length} rowCount={3} />;
  }

  if (error) {
    return (
      <InlineNotification
        kind="error"
        title={t('allergiesLoadError', 'Failed to load allergies')}
        subtitle={error.message}
      />
    );
  }

  if (allergies.length === 0) {
    return <p className={styles.empty}>{t('noAllergies', 'No allergies recorded')}</p>;
  }

  const rows = allergies.map((a) => ({
    id: a.id,
    allergen: resolveDisplayName(a.code?.text ?? a.code?.coding?.[0]?.display ?? '—'),
    category: a.category ? a.category.map(c => resolveDisplayName(c)).join(', ') : '—',
    criticality: a.criticality ? (
      <Tag type={CRITICALITY_TAG[a.criticality]} size="sm">
        {t(`criticality_${a.criticality}`, a.criticality)}
      </Tag>
    ) : (
      '—'
    ),
    // severity: a.severity ? (
    //   <Tag type={SEVERITY_TAG[a.severity]} size="sm">
    //     {t(`severity_${a.severity}`, a.severity)}
    //   </Tag>
    // ) : (
    //   '—'
    // ),
    reactions: formatReactions(a),
    onset: a.onsetDateTime ? new Date(a.onsetDateTime).toLocaleDateString() : '—',
  }));

  return (
    <DataTable rows={rows} headers={HEADERS}>
      {({ rows: tableRows, headers, getTableProps, getHeaderProps, getRowProps }) => (
        <TableContainer>
          <Table {...getTableProps()} size="lg">
            <TableHead>
              <TableRow>
                {headers.map((h) => {
                  const { onClick, ...rest } = getHeaderProps({ header: h });
                  return (
                    <TableHeader
                      {...rest}
                      onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                    >
                      {h.header}
                    </TableHeader>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
              {tableRows.map((row) => (
                <TableRow {...getRowProps({ row })} key={row.id}>
                  {row.cells.map((cell) => (
                    <TableCell key={cell.id}>{cell.value}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </DataTable>
  );
};

export default Allergies;
