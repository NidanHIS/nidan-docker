import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type { NursingTask } from '../../types';

export interface CreateTaskPayload {
  name: string;
  description?: string;
  intent: 'ORDER' | 'proposal';
  status: 'REQUESTED';
  priority: 'routine' | 'urgent' | 'stat';
  patient: { uuid: string };
  taskType?: { uuid: string };
  executionPeriod?: { start: string; end?: string };
}

export interface UpdateTaskPayload {
  status: 'COMPLETED' | 'CANCELLED' | 'REQUESTED' | 'IN_PROGRESS' | 'REJECTED';
  comment?: string;
  executionEndTime: number | string;
}

/**
 * POST /ws/rest/v1/ipd/tasks — create a new nursing task.
 *
 * Migration note: replaces the legacy `axios.post(NON_MEDICATION_BASE_URL, payload)`
 * call in the Bahmni IPD add-task form.
 */
export async function createNursingTask(payload: CreateTaskPayload): Promise<NursingTask> {
  const { data } = await openmrsFetch<NursingTask>(`${restBaseUrl}/ipd/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}

/**
 * POST /ws/rest/v1/ipd/tasks/{uuid} — update task status (start/complete/cancel).
 */
/**
 * PUT /ws/rest/v1/tasks — bulk update task status (start/complete/cancel).
 */
export async function updateNursingTask(uuid: string, payload: UpdateTaskPayload): Promise<any> {
  const { data } = await openmrsFetch<any>(`${restBaseUrl}/ipd/tasks/${uuid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}

export async function acknowledgeNursingTask(uuid: string, notes: string): Promise<any> {
  const { data } = await openmrsFetch<any>(`${restBaseUrl}/ipd/tasks/${uuid}/acknowledge`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      acknowledgmentMethod: 'MANUAL_ENTRY',
      notes,
    }),
  });
  return data;
}

const MEDICATIONS_BASE_URL = `${restBaseUrl}/ipd/schedule/type/medication`;
const ADMINISTERED_MEDICATIONS_BASE_URL = `${restBaseUrl}/ipd/scheduledMedicationAdministrations`;

/**
 * GET /ws/rest/v1/bahmni/nursing-task/medicationTasks
 */
export async function fetchMedicationTasks(
  patientUuid: string,
  startTime: number,
  endTime: number,
  visitUuid: string,
) {
  const url = `${MEDICATIONS_BASE_URL}?patientUuid=${patientUuid}&startTime=${startTime}&endTime=${endTime}&visitUuid=${visitUuid}`;
  const { data } = await openmrsFetch<any[]>(url);
  return data;
}

/**
 * POST /ws/rest/v1/bahmni/administered-medications
 */
export async function saveAdministeredMedication(payload: any) {
  const { data } = await openmrsFetch(ADMINISTERED_MEDICATIONS_BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}

export async function createAdhocMedicationAdministration(payload: any) {
  const url = `${restBaseUrl}/ipd/adhocMedicationAdministrations`;
  const { data } = await openmrsFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}

