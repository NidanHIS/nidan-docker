import React, { useCallback, useState, useMemo, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  Dropdown,
  DataTableSkeleton,
  InlineNotification,
  Toggle,
} from '@carbon/react';
import { Add, ChevronLeft, ChevronRight, WarningAlt } from '@carbon/react/icons';
import { launchWorkspace2, useConfig, useSession } from '@openmrs/esm-framework';
import type { IpdConfig } from '../../config-schema';
import { useAdvancedNursingTasks } from './use-advanced-nursing-tasks';
import { resolveDisplayName } from './nursing-tasks.utils';
import { publishAuditEvent } from '../../utils/audit-event';
import { TaskTile } from './task-tile.component';
import { formatBsDateTime, isBsEnabled } from './bs-calendar';
import styles from './nursing-tasks.scss';
import dayjs from 'dayjs';

interface NursingTasksProps {
  patientUuid: string;
  visitUuid: string;
}

type ShiftDetails = Record<string, { shiftStartTime: string; shiftEndTime: string }>;

const DEFAULT_SHIFTS: ShiftDetails = {
  '1': { shiftStartTime: '08:00', shiftEndTime: '19:00' },
  '2': { shiftStartTime: '19:00', shiftEndTime: '08:00' },
};

function parseHHMM(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

function computeShiftEnd(shiftStart: number, shiftDetails: ShiftDetails): number {
  const d = new Date(shiftStart);
  const startMinsOfDay = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    if (parseHHMM(shiftStartTime) === startMinsOfDay) {
      const endMins = parseHHMM(shiftEndTime);
      const endDate = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(endMins / 60), endMins % 60, 0);
      if (endDate.getTime() <= shiftStart) endDate.setDate(endDate.getDate() + 1);
      return endDate.getTime();
    }
  }
  return shiftStart + 12 * 60 * 60 * 1000;
}

function computeCurrentShiftStart(now: number, shiftDetails: ShiftDetails): number {
  const d = new Date(now);
  const nowMins = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    const startMins = parseHHMM(shiftStartTime);
    const endMins = parseHHMM(shiftEndTime);
    if (endMins > startMins) {
      if (nowMins >= startMins && nowMins < endMins) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
    } else {
      if (nowMins >= startMins) {
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
      if (nowMins < endMins) {
        const prev = new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1);
        return new Date(prev.getFullYear(), prev.getMonth(), prev.getDate(), Math.floor(startMins / 60), startMins % 60, 0).getTime();
      }
    }
  }
  const first = Object.values(shiftDetails)[0];
  const sm = parseHHMM(first.shiftStartTime);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(sm / 60), sm % 60, 0).getTime();
}

function computePrevShiftStart(currentShiftStart: number, shiftDetails: ShiftDetails): number {
  const d = new Date(currentShiftStart);
  const currentStartMins = d.getHours() * 60 + d.getMinutes();
  for (const { shiftStartTime, shiftEndTime } of Object.values(shiftDetails)) {
    if (parseHHMM(shiftEndTime) === currentStartMins) {
      const prevStartMins = parseHHMM(shiftStartTime);
      let prevStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(prevStartMins / 60), prevStartMins % 60, 0).getTime();
      if (prevStart >= currentShiftStart) prevStart -= 24 * 60 * 60 * 1000;
      return prevStart;
    }
  }
  return currentShiftStart - (computeShiftEnd(currentShiftStart, shiftDetails) - currentShiftStart);
}

/** Format a timestamp for the shift header — AD or BS depending on `showBs` */
function formatShiftLabel(ts: number, showBs: boolean): string {
  const d = new Date(ts);
  if (showBs) {
    return formatBsDateTime(d);
  }
  return d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

const FILTERS = [
  { id: 'allTasks', text: 'All Tasks' },
  { id: 'pending', text: 'Pending' },
  { id: 'completed', text: 'Completed' },
  { id: 'skipped', text: 'Skipped/Not Done' },
  { id: 'stopped', text: 'Stopped' },
  { id: 'prn', text: 'PRN' },
];

/**
 * NursingTasks — IPD-02 Parity
 */
const NursingTasks: React.FC<NursingTasksProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const config = useConfig<IpdConfig>();
  const shiftDetails: ShiftDetails = config?.shiftDetails ?? DEFAULT_SHIFTS;
  const useBsCalendar: boolean = config?.useBsCalendar ?? false;

  // Only offer the toggle when the config flag is on AND the framework is
  // actually emitting BS dates (i.e. the locale includes the BS suffix).
  const bsAvailable = useBsCalendar && isBsEnabled();

  // AD/BS display toggle — only relevant when bsAvailable
  const [showBs, setShowBs] = useState(bsAvailable);

  // Shift Management State — initialised from config shift windows
  const [shiftStart, setShiftStart] = useState<number>(() => computeCurrentShiftStart(Date.now(), shiftDetails));

  const shiftEnd = computeShiftEnd(shiftStart, shiftDetails);

  const [filterValue, setFilterValue] = useState(FILTERS[1]);

  const apiStatus = useMemo(() => {
    if (filterValue.id === 'pending') return 'REQUESTED,IN_PROGRESS';
    if (filterValue.id === 'completed') return 'completed';
    if (filterValue.id === 'skipped') return 'Cancelled';
    if (filterValue.id === 'prn') return undefined;
    return undefined;
  }, [filterValue.id]);

  const { nonMedicationTasks, medicationTasks = [], isLoading, error, mutateAll } = useAdvancedNursingTasks(
    patientUuid,
    visitUuid,
    shiftStart,
    shiftEnd,
    apiStatus,
  );

  const handleNextShift = () => setShiftStart((prev) => computeShiftEnd(prev, shiftDetails));
  const handlePrevShift = () => setShiftStart((prev) => computePrevShiftStart(prev, shiftDetails));
  const handleCurrentShift = () => setShiftStart(computeCurrentShiftStart(Date.now(), shiftDetails));

  useEffect(() => {
    const handleRefresh = () => mutateAll();
    window.addEventListener('ipd:medication-refresh', handleRefresh);
    return () => window.removeEventListener('ipd:medication-refresh', handleRefresh);
  }, [mutateAll]);

  const session = useSession();
  const privileges = session?.user?.privileges ?? [];
  const canAddTasks = privileges.some((p: any) => p.display === 'Add Tasks');
  const canApplyTemplates = privileges.some((p: any) => p.display === 'Apply Task Templates');

  const handleAddTask = useCallback(() => {
    launchWorkspace2('add-ipd-task', { mutateTaskList: mutateAll });
    publishAuditEvent('VIEWED_NURSING_TASK_FORM', patientUuid, visitUuid);
  }, [patientUuid, visitUuid, mutateAll]);

  const handleSelectTemplate = useCallback(() => {
    launchWorkspace2('select-task-template', {});
    publishAuditEvent('OPENED_TASK_TEMPLATE_SELECTION', patientUuid, visitUuid);
  }, [patientUuid, visitUuid]);

  // Normalize Tasks for rendering — filter by shift window + status filter
  const normalizedTasks = useMemo(() => {
    const mapped: any[] = [];
    nonMedicationTasks.forEach((t) => {
      const startStr = t.executionPeriod?.start;
      if (!startStr) return;
      const taskTime = new Date(startStr).getTime();
      if (taskTime < shiftStart || taskTime >= shiftEnd) return;

      const scheduledDate = new Date(startStr);
      const completedDate = t.executionPeriod?.end ? new Date(t.executionPeriod.end) : null;

      mapped.push({
        uuid: t.uuid,
        name: resolveDisplayName(t.name),
        status: resolveDisplayName(t.status),
        rawStatus: t.status,
        isMedication: false,
        scheduledTime: startStr,
        time: scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actualTime: completedDate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isLate: completedDate ? completedDate.getTime() > scheduledDate.getTime() : false,
      });
    });

    medicationTasks.forEach((item: any) => {
      const sortedSlots = [...(item.slots || [])].sort((a: any, b: any) => a.startTime - b.startTime);

      item.slots?.forEach((slot: any) => {
        if (slot.serviceType === 'EmergencyMedicationRequest') return;

        const slotTime = slot.startTime * 1000;
        if (slotTime < shiftStart || slotTime >= shiftEnd) return;

        const nextSlot = sortedSlots.find((s: any) => s.startTime > slot.startTime);
        const scheduledDate = new Date(slotTime);
        const completedDate = slot.administeredDateTime ? new Date(slot.administeredDateTime) : null;

        mapped.push({
          uuid: slot.uuid,
          orderUuid: slot.order?.uuid,
          name: slot.order?.drug?.display || slot.order?.drugNonCoded || 'Medication',
          dosage: slot.order?.dose && slot.order?.doseUnits ? `${slot.order.dose} ${slot.order.doseUnits.display}` : undefined,
          dose: slot.order?.dose,
          doseUnitsUuid: slot.order?.doseUnits?.uuid,
          route: slot.order?.route?.display,
          status: slot.status,
          rawStatus: slot.status,
          isMedication: true,
          scheduledTime: scheduledDate.toISOString(),
          nextScheduledTime: nextSlot ? new Date(nextSlot.startTime * 1000).toISOString() : undefined,
          time: scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actualTime: completedDate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isLate: completedDate ? completedDate.getTime() > scheduledDate.getTime() : false,
          asNeeded: !!slot.order?.asNeeded || slot.serviceType === 'AsNeededPlaceholder',
        });
      });
    });

    const filteredByStatus = mapped.filter((t) => {
      if (filterValue.id === 'allTasks') return true;
      if (filterValue.id === 'pending') return t.status === 'REQUESTED' || t.status === 'SCHEDULED' || t.status === 'IN_PROGRESS';
      if (filterValue.id === 'completed') return t.status === 'COMPLETED' || t.status === 'completed';
      if (filterValue.id === 'skipped') return t.status === 'not-done' || t.status === 'NOT_DONE' || t.status === 'CANCELLED';
      if (filterValue.id === 'stopped') return t.status === 'STOPPED';
      if (filterValue.id === 'prn') return !!t.asNeeded;
      return true;
    });

    const isNotCurrentShiftActual = shiftStart !== computeCurrentShiftStart(Date.now(), shiftDetails);
    if (isNotCurrentShiftActual) {
      return filteredByStatus.filter((t) => !t.asNeeded);
    }
    return filteredByStatus;
  }, [nonMedicationTasks, medicationTasks, filterValue, shiftStart, shiftEnd]);

  const handleTileClick = useCallback(
    (clickedTask: any) => {
      if (clickedTask.asNeeded) {
        launchWorkspace2('record-ipd-task', { tasks: [clickedTask], mutateTaskList: mutateAll });
        return;
      }
      const clickedMinute = dayjs(clickedTask.scheduledTime).format('YYYY-MM-DD HH:mm');
      const siblingTasks = normalizedTasks.filter(
        (t) => !t.asNeeded && dayjs(t.scheduledTime).format('YYYY-MM-DD HH:mm') === clickedMinute,
      );
      launchWorkspace2('record-ipd-task', {
        tasks: siblingTasks.length > 0 ? siblingTasks : [clickedTask],
        mutateTaskList: mutateAll,
      });
    },
    [mutateAll, normalizedTasks],
  );

  if (error) {
    return <InlineNotification kind="error" title={t('error', 'Error loading tasks')} subtitle={error.message} />;
  }

  const shiftStartStr = formatShiftLabel(shiftStart, bsAvailable && showBs);
  const shiftEndStr = formatShiftLabel(shiftEnd, bsAvailable && showBs);
  const isNotCurrentShift = shiftStart !== computeCurrentShiftStart(Date.now(), shiftDetails);

  return (
    <div className={styles.nursingTasks}>
      <div className={styles.taskFilters}>
        <div className={styles.shiftControls}>
          <Button kind="tertiary" size="sm" onClick={handleCurrentShift}>
            {t('currentShift', 'Current Shift')}
          </Button>
          <div className={styles.shiftButtons}>
            <Button
              kind="tertiary"
              renderIcon={ChevronLeft}
              hasIconOnly
              size="sm"
              onClick={handlePrevShift}
              iconDescription={t('previousShift', 'Previous Shift')}
            />
            <Button
              kind="tertiary"
              renderIcon={ChevronRight}
              hasIconOnly
              size="sm"
              onClick={handleNextShift}
              iconDescription={t('nextShift', 'Next Shift')}
            />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', fontSize: '0.85rem' }}>
            {isNotCurrentShift && (
              <span style={{ color: '#da1e28', marginBottom: '0.25rem' }}>
                <WarningAlt size={10} />
                {t('notCurrentShiftWarning', " You're not viewing the current shift")}
              </span>
            )}
            <div>
              <strong>{shiftStartStr}</strong> - <strong>{shiftEndStr}</strong>
            </div>
          </div>
          {/* AD / BS calendar toggle — only shown when BS dates are available */}
          {bsAvailable && (
            <Toggle
              id="nursing-tasks-bs-toggle"
              size="sm"
              labelA="AD"
              labelB="BS"
              toggled={showBs}
              onToggle={(checked: boolean) => setShowBs(checked)}
              hideLabel
            />
          )}
        </div>
        <div className={styles.header}>
          <div className={styles.filters}>
            <Dropdown
              id="task-filter"
              titleText="Filter Tasks"
              hideLabel
              label="Filter Tasks"
              items={FILTERS}
              itemToString={(item: any) => item.text}
              selectedItem={filterValue}
              onChange={({ selectedItem }) => selectedItem && setFilterValue(selectedItem)}
              size="sm"
            />
          </div>
          {(canAddTasks || canApplyTemplates) && (
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              {canApplyTemplates && (
                <Button kind="primary" size="sm" renderIcon={Add} onClick={handleSelectTemplate}>
                  {t('addTaskTemplate', 'Task template')}
                </Button>
              )}
              {canAddTasks && (
                <Button kind="ghost" size="sm" renderIcon={Add} onClick={handleAddTask}>
                  {t('addTask', 'Add Task')}
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      {isLoading ? (
        <DataTableSkeleton columnCount={1} rowCount={3} />
      ) : normalizedTasks.length === 0 ? (
        <p className={styles.empty}>{t('noTasks', 'No active tasks for this filter in the current shift')}</p>
      ) : (
        <div className={styles.tileGrid}>
          {normalizedTasks.map((task) => {
            const s = (task.rawStatus?.display || task.rawStatus || '').toUpperCase();
            const isDisabled =
              s === 'COMPLETED' || s === 'CANCELLED' || s === 'STOPPED' || s === 'NOT_DONE' || s === 'NOT-DONE';
            return (
              <TaskTile
                key={task.uuid}
                taskUuid={task.uuid}
                {...task}
                disabled={isDisabled}
                onClick={isDisabled ? undefined : () => handleTileClick(task)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default NursingTasks;
