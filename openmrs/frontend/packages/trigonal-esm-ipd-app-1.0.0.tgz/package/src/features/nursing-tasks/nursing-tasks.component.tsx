import React, { useCallback, useState, useMemo, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  Dropdown,
  DataTableSkeleton,
  InlineNotification,
} from '@carbon/react';
import { Add, ChevronLeft, ChevronRight, WarningAlt } from '@carbon/react/icons';
import { launchWorkspace2, useSession } from '@openmrs/esm-framework';
import { useAdvancedNursingTasks } from './use-advanced-nursing-tasks';
import { resolveDisplayName } from './nursing-tasks.utils';
import { publishAuditEvent } from '../../utils/audit-event';
import { TaskTile } from './task-tile.component';
import styles from './nursing-tasks.scss';
import dayjs from 'dayjs';

interface NursingTasksProps {
  patientUuid: string;
  visitUuid: string;
}

const HOURS_PER_SHIFT = 8;
const SHIFT_MILI = HOURS_PER_SHIFT * 60 * 60 * 1000;

const FILTERS = [
  { id: 'allTasks', text: 'All Tasks' },
  { id: 'pending', text: 'Pending' },
  { id: 'completed', text: 'Completed' },
  { id: 'skipped', text: 'Skipped/Not Done' },
  { id: 'stopped', text: 'Stopped' },
  { id: 'prn', text: 'PRN' },
];

/**
 * NursingTasks — IPD-02 Parity
 */
const NursingTasks: React.FC<NursingTasksProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();

  // Shift Management State
  const [shiftStart, setShiftStart] = useState<number>(() => {
    const now = new Date();
    // Align block to nearest 8 hour boundary
    const hours = now.getHours();
    const alignedHour = Math.floor(hours / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
    const shiftStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), alignedHour, 0, 0);
    return shiftStart.getTime();
  });

  const [filterValue, setFilterValue] = useState(FILTERS[1]);

  const apiStatus = useMemo(() => {
    if (filterValue.id === 'pending') return 'REQUESTED,IN_PROGRESS';
    if (filterValue.id === 'completed') return 'completed';
    if (filterValue.id === 'skipped') return 'Cancelled';
    if (filterValue.id === 'prn') return undefined;
    return undefined;
  }, [filterValue.id]);

  const { nonMedicationTasks, medicationTasks = [], isLoading, error, mutateAll } = useAdvancedNursingTasks(
    patientUuid,
    visitUuid,
    shiftStart,
    shiftStart + SHIFT_MILI,
    apiStatus,
  );

  const handleNextShift = () => setShiftStart((prev) => prev + SHIFT_MILI);
  const handlePrevShift = () => setShiftStart((prev) => prev - SHIFT_MILI);
  const handleCurrentShift = () => {
    const now = new Date();
    const hours = now.getHours();
    const alignedHour = Math.floor(hours / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
    const shiftStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), alignedHour, 0, 0);
    setShiftStart(shiftStart.getTime());
  };

  useEffect(() => {
    const handleRefresh = () => mutateAll();
    window.addEventListener('ipd:medication-refresh', handleRefresh);
    return () => window.removeEventListener('ipd:medication-refresh', handleRefresh);
  }, [mutateAll]);


  const session = useSession();
  const privileges = session?.user?.privileges ?? [];
  const isNurse = session?.user?.roles?.some((role: any) => role.name === 'Organizational: Nurse');
  const canApplyTemplates = privileges.some((p: any) => p.display === 'Apply Task Templates');

  const handleAddTask = useCallback(() => {
    launchWorkspace2('add-ipd-task', { mutateTaskList: mutateAll });
    publishAuditEvent('VIEWED_NURSING_TASK_FORM', patientUuid, visitUuid);
  }, [patientUuid, visitUuid, mutateAll]);

  const handleSelectTemplate = useCallback(() => {
    launchWorkspace2('select-task-template', {});
    publishAuditEvent('OPENED_TASK_TEMPLATE_SELECTION', patientUuid, visitUuid);
  }, [patientUuid, visitUuid]);

  const shiftEnd = shiftStart + SHIFT_MILI;

  // Normalize Tasks for rendering — filter by shift window + status filter
  const normalizedTasks = useMemo(() => {
    const mapped: any[] = [];
    nonMedicationTasks.forEach((t) => {
      // Shift-based time filtering: only include tasks whose executionPeriod.start
      // falls within the current shift window [shiftStart, shiftEnd)
      const startStr = t.executionPeriod?.start;
      if (!startStr) {
        return; // skip tasks without a scheduled time
      }
      const taskTime = new Date(startStr).getTime();
      if (taskTime < shiftStart || taskTime >= shiftEnd) {
        return; // skip tasks outside the current shift
      }

      const scheduledDate = new Date(startStr);
      const completedDate = t.executionPeriod?.end ? new Date(t.executionPeriod.end) : null;

      mapped.push({
        uuid: t.uuid,
        name: resolveDisplayName(t.name),
        status: resolveDisplayName(t.status),
        rawStatus: t.status,
        isMedication: false,
        scheduledTime: startStr,
        time: scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actualTime: completedDate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isLate: completedDate ? completedDate.getTime() > scheduledDate.getTime() : false,
      });
    });

    // Handle Medication tasks
    medicationTasks.forEach((item: any) => {
      const sortedSlots = [...(item.slots || [])].sort((a: any, b: any) => a.startTime - b.startTime);

      item.slots?.forEach((slot: any) => {
        if (slot.serviceType === 'EmergencyMedicationRequest') return;

        const slotTime = slot.startTime * 1000;
        if (slotTime < shiftStart || slotTime >= shiftEnd) return;

        const nextSlot = sortedSlots.find((s: any) => s.startTime > slot.startTime);

        const scheduledDate = new Date(slotTime);
        const completedDate = slot.administeredDateTime ? new Date(slot.administeredDateTime) : null;

        mapped.push({
          uuid: slot.uuid,
          orderUuid: slot.order?.uuid,
          name: slot.order?.drug?.display || slot.order?.drugNonCoded || 'Medication',
          dosage: slot.order?.dose && slot.order?.doseUnits ? `${slot.order.dose} ${slot.order.doseUnits.display}` : undefined,
          dose: slot.order?.dose,
          doseUnitsUuid: slot.order?.doseUnits?.uuid,
          route: slot.order?.route?.display,
          status: slot.status,
          rawStatus: slot.status,
          isMedication: true,
          scheduledTime: scheduledDate.toISOString(),
          nextScheduledTime: nextSlot ? new Date(nextSlot.startTime * 1000).toISOString() : undefined,
          time: scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actualTime: completedDate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isLate: completedDate ? completedDate.getTime() > scheduledDate.getTime() : false,
          asNeeded: !!slot.order?.asNeeded || slot.serviceType === 'AsNeededPlaceholder',
        });
      });
    });

    // Apply status filter (Medication tasks always need this; non-med tasks filtered by API but this ensures UI consistency)
    const filteredByStatus = mapped.filter((t) => {
      if (filterValue.id === 'allTasks') return true;
      if (filterValue.id === 'pending') return t.status === 'REQUESTED' || t.status === 'SCHEDULED' || t.status === 'IN_PROGRESS';
      if (filterValue.id === 'completed') return t.status === 'COMPLETED' || t.status === 'completed';
      if (filterValue.id === 'skipped') return t.status === 'not-done' || t.status === 'NOT_DONE' || t.status === 'CANCELLED';
      if (filterValue.id === 'stopped') return t.status === 'STOPPED';
      if (filterValue.id === 'prn') return !!t.asNeeded;
      return true;
    });

    // Align with legacy flow: exclude PRN tasks from non-current shifts
    const now = new Date();
    const hours = now.getHours();
    const alignedHour = Math.floor(hours / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
    const currentActualShiftStart = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      alignedHour,
      0,
      0,
    ).getTime();
    const isNotCurrentShiftActual = shiftStart !== currentActualShiftStart;

    if (isNotCurrentShiftActual) {
      return filteredByStatus.filter(t => !t.asNeeded);
    }

    return filteredByStatus;
  }, [nonMedicationTasks, medicationTasks, filterValue, shiftStart, shiftEnd]);

  const handleTileClick = useCallback(
    (clickedTask: any) => {
      // PRN isolation: if it's as-needed, we don't group by time
      if (clickedTask.asNeeded) {
        launchWorkspace2('record-ipd-task', {
          tasks: [clickedTask],
          mutateTaskList: mutateAll,
        });
        return;
      }

      // Find all tasks at the same scheduled time (rounded to the minute)
      const clickedMinute = dayjs(clickedTask.scheduledTime).format('YYYY-MM-DD HH:mm');
      const siblingTasks = normalizedTasks.filter(
        (t) => !t.asNeeded && dayjs(t.scheduledTime).format('YYYY-MM-DD HH:mm') === clickedMinute
      );

      // O2 slider functionality: we launch the new record task workspace
      launchWorkspace2('record-ipd-task', {
        tasks: siblingTasks.length > 0 ? siblingTasks : [clickedTask],
        mutateTaskList: mutateAll,
      });
    },
    [mutateAll, normalizedTasks],
  );

  if (error) {
    return (
      <InlineNotification kind="error" title={t('error', 'Error loading tasks')} subtitle={error.message} />
    );
  }

  const shiftEndStr = new Date(shiftEnd).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const shiftStartStr = new Date(shiftStart).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const now = new Date();
  const currentAlignedHour = Math.floor(now.getHours() / HOURS_PER_SHIFT) * HOURS_PER_SHIFT;
  const currentActualShiftStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    currentAlignedHour,
    0,
    0,
  ).getTime();
  const isNotCurrentShift = shiftStart !== currentActualShiftStart;

  return (
    <div className={styles.nursingTasks}>
      <div className={styles.taskFilters}>
        <div className={styles.shiftControls}>
          <Button kind="tertiary" size="sm" onClick={handleCurrentShift}>
            {t('currentShift', 'Current Shift')}
          </Button>
          <div className={styles.shiftButtons}>
            <Button kind="tertiary" renderIcon={ChevronLeft} hasIconOnly size="sm" onClick={handlePrevShift} iconDescription={t('previousShift', 'Previous Shift')} />
            <Button kind="tertiary" renderIcon={ChevronRight} hasIconOnly size="sm" onClick={handleNextShift} iconDescription={t('nextShift', 'Next Shift')} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', fontSize: '0.85rem' }}>
            {isNotCurrentShift && (
              <span style={{ color: '#da1e28', marginBottom: '0.25rem' }}>
                <WarningAlt size={10} />{t('notCurrentShiftWarning', " You're not viewing the current shift")}
              </span>
            )}
            <div>
              <strong>{shiftStartStr}</strong> - <strong>{shiftEndStr}</strong>
            </div>
          </div>
        </div>
        <div className={styles.header}>
          <div className={styles.filters}>
            <Dropdown
              id="task-filter"
              titleText="Filter Tasks"
              hideLabel
              label="Filter Tasks"
              items={FILTERS}
              itemToString={(item: any) => item.text}
              selectedItem={filterValue}
              onChange={({ selectedItem }) => selectedItem && setFilterValue(selectedItem)}
              size="sm"
            />
          </div>
          {(isNurse || canApplyTemplates) && (
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              {canApplyTemplates && (
                <Button kind="primary" size="sm" renderIcon={Add} onClick={handleSelectTemplate}>
                  {t('addTaskTemplate', 'Task template')}
                </Button>
              )}
              {isNurse && (
                <Button kind="ghost" size="sm" renderIcon={Add} onClick={handleAddTask}>
                  {t('addTask', 'Add Task')}
                </Button>
              )}
            </div>
          )}
        </div>
      </div>



      {isLoading ? (
        <DataTableSkeleton columnCount={1} rowCount={3} />
      ) : normalizedTasks.length === 0 ? (
        <p className={styles.empty}>{t('noTasks', 'No active tasks for this filter in the current shift')}</p>
      ) : (
        <div className={styles.tileGrid}>
          {normalizedTasks.map((task) => {
            const s = (task.rawStatus?.display || task.rawStatus || '').toUpperCase();
            const isDisabled = s === 'COMPLETED' || s === 'CANCELLED' || s === 'STOPPED' || s === 'NOT_DONE' || s === 'NOT-DONE';

            return (
              <TaskTile
                key={task.uuid}
                taskUuid={task.uuid}
                {...task}
                disabled={isDisabled}
                onClick={isDisabled ? undefined : () => handleTileClick(task)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default NursingTasks;
