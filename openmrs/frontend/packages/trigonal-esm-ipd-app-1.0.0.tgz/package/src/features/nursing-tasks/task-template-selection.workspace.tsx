import React, { useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  ButtonSet,
  ClickableTile,
  Stack,
  Select,
  SelectItem,
  TextArea,
  InlineNotification,
  Loading,
  Tile,
  Layer,
  Search,
  Pagination,
} from '@carbon/react';
import { useSWRConfig } from 'swr';
import useSWR from 'swr';
import {
  openmrsFetch,
  restBaseUrl,
  showSnackbar,
  Workspace2,
  useSession,
  OpenmrsDatePicker,
} from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import { usePatientBed } from '../patient-ipd/use-ipd-patient';
import styles from './task-template-selection.workspace.scss';
import gridStyles from './nursing-tasks.scss';

interface TaskTemplateSelectionWorkspaceProps {
  // Custom workspace props here if needed
}

const DEFAULT_WARD_UUID = 'ba685651-ed3b-4e63-9b35-78893060758a';

const TaskTemplateSelectionWorkspace: React.FC<
  PatientWorkspace2DefinitionProps<TaskTemplateSelectionWorkspaceProps, any>
> = ({ groupProps: { patient, visitContext }, closeWorkspace }) => {
  const { t } = useTranslation();
  const { mutate } = useSWRConfig();
  const patientUuid = patient.id;

  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [startDate, setStartDate] = useState<string>(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });
  const [endDate, setEndDate] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const session = useSession();
  const privileges = session?.user?.privileges ?? [];
  const canView = privileges.some((p: any) => p.display === 'Get Task Templates');



  // Fetch Templates
  const {
    data: templates,
    isLoading: templatesLoading,
    error: templatesError,
  } = useSWR<any>(
    `${restBaseUrl}/ipd/task-templates?searchQuery=${searchQuery}&pageSize=100`,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );

  // Fetch Patient Ward (from bed)
  const { bed, isLoading: bedLoading } = usePatientBed(patientUuid);
  const wardUuidFromBed = (bed as any)?.physicalLocation?.uuid;
  const wardUuid = wardUuidFromBed || DEFAULT_WARD_UUID;

  const handleApply = useCallback(async () => {
    if (!selectedTemplate || !wardUuid) return;

    setIsSubmitting(true);
    try {
      const formatDateTime = (dateStr: string) => {
        if (!dateStr) return undefined;
        // If already a full ISO string, strip milliseconds/Z and return UTC portion
        if (dateStr.includes('T')) return dateStr.split('.')[0].replace('Z', '');
        const [year, month, day] = dateStr.split('-').map(Number);
        const now = new Date();
        const isToday =
          year === now.getFullYear() &&
          month === now.getMonth() + 1 &&
          day === now.getDate();
        // Use current time for today, midnight for any other date
        const localDate = isToday
          ? new Date(year, month - 1, day, now.getHours(), now.getMinutes(), now.getSeconds())
          : new Date(year, month - 1, day, 0, 0, 0);
        return localDate.toISOString().split('.')[0];
      };

      const payload = {
        patientUuid,
        wardUuid,
        startDate: formatDateTime(startDate),
        endDate: formatDateTime(endDate),
      };

      await openmrsFetch(`${restBaseUrl}/ipd/task-templates/${selectedTemplate.uuid}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      showSnackbar({
        kind: 'success',
        title: t('templateApplied', 'Task template applied successfully'),
      });

      // Refresh nursing tasks
      mutate((key: any) => typeof key === 'string' && key.includes('/ipd/tasks'));
      closeWorkspace();
    } catch (err) {
      showSnackbar({
        kind: 'error',
        title: t('applyError', 'Error applying task template'),
        subtitle: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [selectedTemplate, wardUuid, patientUuid, startDate, endDate, t, mutate, closeWorkspace]);

  if (templatesLoading || bedLoading) {
    return <Loading withOverlay={false} />;
  }

  if (!canView && session) {
    return (
      <Workspace2 title={t('applyTaskTemplate', 'Apply Task Template')}>
        <div className={styles.workspaceContainer}>
          <InlineNotification
            kind="error"
            title={t('forbidden', 'Forbidden')}
            subtitle={t('noPermissionView', 'You do not have permission to view task templates.')}
          />
        </div>
      </Workspace2>
    );
  }

  if (templatesError) {
    return (
      <InlineNotification kind="error" title={t('error', 'Error loading templates')} subtitle={templatesError.message} />
    );
  }

  return (
    <Workspace2 title={t('applyTaskTemplate', 'Apply Task Template')}>
      <div className={styles.workspaceContainer}>
        {!selectedTemplate ? (
          <section className={styles.selectionSection}>
            <h5 className={styles.selectionHeading}>{t('selectTemplate', 'Select a Task Template')}</h5>
            <p className={styles.selectionSubtext}>
              {t('selectTemplateDesc', 'Choose a template to apply for this patient.')}
            </p>

            <div style={{ marginBottom: '1.5rem' }}>
              <Search
                size="md"
                labelText={t('searchTemplates', 'Search templates')}
                placeholder={t('searchTemplates', 'Search templates')}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                }}
              />
            </div>

            <div className={gridStyles.tileGrid}>
              {templates?.results?.map((template: any) => (
                <ClickableTile
                  key={template.uuid}
                  onClick={() => setSelectedTemplate(template)}
                  className={gridStyles.taskTile}
                >
                  <div className={gridStyles.tileTitle}>{template.name}</div>
                  <div className={gridStyles.tileSubtext}>{template.description}</div>
                </ClickableTile>
              )) ?? <p>{t('noTemplatesFound', 'No templates found.')}</p>}
            </div>
          </section>
        ) : (
          <section>
            <Stack gap={6} className={styles.customizationSection}>
              <div>
                <h5 className={styles.selectionHeading}>
                  {t('customizeTemplate', 'Apply Template: {{name}}', { name: selectedTemplate.name })}
                </h5>
                <p className={styles.selectionSubtext}>{selectedTemplate.description}</p>
              </div>

              {!wardUuidFromBed && (
                <InlineNotification
                  kind="warning"
                  title={t('noWardFound', 'No active bed assignment')}
                  subtitle={t('noWardFoundDesc', 'Falling back to default ward: Inpatient (IPD)')}
                />
              )}

              <div style={{ display: 'flex', gap: '1rem' }}>
                <div style={{ flex: 1 }}>
                  <OpenmrsDatePicker
                    labelText={t('startDate', 'Start Date')}
                    value={startDate || undefined}
                    onChange={(date) => {
                      if (date) {
                        const y = date.getFullYear();
                        const m = String(date.getMonth() + 1).padStart(2, '0');
                        const d = String(date.getDate()).padStart(2, '0');
                        setStartDate(`${y}-${m}-${d}`);
                      } else {
                        setStartDate('');
                      }
                    }}
                  />
                  {startDate && (
                    <Button
                      kind="ghost"
                      size="sm"
                      onClick={() => setStartDate('')}
                      style={{ marginTop: '0.5rem' }}
                    >
                      {t('clear', 'Clear')}
                    </Button>
                  )}
                </div>

                <div style={{ flex: 1 }}>
                  <OpenmrsDatePicker
                    labelText={t('endDate', 'End Date')}
                    value={endDate || undefined}
                    onChange={(date) => {
                      if (date) {
                        const y = date.getFullYear();
                        const m = String(date.getMonth() + 1).padStart(2, '0');
                        const d = String(date.getDate()).padStart(2, '0');
                        setEndDate(`${y}-${m}-${d}`);
                      } else {
                        setEndDate('');
                      }
                    }}
                  />
                </div>
              </div>
            </Stack>
          </section>
        )}
      </div>
      <ButtonSet className={styles.buttonSet}>
        <Button kind="secondary" onClick={selectedTemplate ? () => setSelectedTemplate(null) : () => closeWorkspace()}>
          {selectedTemplate ? t('back', 'Back') : t('cancel', 'Cancel')}
        </Button>
        {selectedTemplate && (
          <Button onClick={handleApply} disabled={isSubmitting || !wardUuid}>
            {isSubmitting ? t('applying', 'Applying...') : t('applyTask', 'Apply Task')}
          </Button>
        )}
      </ButtonSet>
    </Workspace2>
  );
};

export default TaskTemplateSelectionWorkspace;
