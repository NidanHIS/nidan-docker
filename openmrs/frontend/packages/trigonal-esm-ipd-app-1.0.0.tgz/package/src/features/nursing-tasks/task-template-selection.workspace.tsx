import React, { useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  ButtonSet,
  ClickableTile,
  Stack,
  Select,
  SelectItem,
  TextArea,
  InlineNotification,
  Loading,
  Tile,
  Layer,
  Search,
  Pagination,
  DatePicker,
  DatePickerInput,
} from '@carbon/react';
import { useSWRConfig } from 'swr';
import useSWR from 'swr';
import {
  openmrsFetch,
  restBaseUrl,
  showSnackbar,
  Workspace2,
  useSession,
} from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import { usePatientBed } from '../patient-ipd/use-ipd-patient';
import styles from './task-template-selection.workspace.scss';
import gridStyles from './nursing-tasks.scss';

interface TaskTemplateSelectionWorkspaceProps {
  // Custom workspace props here if needed
}

const DEFAULT_WARD_UUID = 'ba685651-ed3b-4e63-9b35-78893060758a';

const TaskTemplateSelectionWorkspace: React.FC<
  PatientWorkspace2DefinitionProps<TaskTemplateSelectionWorkspaceProps, any>
> = ({ groupProps: { patient, visitContext }, closeWorkspace }) => {
  const { t } = useTranslation();
  const { mutate } = useSWRConfig();
  const patientUuid = patient.id;

  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const session = useSession();
  const privileges = session?.user?.privileges ?? [];
  const canView = privileges.some((p: any) => p.display === 'Get Task Templates');



  // Fetch Templates
  const {
    data: templates,
    isLoading: templatesLoading,
    error: templatesError,
  } = useSWR<any>(
    `${restBaseUrl}/ipd/task-templates?searchQuery=${searchQuery}&pageSize=100`,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );

  // Fetch Patient Ward (from bed)
  const { bed, isLoading: bedLoading } = usePatientBed(patientUuid);
  const wardUuidFromBed = (bed as any)?.physicalLocation?.uuid;
  const wardUuid = wardUuidFromBed || DEFAULT_WARD_UUID;

  const handleApply = useCallback(async () => {
    if (!selectedTemplate || !wardUuid) return;

    setIsSubmitting(true);
    try {
      const formatDateTime = (dateStr: string) => {
        if (!dateStr) return undefined;
        // If it's just a date YYYY-MM-DD, append current time
        if (dateStr.length === 10) {
          const now = new Date();
          const pad = (n: number) => n.toString().padStart(2, '0');
          return `${dateStr}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        }
        return dateStr;
      };

      const payload = {
        patientUuid,
        wardUuid,
        startDate: formatDateTime(startDate),
        endDate: formatDateTime(endDate),
      };

      await openmrsFetch(`${restBaseUrl}/ipd/task-templates/${selectedTemplate.uuid}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      showSnackbar({
        kind: 'success',
        title: t('templateApplied', 'Task template applied successfully'),
      });

      // Refresh nursing tasks
      mutate((key: any) => typeof key === 'string' && key.includes('/ipd/tasks'));
      closeWorkspace();
    } catch (err) {
      showSnackbar({
        kind: 'error',
        title: t('applyError', 'Error applying task template'),
        subtitle: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [selectedTemplate, wardUuid, patientUuid, startDate, endDate, t, mutate, closeWorkspace]);

  if (templatesLoading || bedLoading) {
    return <Loading withOverlay={false} />;
  }

  if (!canView && session) {
    return (
      <Workspace2 title={t('applyTaskTemplate', 'Apply Task Template')}>
        <div className={styles.workspaceContainer}>
          <InlineNotification
            kind="error"
            title={t('forbidden', 'Forbidden')}
            subtitle={t('noPermissionView', 'You do not have permission to view task templates.')}
          />
        </div>
      </Workspace2>
    );
  }

  if (templatesError) {
    return (
      <InlineNotification kind="error" title={t('error', 'Error loading templates')} subtitle={templatesError.message} />
    );
  }

  return (
    <Workspace2 title={t('applyTaskTemplate', 'Apply Task Template')}>
      <div className={styles.workspaceContainer}>
        {!selectedTemplate ? (
          <section className={styles.selectionSection}>
            <h5 className={styles.selectionHeading}>{t('selectTemplate', 'Select a Task Template')}</h5>
            <p className={styles.selectionSubtext}>
              {t('selectTemplateDesc', 'Choose a template to apply for this patient.')}
            </p>

            <div style={{ marginBottom: '1.5rem' }}>
              <Search
                size="md"
                labelText={t('searchTemplates', 'Search templates')}
                placeholder={t('searchTemplates', 'Search templates')}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                }}
              />
            </div>

            <div className={gridStyles.tileGrid}>
              {templates?.results?.map((template: any) => (
                <ClickableTile
                  key={template.uuid}
                  onClick={() => setSelectedTemplate(template)}
                  className={gridStyles.taskTile}
                >
                  <div className={gridStyles.tileTitle}>{template.name}</div>
                  <div className={gridStyles.tileSubtext}>{template.description}</div>
                </ClickableTile>
              )) ?? <p>{t('noTemplatesFound', 'No templates found.')}</p>}
            </div>
          </section>
        ) : (
          <section>
            <Stack gap={6} className={styles.customizationSection}>
              <div>
                <h5 className={styles.selectionHeading}>
                  {t('customizeTemplate', 'Apply Template: {{name}}', { name: selectedTemplate.name })}
                </h5>
                <p className={styles.selectionSubtext}>{selectedTemplate.description}</p>
              </div>

              {!wardUuidFromBed && (
                <InlineNotification
                  kind="warning"
                  title={t('noWardFound', 'No active bed assignment')}
                  subtitle={t('noWardFoundDesc', 'Falling back to default ward: Inpatient (IPD)')}
                />
              )}

              <div style={{ display: 'flex', gap: '1rem' }}>
                <div style={{ flex: 1 }}>
                  <DatePicker
                    datePickerType="single"
                    dateFormat="Y-m-d"
                    onChange={([date]) => setStartDate(date ? date.toISOString().split('T')[0] : '')}
                    value={startDate}
                  >
                    <DatePickerInput
                      id="startDate"
                      labelText={t('startDate', 'Start Date')}
                      placeholder="yyyy-mm-dd"
                    />
                  </DatePicker>
                </div>

                <div style={{ flex: 1 }}>
                  <DatePicker
                    datePickerType="single"
                    dateFormat="Y-m-d"
                    onChange={([date]) => setEndDate(date ? date.toISOString().split('T')[0] : '')}
                    value={endDate}
                  >
                    <DatePickerInput
                      id="endDate"
                      labelText={t('endDate', 'End Date')}
                      placeholder="yyyy-mm-dd"
                    />
                  </DatePicker>
                </div>
              </div>
            </Stack>
          </section>
        )}
      </div>
      <ButtonSet className={styles.buttonSet}>
        <Button kind="secondary" onClick={selectedTemplate ? () => setSelectedTemplate(null) : () => closeWorkspace()}>
          {selectedTemplate ? t('back', 'Back') : t('cancel', 'Cancel')}
        </Button>
        {selectedTemplate && (
          <Button onClick={handleApply} disabled={isSubmitting || !wardUuid}>
            {isSubmitting ? t('applying', 'Applying...') : t('applyTask', 'Apply Task')}
          </Button>
        )}
      </ButtonSet>
    </Workspace2>
  );
};

export default TaskTemplateSelectionWorkspace;
