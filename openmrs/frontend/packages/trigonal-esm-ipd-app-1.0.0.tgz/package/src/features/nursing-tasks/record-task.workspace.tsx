import React, { useCallback, useState, useMemo, useEffect } from 'react';
import {
  Button,
  ButtonSet,
  Form,
  FormGroup,
  Stack,
  TextArea,
  Toggle,
  TextInput,
  InlineNotification,
  OverflowMenu,
  OverflowMenuItem,
  Tile,
  Tag
} from '@carbon/react';
import { Time } from '@carbon/react/icons';
import { useTranslation } from 'react-i18next';
import { showSnackbar, Workspace2, useSession, useConfig } from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import dayjs from 'dayjs';
import { saveAdministeredMedication, updateNursingTask, createAdhocMedicationAdministration } from './nursing-tasks-resource';
import { isTimeWithinLateWindow, isFutureTime, resolveDisplayName } from './nursing-tasks.utils';
import styles from './nursing-task-form.scss';
import { IpdConfig } from '../../config-schema';

export interface TaskType {
  uuid: string;
  orderUuid?: string;
  name: string;
  dosage?: string;
  dose?: number;
  doseUnitsUuid?: string;
  route?: string;
  status: string;
  isMedication: boolean;
  scheduledTime: string;
  nextScheduledTime?: string;
  asNeeded?: boolean;
  administrationInstructions?: string;
}

interface RecordTaskWorkspaceProps {
  tasks: TaskType[];
  mutateTaskList: () => void;
}

interface TaskState {
  isDone: boolean;
  isSkipped: boolean;
  isStarting: boolean;
  time: string;
  notes: string;
}

/**
 * RecordTaskWorkspace — IPD-02 Parity
 * Supports rendering multiple tasks group by the same scheduled time.
 */
const RecordTaskWorkspace: React.FC<PatientWorkspace2DefinitionProps<RecordTaskWorkspaceProps, any>> = ({
  groupProps: { patient, visitContext },
  workspaceProps: { tasks, mutateTaskList },
  closeWorkspace,
}) => {
  const patientUuid = patient.id;
  const visitUuid = visitContext?.uuid;
  const { t } = useTranslation();
  const session = useSession();
  const isNurse = session?.user?.roles?.some((role: any) => role.name === 'Organizational: Nurse');
  const config = useConfig() as IpdConfig;
  const lateWindowMinutes = config.nursingTaskLateWindowMinutes ?? 60;
  
  const filteredTasks = useMemo(() => {
    return (tasks || []).filter(task => {
        const s = (task.status || '').toUpperCase();
        return s !== 'COMPLETED' && s !== 'SKIPPED' && s !== 'CANCELLED' && s !== 'NOT-DONE' && s !== 'NOT_DONE' && s !== 'STOPPED';
    });
  }, [tasks]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const [taskStates, setTaskStates] = useState<Record<string, TaskState>>({});

  useEffect(() => {
    // initialize states for new tasks
    if (filteredTasks && filteredTasks.length > 0) {
      setTaskStates((prev) => {
        const next = { ...prev };
        let hasChanges = false;
        filteredTasks.forEach(task => {
          if (!next[task.uuid]) {
            next[task.uuid] = {
              isDone: false,
              isSkipped: false,
              isStarting: false,
              time: '',
              notes: '',
            };
            hasChanges = true;
          }
        });
        return hasChanges ? next : prev;
      });
    }
  }, [tasks]);

  const updateTaskState = (uuid: string, updates: Partial<TaskState>) => {
    setTaskStates(prev => {
      const current = prev[uuid] || {
        isDone: false,
        isSkipped: false,
        isStarting: false,
        time: '',
        notes: ''
      };
      
      const next: TaskState = { ...current, ...updates };
      // Default time to "now" when marking as done
      if (updates.isDone && !next.time) {
        next.time = dayjs().format('HH:mm');
      }
      return { ...prev, [uuid]: next };
    });
  };

  const getTaskErrors = (task: TaskType, state: TaskState) => {
    if (!state) return { isLate: false, isInFuture: false, noteRequired: false, disableDoneToggle: false, valid: true, hasAction: false };
    
    const isLate = state.isDone && state.time && task.scheduledTime 
      ? !isTimeWithinLateWindow(task.scheduledTime, state.time, lateWindowMinutes) 
      : false;
      
    const isInFuture = isFutureTime(state.time);

    let disableDoneToggle = false;
    if (task.scheduledTime && !task.asNeeded) {
      const taskTime = dayjs(task.scheduledTime).valueOf();
      const now = Date.now();
      const isTooFarInFuture = taskTime > now + lateWindowMinutes * 60 * 1000;
      let isPastNextDose = false;
      if (task.isMedication && task.nextScheduledTime) {
        isPastNextDose = now >= dayjs(task.nextScheduledTime).valueOf();
      }
      disableDoneToggle = isTooFarInFuture || isPastNextDose;
    }

    const noteRequired = state.isSkipped || (state.isDone && isLate);
    const valid = (() => {
       if (!state.isDone && !state.isSkipped && !state.isStarting) return true; // not taking action on this task is fine
       if (isInFuture && state.isDone) return false;
       if (noteRequired && !state.notes.trim()) return false;
       if (state.isDone && !state.time) return false;
       return true;
    })();

    const hasAction = state.isDone || state.isSkipped || state.isStarting;

    return { isLate, isInFuture, noteRequired, disableDoneToggle, valid, hasAction };
  };

  const canSave = useMemo(() => {
    let hasAnyAction = false;
    for (const task of filteredTasks || []) {
      const state = taskStates[task.uuid];
      if (!state) continue;
      const { valid, hasAction } = getTaskErrors(task, state);
      if (hasAction && !valid) return false; // Action is invalid
      if (hasAction) hasAnyAction = true;
    }
    return hasAnyAction;
  }, [tasks, taskStates, lateWindowMinutes]);

  const onSubmit = useCallback(
    async (e?: React.FormEvent) => {
      if (e) e.preventDefault();
      if (!canSave) return;

      setIsSubmitting(true);
      setErrorMsg(null);

      try {
        const currentProviderUuid = session?.currentProvider?.uuid;
        const medicationPayloads = [];
        const nonMedPromises = [];

        for (const task of filteredTasks || []) {
          const state = taskStates[task.uuid];
          if (!state) continue;
          const hasAction = state.isDone || state.isSkipped || state.isStarting;
          if (!hasAction) continue;

          const executionTime = state.isDone
            ? dayjs(task.scheduledTime)
              .set('hour', parseInt(state.time.split(':')[0]))
              .set('minute', parseInt(state.time.split(':')[1]))
              .toISOString()
            : dayjs().toISOString();

          if (task.isMedication) {
            const payload = {
              patientUuid,
              orderUuid: task.orderUuid,
              status: state.isDone ? 'completed' : 'not-done',
              notes: state.notes ? [{ authorUuid: currentProviderUuid, text: state.notes }] : [],
              slotUuid: task.uuid,
              administeredDateTime: Math.floor(dayjs(executionTime).valueOf() / 1000),
              providers: currentProviderUuid ? [{ providerUuid: currentProviderUuid, function: 'Performer' }] : [],
              dose: task.dose,
              doseUnits: task.doseUnitsUuid,
            };

            if (task.asNeeded) {
              // PRN: recorded as adhoc administration in the legacy flow
              nonMedPromises.push(createAdhocMedicationAdministration(payload));
            } else {
              medicationPayloads.push(payload);
            }
          } else if (state.isStarting) {
            nonMedPromises.push(updateNursingTask(task.uuid, {
              status: 'IN_PROGRESS',
              comment: state.notes || 'Task started',
              executionEndTime: '',
            }));
          } else {
            nonMedPromises.push(updateNursingTask(task.uuid, {
              status: state.isDone ? 'COMPLETED' : 'CANCELLED',
              comment: state.notes,
              executionEndTime: dayjs(executionTime).valueOf(),
            }));
          }
        }

        if (medicationPayloads.length > 0) {
          await saveAdministeredMedication(medicationPayloads);
        }
        
        if (nonMedPromises.length > 0) {
           await Promise.all(nonMedPromises);
        }

        showSnackbar({
          title: t('taskRecorded', 'Tasks successfully recorded'),
          kind: 'success',
          isLowContrast: true,
        });

        mutateTaskList();
        closeWorkspace();
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : String(err));
      } finally {
        setIsSubmitting(false);
      }
    },
    [filteredTasks, taskStates, patientUuid, mutateTaskList, t, session, canSave, closeWorkspace]
  );

  const handleCancel = useCallback(() => closeWorkspace(), [closeWorkspace]);

  const scheduledTimeDisplay = filteredTasks?.length > 0 && filteredTasks[0].scheduledTime 
      ? dayjs(filteredTasks[0].scheduledTime).format('hh:mm A') 
      : '';

  return (
    <Workspace2 title={t('taskTitle', 'Task(s)')}>
      <div className={styles.workspaceLayout}>
        <Form className={styles.recordForm} onSubmit={onSubmit}>
          
          {!filteredTasks.some(t => t.asNeeded) && (
            <div className={styles.scheduledHeader}>
               Scheduled for <Time size={16}/> {scheduledTimeDisplay}
            </div>
          )}

          <Stack className={styles.workspaceContent}>
             {filteredTasks?.map(task => {
                const state = taskStates[task.uuid] || { isDone: false, isSkipped: false, isStarting: false, time: '', notes: '' };
                const { isLate, isInFuture, noteRequired, disableDoneToggle } = getTaskErrors(task, state);
                
                return (
                  <Tile key={task.uuid} className={styles.taskTileCard}>
                    <div className={styles.taskHeaderRow}>
                      <div className={styles.taskTitleGroup}>

                        <div className={styles.taskTitleWrap}>
                           <h4 className={styles.taskName}>{resolveDisplayName(task.name)}</h4>
                           {task.isMedication && (
                             <Tag type="blue" size="sm" className={styles.rxBadge}>
                               {task.asNeeded ? t('rxPrn', 'Rx-PRN') : t('rx', 'Rx')}
                             </Tag>
                           )}
                        </div>

                        {task.dosage && (
                          <p className={styles.taskDetails}>
                            {resolveDisplayName(task.dosage)} {task.route ? ` - ${resolveDisplayName(task.route)}` : ''}
                            {task.administrationInstructions ? ` - ${resolveDisplayName(task.administrationInstructions)}` : ''}
                          </p>
                        )}
                      </div>
                      
                      <div className={styles.taskActions}>
                        <OverflowMenu flipped size="sm">
                          {!task.asNeeded && (
                            <OverflowMenuItem
                              itemText={state.isSkipped ? t('unskipTask', 'Un-skip') : t('skipTask', 'Skip')}
                              onClick={() => {
                                const newSkipped = !state.isSkipped;
                                updateTaskState(task.uuid, {
                                  isSkipped: newSkipped,
                                  isDone: newSkipped ? false : state.isDone,
                                  isStarting: newSkipped ? false : state.isStarting
                                });
                              }}
                            />
                          )}
                        </OverflowMenu>
                      </div>
                    </div>

                    {!state.isSkipped && !state.isStarting && task.status === 'IN_PROGRESS' && (
                          <Toggle
                            id={`done-toggle-${task.uuid}`}
                            size="sm"
                            labelA={t('markDone', 'Done')}
                            labelB={t('markDone', 'Done')}
                            toggled={state.isDone}
                            onToggle={(checked) => {
                              updateTaskState(task.uuid, {
                                isDone: checked,
                                isSkipped: checked ? false : state.isSkipped,
                                isStarting: checked ? false : state.isStarting
                              });
                            }}
                            className={styles.multiDoneToggle}
                            disabled={disableDoneToggle || !isNurse}
                          />
                    )}
                    
                    {!state.isSkipped && !state.isStarting && task.isMedication && (
                          <Toggle
                            id={`done-toggle-${task.uuid}`}
                            size="sm"
                            labelA={t('markDone', 'Done')}
                            labelB={t('markDone', 'Done')}
                            toggled={state.isDone}
                            onToggle={(checked) => {
                              updateTaskState(task.uuid, {
                                isDone: checked,
                                isSkipped: checked ? false : state.isSkipped,
                                isStarting: checked ? false : state.isStarting
                              });
                            }}
                            className={styles.multiDoneToggle}
                            disabled={disableDoneToggle || !isNurse}
                          />
                        )}

                    {!task.isMedication && task.status === 'REQUESTED' && !state.isSkipped && !state.isDone && (
                      <Toggle
                        id={`start-task-toggle-${task.uuid}`}
                        size="sm"
                        labelA={t('startTask', 'Start Task')}
                        labelB={t('startTask', 'Start Task')}
                        toggled={state.isStarting}
                        onToggle={(checked) => {
                           updateTaskState(task.uuid, {
                              isStarting: checked,
                              isDone: checked ? false : state.isDone,
                              isSkipped: checked ? false : state.isSkipped
                           });
                        }}
                        className={styles.multiDoneToggle}
                        disabled={disableDoneToggle || !isNurse}
                      />
                    )}

                    {state.isSkipped && (
                      <InlineNotification
                        kind="warning"
                        title={t('taskSkipped', 'Task Skipped')}
                        subtitle={t('skipWarning', 'This task will be recorded as not performed. A reason is required.')}
                        hideCloseButton
                      />
                    )}

                    {state.isDone && (
                      <FormGroup legendText={t('administrationTime', 'Administration Time')}>
                        <TextInput
                          id={`time-picker-${task.uuid}`}
                          type="time"
                          labelText={t('time', 'Time')}
                          value={state.time}
                          onChange={(e) => updateTaskState(task.uuid, { time: e.target.value })}
                          invalid={isInFuture}
                          invalidText={t('futureTimeError', 'Future time is not allowed')}
                          warn={isLate}
                          warnText={t('lateAdminWarning', 'Task recorded after the allowed window. A clinical note is required.')}
                        />
                      </FormGroup>
                    )}

                    {(state.isSkipped || (task.isMedication && state.isDone) || isLate) && (
                       <div style={{ marginTop: '1rem' }}>
                        <TextArea
                            id={`task-notes-${task.uuid}`}
                            labelText={t('notes', 'Notes')}
                            rows={2}
                            placeholder={noteRequired ? t('reasonRequired', 'A note or reason is required...') : t('optionalNotes', 'Optional notes...')}
                            value={state.notes}
                            onChange={(e) => updateTaskState(task.uuid, { notes: e.target.value })}
                            invalid={noteRequired && !state.notes.trim()}
                            invalidText={t('notesRequiredError', 'Notes are required when a task is skipped or late')}
                        />
                       </div>
                    )}

                  </Tile>
                );
             })}
            {errorMsg && <InlineNotification kind="error" title={t('error', 'Error')} subtitle={errorMsg} />}
          </Stack>
        </Form>
        <ButtonSet className={styles.buttonSet}>
          <Button kind="secondary" onClick={handleCancel} disabled={isSubmitting}>
            {t('cancel', 'Cancel')}
          </Button>
          <Button kind="primary" type="button" onClick={onSubmit} disabled={isSubmitting || !canSave || !isNurse}>
            {isSubmitting ? t('saving', 'Saving…') : t('saveTaskRecord', 'Save')}
          </Button>
        </ButtonSet>
      </div>
    </Workspace2>
  );
};

export default RecordTaskWorkspace;
