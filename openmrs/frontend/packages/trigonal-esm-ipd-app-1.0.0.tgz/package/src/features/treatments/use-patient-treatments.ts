import useSWR from 'swr';
import { type FetchResponse, openmrsFetch } from '@openmrs/esm-framework';

export interface IPDDrugOrder {
  orderUuid: string;
  drugName: string;
  dose?: number;
  doseUnitsName?: string;
  routeName?: string;
  durationUnitsName?: string;
  duration?: number;
  quantity?: number;
  quantityUnitsName?: string;
  frequency?: string;
  asNeeded?: boolean;
  action?: string;
  orderSetUuid?: string | null;
  providerUuid?: string;
  providerName?: string;
  dateActivated?: string;
  dateStopped?: string;
  effectiveStartDate?: string;
  drugOrderSchedule?: {
    medicationAdministrationStarted?: boolean;
    allSlotsAttended?: boolean;
    notes?: string;
    pendingSlotsAvailable?: boolean;
  } | null;
  orderReasonText?: string;
  orderReasonConcept?: { name: string };
  instructions?: string;
  additionalInstructions?: string;
  asNeededCondition?: string;
  administrationInstructions?: string;
}

export interface EmergencyMedicationProvider {
  uuid: string;
  function: 'Requester' | 'Verifier' | 'Performer' | 'Witness' | string;
  provider: { uuid: string; display: string };
}

export interface EmergencyMedicationNote {
  uuid: string;
  text: string;
  recordedTime: number | string;
  author: { uuid: string; display: string; name?: string };
}

export interface MedicationAdministration {
  uuid: string;
  drug: { display: string; uuid?: string };
  administeredDateTime: number | string;
  dose: number;
  doseUnits?: { display: string; uuid?: string };
  route?: { display: string; uuid?: string };
  providers: EmergencyMedicationProvider[];
  notes: EmergencyMedicationNote[];
  status?: string;
}

export interface EmergencyMedication {
  uuid: string;
  id?: number;
  serviceType?: string;
  status?: string;
  startTime?: number | string;
  medicationAdministration?: MedicationAdministration;
  // Keep legacy properties for robustness
  drug?: { display: string };
  administeredDateTime?: string | number;
  dose?: number;
  doseUnits?: { display: string };
  route?: { display: string };
  providers?: EmergencyMedicationProvider[];
  notes?: EmergencyMedicationNote[];
}

export interface PatientTreatmentsResponse {
  ipdDrugOrders: IPDDrugOrder[];
  emergencyMedications?: EmergencyMedication[];
}

export function usePatientTreatments(visitUuid?: string) {
  const url = visitUuid ? `/ws/rest/v1/ipdVisit/${visitUuid}/medication?includes=emergencyMedications` : null;

  const { data, error, isLoading, mutate } = useSWR<
    FetchResponse<PatientTreatmentsResponse>,
    Error
  >(
    url,
    openmrsFetch,
  );

  return {
    treatmentsResponse: data?.data,
    isLoading,
    isError: error,
    mutate,
  };
}

