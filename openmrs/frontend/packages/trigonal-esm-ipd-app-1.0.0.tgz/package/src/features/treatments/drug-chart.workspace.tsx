import React, { useCallback, useEffect, useState, useMemo } from 'react';
import {
  Button,
  ButtonSet,
  Form,
  Stack,
  TextArea,
  TextInput,
  InlineNotification,
  Loading,
} from '@carbon/react';
import {
  showSnackbar,
  Workspace2,
  useSession,
  useConfig,
} from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import { saveMedication, updateMedication, fetchDrugConfigs, fetchDrugOrderFrequencies } from './treatments.resource';
import { resolveDisplayName } from '../../utils/display';
import styles from './treatments.scss';

dayjs.extend(utc);

interface DrugChartWorkspaceProps {
  drugOrder: any;
  isEdit?: boolean;
  mutate?: () => void;
}

const DrugChartWorkspace: React.FC<PatientWorkspace2DefinitionProps<DrugChartWorkspaceProps, any>> = ({
  groupProps: { patient },
  workspaceProps: { drugOrder, isEdit, mutate },
  closeWorkspace,
}) => {
  const patientUuid = patient.id;
  const { t } = useTranslation();
  const session = useSession();
  const config = useConfig();

  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notes, setNotes] = useState(drugOrder?.drugOrderSchedule?.notes || drugOrder?.drugOrderSchedule?.comments || '');

  // Scheduling state
  const [startTime, setStartTime] = useState('');
  const [firstDaySlots, setFirstDaySlots] = useState<string[]>([]);
  const [subsequentDaySlots, setSubsequentDaySlots] = useState<string[]>([]);
  const [finalDaySlots, setFinalDaySlots] = useState<string[]>([]);
  const [firstDaySlotsMissed, setFirstDaySlotsMissed] = useState(0);
  const [isUncommonFrequency, setIsUncommonFrequency] = useState(false);

  const asNeeded = !!drugOrder.asNeeded;
  const drugChartSliderConfig = config?.drugChartSlider || {};
  const timeWindowToDisableSlots = drugChartSliderConfig.timeInMinutesToDisableSlotPostScheduledTime || 0;

  const enableStartTime = useMemo(() => {
    // Ported logic: hostData?.startTimeFrequencies?.includes(frequency) || !frequency || !duration
    // For now, simplifying based on available drugOrder data
    return !drugOrder.frequency || !drugOrder.duration || isUncommonFrequency;
  }, [drugOrder, isUncommonFrequency]);

  const isFormValid = useMemo(() => {
    if (asNeeded) return true;

    if (enableStartTime && !startTime) return false;

    if (!isUncommonFrequency) {
      // Check first day slots (excluding disabled/missed ones)
      if (firstDaySlots.some((slot) => slot !== 'hh:mm' && !slot)) return false;
      // Check subsequent day slots
      if (subsequentDaySlots.some((slot) => !slot)) return false;
      // Check final day slots
      if (finalDaySlots.some((slot) => !slot)) return false;
    }

    return true;
  }, [asNeeded, enableStartTime, startTime, isUncommonFrequency, firstDaySlots, subsequentDaySlots, finalDaySlots]);

  const isTimePassed = useCallback((timeStr: string, window: number) => {
    if (!timeStr || timeStr === 'hh:mm') return true;
    const [h, m] = timeStr.split(':').map(Number);
    const now = dayjs();
    const scheduledTime = dayjs().hour(h).minute(m).second(0);
    return now.isAfter(scheduledTime.add(window, 'minutes'));
  }, []);

  const getUTCTime = useCallback((timeStr: string) => {
    if (!timeStr || timeStr === 'hh:mm') return null;
    const [h, m] = timeStr.split(':').map(Number);
    const scheduledDate = drugOrder.effectiveStartDate || drugOrder.dateActivated;
    return dayjs(scheduledDate).hour(h).minute(m).second(0).utc().unix();
  }, [drugOrder]);

  useEffect(() => {
    async function initWorkspace() {
      try {
        const [appCfgResponse, restFreqs] = await Promise.all([
          fetchDrugConfigs().catch(() => ({})),
          fetchDrugOrderFrequencies().catch(() => []),
        ]);

        const appCfg = appCfgResponse as any;

        // Dummy data for testing if config is empty
        if (!appCfg.drugChartScheduleFrequencies) {
          appCfg.drugChartScheduleFrequencies = [
            { name: 'Twice daily', frequencyPerDay: 2, scheduleTiming: ['06:00', '18:00'] },
            { name: 'Thrice daily', frequencyPerDay: 3, scheduleTiming: ['06:00', '14:00', '22:00'] },
            { name: 'Four times a day', frequencyPerDay: 4, scheduleTiming: ['06:00', '12:00', '18:00', '23:45'] },
          ];
        }

        const frequencyName = resolveDisplayName(drugOrder.frequency);
        const scheduleFreqs = appCfg.drugChartScheduleFrequencies || appCfg.scheduleFrequencies || [];

        let freqCfg = scheduleFreqs.find((f: any) => f.name === frequencyName);

        const uncommon = !freqCfg;
        setIsUncommonFrequency(uncommon);

        let frequencyPerDay = freqCfg?.frequencyPerDay || 0;

        // Fallback to REST API results if not in module config
        if (!freqCfg) {
          const restFreq = restFreqs?.find((f: any) => f.name === frequencyName);
          if (restFreq) {
            frequencyPerDay = restFreq.frequencyPerDay || 0;
            freqCfg = restFreq;
          }
        }

        if (isEdit) {
          const schedule = drugOrder.drugOrderSchedule;
          if (schedule) {
            const formatTime = (epoch: number) => dayjs.unix(epoch).local().format('HH:mm');

            if (schedule.slotStartTime) {
              setStartTime(formatTime(schedule.slotStartTime));
            }

            let missedCount = 0;
            if (schedule.firstDaySlotsStartTime) {
              const activeSlotsCount = schedule.firstDaySlotsStartTime.length;
              const actualFreq = Math.max(frequencyPerDay, activeSlotsCount);
              missedCount = Math.max(0, actualFreq - activeSlotsCount);

              setFirstDaySlotsMissed(missedCount);
              const slots = Array(missedCount).fill('hh:mm');
              const activeSlots = schedule.firstDaySlotsStartTime.map(formatTime);
              setFirstDaySlots([...slots, ...activeSlots]);
            }

            const subSlots = schedule.dayWiseSlotsStartTime?.map(formatTime) || [];
            const subMissing = Math.max(0, frequencyPerDay - subSlots.length);
            setSubsequentDaySlots([...subSlots, ...Array(subMissing).fill('')]);

            const finalSlots = schedule.remainingDaySlotsStartTime?.map(formatTime) || [];
            const finalMissing = Math.max(0, missedCount - finalSlots.length);
            setFinalDaySlots([...finalSlots, ...Array(finalMissing).fill('')]);
          }
        } else if (!asNeeded && frequencyPerDay > 0) {
          const timings = freqCfg?.scheduleTiming || Array(frequencyPerDay).fill('');
          let missedCount = 0;
          const firstDay: string[] = [];

          timings.forEach((time: string) => {
            if (time && isTimePassed(time, timeWindowToDisableSlots)) {
              firstDay.push('hh:mm');
              missedCount++;
            } else {
              firstDay.push(time);
            }
          });

          setFirstDaySlots(firstDay);
          setFirstDaySlotsMissed(missedCount);
          setSubsequentDaySlots(timings);
          setFinalDaySlots(timings.slice(0, missedCount).filter(Boolean));
        } else {
          // Default empty slots based on frequency discovered
          const defaultSlots = frequencyPerDay > 0 ? Array(frequencyPerDay).fill('') : [];
          setSubsequentDaySlots(defaultSlots);
        }
      } catch (err) {
        console.error('Failed to initialize drug chart workspace', err);
      } finally {
        setIsLoading(false);
      }
    }
    initWorkspace();
  }, [drugOrder, isEdit, asNeeded, isTimePassed, timeWindowToDisableSlots]);


  const handleSave = useCallback(async () => {
    setIsSubmitting(true);
    try {
      const payload: any = {
        patientUuid,
        orderUuid: drugOrder.orderUuid,
        comments: notes,
        providerUuid: session?.currentProvider?.uuid,
      };

      if (asNeeded) {
        payload.serviceType = 'AS_NEEDED_PLACEHOLDER';
      } else {
        payload.serviceType = 'MEDICATION_REQUEST';

        const SECONDS_IN_DAY = 24 * 60 * 60;
        const duration = Number(drugOrder.duration) || 0;

        if (isUncommonFrequency) {
          payload.slotStartTime = getUTCTime(startTime);
          payload.firstDaySlotsStartTime = null;
          payload.dayWiseSlotsStartTime = null;
          payload.remainingDaySlotsStartTime = null;
          payload.medicationFrequency = 'START_TIME_DURATION_FREQUENCY';
        } else {
          const firstDayUTCEpochs = firstDaySlots
            .map(getUTCTime)
            .filter((epoch): epoch is number => epoch !== null);

          const subsequentUTCEpochs = subsequentDaySlots
            .map(getUTCTime)
            .filter((epoch): epoch is number => epoch !== null);

          const finalUTCEpochs = finalDaySlots
            .map(getUTCTime)
            .filter((epoch): epoch is number => epoch !== null);

          // If there are missed slots, subsequent days are shifted by 1 day
          const dayWiseOffset = firstDaySlots.some(slot => slot === 'hh:mm') ? SECONDS_IN_DAY : 0;

          payload.firstDaySlotsStartTime = firstDaySlotsMissed > 0 ? firstDayUTCEpochs : [];
          payload.dayWiseSlotsStartTime = subsequentUTCEpochs.map(epoch => epoch + dayWiseOffset);

          // Final day slots are shifted by duration days
          payload.remainingDaySlotsStartTime = finalUTCEpochs
            .slice(0, firstDaySlotsMissed)
            .map(epoch => epoch + (duration * SECONDS_IN_DAY));

          if (enableStartTime) {
            payload.slotStartTime = getUTCTime(startTime);
            payload.medicationFrequency = 'START_TIME_DURATION_FREQUENCY';
          } else {
            payload.medicationFrequency = 'FIXED_SCHEDULE_FREQUENCY';
          }
        }
      }


      const response = isEdit ? await updateMedication(payload) : await saveMedication(payload);

      if (response.ok) {
        showSnackbar({
          title: isEdit ? t('drugScheduleUpdated', 'Drug schedule updated') : t('addedToDrugChart', 'Added to Drug Chart'),
          kind: 'success',
        });
        mutate?.();
        window.dispatchEvent(new CustomEvent('ipd:medication-refresh'));
        closeWorkspace();
      }
    } catch (err) {
      showSnackbar({
        title: t('errorSavingSchedule', 'Error saving drug schedule'),
        kind: 'error',
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [patientUuid, drugOrder, notes, session, asNeeded, firstDaySlots, subsequentDaySlots, finalDaySlots, firstDaySlotsMissed, enableStartTime, startTime, getUTCTime, isEdit, t, mutate, closeWorkspace]);

  if (isLoading) return <Loading withOverlay={false} />;

  return (
    <Workspace2 title={isEdit ? t('editDrugChart', 'Edit Drug Chart') : t('addToDrugChart', 'Add to Drug Chart')}>
      <div className={styles.drugChartForm}>
        <Stack gap={6} className={styles.workspaceContent}>
        <section className={styles.drugSection}>
          <h4>{resolveDisplayName(drugOrder.drugName)}</h4>
          <p>
            <strong>{resolveDisplayName(drugOrder.dose)} {resolveDisplayName(drugOrder.doseUnitsName)}</strong> {' • '}
            {resolveDisplayName(drugOrder.routeName)} {' • '}
            {resolveDisplayName(drugOrder.frequency)}
          </p>
        </section>

        {!asNeeded && (
          <Stack gap={6}>
            {enableStartTime && (
              <div className={styles.formGroup}>
                <TextInput
                  id="start-time"
                  type="time"
                  labelText={
                    <>
                      {isUncommonFrequency ? t('startTime12Hr', 'Start Time (12 hrs format)') : t('startTime', 'Start Time')}
                      <span className={styles.requiredIndicator}>*</span>
                    </>
                  }
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                />
              </div>
            )}

            {!isUncommonFrequency && firstDaySlots.length > 0 && (
              <div className={styles.scheduleSection}>
                <h5 className={styles.sectionTitle}>
                  {t('firstDaySchedule', 'First Day Schedule')}
                  <span className={styles.requiredIndicator}>*</span>
                </h5>
                <div className={styles.slotGrid}>
                  {firstDaySlots.map((slot, i) => (
                    <TextInput
                      key={`first-${i}`}
                      id={`first-${i}`}
                      type="time"
                      labelText=""
                      value={slot === 'hh:mm' ? '' : slot}
                      disabled={slot === 'hh:mm'}
                      placeholder={slot === 'hh:mm' ? 'Missed' : ''}
                      onChange={(e) => {
                        const newSlots = [...firstDaySlots];
                        newSlots[i] = e.target.value;
                        setFirstDaySlots(newSlots);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {!isUncommonFrequency && (
              <div className={styles.scheduleSection}>
              <h5 className={styles.sectionTitle}>
                {t('subsequentDaySchedule', 'Subsequent Day Schedule')}
                <span className={styles.requiredIndicator}>*</span>
              </h5>
              <div className={styles.slotGrid}>
                {subsequentDaySlots.map((slot, i) => (
                  <TextInput
                    key={`sub-${i}`}
                    id={`sub-${i}`}
                    type="time"
                    labelText=""
                    value={slot}
                    onChange={(e) => {
                      const newSlots = [...subsequentDaySlots];
                      newSlots[i] = e.target.value;
                      setSubsequentDaySlots(newSlots);
                    }}
                  />
                ))}
              </div>
            </div>
            )}

            {!isUncommonFrequency && finalDaySlots.length > 0 && (
              <div className={styles.scheduleSection}>
                <h5 className={styles.sectionTitle}>
                  {t('finalDaySchedule', 'Remaining slots (Final Day)')}
                  <span className={styles.requiredIndicator}>*</span>
                </h5>
                <div className={styles.slotGrid}>
                  {finalDaySlots.map((slot, i) => (
                    <TextInput
                      key={`final-${i}`}
                      id={`final-${i}`}
                      type="time"
                      labelText=""
                      value={slot}
                      onChange={(e) => {
                        const newSlots = [...finalDaySlots];
                        newSlots[i] = e.target.value;
                        setFinalDaySlots(newSlots);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
          </Stack>
        )}

        <TextArea
          id="notes"
          labelText={t('notes', 'Notes')}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
        />
        </Stack>

        <ButtonSet className={styles.buttonSet}>
          <Button kind="secondary" onClick={() => closeWorkspace()}>
            {t('cancel', 'Cancel')}
          </Button>
          <Button kind="primary" onClick={handleSave} disabled={isSubmitting || !isFormValid}>
            {isSubmitting ? t('saving', 'Saving...') : t('save', 'Save')}
          </Button>
        </ButtonSet>
      </div>
    </Workspace2>
  );
};

export default DrugChartWorkspace;

