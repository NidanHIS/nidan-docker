import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export async function saveMedication(payload: any) {
  return openmrsFetch(`${restBaseUrl}/ipd/schedule/type/medication`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function updateMedication(payload: any) {
  return openmrsFetch(`${restBaseUrl}/ipd/schedule/type/medication/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function stopDrugOrder(payload: any) {
  return openmrsFetch(`${restBaseUrl}/encounter`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function getOrder(orderUuid: string) {
  return openmrsFetch(`${restBaseUrl}/order/${orderUuid}`).then((res) => res.data);
}

export async function fetchDrugConfigs() {
  return openmrsFetch('/openmrs/apps/ipdDashboard/app.json').then((res) => res.data.config);
}

export async function getEncounterType(name: string) {
  return openmrsFetch(`${restBaseUrl}/encountertype?q=${name}&v=default`).then((res) => res.data.results?.[0]);
}

export async function fetchDrugOrderFrequencies() {
  return openmrsFetch(`${restBaseUrl}/bahmnicore/config/drugOrders`).then((res) => res.data.results);
}


