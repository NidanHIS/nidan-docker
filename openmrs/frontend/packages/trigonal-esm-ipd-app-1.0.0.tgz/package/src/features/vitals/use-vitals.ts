import { useMemo } from 'react';
import useSWRImmutable from 'swr/immutable';
import { fhirBaseUrl, openmrsFetch, useConfig } from '@openmrs/esm-framework';
import type { IpdConfig } from '../../config-schema';

interface FHIRObservation {
  id: string;
  code: {
    coding: Array<{ code: string; display: string }>;
    text: string;
  };
  effectiveDateTime?: string;
  valueQuantity?: {
    value: number;
    unit: string;
  };
  encounter?: {
    reference: string;
  };
}

interface FHIRBundle {
  entry?: Array<{
    resource: FHIRObservation;
  }>;
}

export interface VitalSignOrBiometric {
  date: string;
  systolic?: number;
  diastolic?: number;
  pulse?: number;
  temperature?: number;
  respiratoryRate?: number;
  spo2?: number;
  height?: number;
  weight?: number;
  bmi?: number;
  muac?: number;
}

export function useIpdVitals(patientUuid: string) {
  const config = useConfig<IpdConfig>();
  const { concepts } = config;

  // We fetch vitals & biometrics
  const conceptUuids = [
    concepts.systolicBloodPressureUuid,
    concepts.diastolicBloodPressureUuid,
    concepts.pulseUuid,
    concepts.temperatureUuid,
    concepts.respiratoryRateUuid,
    concepts.oxygenSaturationUuid,
    concepts.heightUuid,
    concepts.weightUuid,
    concepts.midUpperArmCircumferenceUuid,
  ]
    .filter(Boolean)
    .join(',');

  const url = patientUuid
    ? `${fhirBaseUrl}/Observation?subject:Patient=${patientUuid}&code=${conceptUuids}&_sort=-date&_count=100`
    : null;

  const { data, error, isLoading, isValidating } = useSWRImmutable<{ data: FHIRBundle }>(
    url,
    openmrsFetch
  );

  const parsedData = useMemo(() => {
    if (!data?.data?.entry) {
      return { vitals: [], biometrics: [] };
    }

    // Map raw observations to their concept
    const groupedData = data.data.entry.reduce((acc, entry) => {
      const resource = entry.resource;
      const code = resource.code?.coding?.[0]?.code;
      const dateStr = resource.effectiveDateTime;
      const value = resource.valueQuantity?.value;
      const encounterRef = resource.encounter?.reference;

      if (!code || !dateStr || value === undefined) return acc;

      // Group by encounter if available, otherwise exact timestamp
      const groupKey = encounterRef ? encounterRef : dateStr;

      if (!acc[groupKey]) {
        acc[groupKey] = { date: dateStr } as VitalSignOrBiometric;
      }

      switch (code) {
        case concepts.systolicBloodPressureUuid: acc[groupKey].systolic = value; break;
        case concepts.diastolicBloodPressureUuid: acc[groupKey].diastolic = value; break;
        case concepts.pulseUuid: acc[groupKey].pulse = value; break;
        case concepts.temperatureUuid: acc[groupKey].temperature = value; break;
        case concepts.respiratoryRateUuid: acc[groupKey].respiratoryRate = value; break;
        case concepts.oxygenSaturationUuid: acc[groupKey].spo2 = value; break;
        case concepts.heightUuid: acc[groupKey].height = value; break;
        case concepts.weightUuid: acc[groupKey].weight = value; break;
        case concepts.midUpperArmCircumferenceUuid: acc[groupKey].muac = value; break;
      }

      return acc;
    }, {} as Record<string, VitalSignOrBiometric>);

    const allData = Object.values(groupedData).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // Calculate BMI
    allData.forEach(row => {
      if (row.height && row.weight) {
        row.bmi = Number((row.weight / ((row.height / 100) ** 2)).toFixed(1));
      }
    });

    // Split out arrays based on data presence
    const vitals = allData.filter(row => row.systolic || row.diastolic || row.pulse || row.temperature || row.respiratoryRate || row.spo2);
    const biometrics = allData.filter(row => row.height || row.weight || row.bmi || row.muac);

    return { vitals, biometrics };
  }, [data, concepts]);

  return {
    vitals: parsedData.vitals,
    biometrics: parsedData.biometrics,
    isLoading,
    error,
    isValidating,
  };
}
