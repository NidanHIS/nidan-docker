import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button, InlineLoading, Tag, Tile } from '@carbon/react';
import { Hospital, HospitalBed } from '@carbon/react/icons';
import {
  launchWorkspace,
  launchWorkspace2,
  openmrsFetch,
  restBaseUrl,
  type Visit,
  formatDatetime,
  parseDate,
  useVisit,
  usePatient,
  useDefineAppContext,
} from '@openmrs/esm-framework';
import useSWR from 'swr';
import { usePatientBed } from '../patient-ipd/use-ipd-patient';
import { resolveDisplayName } from '../../utils/display';
import { publishAuditEvent } from '../../utils/audit-event';
import type { BedInformation } from '../../types';
import { Toggletip, ToggletipButton, ToggletipContent } from '@carbon/react';
import styles from './bed-assignment-banner.scss';

interface BedAssignmentBannerProps {
  patientUuid: string;
  visitUuid: string;
}

/**
 * BedAssignmentBanner — IPD-05
 *
 * Displayed at the top of the patient IPD dashboard (patient-ipd-banner-slot).
 *
 * Shows:
 *   - Current bed number and ward (if assigned)
 *   - Bed status tag (AVAILABLE / OCCUPIED)
 *   - "Assign Bed" or "Reassign Bed" button that opens the
 *     `assign-bed` workspace from @openmrs/esm-bed-management-app
 *
 * ## Workspace integration
 *
 * `@openmrs/esm-bed-management-app` must register a workspace named `assign-bed`.
 * It is listed in `spa-assemble-config.json` as `@openmrs/esm-bed-management-app: "next"`.
 * The workspace receives `{ patientUuid, visitUuid, currentBedId }` as props.
 *
 * Migration note: replaces the legacy Bahmni ADT modal (`PatientMovement.jsx`)
 * which used `axios.post(PATIENT_MOVEMENT_URL)` with a Bahmni encounter type.
 * In O3, bed management is handled by `esm-bed-management-app` via the
 * standard bedmanagement REST module.
 */
const BedAssignmentBanner: React.FC<BedAssignmentBannerProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { bed, isLoading, mutate } = usePatientBed(patientUuid);

  const typedBed = bed as BedInformation | null;

  const handleAssignBed = () => {
    publishAuditEvent('OPENED_BED_ASSIGNMENT', patientUuid, visitUuid);
    launchWorkspace('assign-bed', {
      patientUuid,
      visitUuid,
      currentBedId: typedBed?.uuid,
      onSuccess: mutate,
    });
  };

  if (isLoading) {
    return (
      <Tile className={styles.banner}>
        <InlineLoading description={t('loadingBed', 'Loading bed assignment…')} />
      </Tile>
    );
  }

  return (
    <Tile className={styles.banner}>
      <div className={styles.bedInfo}>
        <Hospital size={20} className={styles.bedIcon} />

        {typedBed ? (
          <>
            <div className={styles.bedDetails}>
              <span className={styles.bedLabel}>{t('currentBed', 'Current Bed')}</span>
              <span className={styles.bedNumber}>{resolveDisplayName(typedBed.bedNumber)}</span>
              {/* <Tag
                type={typedBed.status === 'OCCUPIED' ? 'green' : 'gray'}
                size="sm"
                className={styles.statusTag}
              >
                {t(
                  `bedStatus_${(typedBed.status ?? '').toLowerCase()}`,
                  typedBed.status ?? t('unknown', 'Unknown')
                )}  
              </Tag> */}
              {typedBed.physicalLocation?.display && (
                <span className={styles.wardLabel}>
                  {t('ward', 'Ward')}: {typedBed.physicalLocation.display}
                </span>
              )}
            </div>

            {/* <Button
            //todo reassign bed
              kind="tertiary"
              size="sm"
              renderIcon={Hospital}
              onClick={handleAssignBed}
            >
              {t('reassignBed', 'Reassign Bed')}
            </Button> */}
          </>
        ) : (
          <>
            <span className={styles.noBed}>{t('noBedAssigned', 'No bed assigned')}</span>
            <Button
              kind="primary"
              size="sm"
              renderIcon={Hospital}
              onClick={handleAssignBed}
            >
              {t('assignBed', 'Assign Bed')}
            </Button>
          </>
        )}
      </div>
    </Tile>
  );
};
const ADMISSION_REP =
  'custom:(visit,patient:(uuid,identifiers:(uuid,display,identifier,identifierType),voided,person:(uuid,display,gender,age,birthdate,birthtime,preferredName,preferredAddress,dead,deathDate)),encounterAssigningToCurrentInpatientLocation:(encounterDatetime),currentInpatientRequest:(dispositionLocation,dispositionType,disposition:(uuid,display),dispositionEncounter:(uuid,display),dispositionObsGroup:(uuid,display),visit:(uuid),patient:(uuid)),firstAdmissionOrTransferEncounter:(encounterDatetime),currentInpatientLocation,)';

const REQUEST_REP =
  'custom:(dispositionLocation,dispositionType,disposition,dispositionEncounter:full,patient:(uuid,identifiers,voided,person:(uuid,display,gender,age,birthdate,birthtime,preferredName,preferredAddress,dead,deathDate)),dispositionObsGroup,visit)';

const ADMISSION_LOCATION_REP =
  'custom:(ward,totalBeds,occupiedBeds,bedLayouts:(rowNumber,columnNumber,bedNumber,bedId,bedType,bedUuid,status,location,patients:(person:full,identifiers,uuid)))';

export const bedTagBadge: React.FC<BedAssignmentBannerProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { patient } = usePatient(patientUuid);
  const { activeVisit } = useVisit(patientUuid);
  const { bed, isLoading, mutate } = usePatientBed(patientUuid);
  const typedBed = bed as BedInformation | null;

  // Fetch inpatient admission
  const { data: admissionData } = useSWR(
    patientUuid ? `${restBaseUrl}/emrapi/inpatient/admission?patients=${patientUuid}&v=${ADMISSION_REP}` : null,
    openmrsFetch,
  );
  const inpatientAdmission = (admissionData as any)?.data?.results?.[0];

  // Fetch inpatient request
  const { data: requestData } = useSWR(
    patientUuid
      ? `${restBaseUrl}/emrapi/inpatient/request?patients=${patientUuid}&dispositionType=ADMIT,TRANSFER&v=${REQUEST_REP}`
      : null,
    openmrsFetch,
  );
  const inpatientRequest = (requestData as any)?.data?.results?.[0];

  const locationUuid = typedBed?.physicalLocation?.uuid || activeVisit?.location?.uuid;

  // Fetch admission location (beds)
  const {
    data: admissionLocationData,
    isLoading: isLoadingAdmissionLocation,
    mutate: mutateAdmissionLocation,
  } = useSWR(
    locationUuid ? `${restBaseUrl}/admissionLocation/${locationUuid}?v=${ADMISSION_LOCATION_REP}` : null,
    openmrsFetch,
  );
  const admissionLocation = (admissionLocationData as any)?.data;

  useDefineAppContext('ward-view-context', {
    wardPatientGroupDetails: {
      mutate: () => {
        mutate();
        mutateAdmissionLocation();
      },
      inpatientAdmissionsByPatientUuid: new Map([[patientUuid, inpatientAdmission]]),
      bedLayouts: admissionLocation?.bedLayouts || [],
      admissionLocationResponse: {
        data: admissionLocationData,
        isLoading: isLoadingAdmissionLocation,
        mutate: mutateAdmissionLocation,
      },
    },
    WardPatientHeader: null,
  });

  useDefineAppContext('ward-location-context', {
    location: typedBed?.physicalLocation?.uuid || activeVisit?.location,
  });

  if (!typedBed) return null;

  const handleOpenWardWorkspace = () => {
    launchWorkspace2(
      'ward-patient-workspace',
      {},
      {},
      {
        wardPatient: {
          patient: inpatientAdmission?.patient || inpatientRequest?.patient,
          visit: activeVisit,
          bed: typedBed
            ? {
                ...typedBed,
                id: typedBed.id || (typedBed as any).bedId,
              }
            : null,
          inpatientAdmission,
          inpatientRequest,
        },
      },
    );
  };

  return (
    <Toggletip align="bottom" className={styles.bannerBadge}>
      <ToggletipButton label={t('admitted', 'Admitted')}>
        <Tag
          type="blue"
          onClick={handleOpenWardWorkspace}
          style={{ cursor: 'pointer' }}
        >
          <HospitalBed size={12} className={styles.bedIcon} /> {resolveDisplayName(typedBed?.bedNumber)}
        </Tag>
      </ToggletipButton>
    </Toggletip>
  );
};

export default BedAssignmentBanner;