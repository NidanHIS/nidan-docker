import { Type } from '@openmrs/esm-framework';
import type { DashboardSection } from './types';

/**
 * Module config schema — all values are overridable via the O3 Implementer Tools.
 *
 * UUIDs here are OpenMRS defaults; implementers MUST override them with their
 * site-specific values via the implementer tools or config JSON.
 */
export const configSchema = {
  concepts: {
    systolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    diastolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    pulseUuid: {
      _type: Type.ConceptUuid,
      _default: '5087AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    temperatureUuid: {
      _type: Type.ConceptUuid,
      _default: '5088AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    oxygenSaturationUuid: {
      _type: Type.ConceptUuid,
      _default: '5092AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    respiratoryRateUuid: {
      _type: Type.ConceptUuid,
      _default: '5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    heightUuid: {
      _type: Type.ConceptUuid,
      _default: '5090AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    weightUuid: {
      _type: Type.ConceptUuid,
      _default: '5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    midUpperArmCircumferenceUuid: {
      _type: Type.ConceptUuid,
      _default: '1343AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    vitalSignsConceptSetUuid: {
      _type: Type.ConceptUuid,
      _default: '1114AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    nursingTaskTypesConceptSetUuid: {
      _type: Type.ConceptUuid,
      _default: 'c2144f97-efa1-49c0-b9f2-2b3e8bf974a9',
    },
    defaultNursingTaskTypeUuid: {
      _type: Type.ConceptUuid,
      _default: 'ada92e1a-81e5-4607-a003-3bed8356549e',
    },
  },

  /** Location tag UUID that identifies "admission" locations (wards) */
  admissionLocationTagUuid: {
    _type: Type.UUID,
    _description: 'UUID of the "Admission Location" location tag',
    _default: '7d0f0b44-dc7a-11e8-9f8b-f2801f1b9fd1',
  },

  /** Encounter type UUID for bed-assignment (ADT) events */
  admissionEncounterTypeUuid: {
    _type: Type.UUID,
    _description: 'UUID of the Admission encounter type',
    _default: 'e22e39fd-7db2-45e7-80f1-60fa0d5a4378',
  },

  /** Encounter type UUID for IPD visit note/discharge */
  dischargeEncounterTypeUuid: {
    _type: Type.UUID,
    _description: 'UUID of the Discharge encounter type',
    _default: '181820aa-88c9-479b-9077-af92f5364329',
  },

  /** Visit type UUID for IPD visits */
  ipdVisitTypeUuid: {
    _type: Type.UUID,
    _description: 'UUID of the IPD visit type',
    _default: '7b0f5697-27e3-40c4-8bae-f4049abfb4ed',
  },

  /** Whether to show medication drug chart in the IPD patient dashboard */
  showMedicationChart: {
    _type: Type.Boolean,
    _description: 'Show the medication drug chart section in the IPD patient dashboard',
    _default: true,
  },

  /** Whether to show nursing tasks section */
  showNursingTasks: {
    _type: Type.Boolean,
    _description: 'Show the nursing tasks section in the IPD patient dashboard',
    _default: true,
  },

  /** Whether to show intake-output section */
  showIntakeOutput: {
    _type: Type.Boolean,
    _description: 'Show the intake-output section in the IPD patient dashboard',
    _default: true,
  },

  /** Whether to show non-medication tasks section */
  showNonMedicationTasks: {
    _type: Type.Boolean,
    _description: 'Show the non-medication tasks section in the IPD patient dashboard',
    _default: false,
  },

  /** Ordered list of sections to display in the patient IPD dashboard */
  ipdDashboardSections: {
    _type: Type.Array,
    _description: 'Ordered list of dashboard sections. Each entry is {componentKey, title, displayOrder}.',
    _elements: {
      _type: Type.Object,
      componentKey: {
        _type: Type.String,
        _description: 'One of AL, VT, DG, TR, NT, DC, IO',
      },
      title: {
        _type: Type.String,
      },
      displayOrder: {
        _type: Type.Number,
      },
    },
    _default: [
      { componentKey: 'AL', title: 'Allergies', displayOrder: 1 },
      { componentKey: 'VT', title: 'Vitals', displayOrder: 2 },
      { componentKey: 'DG', title: 'Diagnosis', displayOrder: 3 },
      { componentKey: 'TR', title: 'Treatments', displayOrder: 4 },
      { componentKey: 'NT', title: 'Nursing Tasks', displayOrder: 5 },
      { componentKey: 'DC', title: 'Drug Chart', displayOrder: 6 },
      { componentKey: 'IO', title: 'Intake Output', displayOrder: 7 },
      { componentKey: 'NMT', title: 'Non-Medication Tasks', displayOrder: 8 },
    ] satisfies DashboardSection[],
  },

  /** Minimum characters required for ward patient search */
  patientSearchMinChars: {
    _type: Type.Number,
    _description: 'Minimum characters to trigger patient search within a ward',
    _default: 3,
  },

  /** Late window in minutes for nursing tasks before a note is required */
  nursingTaskLateWindowMinutes: {
    _type: Type.Number,
    _description: 'Number of minutes after scheduled time before a note is mandatory for administration.',
    _default: 60,
  },

  /** Configuration for the drug chart slider/workspace */
  drugChartSlider: {
    _type: Type.Object,
    _description: 'Configuration for the drug chart administration workspace',
    timeInMinutesToDisableSlotPostScheduledTime: {
      _type: Type.Number,
      _description: 'Number of minutes after a scheduled slot is considered "missed".',
      _default: 60,
    },
  },

  /** UUID of the Intake/Output form */
  intakeOutputFormUuid: {
    _type: Type.UUID,
    _description: 'UUID of the Intake/Output form',
    _default: 'de010f04-2eb5-3a9c-afec-587868f3c2fa',
  },

  /**
   * Shift time definitions keyed by shift number.
   * Each entry defines the start and end time (HH:mm, 24-hour) for that shift.
   * Shift 2 can span midnight (e.g. 19:00 → 08:00 next day).
   */
  shiftDetails: {
    _type: Type.Object,
    _description: 'Shift time windows keyed by shift number (1-based)',
    _default: {
      '1': { shiftStartTime: '06:00', shiftEndTime: '13:00' },
      '2': { shiftStartTime: '13:00', shiftEndTime: '17:00' },
      '3': { shiftStartTime: '17:00', shiftEndTime: '06:00' }
    },
  },
};

export type IpdConfig = {
  concepts: {
    systolicBloodPressureUuid: string;
    diastolicBloodPressureUuid: string;
    pulseUuid: string;
    temperatureUuid: string;
    oxygenSaturationUuid: string;
    respiratoryRateUuid: string;
    heightUuid: string;
    weightUuid: string;
    midUpperArmCircumferenceUuid: string;
    vitalSignsConceptSetUuid: string;
    nursingTaskTypesConceptSetUuid: string;
    defaultNursingTaskTypeUuid: string;
  };
  admissionLocationTagUuid: string;
  admissionEncounterTypeUuid: string;
  dischargeEncounterTypeUuid: string;
  ipdVisitTypeUuid: string;
  showMedicationChart: boolean;
  showNursingTasks: boolean;
  showIntakeOutput: boolean;
  showNonMedicationTasks: boolean;
  ipdDashboardSections: DashboardSection[];
  patientSearchMinChars: number;
  nursingTaskLateWindowMinutes: number;
  drugChartSlider: {
    timeInMinutesToDisableSlotPostScheduledTime: number;
  };
  intakeOutputFormUuid: string;
  shiftDetails: Record<string, { shiftStartTime: string; shiftEndTime: string }>;
};

