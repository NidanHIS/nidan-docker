/** OpenMRS core types used across the IPD module */

export interface OpenmrsResource {
  uuid: string;
  display?: string;
}

export interface Person extends OpenmrsResource {
  display: string;
  gender?: string;
  age?: number;
  birthdate?: string;
  attributes?: Array<{ attributeType: OpenmrsResource; value: string }>;
}

export interface Patient extends OpenmrsResource {
  display: string;
  person: Person;
  identifiers: Array<PatientIdentifier>;
}

export interface PatientIdentifier extends OpenmrsResource {
  identifier: string;
  identifierType: OpenmrsResource;
  preferred: boolean;
}

/** Admission / Ward types */
export interface AdmissionLocation extends OpenmrsResource {
  ward: OpenmrsResource;
  totalBeds: number;
  occupiedBeds: number;
}

export interface WardSummary {
  totalPatients: number;
  myPatients: number;
  ward: OpenmrsResource;
}

export interface BedInformation extends OpenmrsResource {
  bedNumber: string;
  bedType: OpenmrsResource;
  status: 'AVAILABLE' | 'OCCUPIED';
  location: OpenmrsResource;
}

export interface AdmittedPatient {
  patient: Patient;
  bed: BedInformation | null;
  visit: Visit;
  currentAdmission: Encounter | null;
}

export interface Visit extends OpenmrsResource {
  visitType: OpenmrsResource;
  startDatetime: string;
  stopDatetime?: string;
  location: OpenmrsResource;
  encounters?: Encounter[];
}

export interface Encounter extends OpenmrsResource {
  encounterType: OpenmrsResource;
  encounterDatetime: string;
  patient: OpenmrsResource;
  location?: OpenmrsResource;
  obs?: Array<Observation>;
}

export interface Observation extends OpenmrsResource {
  concept: OpenmrsResource;
  value: string | number | OpenmrsResource;
  obsDatetime: string;
}

/** Medication types */
export interface MedicationSchedule {
  uuid: string;
  drug: OpenmrsResource & { name: string };
  dose: number;
  doseUnits: OpenmrsResource;
  frequency: OpenmrsResource;
  route: OpenmrsResource;
  startDate: string;
  endDate?: string;
  slots: MedicationSlot[];
}

export interface MedicationSlot {
  uuid: string;
  scheduledDate: string;
  status: 'SCHEDULED' | 'COMPLETED' | 'NOT_DONE' | 'MISSED' | 'STOPPED' | 'ADMINISTERED';
  administeredDateTime?: string;
  administeredBy?: OpenmrsResource;
  notes?: string;
  serviceType?: string;
  order?: { uuid: string; asNeeded?: boolean };
}

/** Nursing task types */
export interface NursingTask extends OpenmrsResource {
  name: string;
  description?: string;
  intent: string;
  status: 'REQUESTED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  patient: OpenmrsResource;
  forRequest?: OpenmrsResource;
  executionPeriod?: { start: string; end?: string };
  taskType?: OpenmrsResource;
}

/** IPD Dashboard section config */
export interface DashboardSection {
  componentKey: string;
  title: string;
  displayOrder: number;
  config?: Record<string, unknown>;
  refreshKey?: number;
}

/** Care View context value */
export interface CareViewContextValue {
  selectedWard: Partial<AdmissionLocation>;
  setSelectedWard: (ward: Partial<AdmissionLocation>) => void;
  wardSummary: Partial<WardSummary>;
  setWardSummary: (summary: Partial<WardSummary>) => void;
  headerSelected: string;
  setHeaderSelected: (header: string) => void;
  refreshPatientList: boolean;
  handleRefreshPatientList: () => void;
  refreshSummary: boolean;
  handleRefreshSummary: () => void;
}

/** REST API response wrappers */
export interface RestApiResult<T> {
  results: T[];
  links?: Array<{ rel: string; uri: string }>;
}
