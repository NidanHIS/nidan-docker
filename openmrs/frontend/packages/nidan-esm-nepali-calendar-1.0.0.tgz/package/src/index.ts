/**
 * Nidan Nepali Calendar — entry point.
 *
 * Design intent (post-toggle refactor): *presence of this package* is the
 * configuration switch. Install it → date inputs and read-only displays
 * use BS + AD; don't install it → upstream OpenMRS behaviour, AD only.
 * No user-facing toggle, no per-tab mode store.
 *
 * - Declares the OpenMRS config schema.
 * - Registers form-engine custom controls + schema transformer at
 *   startup (BEFORE any form is loaded — that's why this fires in
 *   `startupApp`, not lazily).
 */

import { defineConfigSchema, getSyncLifecycle, OpenmrsDatePicker } from '@openmrs/esm-framework';
import * as openmrsFramework from '@openmrs/esm-framework';
import { featureName, moduleName } from './constants';
import { configSchema } from './config-schema';
import { registerBsCalendarHooks } from './form-engine/register';
import { installOpenmrsDatePickerWrapSync, WRAP_MARKER, WRAP_VERSION } from './lib/wrap-openmrs-date-picker';
import { installFormatDateWrapSync } from './lib/wrap-format-date';
import InitAnchor from './components/init-anchor.component';

// Wrap as soon as this bundle loads — before startupApp / first date field render.
const pickerVersion = (OpenmrsDatePicker as { __nidanWrapVersion?: number } & { [WRAP_MARKER]?: boolean })[
  '__nidanWrapVersion'
] ?? 0;
if (!(OpenmrsDatePicker as { [WRAP_MARKER]?: boolean })[WRAP_MARKER] || pickerVersion < WRAP_VERSION) {
  installOpenmrsDatePickerWrapSync(
    openmrsFramework as unknown as Record<string, unknown> & {
      OpenmrsDatePicker?: typeof OpenmrsDatePicker;
    },
  );
}

installFormatDateWrapSync(openmrsFramework as unknown as Record<string, unknown>);

if (typeof window !== 'undefined' && !(window as Window & { __NIDAN_PICKER_V7_LOGGED?: boolean }).__NIDAN_PICKER_V7_LOGGED) {
  (window as Window & { __NIDAN_PICKER_V7_LOGGED?: boolean }).__NIDAN_PICKER_V7_LOGGED = true;
  // eslint-disable-next-line no-console
  console.info(
    '[nidan-nepali-calendar] OpenmrsDatePicker v7 active — BS default tab, equivalent span beside AD|BS; read-only dates append BS suffix',
  );
}

const options = { featureName, moduleName };

/** Webpack lazy-loads translations per locale. */
export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  // EVERY step is wrapped so a single failure inside this module
  // cannot bring the OpenMRS SPA shell down. The SPA's app loader
  // surfaces any startupApp throw as a hard crash — we'd rather degrade
  // gracefully and leave breadcrumbs in the console for the operator.
  try {
    defineConfigSchema(moduleName, configSchema);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[nidan-nepali-calendar] defineConfigSchema failed:', err);
  }
  try {
    registerBsCalendarHooks();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(
      '[nidan-nepali-calendar] form-engine registration failed:',
      err,
    );
  }
}

// ── Extensions ──────────────────────────────────────────────────────────────

/**
 * Invisible top-nav entry. Exists ONLY to trigger the framework's
 * lifecycle loader so our `startupApp` runs and the BS form-engine
 * controls get registered. See InitAnchor for the full background.
 */
export const initAnchor = getSyncLifecycle(InitAnchor, options);

// ── Re-exports for Phase 2 consumers ────────────────────────────────────────

/**
 * Public helpers other Nidan ESM apps can consume directly (read-only
 * display surfaces, custom date inputs). Importing from this entry
 * point keeps the BS library single-sourced.
 */
export { default as AdWithBsDisplay } from './components/ad-with-bs-display.component';
export { default as BSDatePicker } from './components/bs-date-picker.component';
export { default as NidanDate, type NidanDatePrecision } from './components/nidan-date.component';
export * from './lib/bs-converter';
