'use strict';
/**
 * postinstall for @nidan/esm-nepali-calendar
 * - Git checkout / local dev: run the openmrs importmap localhost → 127.0.0.1 patch.
 * - Packed install (e.g. Docker `yarn add *.tgz`): usually only this file ships — exit 0.
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const pkgRoot = path.join(__dirname, '..');
const patchScript = path.join(__dirname, 'patch-openmrs-localhost-mf.js');

if (fs.existsSync(patchScript)) {
  const r = spawnSync(process.execPath, [patchScript], { cwd: pkgRoot, stdio: 'inherit' });
  if (r.status !== 0 && r.status != null) {
    process.exit(r.status);
  }
}
