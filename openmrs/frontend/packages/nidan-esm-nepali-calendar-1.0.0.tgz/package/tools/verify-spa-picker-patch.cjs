#!/usr/bin/env node
/**
 * Post-`openmrs build` gate for Nepali calendar SPA builds.
 * - Picker patch markers must appear in a non-MF shell chunk.
 * - esm-utils formatDate patch must be present on disk under node_modules.
 * - Nidan MF must include the runtime formatDate wrap.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const LP = '[verify-spa-picker-patch]';
const root = process.argv[2] || '/app/spa';
const allowMissing = process.argv.includes('--allow-missing');

const PICKER_REQUIRED = ['nidan-picker-equivalent', 'nidan-bs-popover-close', 'nidan-picker-v7'];
const FORMAT_PATCH_FILE_MARKERS = [
  '/* @nidan/esm-nepali-calendar formatDate BS suffix v1 */',
  "' (BS '",
];
const RUNTIME_FORMAT_MARKERS = ['__nidanFormatDateWrapped', ' (BS '];
const FORBIDDEN = ['[nidan-picker-wrap]', 'Select date (BS)'];

function safeIsFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

function findEsmUtilsDateUtilFiles() {
  const files = new Set();
  const cwdFile = path.join(process.cwd(), 'node_modules', '@openmrs', 'esm-utils', 'dist', 'dates', 'date-util.js');
  if (safeIsFile(cwdFile)) files.add(cwdFile);

  const queue = [path.join(process.cwd(), 'node_modules')];
  const seen = new Set();
  while (queue.length > 0) {
    const nm = queue.shift();
    if (!nm || seen.has(nm) || !fs.existsSync(nm)) continue;
    seen.add(nm);
    const candidate = path.join(nm, '@openmrs', 'esm-utils', 'dist', 'dates', 'date-util.js');
    if (safeIsFile(candidate)) files.add(candidate);
    let entries;
    try {
      entries = fs.readdirSync(nm, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const ent of entries) {
      if (ent.isDirectory() && ent.name === 'node_modules') {
        queue.push(path.join(nm, ent.name));
      }
    }
  }
  return [...files];
}

function verifyEsmUtilsPatchOnDisk() {
  const files = findEsmUtilsDateUtilFiles();
  if (files.length === 0) {
    console.error(`${LP} No @openmrs/esm-utils dist/dates/date-util.js found under node_modules`);
    return false;
  }
  for (const file of files) {
    let content;
    try {
      content = fs.readFileSync(file, 'utf8');
    } catch {
      continue;
    }
    const ok = FORMAT_PATCH_FILE_MARKERS.every((m) => content.includes(m));
    if (ok) {
      console.log(`${LP} esm-utils formatDate patch OK on disk: ${file}`);
      return true;
    }
  }
  console.error(`${LP} esm-utils formatDate patch missing or incomplete on disk`);
  for (const file of files.slice(0, 3)) {
    console.error(`${LP}   checked: ${file}`);
  }
  return false;
}

function* walkJs(dir) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) yield* walkJs(p);
    else if (ent.isFile() && p.endsWith('.js')) yield p;
  }
}

if (!fs.existsSync(root)) {
  console.error(`${LP} ${root} does not exist`);
  process.exit(allowMissing ? 0 : 2);
}

if (!verifyEsmUtilsPatchOnDisk()) {
  process.exit(2);
}

const forbidden = [];
const pickerFound = new Set();
let runtimeFormatFound = false;
let pickerInShell = false;
let nidanChunkFound = false;

for (const file of walkJs(root)) {
  let content;
  try {
    content = fs.readFileSync(file, 'utf8');
  } catch {
    continue;
  }
  if (file.includes('nidan-esm-nepali-calendar')) {
    nidanChunkFound = true;
  }
  for (const marker of FORBIDDEN) {
    if (content.includes(marker)) {
      forbidden.push({ file, marker });
      break;
    }
  }
  if (RUNTIME_FORMAT_MARKERS.some((m) => content.includes(m))) {
    runtimeFormatFound = true;
  }
  const isNidanChunk = file.includes('nidan-esm-nepali-calendar');
  for (const marker of PICKER_REQUIRED) {
    if (content.includes(marker)) {
      pickerFound.add(marker);
      if (!isNidanChunk) pickerInShell = true;
    }
  }
}

if (forbidden.length > 0) {
  console.error(`${LP} Retired patch artifacts detected — rebuild with --no-cache:`);
  for (const f of forbidden.slice(0, 5)) {
    console.error(`${LP}   ${f.marker} → ${f.file}`);
  }
  process.exit(2);
}

const missingPicker = PICKER_REQUIRED.filter((m) => !pickerFound.has(m));
if (missingPicker.length > 0) {
  console.error(`${LP} Missing picker markers: ${missingPicker.join(', ')}`);
  process.exit(2);
}

if (!runtimeFormatFound) {
  console.error(`${LP} Missing runtime formatDate wrap markers in SPA output`);
  process.exit(2);
}

if (!nidanChunkFound) {
  console.error(`${LP} No nidan-esm-nepali-calendar chunk in ${root}`);
  process.exit(2);
}

if (!pickerInShell) {
  console.error(`${LP} Picker markers found only in MF chunk — styleguide patch may not have bundled`);
  process.exit(2);
}

console.log(`${LP} OK`);
process.exit(0);
