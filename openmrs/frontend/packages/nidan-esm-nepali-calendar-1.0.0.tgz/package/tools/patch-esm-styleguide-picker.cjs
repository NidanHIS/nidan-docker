#!/usr/bin/env node
/**
 * Patches @openmrs/esm-styleguide OpenmrsDatePicker for global AD/BS tabs.
 * Run via tools/spa-build-hook.cjs patch (after openmrs assemble, before openmrs build).
 */
'use strict';

const fs = require('fs');
const path = require('path');

function parseArgs(argv) {
  const opts = { allowSkip: false, extraRoots: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--allow-skip') {
      opts.allowSkip = true;
    } else if (arg === '--root' && argv[i + 1]) {
      opts.extraRoots.push(path.resolve(argv[++i]));
    } else if (!arg.startsWith('-')) {
      opts.extraRoots.push(path.resolve(arg));
    }
  }
  return opts;
}

const MARKER = '/* @nidan/esm-nepali-calendar OpenmrsDatePicker wrap v9 */';
const NIDAN_PICKER_VERSION = '9';
const MARKER_PREFIX = '@nidan/esm-nepali-calendar OpenmrsDatePicker wrap';
const LOG_PREFIX = '[patch-esm-styleguide-picker]';

// Build stamp: lets us correlate a deployed bundle's logs with a
// specific docker build. The user can grep this string in the
// container's nginx html dir to confirm the bundle was actually
// produced by this patch run rather than a cached layer.
const BUILD_STAMP = new Date().toISOString() + '_' + Math.random().toString(36).slice(2, 8);

// === BS month-day table — KEEP IN SYNC with src/lib/bs-calendar-data.ts ===
const BS_MONTH_DATA = {
  1975: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  1976: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  1977: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  1978: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1979: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  1980: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  1981: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  1982: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1983: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  1984: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  1985: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  1986: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1987: [31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  1988: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  1989: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  1990: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1991: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  1992: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  1993: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1994: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1995: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  1996: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  1997: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1998: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  1999: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2000: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2001: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2002: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2003: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2004: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2005: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2006: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2007: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2008: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31],
  2009: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2010: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2011: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2012: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  2013: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2014: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2015: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2016: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  2017: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2018: [31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2019: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2020: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2021: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2022: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  2023: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2024: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2025: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2026: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2027: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2028: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2029: [31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30],
  2030: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2031: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2032: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2033: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2034: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2035: [30, 32, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31],
  2036: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2037: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2038: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2039: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  2040: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2041: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2042: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2043: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  2044: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2045: [31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2046: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2047: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2048: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2049: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  2050: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2051: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2052: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2053: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  2054: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2055: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2056: [31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30],
  2057: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2058: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2059: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2060: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2061: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2062: [30, 32, 31, 32, 31, 31, 29, 30, 29, 30, 29, 31],
  2063: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2064: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2065: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2066: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31],
  2067: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2068: [31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2069: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2070: [31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30],
  2071: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2072: [31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2073: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2074: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2075: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2076: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  2077: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2078: [31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30],
  2079: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2080: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30],
  2081: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2082: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2083: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2084: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31],
  2085: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31],
  2086: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30],
  2087: [31, 31, 32, 31, 31, 31, 30, 30, 29, 30, 30, 30],
  2088: [30, 31, 32, 32, 30, 31, 30, 30, 29, 30, 30, 30],
  2089: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30],
  2090: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30],
  2091: [31, 31, 32, 31, 31, 31, 30, 30, 29, 30, 30, 30],
  2092: [30, 31, 32, 32, 31, 30, 30, 30, 29, 30, 30, 30],
  2093: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30],
  2094: [31, 31, 32, 31, 31, 30, 30, 30, 29, 30, 30, 30],
  2095: [31, 31, 32, 31, 31, 31, 30, 29, 30, 30, 30, 30],
  2096: [30, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30],
  2097: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30],
  2098: [31, 31, 32, 31, 31, 31, 29, 30, 29, 30, 29, 31],
  2099: [31, 31, 32, 31, 31, 31, 30, 29, 29, 30, 30, 30],
  2100: [31, 32, 31, 32, 30, 31, 30, 29, 30, 29, 30, 30],
};

// Finds every esm-styleguide install root and returns a list of
// `{ root, mode, target }`:
//   mode === 'split'   → 9.x-style layout, target = dist/datepicker/index.js
//                        (we rewrite that file to re-export a wrapper).
//   mode === 'bundle'  → 8.x-style layout, target = dist/openmrs-esm-styleguide.js
//                        (we append a CJS IIFE that reassigns module.exports.OpenmrsDatePicker).
// The two layouts have completely different patch strategies, so we
// detect per-install which one applies.
function collectNodeModulesRoots(extraRoots) {
  const nodeModulesRoots = new Set();
  const cwdNm = path.join(process.cwd(), 'node_modules');
  if (safeIsDir(cwdNm)) nodeModulesRoots.add(cwdNm);
  let dirUp = process.cwd();
  for (let i = 0; i < 6; i++) {
    const nm = path.join(dirUp, 'node_modules');
    if (safeIsDir(nm)) nodeModulesRoots.add(nm);
    dirUp = path.dirname(dirUp);
  }
  let dirOwn = __dirname;
  while (dirOwn && dirOwn !== path.dirname(dirOwn)) {
    if (path.basename(dirOwn) === 'node_modules') nodeModulesRoots.add(dirOwn);
    dirOwn = path.dirname(dirOwn);
  }
  for (const extra of extraRoots) {
    const nm = path.join(extra, 'node_modules');
    if (safeIsDir(nm)) nodeModulesRoots.add(nm);
  }
  return nodeModulesRoots;
}

// Also walk arbitrary trees (e.g. a unpacked package cache) for esm-styleguide dirs.
function walkTreeForStyleguideRoots(dir, roots, depth) {
  if (depth > 8 || !safeIsDir(dir)) return;
  if (path.basename(dir) === 'esm-styleguide' && safeIsFile(path.join(dir, 'package.json'))) {
    roots.add(dir);
    return;
  }
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    if (ent.name === 'node_modules' || ent.name.startsWith('.')) {
      walkTreeForStyleguideRoots(path.join(dir, ent.name), roots, depth + 1);
      continue;
    }
    if (ent.name === 'esm-styleguide') {
      roots.add(path.join(dir, ent.name));
      continue;
    }
    walkTreeForStyleguideRoots(path.join(dir, ent.name), roots, depth + 1);
  }
}

function findStyleguideTargets(extraRoots) {
  const roots = new Set();
  const nodeModulesRoots = collectNodeModulesRoots(extraRoots);
  for (const root of nodeModulesRoots) walkCollectStyleguideRoots(root, roots);
  for (const extra of extraRoots) walkTreeForStyleguideRoots(extra, roots, 0);

  const targets = [];
  for (const root of roots) {
    const splitFile = path.join(root, 'dist', 'datepicker', 'index.js');
    const bundleFile = path.join(root, 'dist', 'openmrs-esm-styleguide.js');
    if (safeIsFile(splitFile)) {
      targets.push({ root, mode: 'split', target: splitFile });
    } else if (safeIsFile(bundleFile)) {
      targets.push({ root, mode: 'bundle', target: bundleFile });
    }
  }
  return targets;
}

function walkCollectStyleguideRoots(nmRoot, roots) {
  let entries;
  try {
    entries = fs.readdirSync(nmRoot, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    if (ent.name.startsWith('@')) {
      let scopeEntries;
      try {
        scopeEntries = fs.readdirSync(path.join(nmRoot, ent.name), { withFileTypes: true });
      } catch {
        continue;
      }
      for (const se of scopeEntries) {
        if (!se.isDirectory()) continue;
        const pkgDir = path.join(nmRoot, ent.name, se.name);
        if (se.name === 'esm-styleguide') roots.add(pkgDir);
        const nestedNm = path.join(pkgDir, 'node_modules');
        if (safeIsDir(nestedNm)) walkCollectStyleguideRoots(nestedNm, roots);
      }
    } else {
      const nestedNm = path.join(nmRoot, ent.name, 'node_modules');
      if (safeIsDir(nestedNm)) walkCollectStyleguideRoots(nestedNm, roots);
    }
  }
}

function safeIsDir(p) {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
}
function safeIsFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

function diagnoseMissing() {
  const omrsDir = path.join(process.cwd(), 'node_modules', '@openmrs');
  console.error(`${LOG_PREFIX} Searched CWD = ${process.cwd()}`);
  try {
    console.error(`${LOG_PREFIX} ${omrsDir} contains: ${fs.readdirSync(omrsDir).join(', ')}`);
  } catch (e) {
    console.error(`${LOG_PREFIX} ${omrsDir} not readable: ${e.message}`);
  }
  // Dive into esm-styleguide so we can see how its dist is laid out
  // in this image — different package versions ship different
  // sub-structures and the target path may need updating.
  const sg = path.join(omrsDir, 'esm-styleguide');
  if (safeIsDir(sg)) {
    try {
      console.error(`${LOG_PREFIX} ${sg} contains: ${fs.readdirSync(sg).join(', ')}`);
    } catch (e) {
      console.error(`${LOG_PREFIX} ${sg} listing failed: ${e.message}`);
    }
    const sgDist = path.join(sg, 'dist');
    if (safeIsDir(sgDist)) {
      try {
        console.error(`${LOG_PREFIX} ${sgDist} contains: ${fs.readdirSync(sgDist).join(', ')}`);
      } catch (e) {
        console.error(`${LOG_PREFIX} ${sgDist} listing failed: ${e.message}`);
      }
      const sgDp = path.join(sgDist, 'datepicker');
      if (safeIsDir(sgDp)) {
        try {
          console.error(`${LOG_PREFIX} ${sgDp} contains: ${fs.readdirSync(sgDp).join(', ')}`);
        } catch (e) {
          console.error(`${LOG_PREFIX} ${sgDp} listing failed: ${e.message}`);
        }
      } else {
        console.error(`${LOG_PREFIX} ${sgDp} is NOT a directory`);
      }
    } else {
      console.error(`${LOG_PREFIX} ${sgDist} is NOT a directory`);
    }
    // Also list the package version + main fields so we can see which
    // build we got.
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(sg, 'package.json'), 'utf8'));
      console.error(`${LOG_PREFIX} ${sg}/package.json: version=${pkg.version}, module=${pkg.module}, main=${pkg.main}`);
    } catch (e) {
      console.error(`${LOG_PREFIX} ${sg}/package.json read failed: ${e.message}`);
    }
  }
}

// The new index.js content. Replaces the original two re-export lines
// with: an aliased import of the original picker, a self-contained
// wrapper component, and re-exports.
function generatePatchedIndex() {
  return `${MARKER}
// build-stamp=${BUILD_STAMP}
import React, { forwardRef, useState, useMemo, useCallback, useEffect, useRef } from "react";
import { OpenmrsDatePicker as _NidanOriginalOpenmrsDatePicker } from "./openmrs-date-picker.component.js";
export { OpenmrsDateRangePicker } from "./openmrs-date-range-picker.component.js";

// === Inlined BS conversion (KEEP IN SYNC with package's bs-converter) ===
const _NIDAN_BS_MONTH_DATA = ${JSON.stringify(BS_MONTH_DATA)};
const _NIDAN_BS_EPOCH_YEAR = 1975;
const _NIDAN_BS_EPOCH_AD = new Date(1918, 3, 13);
const _NIDAN_MS_PER_DAY = 86400000;

function _nidanAdToBS(d) {
  const epochMid = Date.UTC(
    _NIDAN_BS_EPOCH_AD.getFullYear(),
    _NIDAN_BS_EPOCH_AD.getMonth(),
    _NIDAN_BS_EPOCH_AD.getDate(),
  );
  const targetMid = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate());
  let totalDays = Math.floor((targetMid - epochMid) / _NIDAN_MS_PER_DAY);
  if (totalDays < 0) throw new Error('pre-epoch');
  const years = Object.keys(_NIDAN_BS_MONTH_DATA).map(Number);
  const maxYear = Math.max.apply(null, years);
  for (let y = _NIDAN_BS_EPOCH_YEAR; y <= maxYear; y++) {
    const months = _NIDAN_BS_MONTH_DATA[y];
    if (!months) throw new Error('beyond range');
    for (let m = 0; m < 12; m++) {
      if (totalDays < months[m]) return { year: y, month: m + 1, day: totalDays + 1 };
      totalDays -= months[m];
    }
  }
  throw new Error('beyond range');
}

function _nidanBsToAD(year, month, day) {
  let totalDays = 0;
  for (let y = _NIDAN_BS_EPOCH_YEAR; y < year; y++) {
    const months = _NIDAN_BS_MONTH_DATA[y];
    if (!months) throw new Error('beyond range');
    for (let m = 0; m < 12; m++) totalDays += months[m];
  }
  const yearMonths = _NIDAN_BS_MONTH_DATA[year];
  if (!yearMonths) throw new Error('beyond range');
  for (let m = 0; m < month - 1; m++) totalDays += yearMonths[m];
  totalDays += day - 1;
  const result = new Date(_NIDAN_BS_EPOCH_AD.getFullYear(), _NIDAN_BS_EPOCH_AD.getMonth(), _NIDAN_BS_EPOCH_AD.getDate());
  result.setDate(result.getDate() + totalDays);
  return result;
}

function _nidanDaysInBSMonth(year, month) {
  const m = _NIDAN_BS_MONTH_DATA[year];
  return m ? m[month - 1] : 30;
}

const _NIDAN_BS_MONTHS = [
  'Baisakh','Jestha','Ashadh','Shrawan','Bhadra','Ashwin',
  'Kartik','Mangsir','Poush','Magh','Falgun','Chaitra',
];

const _NIDAN_DAY_HEADERS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

// Coerce the polymorphic OpenmrsDatePicker value/defaultValue prop into
// a JS Date for our internal state. The styleguide picker accepts
// CalendarDate, CalendarDateTime, ZonedDateTime, dayjs config, etc.
function _nidanToDate(v) {
  if (v == null) return null;
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  // CalendarDate-ish shape (react-aria): { year, month, day }
  if (typeof v === 'object' && typeof v.year === 'number' && typeof v.month === 'number' && typeof v.day === 'number') {
    return new Date(v.year, v.month - 1, v.day);
  }
  if (typeof v === 'string' || typeof v === 'number') {
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof v === 'object' && typeof v.toDate === 'function') {
    const d = v.toDate();
    return d instanceof Date && !isNaN(d.getTime()) ? d : null;
  }
  return null;
}

function _nidanStartOfDay(d) {
  const x = new Date(d.getTime());
  x.setHours(0, 0, 0, 0);
  return x;
}

function _nidanEndOfDay(d) {
  const x = new Date(d.getTime());
  x.setHours(23, 59, 59, 999);
  return x;
}

function _nidanIsDayInRange(ad, minDate, maxDate) {
  if (!ad || isNaN(ad.getTime())) return false;
  const dayMs = _nidanStartOfDay(ad).getTime();
  if (minDate) {
    const minMs = _nidanStartOfDay(minDate).getTime();
    if (dayMs < minMs) return false;
  }
  if (maxDate) {
    const maxMs = _nidanEndOfDay(maxDate).getTime();
    if (dayMs > maxMs) return false;
  }
  return true;
}

function _nidanPropDate(props, key) {
  return _nidanToDate(props[key]);
}

// === Wrapped picker ===
const _nidanWrapStyles = {
  wrapper: { display: 'flex', flexDirection: 'column', gap: '0.25rem' },
  tabBar: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    flexWrap: 'wrap',
    marginBottom: '0.25rem',
  },
  tabs: { display: 'inline-flex', gap: '0.25rem' },
  tab: {
    padding: '0.25rem 0.75rem',
    border: '1px solid var(--cds-border-subtle, #c6c6c6)',
    background: 'transparent',
    cursor: 'pointer',
    fontSize: '0.85rem',
    borderRadius: '2px',
    color: 'var(--cds-text-primary, #161616)',
  },
  tabActive: {
    background: 'var(--cds-layer-selected, #e8e8e8)',
    fontWeight: 600,
  },
  // Full-width picker row (equivalent span lives in tabBar).
  pickerRow: { display: 'block', width: '100%' },
  pickerCol: { width: '100%', minWidth: 0 },
  equivalent: {
    display: 'inline-flex',
    alignItems: 'center',
    padding: '0.25rem 0.5rem',
    background: 'var(--cds-layer-accent, #e0e0e0)',
    color: 'var(--cds-text-secondary, #525252)',
    fontSize: '0.8rem',
    borderRadius: '2px',
    whiteSpace: 'nowrap',
    flexShrink: 0,
  },
  bsFieldInput: {
    width: '100%',
    boxSizing: 'border-box',
    padding: '0.6875rem 1rem',
    border: 'none',
    borderBottom: '1px solid var(--cds-border-strong, #8d8d8d)',
    background: 'var(--cds-field, #f4f4f4)',
    fontSize: '0.875rem',
    color: 'var(--cds-text-primary, #161616)',
    cursor: 'pointer',
  },
  bsPopover: {
    position: 'absolute',
    top: '100%',
    left: 0,
    zIndex: 10000,
    marginTop: '2px',
    border: '1px solid var(--cds-border-subtle, #c6c6c6)',
    padding: '0.75rem',
    background: 'var(--cds-layer, #ffffff)',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    minWidth: '18rem',
  },
  bsPopoverHeader: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginBottom: '0.35rem',
  },
  bsCloseBtn: {
    border: 'none',
    background: 'transparent',
    cursor: 'pointer',
    fontSize: '1.25rem',
    lineHeight: 1,
    padding: '0.15rem 0.35rem',
    color: 'var(--cds-text-primary, #161616)',
    borderRadius: '2px',
  },
  bsPanel: {
    border: '1px solid var(--cds-border-subtle, #c6c6c6)',
    padding: '0.75rem',
    background: 'var(--cds-layer, #ffffff)',
  },
  bsSummary: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '0.5rem',
    marginBottom: '0.5rem',
  },
  bsSummaryText: {
    fontSize: '0.9rem',
    fontWeight: 600,
    color: 'var(--cds-text-primary, #161616)',
  },
  bsChangeBtn: {
    padding: '0.2rem 0.6rem',
    border: '1px solid var(--cds-border-subtle, #c6c6c6)',
    background: 'transparent',
    cursor: 'pointer',
    fontSize: '0.8rem',
    borderRadius: '2px',
    color: 'var(--cds-text-primary, #161616)',
  },
  bsRow: { display: 'flex', gap: '0.5rem', alignItems: 'center', marginBottom: '0.5rem', flexWrap: 'wrap' },
  bsSelect: {
    padding: '0.25rem 0.5rem',
    border: '1px solid var(--cds-border-strong, #8d8d8d)',
    background: 'var(--cds-field, #f4f4f4)',
    fontSize: '0.875rem',
    minWidth: '8rem',
  },
  bsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(7, 1fr)',
    gap: '2px',
    marginTop: '0.5rem',
  },
  bsDayHeader: {
    padding: '0.25rem',
    textAlign: 'center',
    fontSize: '0.75rem',
    color: 'var(--cds-text-secondary, #525252)',
    fontWeight: 600,
  },
  bsDayCell: {
    padding: '0.4rem 0',
    textAlign: 'center',
    fontSize: '0.875rem',
    border: '1px solid transparent',
    background: 'transparent',
    cursor: 'pointer',
    borderRadius: '2px',
    color: 'var(--cds-text-primary, #161616)',
  },
  bsDayCellSelected: {
    background: 'var(--cds-background-brand, #0f62fe)',
    color: '#fff',
    fontWeight: 600,
  },
  bsDayCellDisabled: {
    color: 'var(--cds-text-disabled, #c6c6c6)',
    cursor: 'not-allowed',
    opacity: 0.45,
  },
  bsDayCellToday: {
    color: 'var(--cds-link-primary, #0f62fe)',
    fontWeight: 600,
    position: 'relative',
    paddingBottom: '0.6rem',
  },
  bsDayCellTodayDot: {
    position: 'absolute',
    bottom: '0.25rem',
    left: '50%',
    transform: 'translateX(-50%)',
    display: 'block',
    width: '0.25rem',
    height: '0.25rem',
    borderRadius: '50%',
    background: 'var(--cds-link-primary, #0f62fe)',
  },
  bsDayEmpty: { visibility: 'hidden' },
  bsHelp: { color: 'var(--cds-text-secondary, #525252)', fontSize: '0.75rem' },
  bsLabel: { display: 'block', marginBottom: '0.5rem', fontSize: '0.75rem', fontWeight: 400, letterSpacing: '0.32px', lineHeight: 1.29, color: 'var(--cds-text-secondary, #525252)' },
};

// Compute the weekday (0 = Sunday) for BS day 1 of a given BS month —
// we derive it from the corresponding AD date.
function _nidanBSFirstWeekday(year, month) {
  try {
    return _nidanBsToAD(year, month, 1).getDay();
  } catch {
    return 0;
  }
}

// Format an AD Date as "DD Mon YYYY" without depending on Intl quirks.
const _NIDAN_AD_MONTHS_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function _nidanFormatAD(d) {
  if (!d || isNaN(d.getTime())) return '';
  return String(d.getDate()).padStart(2,'0') + ' ' + _NIDAN_AD_MONTHS_SHORT[d.getMonth()] + ' ' + d.getFullYear();
}
function _nidanFormatBS(bs) {
  if (!bs) return '';
  return bs.year + '-' + String(bs.month).padStart(2,'0') + '-' + String(bs.day).padStart(2,'0');
}

const NidanBsCalendarPanel = function NidanBsCalendarPanel(props) {
  const containerRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const [open, setOpen] = useState(false);

  const _nidanTodayBs = useMemo(() => {
    try { return _nidanAdToBS(new Date()); } catch { return null; }
  }, []);

  const initialBs = useMemo(() => {
    if (props.value) {
      try { return _nidanAdToBS(props.value); } catch { return null; }
    }
    try {
      const seed = props.maxDate && props.maxDate.getTime() < Date.now() ? props.maxDate : new Date();
      return _nidanAdToBS(seed);
    } catch { return null; }
  }, [props.value, props.maxDate]);

  const [bsYear, setBsYear] = useState(initialBs ? initialBs.year : 2080);
  const [bsMonth, setBsMonth] = useState(initialBs ? initialBs.month : 1);

  useEffect(() => {
    if (!props.value) return;
    try {
      const bs = _nidanAdToBS(props.value);
      setBsYear(bs.year);
      setBsMonth(bs.month);
    } catch {}
  }, [props.value]);

  useEffect(() => {
    if (!open) return undefined;
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('click', handler, true);
    return () => document.removeEventListener('click', handler, true);
  }, [open]);

  const selectedBs = useMemo(() => {
    if (!props.value) return null;
    try { return _nidanAdToBS(props.value); } catch { return null; }
  }, [props.value]);

  const closePopover = useCallback(() => {
    setOpen(false);
    if (inputRef.current && typeof inputRef.current.blur === 'function') {
      inputRef.current.blur();
    }
  }, []);

  const handlePickDay = useCallback((day) => {
    try {
      const ad = _nidanBsToAD(bsYear, bsMonth, day);
      if (!_nidanIsDayInRange(ad, props.minDate, props.maxDate)) return;
      closePopover();
      if (typeof props.onPick === 'function') props.onPick(ad);
    } catch (e) {
      // out of range — ignore
    }
  }, [bsYear, bsMonth, props.onPick, props.minDate, props.maxDate, closePopover]);

  const daysInMonth = _nidanDaysInBSMonth(bsYear, bsMonth);
  const firstWeekday = _nidanBSFirstWeekday(bsYear, bsMonth);

  const years = useMemo(() => {
    const out = [];
    for (let y = _NIDAN_BS_EPOCH_YEAR; y <= 2100; y++) out.push(y);
    return out;
  }, []);

  const displayText = selectedBs ? _nidanFormatBS(selectedBs) : '';

  const cells = [];
  for (let i = 0; i < firstWeekday; i++) {
    cells.push(React.createElement('div', { key: 'pad-' + i, style: _nidanWrapStyles.bsDayEmpty }, ''));
  }
  const _isTodayMonth = _nidanTodayBs && _nidanTodayBs.year === bsYear && _nidanTodayBs.month === bsMonth;
  for (let day = 1; day <= daysInMonth; day++) {
    const isSelected = selectedBs && selectedBs.year === bsYear && selectedBs.month === bsMonth && selectedBs.day === day;
    const isToday = !isSelected && !!(_isTodayMonth && _nidanTodayBs && _nidanTodayBs.day === day);
    var inRange = true;
    try {
      inRange = _nidanIsDayInRange(_nidanBsToAD(bsYear, bsMonth, day), props.minDate, props.maxDate);
    } catch (e) {
      inRange = false;
    }
    cells.push(
      React.createElement('button', {
        key: 'd-' + day,
        type: 'button',
        disabled: !inRange || !!props.disabled,
        style: Object.assign(
          {},
          _nidanWrapStyles.bsDayCell,
          isSelected ? _nidanWrapStyles.bsDayCellSelected : null,
          isToday ? _nidanWrapStyles.bsDayCellToday : null,
          !inRange ? _nidanWrapStyles.bsDayCellDisabled : null,
        ),
        onMouseDown: function (e) {
          if (!inRange || props.disabled) return;
          e.preventDefault();
          e.stopPropagation();
          handlePickDay(day);
        },
        'aria-label': 'BS ' + bsYear + '-' + String(bsMonth).padStart(2,'0') + '-' + String(day).padStart(2,'0'),
      },
        String(day),
        isToday ? React.createElement('span', {
          'aria-hidden': 'true',
          style: _nidanWrapStyles.bsDayCellTodayDot,
        }) : null
      )
    );
  }

  const _nidanInputId = props.id ? (props.id + '-bs') : ('nidan-bs-' + Math.random().toString(36).slice(2, 8));
  return React.createElement('div', { ref: containerRef, style: { position: 'relative', width: '100%' } },
    props.labelText
      ? React.createElement('label', {
          htmlFor: _nidanInputId,
          className: 'cds--label',
          style: _nidanWrapStyles.bsLabel,
        }, props.labelText)
      : null,
    React.createElement('input', {
      ref: inputRef,
      id: _nidanInputId,
      type: 'text',
      readOnly: true,
      value: displayText,
      placeholder: 'YYYY-MM-DD (BS)',
      style: _nidanWrapStyles.bsFieldInput,
      disabled: !!props.disabled,
      onClick: function () {
        if (!props.disabled) setOpen(true);
      },
      'aria-label': props['aria-label'] || props.labelText || 'Bikram Sambat date',
      'aria-expanded': open,
    }),
    open && !props.disabled && React.createElement('div', {
      style: _nidanWrapStyles.bsPopover,
      role: 'dialog',
      'aria-label': 'BS calendar',
      onMouseDown: function (e) { e.stopPropagation(); },
    },
      React.createElement('div', { style: _nidanWrapStyles.bsPopoverHeader },
        React.createElement('button', {
          type: 'button',
          style: _nidanWrapStyles.bsCloseBtn,
          className: 'nidan-bs-popover-close',
          'aria-label': 'Close calendar',
          onMouseDown: function (e) {
            e.preventDefault();
            e.stopPropagation();
            closePopover();
          },
        }, '\u00D7')
      ),
      React.createElement('div', { style: _nidanWrapStyles.bsRow },
        React.createElement('label', { style: _nidanWrapStyles.bsLabel }, 'Year (BS)',
          React.createElement('select', {
            'aria-label': 'BS year',
            style: _nidanWrapStyles.bsSelect,
            value: bsYear,
            onChange: (e) => setBsYear(parseInt(e.target.value, 10)),
          }, years.map((y) => React.createElement('option', { key: y, value: y }, y)))
        ),
        React.createElement('label', { style: _nidanWrapStyles.bsLabel }, 'Month (BS)',
          React.createElement('select', {
            'aria-label': 'BS month',
            style: _nidanWrapStyles.bsSelect,
            value: bsMonth,
            onChange: (e) => setBsMonth(parseInt(e.target.value, 10)),
          }, _NIDAN_BS_MONTHS.map((name, i) => React.createElement('option', { key: i, value: i + 1 }, (i+1) + '. ' + name)))
        )
      ),
      React.createElement('div', { style: _nidanWrapStyles.bsGrid },
        _NIDAN_DAY_HEADERS.map((dh) => React.createElement('div', { key: 'h-' + dh, style: _nidanWrapStyles.bsDayHeader }, dh)),
        cells
      )
    )
  );
};

export const OpenmrsDatePicker = /*#__PURE__*/ forwardRef(function NidanWrappedOpenmrsDatePicker(props, ref) {
  const [tab, setTab] = useState('bs');
  const [pendingAd, setPendingAd] = useState(null);

  useEffect(() => {
    if (_nidanToDate(props.value)) setPendingAd(null);
  }, [props.value]);

  const currentAd = useMemo(
    () => _nidanToDate(props.value) || _nidanToDate(props.defaultValue) || pendingAd,
    [props.value, props.defaultValue, pendingAd],
  );
  const currentBs = useMemo(() => {
    if (!currentAd) return null;
    try { return _nidanAdToBS(currentAd); } catch { return null; }
  }, [currentAd]);

  const minBound = _nidanPropDate(props, 'minDate');
  const maxBound = _nidanPropDate(props, 'maxDate');

  const handleBsPick = useCallback((ad) => {
    setPendingAd(ad);
    if (typeof props.onChange === 'function') {
      props.onChange(ad);
    }
  }, [props.onChange]);

  const tabBtn = (key, label) => React.createElement('button', {
    key,
    type: 'button',
    role: 'tab',
    'aria-selected': tab === key,
    style: Object.assign({}, _nidanWrapStyles.tab, tab === key ? _nidanWrapStyles.tabActive : null),
    onClick: () => setTab(key),
  }, label);

  const equivalent = currentAd ? (
    tab === 'ad'
      ? (currentBs ? React.createElement('span', { style: _nidanWrapStyles.equivalent, className: 'nidan-picker-equivalent', 'aria-label': 'BS equivalent' }, 'BS ' + _nidanFormatBS(currentBs)) : null)
      : React.createElement('span', { style: _nidanWrapStyles.equivalent, className: 'nidan-picker-equivalent', 'aria-label': 'AD equivalent' }, 'AD ' + _nidanFormatAD(currentAd))
  ) : null;

  return React.createElement('div', {
    style: _nidanWrapStyles.wrapper,
    className: 'nidan-picker-wrapper nidan-picker-v9',
    'data-nidan-picker-version': '${NIDAN_PICKER_VERSION}',
  },
    React.createElement('div', { style: _nidanWrapStyles.tabBar },
      React.createElement('div', { role: 'tablist', 'aria-label': 'Calendar system', style: _nidanWrapStyles.tabs },
        tabBtn('ad', 'AD'),
        tabBtn('bs', 'BS')
      ),
      equivalent
    ),
    React.createElement('div', { style: _nidanWrapStyles.pickerRow },
      React.createElement('div', { style: _nidanWrapStyles.pickerCol },
        tab === 'ad'
          ? React.createElement(_NidanOriginalOpenmrsDatePicker, Object.assign({}, props, { ref }))
          : React.createElement(NidanBsCalendarPanel, {
              value: currentAd,
              onPick: handleBsPick,
              minDate: minBound,
              maxDate: maxBound,
              disabled: !!(props.isDisabled || props.disabled),
              labelText: props.labelText || props.label,
              id: props.id,
              'aria-label': props['aria-label'],
            })
      )
    )
  );
});
OpenmrsDatePicker.__nidanInnerOriginal = _NidanOriginalOpenmrsDatePicker;
OpenmrsDatePicker.__nidanWrapped = true;
OpenmrsDatePicker.__nidanWrapVersion = 9;
`;
}

const cli = parseArgs(process.argv.slice(2));
const targets = findStyleguideTargets(cli.extraRoots);
if (targets.length === 0) {
  console.warn(
    `${LOG_PREFIX} No @openmrs/esm-styleguide install found — cannot patch OpenmrsDatePicker.`,
  );
  diagnoseMissing();
  if (cli.allowSkip) {
    console.warn(`${LOG_PREFIX} --allow-skip set; exiting without patch.`);
    process.exit(0);
  }
  console.error(
    `${LOG_PREFIX} Install openmrs (which pulls esm-styleguide) before build, e.g. ` +
      `\`yarn add openmrs@next --legacy-peer-deps\`, then re-run this script BEFORE \`openmrs build\`.`,
  );
  process.exit(2);
}

console.log(`${LOG_PREFIX} build-stamp = ${BUILD_STAMP}`);

let patched = 0;
let skipped = 0;
for (const t of targets) {
  const content = fs.readFileSync(t.target, 'utf8');
  const sizeBefore = content.length;
  const hasCurrentMarker = content.includes(MARKER);
  const hasOlderNidanPatch =
    content.includes(MARKER_PREFIX) && !hasCurrentMarker;
  if (hasCurrentMarker) {
    console.log(
      `${LOG_PREFIX} Already patched (${MARKER}), skipping (${t.mode}): ${t.target} (${sizeBefore} bytes)`,
    );
    skipped++;
    continue;
  }
  if (t.mode === 'split') {
    const isOriginalShape = /OpenmrsDatePicker.*openmrs-date-picker\.component\.js/.test(content);
    if (!isOriginalShape && !hasOlderNidanPatch) {
      console.error(`${LOG_PREFIX} Unexpected shape in ${t.target}; refusing to patch.`);
      continue;
    }
    if (hasOlderNidanPatch) {
      console.log(
        `${LOG_PREFIX} Replacing older Nidan patch in ${t.target} with ${MARKER}`,
      );
    }
    const newContent = generatePatchedIndex();
    fs.writeFileSync(t.target, newContent, 'utf8');
    const after = fs.readFileSync(t.target, 'utf8');
    const ok = after.includes(MARKER) && after.includes(BUILD_STAMP);
    console.log(
      `${LOG_PREFIX} Patched (split) ${t.target} — before=${sizeBefore} after=${after.length} marker-present=${ok}`,
    );
    if (!ok) console.error(`${LOG_PREFIX} VERIFY FAILED: marker or build-stamp missing after write`);
    patched++;
  } else if (t.mode === 'bundle') {
    console.warn(
      `${LOG_PREFIX} Skipping legacy bundle target (noisy retired IIFE removed): ${t.target}. ` +
        `Use split-mode dist/datepicker/index.js patch only.`,
    );
    skipped++;
  }
}

console.log(`${LOG_PREFIX} Done: patched=${patched}, skipped=${skipped}, total=${targets.length}, build-stamp=${BUILD_STAMP}`);
if (patched === 0 && skipped === 0) process.exit(2);
