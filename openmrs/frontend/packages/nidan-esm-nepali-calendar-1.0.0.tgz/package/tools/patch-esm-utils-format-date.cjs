#!/usr/bin/env node
/**
 * Patches @openmrs/esm-utils formatDate so read-only SPA surfaces append BS suffixes.
 * Run via tools/spa-build-hook.cjs patch (after openmrs assemble, before openmrs build).
 */
'use strict';

const fs = require('fs');
const path = require('path');

const MARKER = '/* @nidan/esm-nepali-calendar formatDate BS suffix v1 */';
const LOG_PREFIX = '[patch-esm-utils-format-date]';

function parseArgs(argv) {
  const opts = { allowSkip: false, extraRoots: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--allow-skip') {
      opts.allowSkip = true;
    } else if (arg === '--root' && argv[i + 1]) {
      opts.extraRoots.push(path.resolve(argv[++i]));
    } else if (!arg.startsWith('-')) {
      opts.extraRoots.push(path.resolve(arg));
    }
  }
  return opts;
}

function safeIsDir(p) {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function safeIsFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

function collectNodeModulesRoots(extraRoots) {
  const nodeModulesRoots = new Set();
  const cwdNm = path.join(process.cwd(), 'node_modules');
  if (safeIsDir(cwdNm)) nodeModulesRoots.add(cwdNm);
  let dirUp = process.cwd();
  for (let i = 0; i < 6; i++) {
    const nm = path.join(dirUp, 'node_modules');
    if (safeIsDir(nm)) nodeModulesRoots.add(nm);
    dirUp = path.dirname(dirUp);
  }
  for (const extra of extraRoots) {
    const nm = path.join(extra, 'node_modules');
    if (safeIsDir(nm)) nodeModulesRoots.add(nm);
  }
  return nodeModulesRoots;
}

function walkTreeForEsmUtilsRoots(dir, roots, depth) {
  if (depth > 8 || !safeIsDir(dir)) return;
  if (path.basename(dir) === 'esm-utils' && safeIsFile(path.join(dir, 'package.json'))) {
    roots.add(dir);
    return;
  }
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    if (ent.name === 'node_modules' || ent.name.startsWith('.')) {
      walkTreeForEsmUtilsRoots(path.join(dir, ent.name), roots, depth + 1);
      continue;
    }
    if (ent.name === 'esm-utils') {
      roots.add(path.join(dir, ent.name));
      continue;
    }
    walkTreeForEsmUtilsRoots(path.join(dir, ent.name), roots, depth + 1);
  }
}

function walkCollectEsmUtilsRoots(nmRoot, roots) {
  let entries;
  try {
    entries = fs.readdirSync(nmRoot, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    if (ent.name.startsWith('@')) {
      let scopeEntries;
      try {
        scopeEntries = fs.readdirSync(path.join(nmRoot, ent.name), { withFileTypes: true });
      } catch {
        continue;
      }
      for (const se of scopeEntries) {
        if (!se.isDirectory()) continue;
        const pkgDir = path.join(nmRoot, ent.name, se.name);
        if (se.name === 'esm-utils') roots.add(pkgDir);
        const nestedNm = path.join(pkgDir, 'node_modules');
        if (safeIsDir(nestedNm)) walkCollectEsmUtilsRoots(nestedNm, roots);
      }
    } else {
      const nestedNm = path.join(nmRoot, ent.name, 'node_modules');
      if (safeIsDir(nestedNm)) walkCollectEsmUtilsRoots(nestedNm, roots);
    }
  }
}

function findEsmUtilsTargets(extraRoots) {
  const roots = new Set();
  const extraWalkRoots = new Set();
  for (const extra of extraRoots) walkTreeForEsmUtilsRoots(extra, extraWalkRoots, 0);
  for (const root of extraWalkRoots) roots.add(root);
  for (const nmRoot of collectNodeModulesRoots(extraRoots)) {
    walkCollectEsmUtilsRoots(nmRoot, roots);
  }

  const targets = [];
  for (const root of roots) {
    const file = path.join(root, 'dist', 'dates', 'date-util.js');
    if (safeIsFile(file)) targets.push(file);
  }
  return [...new Set(targets)];
}

function loadBsMonthData() {
  const styleguidePatch = path.join(__dirname, 'patch-esm-styleguide-picker.cjs');
  const content = fs.readFileSync(styleguidePatch, 'utf8');
  const start = content.indexOf('const BS_MONTH_DATA = {');
  if (start < 0) throw new Error('BS_MONTH_DATA not found in patch-esm-styleguide-picker.cjs');
  const end = content.indexOf('\n};', start) + 3;
  // eslint-disable-next-line no-new-func
  return new Function(`${content.slice(start, end)}; return BS_MONTH_DATA;`)();
}

function generateHelper() {
  const bsMonthData = loadBsMonthData();
  return `${MARKER}
function __nidanAppendBsSuffix(text, date, precision) {
  if (!text || /\\(BS /.test(text)) return text;
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) return text;
  var showYear = precision.year !== false;
  var showMonth = precision.month !== false;
  var showDay = precision.day !== false;
  if (!showYear) return text;
  var adY = date.getFullYear();
  var adD = date.getDate();
  var epoch = Date.UTC(1918, 3, 13);
  var target = Date.UTC(adY, date.getMonth(), adD);
  var total = Math.floor((target - epoch) / 86400000);
  if (total < 0) return text;
  var BS = ${JSON.stringify(bsMonthData)};
  var bsY = 1975, bsM = 1, bsD = 1, found = false;
  outer: for (var y = 1975; y <= 2099; y++) {
    var md = BS[y];
    if (!md) continue;
    for (var m = 1; m <= 12; m++) {
      var dim = md[m - 1];
      if (total < dim) { bsY = y; bsM = m; bsD = total + 1; found = true; break outer; }
      total -= dim;
    }
  }
  if (!found) return text;
  var bsText = String(bsY);
  if (showMonth) {
    bsText += '-' + String(bsM).padStart(2, '0');
    if (showDay) bsText += '-' + String(bsD).padStart(2, '0');
  }
  return text + ' (BS ' + bsText + ')';
}
`;
}

function patchFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  if (content.includes(MARKER) && content.includes("' (BS '")) {
    console.log(`${LOG_PREFIX} Already patched, skipping: ${filePath}`);
    return 'skipped';
  }
  if (content.includes(MARKER)) {
    console.log(`${LOG_PREFIX} Upgrading older formatDate patch in ${filePath}`);
    const helperStart = content.indexOf(MARKER);
    const formatDateExport = content.indexOf('export function formatDate(date, options)', helperStart);
    if (helperStart < 0 || formatDateExport < 0) {
      console.error(`${LOG_PREFIX} Could not locate older patch block in ${filePath}`);
      return 'failed';
    }
    content = content.slice(0, helperStart) + content.slice(formatDateExport);
    content = content.replace(
      'return __nidanAppendBsSuffix(localeString, date, { year, month, day });',
      'return localeString;',
    );
  }
  if (!content.includes('export function formatDate(date, options)')) {
    console.error(`${LOG_PREFIX} Unexpected shape in ${filePath}; refusing to patch.`);
    return 'failed';
  }

  const helper = generateHelper();
  const exportIdx = content.indexOf('export function formatDate(date, options)');
  content = content.slice(0, exportIdx) + helper + content.slice(exportIdx);

  const returnNeedle = `    if (time === true || isToday && time === 'for today') {
        localeString += \`, \${formatTime(date)}\`;
    }
    return localeString;
}`;
  const returnReplacement = `    if (time === true || isToday && time === 'for today') {
        localeString += \`, \${formatTime(date)}\`;
    }
    return __nidanAppendBsSuffix(localeString, date, { year, month, day });
}`;

  if (!content.includes(returnNeedle)) {
    console.error(`${LOG_PREFIX} formatDate return block not found in ${filePath}`);
    return 'failed';
  }

  content = content.replace(returnNeedle, returnReplacement);
  fs.writeFileSync(filePath, content, 'utf8');
  const after = fs.readFileSync(filePath, 'utf8');
  if (!after.includes(MARKER) || !after.includes("' (BS '")) {
    console.error(`${LOG_PREFIX} VERIFY FAILED after write: ${filePath}`);
    return 'failed';
  }
  console.log(`${LOG_PREFIX} Patched ${filePath}`);
  return 'patched';
}

const cli = parseArgs(process.argv.slice(2));
const targets = findEsmUtilsTargets(cli.extraRoots);

if (targets.length === 0) {
  console.warn(`${LOG_PREFIX} No @openmrs/esm-utils install found.`);
  if (cli.allowSkip) process.exit(0);
  process.exit(2);
}

let patched = 0;
let skipped = 0;
let failed = 0;
for (const t of targets) {
  const result = patchFile(t);
  if (result === 'patched') patched++;
  else if (result === 'skipped') skipped++;
  else failed++;
}

console.log(`${LOG_PREFIX} Done: patched=${patched}, skipped=${skipped}, failed=${failed}, targets=${targets.length}`);
process.exit(failed > 0 ? 2 : 0);
