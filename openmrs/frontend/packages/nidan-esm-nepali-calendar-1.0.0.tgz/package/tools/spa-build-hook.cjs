#!/usr/bin/env node
/**
 * Docker / CI entry point for Nepali calendar SPA build steps.
 *
 *   node spa-build-hook.cjs patch          # before `openmrs build`
 *   node spa-build-hook.cjs verify [dir]   # after `openmrs build` (default /app/spa)
 *
 * Only invoked from Dockerfile (Nepali calendar builds). Vanilla builds use Dockerfile.vanilla.
 */
'use strict';

const { spawnSync } = require('child_process');
const path = require('path');

const LOG = '[nidan-spa-build-hook]';

function runTool(scriptName, args) {
  const script = path.join(__dirname, scriptName);
  const result = spawnSync(process.execPath, [script, ...args], {
    stdio: 'inherit',
    cwd: process.cwd(),
    env: process.env,
  });
  return result.status ?? 1;
}

const cmd = process.argv[2];

if (!cmd || cmd === '--help' || cmd === '-h') {
  console.log(`Usage: node spa-build-hook.cjs patch|verify [spa-dir]`);
  process.exit(cmd ? 0 : 2);
}

if (cmd === 'patch') {
  const extraArgs = process.argv.slice(3);
  const codes = [
    runTool('patch-esm-styleguide-picker.cjs', extraArgs),
    runTool('patch-esm-utils-format-date.cjs', extraArgs),
  ];
  process.exit(Math.max(...codes));
} else if (cmd === 'verify') {
  const spaDir = process.argv[3] || '/app/spa';
  process.exit(runTool('verify-spa-picker-patch.cjs', [spaDir]));
} else {
  console.error(`${LOG} Unknown command "${cmd}". Use patch or verify.`);
  process.exit(2);
}
