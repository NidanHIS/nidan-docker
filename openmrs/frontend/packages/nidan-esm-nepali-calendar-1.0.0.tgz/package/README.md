# @nidan/esm-nepali-calendar

Bikram Sambat (BS / Nepali) calendar support for OpenMRS O3.

## What it does

Two independent capabilities, both opt-in by the deployment (presence
of this package in `spa-assemble-config.json`) rather than per-user
preference. The stored value is always an AD `Date` regardless of
which UI the clinician used.

### 1. AD / BS tab switcher on every `OpenmrsDatePicker`

Wraps the styleguide's `OpenmrsDatePicker` so every date input across
the SPA — patient registration DOB, visit creation, lab orders,
medication entry, appointments, anything — renders an AD/BS tab
above the field. The AD tab is the upstream Carbon picker, untouched.
The BS tab is a Bikram Sambat calendar grid (year + month dropdowns,
7-day grid, selected day highlighted) that converts back to AD before
invoking the consumer's `onChange`. Two layers wire this up — see
*Architecture* below.

### 2. BS-aware controls in the form engine

Adds Carbon-styled BS date and datetime pickers that form authors opt
into per question by setting `questionOptions.rendering` to one of:

| Rendering              | Editable picker            | Read-only view |
|------------------------|----------------------------|----------------|
| `bs-date`              | BS calendar only           | BS + AD lines  |
| `bs-datetime`          | BS calendar + time picker  | BS + AD lines  |
| `bs-date-with-ad`      | BS calendar + AD chip      | BS + AD lines  |
| `bs-datetime-with-ad`  | BS calendar + time + AD chip | BS + AD lines |

## Recent design changes (what was removed and why)

This README used to document an in-app **AD / BS / Both** toggle in the
top navigation bar, backed by a `localStorage` mode store and a
`defaultMode` config knob. All of that was removed. The reasoning:

- A clinic in Nepal wants BS+AD everywhere; a clinic outside Nepal
  doesn't install the package. The deployment is the switch — there's
  nothing for an individual clinician to choose.
- The toggle introduced cross-tab sync state, BroadcastChannel
  plumbing, a Phase-2 mode-rewrite path on stock pickers that depended
  on the upstream registry hook (see Limitations below), and a config
  schema with `defaultMode`/`showToggleInNavbar` that aged badly.

Concrete removals: `src/settings/calendar-mode-store.ts`,
`src/settings/calendar-mode-toggle.component.tsx`, the
`top-nav-actions-slot` toggle extension, the
`calendarMode`/`calendarModeToggleLabel`/`calendarAd`/`calendarBs`/`calendarBoth`
translation keys, and the `defaultMode` + `showToggleInNavbar` keys in
`config-schema.ts`. The only surviving config knob is `displayLanguage`.

Also worth noting (now resolved): the form-engine submits date obs as
`YYYY-MM-DD` and datetime obs as `YYYY-MM-DD HH:mm`. The BS field
short-circuits `setFieldValue` to hand the engine those formatted
strings directly so OpenMRS REST's `Obs.setValueAsString` accepts the
payload. Earlier iterations sent a raw JS `Date`, which JSON-stringified
to ISO-8601 with `Z` and tripped `Obs.setValueAsString`'s locale
`DateFormat.parse`. See `src/components/bs-date-field-base.component.tsx`.

## Roadmap

1. **Auto-rewriting stock `date` / `datetime` form-engine renderings.**
   The schema transformer (`src/form-engine/bs-schema-transformer.ts`)
   is written to do this — any stock `date` becomes `bs-date-with-ad`
   at form-load time — but `register.ts` keeps `enableAutoRewrite =
   false`. Reason:
   `@openmrs/esm-form-engine-lib/src/registry/registry.ts:193–196`
   contains a `find(...).name` crash for any non-built-in transformer,
   which kills the whole form. **Plan:** ship a build-time patch
   against the form-engine bundle in `nidan-docker`'s SPA assembly,
   then flip the flag in `register.ts`. Until then, authors opt in per
   question via the `bs-*` rendering names.
2. **BS rendering selectable in the form-builder UI.** Adding the four
   `bs-*` names to `openmrs-esm-form-builder`'s `renderTypeOptions.obs`
   and mapping them to the existing `Date` input editor makes the
   Interactive Builder a one-click experience instead of hand-editing
   JSON.
3. **`OpenmrsDateRangePicker`** — same wrap idiom as
   `OpenmrsDatePicker`, but for date-range inputs (visit filters,
   encounter list ranges). Not yet implemented; can be added once the
   single-date wrap proves stable in production.
4. **Read-only BS display on upstream surfaces** (patient banner DOB,
   encounter dates, medication start dates). Use the exported
   `<NidanDate>` component for Nidan-owned modules. We previously
   tried a global `Intl.DateTimeFormat` shim and removed it — it broke
   picker chrome (month/year headers, weekday labels) because the same
   `Intl` is used by both display surfaces and Carbon's calendar UI.

## Architecture

The `OpenmrsDatePicker` AD/BS tab switcher is wired up via **two
independent paths that both target the same shared framework export**.
Either one alone produces a working picker; running both makes the
result robust across dev/prod modes and idempotent.

1. **Build-time styleguide patch** —
   `tools/patch-esm-styleguide-picker.cjs`. In the docker image build,
   `yarn add openmrs@next` is the load-bearing trick: it hoists
   `@openmrs/esm-styleguide` into `/app/node_modules` (whereas
   `npx openmrs ...` puts the CLI's deps in an npx cache that the SPA
   build never reads). The patch then rewrites
   `node_modules/@openmrs/esm-styleguide/dist/datepicker/index.js`
   between `yarn openmrs assemble` and `yarn openmrs build` so the
   bundled `OpenmrsDatePicker` export is the wrapped version. Idempotent
   (`v1` marker comment), accepts `--allow-skip` for minimal builds
   without OpenMRS apps. Verified post-build by
   `tools/verify-spa-picker-patch.cjs`, which also fails the image
   build loudly if any retired-IIFE markers leak back in.
2. **Runtime framework-namespace wrap** —
   `src/lib/wrap-openmrs-date-picker.ts`. On `startupApp`, this module
   dynamically imports `@openmrs/esm-framework`, captures the
   `OpenmrsDatePicker` export, builds a wrapped `forwardRef` component,
   and reassigns the namespace property (with `Object.defineProperty`
   fallback). Because consumer apps hold live ESM bindings to the
   shared framework singleton, the mutation propagates on the next
   render. This is the safety net for dev servers serving unpatched
   `node_modules` and for environments where the build-time patch
   couldn't run.

The wrapped component renders a tab UI. The AD tab forwards every prop
(including `ref`) to the original `OpenmrsDatePicker`; the BS tab
renders the package's own `BSDatePicker` and converts back to AD via
`bsToAD` before invoking the consumer's `onChange`.

### Form-engine layer

1. **Custom controls.** `src/form-engine/register.ts` calls
   `registerControl` four times, binding `bs-date`, `bs-datetime`,
   `bs-date-with-ad`, `bs-datetime-with-ad` to React components in
   `src/components/`. The shared base (`bs-date-field-base.component.tsx`)
   wraps a Carbon-styled `BSDatePicker` and a `TimePicker`, hands the
   form engine a pre-formatted string via `setFieldValue`, and
   normalises any hydrated initial `Date` on mount so unedited saves
   still submit the correct wire format.
2. **Schema transformer (registered as code, runtime-disabled).**
   `src/form-engine/bs-schema-transformer.ts` walks the schema and
   rewrites stock `date`/`datetime` to their `bs-*-with-ad` variants.
   It's idempotent, non-mutating, and defensively returns the input on
   any unexpected shape (null forms, missing pages, future schema
   drift). Currently dead code; activated by flipping
   `enableAutoRewrite` once the upstream registry bug is patched.

### Shared building blocks

1. **`startupApp` anchor.** `@openmrs/esm-routes`' lifecycle loader
   only imports a module's bundle and calls `startupApp` when a
   routes.json component is referenced for slot rendering. With no
   extensions, our bundle would never load and neither
   `registerControl` nor the runtime picker wrap would ever run.
   `src/components/init-anchor.component.tsx` is a `() => null`
   extension slotted into `top-nav-actions-slot` purely to give the
   loader something to call — no visible UI.
2. **BS converter.** `src/lib/bs-converter.ts` does AD↔BS arithmetic
   from a field-validated days-per-month table
   (`src/lib/bs-calendar-data.ts`). The table is **also inlined** in
   `tools/patch-esm-styleguide-picker.cjs` so the build-time patch is
   self-contained; extend both together when stretching past 2100 BS.
3. **`BSDatePicker`.** Carbon-styled BS calendar input that emits AD
   `Date` objects via `onChange` — the BS UI is presentational, never a
   stored value. Used by both the form-engine controls and the
   runtime wrapper's BS tab.

## Limitations

- **Stock `date`/`datetime` form-engine renderings stay AD.** See
  roadmap item 1. (Single-input `OpenmrsDatePicker` IS wrapped — this
  point is only about form-engine schema-level renderings.)
- **`OpenmrsDateRangePicker`** is not wrapped yet. See roadmap item 3.
- **Read-only date displays elsewhere in the SPA stay AD.** Patient
  banner DOB, encounter dates in visit history, medication start
  dates, etc. See roadmap item 4 — use `<NidanDate>` per surface in
  Nidan-owned modules.
- **BS converter range: 1975 – 2100 BS** (~AD 1918 – 2043). Outside
  this range conversion throws. Extend via `src/lib/bs-calendar-data.ts`
  (and the inlined table in `tools/patch-esm-styleguide-picker.cjs`).

## Public API (for Phase 2 consumers)

```ts
import {
  // Conversion
  adToBS, bsToAD, formatBS, parseBS, todayBS,
  // Drop-in components for non-form-engine call sites
  BSDatePicker,           // mirrors OpenmrsDatePicker API
  AdWithBsDisplay,        // "12 Apr 2025 (BS 2082-01-30)"
} from '@nidan/esm-nepali-calendar';
```

## Configuration

Override via the O3 Implementer Tools:

| Key               | Type   | Default | What it does                                              |
|-------------------|--------|---------|-----------------------------------------------------------|
| `displayLanguage` | string | `np`    | Month/weekday names in the picker. `np` (Nepali) or `en`. |

Validation uses `validators.oneOf(['np', 'en'])` from
`@openmrs/esm-framework`.

## Install

This package is a standard OpenMRS ESM app. After adding it to the
importmap:

```bash
cd openmrs-frontend/nidan-esm-nepali-calendar
yarn install
yarn build
```

To bundle into a tgz for the SPA assembly:

```bash
yarn pack --out /tmp/nidan-esm-nepali-calendar-%v.tgz
# then copy the tgz into nidan-docker/openmrs/frontend/packages/
# and add an entry in spa-assemble-config.json + Dockerfile.
```

## Local development

### Quick start (against nidan-docker)

```bash
cd openmrs-frontend/nidan-esm-nepali-calendar
yarn install                      # one-time; runs the localhost→127.0.0.1 importmap patch
cp example.env .env               # one-time; adjust the gateway URL if needed
yarn start:local                  # reads .env, runs `openmrs develop`
```

`start:local` (see `tools/start-openmrs-develop.mjs`) reads
`OPENMRS_BACKEND_URL`, `OPENMRS_DEVELOP_HOST`/`PORT`, and
`NIDAN_BACKEND_URL` from `.env`. Pass the **gateway origin** (e.g.
`http://localhost`), not `…/openmrs/` — the openmrs CLI appends the
`/openmrs/...` path itself. `NIDAN_BACKEND_URL` activates the opt-in
dev-server proxy in `webpack.config.js` so root-relative importmap URLs
resolve against your gateway.

Open `http://127.0.0.1:9101/openmrs/spa/` (or
`http://localhost/openmrs/spa/` through the gateway) and log in. The
SPA shell loads our local working tree for `@nidan/esm-nepali-calendar`
— every code save triggers a rebuild + reload.

### Quick start (against dev3, no docker)

```bash
yarn start
```

`yarn start` is just `openmrs develop`, defaulting to
`https://dev3.openmrs.org` as the backend. Useful for solo UI work
when you don't need a real docker.

### Pointing at the docker backend

Confirm the gateway is up:

```bash
curl http://localhost/openmrs/ws/rest/v1/session
# expect: {"sessionId":"...","authenticated":false,...}
```

Then set in `.env` (or override per-run):

| Your gateway config                       | `OPENMRS_BACKEND_URL`           |
|-------------------------------------------|---------------------------------|
| Gateway on `:80` (default)                | `http://localhost`              |
| Gateway on `:80` with HTTPS rewrite       | `https://localhost`             |
| Direct to OpenMRS on `:8080`              | `http://localhost:8080`         |
| Custom hostname (e.g. `nidan.local`)      | `http://nidan.local`            |

CLI override:

```bash
yarn start:local -- --backend http://localhost
```

### Developing alongside other local modules

Add `--sources` for every checkout you want to override:

```bash
yarn start:local -- \
  --sources \
    ../openmrs-esm-patient-chart/packages/esm-patient-chart-app \
    ../openmrs-esm-patient-chart/packages/esm-patient-medications-app \
    ../trigonal-esm-ipd-app
```

Each `--sources` target must have a `package.json` with a valid
`name`/`main` and have its deps installed.

### Verifying the BS pickers are live

Once the dev server is running and you log in:

1. **Network tab** — `nidan-esm-nepali-calendar.js` is fetched from
   `127.0.0.1:9101` (or your configured port), not from a CDN.
2. **Open a form with a question whose `questionOptions.rendering` is
   `"bs-date"`** (or one of the four BS renderings). The Carbon-styled
   BS picker (Baisakh / Jestha / …) renders. A read-only view of an
   existing obs shows both `BS: …` and `AD: …` lines.
3. **Submit the form**. The encounter POST shows the obs value as
   `"2026-06-01"` (BS-date and date) or `"2026-06-01 00:00"` (datetime),
   not an ISO-8601 string with `Z`. OpenMRS REST accepts it without a
   parse error.

### Common gotchas

- **CORS errors on auth** almost always mean the `--backend` URL
  doesn't match how your cookies were set. If you logged in via
  `http://localhost/openmrs` but pass `--backend https://localhost`,
  the session cookie won't travel. Use the exact scheme + host you log
  in with.
- **Stock `date` fields don't switch to BS.** That's the upstream
  registry bug (see Roadmap item 1). Use an explicit
  `rendering: "bs-date"` in the question for now.
- **Hot reload not picking up changes** — edits to non-component files
  (e.g. `bs-calendar-data.ts`) sometimes don't trigger a rebuild
  through the `require.context` watcher. Save any `.tsx` file to
  force.

### Other yarn scripts

```bash
yarn test            # Jest — converter + schema transformer
yarn typescript      # tsc --noEmit, strict type-check
yarn lint            # eslint, --max-warnings 0
yarn build           # production bundle into dist/
yarn coverage        # yarn test --coverage
yarn pack            # produce a .tgz for the SPA assembly
```

## Supported BS range

**1975 – 2100 BS** (~AD 1918 – 2043). Days-per-month table is lifted
from the field-validated Odoo module (`nidan_nepali_datepicker`). To
extend, add new year entries to `src/lib/bs-calendar-data.ts`.

## License

MPL-2.0.
