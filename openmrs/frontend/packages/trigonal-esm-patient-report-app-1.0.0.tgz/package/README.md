# Trigonal ESM Patient Report App

This repository contains a microfrontend for the [OpenMRS](https://openmrs.org/) ecosystem, developed to generate and print patient summary reports. It is built as an ESM (ES Module) for use within OpenMRS 3.

## Features

- Generate structured patient summary reports
- Print or download reports directly from the patient dashboard
- Seamless integration into the OpenMRS 3 frontend

## Getting Started

### Prerequisites

Before running this app locally, ensure you have the following installed:

- [Node.js](https://nodejs.org/) (v16 or later recommended)
- [Yarn](https://classic.yarnpkg.com/en/docs/install/)
- A local or remote instance of OpenMRS 3 running

### Installation

Clone this repository and install the necessary dependencies:

```bash

git clone https://github.com/Trigonal-Technology/trigonal-esm-patient-report-app.git
cd trigonal-esm-patient-report-app

yarn
```

### Running the App Locally

To start the development server, run:

```bash
yarn start
```

### Building the App

To build the app for production, use the following command:

```bash
yarn build
```

### Accessing the App in OpenMRS

To access and use the app in OpenMRS, follow these steps:

1. Open your OpenMRS 3 frontend in the browser.
2. Log in with the default credentials:
   - **Username**: `admin`
   - **Password**: `Admin123`
3. Navigate to a patient’s dashboard.
4. Start the visit for the patient.
4. Click the **"Print Summary"** button to preview or download the report.

> **Note:** The **"Print Summary"** button will only appear after the patient visit is started.