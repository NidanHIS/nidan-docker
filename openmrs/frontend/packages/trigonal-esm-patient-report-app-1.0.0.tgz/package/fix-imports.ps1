
$m = "d:\Nidan\trigonal-esm-patient-report-app\src\components\modals"
$d = "d:\Nidan\trigonal-esm-patient-report-app\src\components\documents"
$p = "d:\Nidan\trigonal-esm-patient-report-app\src\components\print"

function Replace-In-File {
  param($file, [string[]]$from, [string[]]$to)
  $c = Get-Content $file -Raw
  for ($i = 0; $i -lt $from.Length; $i++) {
    $c = $c -replace [regex]::Escape($from[$i]), $to[$i]
  }
  Set-Content $file $c -NoNewline
}

# ── Modals ────────────────────────────────────────────────────────────────────
$mFrom = @(
  "from '../hooks/usePatientSummary'",
  "from '../hooks/useVisitSummaryData'",
  "from '../hooks/useDischargeSummaryData'",
  "from '../hooks/useInsuranceDischargeSummaryData'",
  "from '../hooks/useInsuranceReferralReportData'",
  "from '../hooks/useReferralReportData'",
  "from '../hooks/useDeathNoteData'",
  "from '../hooks/useNewbornAdmissionData'",
  "from '../hooks/usePatientInfo'",
  "from './patient-report-document/patient-summary-document'",
  "from './patient-report-document/insurance-discharge-summary-document'",
  "from './patient-report-document/insurance-referral-report-document'",
  "from './patient-report-document/discharge-summary-document'",
  "from './patient-report-document/referral-report-document'",
  "from './patient-report-document/birth-certificate-document'",
  "from './patient-report-document/death-certificate-document'"
)
$mTo = @(
  "from '../../hooks/reports/usePatientSummary'",
  "from '../../hooks/visit/useVisitSummaryData'",
  "from '../../hooks/reports/useDischargeSummaryData'",
  "from '../../hooks/reports/useInsuranceDischargeSummaryData'",
  "from '../../hooks/reports/useInsuranceReferralReportData'",
  "from '../../hooks/reports/useReferralReportData'",
  "from '../../hooks/reports/useDeathNoteData'",
  "from '../../hooks/reports/useNewbornAdmissionData'",
  "from '../../hooks/data/usePatientInfo'",
  "from '../documents/patient-summary-document'",
  "from '../documents/insurance-discharge-summary-document'",
  "from '../documents/insurance-referral-report-document'",
  "from '../documents/discharge-summary-document'",
  "from '../documents/referral-report-document'",
  "from '../documents/birth-certificate-document'",
  "from '../documents/death-certificate-document'"
)
Get-ChildItem "$m\*.tsx" | ForEach-Object {
  Replace-In-File $_.FullName $mFrom $mTo
  Write-Host "  fixed modal: $($_.Name)"
}

# ── Documents ─────────────────────────────────────────────────────────────────
$docFrom = @(
  "from '../../hooks/useDeathNoteData'",
  "from '../../hooks/useDischargeSummaryData'",
  "from '../../hooks/useReferralReportData'",
  "from '../../hooks/useLabResultsData'",
  "from '../../hooks/useInsuranceDischargeSummaryData'",
  "from '../../hooks/useInsuranceReferralReportData'",
  "from '../patient-report-document/lab-results.component'",
  "from '../patient-report-document/patient-report-header.component'",
  "from '../patient-report-document/patient-vitals-bio.component'",
  "from '../patient-report-document/patient-conditions-history.component'",
  "from '../patient-report-document/patient-encounters.components'",
  "from '../patient-report-document/patient-orders.component'",
  "from '../../encounter-print-letterhead.component'"
)
$docTo = @(
  "from '../../hooks/reports/useDeathNoteData'",
  "from '../../hooks/reports/useDischargeSummaryData'",
  "from '../../hooks/reports/useReferralReportData'",
  "from '../../hooks/reports/useLabResultsData'",
  "from '../../hooks/reports/useInsuranceDischargeSummaryData'",
  "from '../../hooks/reports/useInsuranceReferralReportData'",
  "from './lab-results.component'",
  "from './patient-report-header.component'",
  "from './patient-vitals-bio.component'",
  "from './patient-conditions-history.component'",
  "from './patient-encounters.components'",
  "from './patient-orders.component'",
  "from '../print/encounter-print-letterhead.component'"
)
Get-ChildItem "$d\*.tsx" | ForEach-Object {
  Replace-In-File $_.FullName $docFrom $docTo
  Write-Host "  fixed doc: $($_.Name)"
}

# ── Print button ──────────────────────────────────────────────────────────────
$btnFile = "$p\print-summary-button.component.tsx"
$btnFrom = @(
  "from './hooks/useLatestVisit'",
  "from '../hooks/useLatestVisit'",
  "from '../../hooks/useLatestVisit'"
)
$btnTo = @(
  "from '../../hooks/visit/useLatestVisit'",
  "from '../../hooks/visit/useLatestVisit'",
  "from '../../hooks/visit/useLatestVisit'"
)
Replace-In-File $btnFile $btnFrom $btnTo
Write-Host "  fixed print-summary-button"

# ── index.ts — update all dynamic import paths ────────────────────────────────
$indexFile = "d:\Nidan\trigonal-esm-patient-report-app\src\index.ts"
$idxFrom = @(
  "from './print-summary-button.component'",
  "import('./components/print-patient-summary.modal')",
  "import('./components/birth-certificate-modal')",
  "import('./components/death-certificate-modal')",
  "import('./components/referral-report-modal')",
  "import('./components/discharge-summary-modal')",
  "import('./components/insurance-discharge-summary-modal')",
  "import('./components/insurance-referral-report-modal')",
  "import('./components/print-visit-summary.modal')"
)
$idxTo = @(
  "from './components/print/print-summary-button.component'",
  "import('./components/modals/print-patient-summary.modal')",
  "import('./components/modals/birth-certificate-modal')",
  "import('./components/modals/death-certificate-modal')",
  "import('./components/modals/referral-report-modal')",
  "import('./components/modals/discharge-summary-modal')",
  "import('./components/modals/insurance-discharge-summary-modal')",
  "import('./components/modals/insurance-referral-report-modal')",
  "import('./components/modals/print-visit-summary.modal')"
)
Replace-In-File $indexFile $idxFrom $idxTo

# Also fix getSyncLifecycle import which references PrintSummaryButton from old path
$ic = Get-Content $indexFile -Raw
$ic = $ic -replace [regex]::Escape("import { PrintSummaryButton } from './print-summary-button.component'"), "import { PrintSummaryButton } from './components/print/print-summary-button.component'"
$ic = $ic -replace [regex]::Escape("import PrintVisitSummary from './components/visit-action-items/print-visit-details.component'"), "import PrintVisitSummary from './components/visit-action-items/print-visit-details.component'"
Set-Content $indexFile $ic -NoNewline
Write-Host "  fixed index.ts"

Write-Host "All done."
