import { Type, validators } from '@openmrs/esm-framework';

export const configSchema = {
  concepts: {
    systolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    diastolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    pulseUuid: {
      _type: Type.ConceptUuid,
      _default: '5087AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    temperatureUuid: {
      _type: Type.ConceptUuid,
      _default: '5088AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    oxygenSaturationUuid: {
      _type: Type.ConceptUuid,
      _default: '5092AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    heightUuid: {
      _type: Type.ConceptUuid,
      _default: '5090AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    weightUuid: {
      _type: Type.ConceptUuid,
      _default: '5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    respiratoryRateUuid: {
      _type: Type.ConceptUuid,
      _default: '5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    generalPatientNoteUuid: {
      _type: Type.ConceptUuid,
      _default: '165095AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    midUpperArmCircumferenceUuid: {
      _type: Type.ConceptUuid,
      _default: '1343AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    },
    notesConceptUuid: {
      _type: Type.Array,
      _default: ['162169AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'],
    },
  },
  hospitalName: {
    _type: Type.String,
    _default: 'Bhalubang Hospital',
    _description: 'The name of the hospital to be displayed on the print letterhead',
  },
  hospitalAddress: {
    _type: Type.String,
    _default: 'Bhalubang, Dang',
    _description: 'The address of the hospital to be displayed on the print letterhead',
  },
  hospitalContactInfo: {
    _type: Type.String,
    _default: '',
    _description: 'Additional contact information (phone, email) for the hospital letterhead',
  },
  hospitalLetterheadTopLines: {
    _type: Type.Array,
    _elements: {
      _type: Type.String,
    },
    _default: ['Lumbini province government', 'Ministry of health', 'health directorate'],
    _description: 'Lines of text to display at the very top of the hospital letterhead',
  },
  hospitalLetterheadBottomLines: {
    _type: Type.Array,
    _elements: {
      _type: Type.String,
    },
    _default: [],
    _description: 'Lines of text to display below the hospital name in the letterhead',
  },
  printLetterhead: {
    _type: Type.Boolean,
    _default: false,
    _description: 'Whether to print the hospital letterhead on documents',
  },
};

export interface ConfigObject {
  concepts: {
    systolicBloodPressureUuid: string;
    diastolicBloodPressureUuid: string;
    pulseUuid: string;
    temperatureUuid: string;
    oxygenSaturationUuid: string;
    heightUuid: string;
    weightUuid: string;
    respiratoryRateUuid: string;
    generalPatientNoteUuid: string;
    midUpperArmCircumferenceUuid: string;
    notesConceptUuid: string[];
  };
  hospitalName: string;
  hospitalAddress: string;
  hospitalContactInfo: string;
  hospitalLetterheadTopLines: Array<string>;
  hospitalLetterheadBottomLines: Array<string>;
  printLetterhead: boolean;
}
