import { Type } from '@openmrs/esm-framework';

export const configSchema = {
  // ─── Vitals Concept UUIDs ───────────────────────────────────────────────────
  concepts: {
    systolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for systolic blood pressure',
    },
    diastolicBloodPressureUuid: {
      _type: Type.ConceptUuid,
      _default: '5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for diastolic blood pressure',
    },
    pulseUuid: {
      _type: Type.ConceptUuid,
      _default: '5087AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for pulse / heart rate',
    },
    temperatureUuid: {
      _type: Type.ConceptUuid,
      _default: '5088AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for body temperature',
    },
    oxygenSaturationUuid: {
      _type: Type.ConceptUuid,
      _default: '5092AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for oxygen saturation (SpO2)',
    },
    heightUuid: {
      _type: Type.ConceptUuid,
      _default: '5090AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for height',
    },
    weightUuid: {
      _type: Type.ConceptUuid,
      _default: '5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for weight',
    },
    respiratoryRateUuid: {
      _type: Type.ConceptUuid,
      _default: '5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for respiratory rate',
    },
    generalPatientNoteUuid: {
      _type: Type.ConceptUuid,
      _default: '165095AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for general patient notes',
    },
    midUpperArmCircumferenceUuid: {
      _type: Type.ConceptUuid,
      _default: '1343AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for mid-upper arm circumference (MUAC)',
    },
    notesConceptUuid: {
      _type: Type.Array,
      _default: ['162169AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'],
      _description: 'Concept UUIDs for clinical note observations shown in the visit summary',
    },
  },

  // ─── Observation Concept UUIDs ──────────────────────────────────────────────
  // These concepts are used to extract specific clinical values from encounter
  // obs arrays in the discharge, referral, and summary report documents.
  obsConcepts: {
    chiefComplaintUuid: {
      _type: Type.ConceptUuid,
      _default: 'e32add25-df38-4b2b-85e8-709633467ce2',
      _description: 'Concept UUID for chief complaint (stored as FHIR free-text observation)',
    },
    historyOfPresentIllnessUuid: {
      _type: Type.ConceptUuid,
      _default: '1390AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      _description: 'Concept UUID for history of present illness',
    },
    reasonForReferralUuid: {
      _type: Type.ConceptUuid,
      _default: 'bc44de6f-db98-42c7-98b5-5fd059f50d3a',
      _description: 'Concept UUID for reason for referral',
    },
    followUpInstructionsUuid: {
      _type: Type.ConceptUuid,
      _default: '75ca7f0d-a0f4-49b7-9d4c-077839a1f1cf',
      _description: 'Concept UUID for follow-up instructions / advice',
    },
    treatmentGivenUuid: {
      _type: Type.ConceptUuid,
      _default: '062acf82-584a-4ea3-9c7e-08a955b34da0',
      _description: 'Concept UUID for treatment given',
    },
    referInstitutionUuid: {
      _type: Type.ConceptUuid,
      _default: 'c0f2ccac-003e-406e-afe2-b0cf97b88916',
      _description: 'Concept UUID for referral institution name',
    },
    diagnosisUuid: {
      _type: Type.ConceptUuid,
      _default: '600f6ff5-ca78-4928-9fce-e750aafe9641',
      _description: 'Concept UUID for obs-level diagnosis (used alongside encounter-level diagnoses)',
    },
    dateOfAdmissionUuid: {
      _type: Type.ConceptUuid,
      _default: 'fee07cde-19c9-46a6-a117-2ce8dae3aefb',
      _description: 'Concept UUID for date of admission',
    },
    dischargeDateUuid: {
      _type: Type.ConceptUuid,
      _default: 'f50023bd-feb5-4945-ac00-4f6e8df0b359',
      _description: 'Concept UUID for discharge date',
    },
    briefHospitalCourseUuid: {
      _type: Type.ConceptUuid,
      _default: '9986de91-7fa2-4e4a-a0cc-9504c342ad87',
      _description: 'Concept UUID for brief hospital course narrative',
    },
    majorSurgeryUuid: {
      _type: Type.ConceptUuid,
      _default: 'dd53dd9e-f0d3-438e-b08a-c4af65923d91',
      _description: 'Concept UUID for major surgery performed',
    },
    postOpComplicationsUuid: {
      _type: Type.ConceptUuid,
      _default: 'a2fd14a5-6ce1-4fec-aa85-900ab3650ffa',
      _description: 'Concept UUID for post-operative complications',
    },
    inpatientOutcomeUuid: {
      _type: Type.ConceptUuid,
      _default: 'ca1eee0c-eb4c-4c6c-85ff-e7f644d1af30',
      _description: 'Concept UUID for inpatient outcome',
    },
    medicationOnDischargeUuid: {
      _type: Type.ConceptUuid,
      _default: 'c5b9574b-7ec3-4808-9a75-c78303fe7ed6',
      _description: 'Concept UUID for medication on discharge',
    },
    followUpDateUuid: {
      _type: Type.ConceptUuid,
      _default: 'f5cda421-be04-4b04-a4e8-85267d32ebe5',
      _description: 'Concept UUID for follow-up appointment date',
    },
    dischargedToUuid: {
      _type: Type.ConceptUuid,
      _default: 'd70df6f0-46d9-4cd0-aa33-1dd91a4c5c87',
      _description: 'Concept UUID for discharged-to location / setting',
    },
    assignedBedUuid: {
      _type: Type.ConceptUuid,
      _default: '71525388-448c-4503-979a-921cd6fdc989',
      _description: 'Concept UUID for assigned bed number (Admission Summary form)',
    },
    providersUuid: {
      _type: Type.ConceptUuid,
      _default: 'f4f0eec4-5a84-419c-9192-df30ffc72a4c',
      _description: 'Concept UUID for consultant / provider name (Admission Summary form)',
    },
  },

  // ─── Form UUIDs ─────────────────────────────────────────────────────────────
  // These form UUIDs are used to filter encounter queries to specific clinical
  // forms. Override these if your implementation uses different form UUIDs.
  forms: {
    dischargeSummaryFormUuid: {
      _type: Type.UUID,
      _default: 'a9d36a3b-71d5-3dfc-9ebb-61db4bbbab2d',
      _description: 'UUID of the Discharge Summary encounter form',
    },
    referralReportFormUuid: {
      _type: Type.UUID,
      _default: '55fcfbee-6510-3abb-b2da-dbd0d5353b2e',
      _description: 'UUID of the Referral Report encounter form',
    },
    admissionSummaryFormUuid: {
      _type: Type.UUID,
      _default: 'f9948b4c-1ae2-3246-a34f-a9f396b914b7',
      _description: 'UUID of the Admission Summary Record Note form',
    },
    deathNoteFormUuid: {
      _type: Type.UUID,
      _default: 'de010f04-2eb5-3a9c-afec-587868f3c2fa',
      _description: 'UUID of the Death Note encounter form',
    },
  },

  // ─── Hospital Letterhead ────────────────────────────────────────────────────
  hospitalName: {
    _type: Type.String,
    _default: 'Basic health service hospital Bijayanagar',
    _description: 'The name of the hospital to be displayed on the print letterhead',
  },
  hospitalAddress: {
    _type: Type.String,
    _default: 'Bhalubang, Dang',
    _description: 'The address of the hospital to be displayed on the print letterhead',
  },
  hospitalContactInfo: {
    _type: Type.String,
    _default: '',
    _description: 'Additional contact information (phone, email) for the hospital letterhead',
  },
  hospitalLetterheadTopLines: {
    _type: Type.Array,
    _elements: { _type: Type.String },
    _default: ['Lumbini province government', 'Ministry of health', 'health directorate'],
    _description: 'Lines of text to display at the very top of the hospital letterhead',
  },
  hospitalLetterheadBottomLines: {
    _type: Type.Array,
    _elements: { _type: Type.String },
    _default: [],
    _description: 'Lines of text to display below the hospital name in the letterhead',
  },
  printLetterhead: {
    _type: Type.Boolean,
    _default: true,
    _description: 'Whether to print the hospital letterhead on documents',
  },

  // ─── Provider Attribute UUIDs ────────────────────────────────────────────────
  // Attribute type UUIDs used to extract typed values from provider records.
  providers: {
    medicalCouncilNumberAttributeTypeUuid: {
      _type: Type.UUID,
      _default: 'decb58a5-8bf8-4959-ab13-bca04aef59c3',
      _description: 'UUID of the Medical Council Number provider attribute type (e.g. NMC number)',
    },
  },

  // ─── Document Settings ──────────────────────────────────────────────────────
  patientSummaryDocument: {
    excludeObsForms: {
      _type: Type.Array,
      _elements: { _type: Type.UUID },
      _default: [
        '55fcfbee-6510-3abb-b2da-dbd0d5353b2e', // referralReportFormUuid
        'de010f04-2eb5-3a9c-afec-587868f3c2fa', // deathNoteFormUuid
      ],
      _description: 'Form UUIDs whose observations are excluded from the patient summary obs table',
    },
  },
  dischargeNote: {
    excludeObsForms: {
      _type: Type.Array,
      _elements: { _type: Type.UUID },
      _default: [
        '55fcfbee-6510-3abb-b2da-dbd0d5353b2e',
        'de010f04-2eb5-3a9c-afec-587868f3c2fa',
      ],
      _description: 'Form UUIDs whose observations are excluded from the discharge note obs table',
    },
  },
};

// ─── TypeScript Interface ─────────────────────────────────────────────────────

export interface ConfigObject {
  concepts: {
    systolicBloodPressureUuid: string;
    diastolicBloodPressureUuid: string;
    pulseUuid: string;
    temperatureUuid: string;
    oxygenSaturationUuid: string;
    heightUuid: string;
    weightUuid: string;
    respiratoryRateUuid: string;
    generalPatientNoteUuid: string;
    midUpperArmCircumferenceUuid: string;
    notesConceptUuid: string[];
  };
  obsConcepts: {
    chiefComplaintUuid: string;
    historyOfPresentIllnessUuid: string;
    reasonForReferralUuid: string;
    followUpInstructionsUuid: string;
    treatmentGivenUuid: string;
    referInstitutionUuid: string;
    diagnosisUuid: string;
    dateOfAdmissionUuid: string;
    dischargeDateUuid: string;
    briefHospitalCourseUuid: string;
    majorSurgeryUuid: string;
    postOpComplicationsUuid: string;
    inpatientOutcomeUuid: string;
    medicationOnDischargeUuid: string;
    followUpDateUuid: string;
    dischargedToUuid: string;
    assignedBedUuid: string;
    providersUuid: string;
  };
  forms: {
    dischargeSummaryFormUuid: string;
    referralReportFormUuid: string;
    admissionSummaryFormUuid: string;
    deathNoteFormUuid: string;
  };
  hospitalName: string;
  hospitalAddress: string;
  hospitalContactInfo: string;
  hospitalLetterheadTopLines: string[];
  hospitalLetterheadBottomLines: string[];
  printLetterhead: boolean;
  providers: {
    medicalCouncilNumberAttributeTypeUuid: string;
  };
  patientSummaryDocument: {
    excludeObsForms: string[];
  };
  dischargeNote: {
    excludeObsForms: string[];
  };
}
