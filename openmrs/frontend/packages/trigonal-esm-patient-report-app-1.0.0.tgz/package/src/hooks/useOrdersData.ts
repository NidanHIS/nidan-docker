import { useMemo } from 'react';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import type { Orders } from '../types';
import { openmrsFetcher } from '../utils';

interface OrdersApiResponse {
  results: Orders[];
}

export function useOrdersData(
  patientUuid: string,
  activatedOnOrAfterDate?: string,
  activatedOnOrBeforeDate?: string,
) {
  const { t } = useTranslation();

  const { data, error, isLoading, mutate } = useSWR<OrdersApiResponse, Error>(
    patientUuid
      ? (() => {
          const params = new URLSearchParams({
            patient: patientUuid,
            v: 'full',
          });
          if (activatedOnOrAfterDate) params.set('activatedOnOrAfterDate', activatedOnOrAfterDate);
          if (activatedOnOrBeforeDate) params.set('activatedOnOrBeforeDate', activatedOnOrBeforeDate);
          return `${restBaseUrl}/order?${params.toString()}`;
        })()
      : null,
    openmrsFetcher,
  );

  const orders = useMemo(() => {
    if (!data?.results) return [];

    const mapped = data.results
      .map((order) => {
        if (order.orderType?.name === 'Drug Order') {
          return {
            uuid: order.uuid,
            orderType: { name: 'Drug Order' },
            drug: { display: order.drug?.display || t('unknownValue', 'Unknown') },
            dose: order.dose || '',
            doseUnits: { display: order.doseUnits?.display || '' },
            frequency: { display: order.frequency?.display || '' },
            dosingInstructions: order.dosingInstructions || t('takeAsDirected', 'Take as directed'),
            route: { display: order.route?.display || '' },
            duration: order.duration || '',
            durationUnits: { display: order.durationUnits?.display || '' },
            orderer: { display: order.orderer?.display || '' },
            dateActivated: order.dateActivated,
            auditInfo: order.auditInfo,
            conceptUuid: (order as any).concept?.uuid ?? null,
            encounterUuid: (order as any).encounter?.uuid ?? null,
          };
        } else if (
          order.orderType?.name === 'Test Order' ||
          order.orderType?.name === 'Radiology Order' ||
          order.orderType?.name === 'Procedure Order' ||
          order.orderType?.name === 'Medical Supply Order'
        ) {
          return {
            uuid: order.uuid,
            orderType: { name: order.orderType.name },
            drug: { display: order.display || '' },
            dose: '',
            doseUnits: { display: '' },
            frequency: { display: '' },
            route: { display: '' },
            duration: '',
            durationUnits: { display: '' },
            orderer: { display: order.orderer?.display || '' },
            dateActivated: order.dateActivated || '',
            display: order.display,
            urgency: order.urgency || t('routineUrgency', 'ROUTINE'),
            instructions: order.instructions || '',
            auditInfo: order.auditInfo,
            conceptUuid: (order as any).concept?.uuid ?? null,
            encounterUuid: (order as any).encounter?.uuid ?? null,
          };
        }
        return null;
      })
      .filter((o): o is NonNullable<typeof o> => o !== null);

    // Deduplicate: keep only the most recent order per orderType + conceptUuid.
    // The API returns orders sorted newest-first, so the first hit per key wins.
    const seen = new Set<string>();
    return mapped.filter((order) => {
      const key = `${order.orderType.name}::${order.conceptUuid ?? order.uuid}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [data, t]);

  return { orders, isLoading, error, mutate };
}