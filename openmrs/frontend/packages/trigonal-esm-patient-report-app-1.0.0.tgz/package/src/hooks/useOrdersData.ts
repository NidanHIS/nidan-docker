import { useMemo } from 'react';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import type { Orders } from '../types';
import { openmrsFetcher } from '../utils';

interface OrdersApiResponse {
  results: Orders[];
}

export function useOrdersData(patientUuid: string) {
  const { t } = useTranslation();

  const { data, error, isLoading, mutate } = useSWR<OrdersApiResponse, Error>(
    patientUuid ? `${restBaseUrl}/order?patient=${patientUuid}&v=full&includeInactive=true` : null,
    openmrsFetcher,
  );

  const orders = useMemo(() => {
    if (!data?.results) return [];

    return data.results
      .map((order) => {
        if (order.orderType?.name === 'Drug Order') {
          return {
            uuid: order.uuid,
            orderType: { name: 'Drug Order' },
            drug: { display: order.drug?.display || t('unknownValue', 'Unknown') },
            dose: order.dose || '',
            doseUnits: { display: order.doseUnits?.display || '' },
            frequency: { display: order.frequency?.display || '' },
            dosingInstructions: order.dosingInstructions || t('takeAsDirected', 'Take as directed'),
            route: { display: order.route?.display || '' },
            duration: order.duration || '',
            durationUnits: { display: order.durationUnits?.display || '' },
            orderer: { display: order.orderer?.display || '' },
            auditInfo: order.auditInfo,
          };
        } else if (
          order.orderType?.name === 'Test Order' ||
          order.orderType?.name === 'Radiology Order' ||
          order.orderType?.name === 'Procedure Order'
        ) {
          return {
            uuid: order.uuid,
            orderType: { name: order.orderType.name },
            drug: { display: order.display || '' },
            dose: '',
            doseUnits: { display: '' },
            frequency: { display: '' },
            route: { display: '' },
            duration: '',
            durationUnits: { display: '' },
            orderer: { display: order.orderer?.display || '' },
            dateActivated: order.dateActivated
              ? new Date(order.dateActivated).toLocaleDateString('en-GB')
              : '',
            display: order.display,
            urgency: order.urgency || t('routineUrgency', 'ROUTINE'),
            instructions: order.instructions || '',
            auditInfo: order.auditInfo,
            conceptUuid: (order as any).concept?.uuid || null,
          };
        }
        return null;
      })
      .filter((o): o is NonNullable<typeof o> => o !== null);
  }, [data, t]);

  return { orders, isLoading, error, mutate };
}