import { useMemo } from 'react';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import { openmrsFetch } from '@openmrs/esm-framework';

export function useOrdersData(patientUuid) {
  const fetchOrders = async (url: string): Promise<Orders[]> => {
    const response = await openmrsFetch(url);
    return response.data.results;
  };
  const { t } = useTranslation();

  const { data: orders, error, isLoading } = useSWR(
    `${restBaseUrl}/order?patient=${patientUuid}&v=full&includeInactive=false`,
    fetchOrders
  );

  const ordersData = useMemo(() => {
    if (!orders) return [];
    
    return orders
      .map(order => {
        if (order.orderType?.name === 'Drug Order') {
          return {
            orderType: { name: 'Drug Order' },
            drug: { display: order.drug?.display || t('unknownValue', 'Unknown') },
            dose: order.dose || '',
            doseUnits: { display: order.doseUnits?.display || '' },
            frequency: { display: order.frequency?.display || '' },
            dosingInstructions: order.dosingInstructions || t('takeAsDirected', 'Take as directed'),
            route: { display: order.route?.display || '' },
            duration: order.duration || '',
            durationUnits: { display: order.durationUnits?.display || '' }
            
          };
        } else if (order.orderType?.name === 'Test Order') {
          return {
            orderType: { name: 'Test Order' },
            dateActivated: new Date(order.dateActivated).toLocaleDateString('en-GB') || '',
            display: order.display,
            urgency: order.urgency || t('routineUrgency', 'ROUTINE'),
            instructions: order.instructions || ''
          };
        }
        return null;
      })
      .filter(Boolean);
  }, [orders]);

  return {
    orders,
    isLoading,
    error
  };
}