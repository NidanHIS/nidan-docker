import { useMemo } from 'react';
import { usePatient } from '@openmrs/esm-framework';
import { calculateAge } from '../utils';
export function usePatientInfo(patientUuid) {
  const { patient, isLoading, error } = usePatient(patientUuid);

  const formattedPatientInfo = useMemo(() => {
    if (!patient) return null;
    return {
      name: patient?.name?.[0]?.text || 'Unknown',
      age: calculateAge(patient?.birthDate) || 'Unknown',
      birthDate: patient?.birthDate || 'Unknown',
      gender: patient?.gender || 'Unknown',
      address: patient?.address?.[0]?.extension?.[0]?.extension?.[0]?.valueString || 'Unknown',
      patientId: patient?.identifier?.[0]?.value || 'Unknown',
    };
  }, [patient]);

  return {
    patientInfo: formattedPatientInfo,
    isLoading,
    error
  };
}