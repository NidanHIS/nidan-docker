import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher } from '../utils';

export interface LatestVisitResult {
  uuid: string;
  startDatetime: string;
  stopDatetime: string | null;
}

/**
 * Fetches the most recent visit for a patient, including inactive/closed visits.
 * Used across hooks that need to scope data (orders, observations, encounters)
 * to the latest visit window regardless of whether it is currently active.
 */
export function useLatestVisit(patientUuid: string) {
  const { data, error, isLoading } = useSWR<{ results: LatestVisitResult[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/visit?patient=${patientUuid}&includeInactive=true&v=custom:(uuid,startDatetime,stopDatetime)&limit=1`
      : null,
    openmrsFetcher,
  );

  return {
    visit: data?.results?.[0] ?? null,
    isLoading,
    error,
  };
}
