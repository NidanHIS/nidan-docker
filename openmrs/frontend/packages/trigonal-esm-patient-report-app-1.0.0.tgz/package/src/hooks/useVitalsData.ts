import { useMemo } from 'react';
import { fhirBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import type { VitalsMain, VitalsData } from '../types';
import { type ConfigObject } from '../config-schema';
import { vitalsDataStatus, openmrsFetcher, toFhirDateTime } from '../utils';

export function useVitalsData(patientUuid: string, startDatetime?: string, stopDatetime?: string) {
  const { concepts } = useConfig<ConfigObject>();

  const vitalsConcepts = useMemo(
    () => [
      concepts.systolicBloodPressureUuid,
      concepts.diastolicBloodPressureUuid,
      concepts.pulseUuid,
      concepts.temperatureUuid,
      concepts.oxygenSaturationUuid,
      concepts.respiratoryRateUuid,
    ],
    [concepts],
  );

  const url = useMemo(() => {
    if (!patientUuid) return null;
    const params = new URLSearchParams({
      'subject:Patient': patientUuid,
      code: vitalsConcepts.join(','),
      _sort: 'date',
      _count: '100',
    });
    const fhirStart = toFhirDateTime(startDatetime);
    const fhirStop = toFhirDateTime(stopDatetime);
    if (fhirStart) params.append('date', `ge${fhirStart}`);
    if (fhirStop) params.append('date', `le${fhirStop}`);
    return `${fhirBaseUrl}/Observation?${params.toString()}`;
  }, [patientUuid, vitalsConcepts, startDatetime, stopDatetime]);

  const { data: vitals, error, isLoading, mutate } = useSWR<VitalsMain, Error>(url, openmrsFetcher);

  const vitalsData = useMemo<VitalsData>(() => {
    if (!vitals?.entry) return {};

    const result: VitalsData = {};

    vitals.entry.forEach(({ resource: observation }) => {
      const code = observation.code.coding[0].code;
      const value = observation?.valueQuantity?.value;
      const referenceRange = observation?.referenceRange?.[0];
      const status = referenceRange ? vitalsDataStatus(value, referenceRange) : '';

      switch (code) {
        case concepts.diastolicBloodPressureUuid:
          result.diastolicBP = { value, status };
          break;
        case concepts.systolicBloodPressureUuid:
          result.systolicBP = { value, status };
          break;
        case concepts.temperatureUuid:
          result.temperature = { value, status };
          break;
        case concepts.pulseUuid:
          result.pulse = { value, status };
          break;
        case concepts.respiratoryRateUuid:
          result.respiratoryRate = { value, status };
          break;
        case concepts.oxygenSaturationUuid:
          result.oxygenSaturation = { value, status };
          break;
      }
    });

    return result;
  }, [vitals, concepts]);

  return { vitalsData, isLoading, error, mutate };
}