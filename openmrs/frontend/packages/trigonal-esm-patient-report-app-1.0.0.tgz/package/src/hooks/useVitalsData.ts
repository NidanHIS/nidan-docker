import { useMemo, useEffect, useState } from 'react';
import { fhirBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { openmrsFetch } from '@openmrs/esm-framework';
import { type ConfigObject } from '../config-schema';
import { vitalsDataStatus } from '../utils';

export function useVitalsData(patientUuid) {
  const { concepts } = useConfig<ConfigObject>();
  const [vitalsData, setVitalsData] = useState<VitalsData>({});
  const vitalsConcepts = useMemo(
    () => [concepts.systolicBloodPressureUuid,concepts.diastolicBloodPressureUuid,concepts.pulseUuid,concepts.temperatureUuid,concepts.oxygenSaturationUuid,concepts.respiratoryRateUuid],
    [concepts.systolicBloodPressureUuid,concepts.diastolicBloodPressureUuid,concepts.pulseUuid,concepts.temperatureUuid,concepts.oxygenSaturationUuid,concepts.respiratoryRateUuid],
  );

  const fetchVitals = async (url) => {
    const response = await openmrsFetch(url);
    return response.data;
  };

  const { data: vitals, error, isLoading } = useSWR(
    `${fhirBaseUrl}/Observation?subject:Patient=${patientUuid}&code=${vitalsConcepts.join(',')}&_sort=date&_count=100`,
    fetchVitals
  );

  useEffect(() => {
  if (vitals?.entry) {
    const processedData: VitalsData = {};
    
    vitals.entry.forEach((entry: { resource: VitalObservation }) => {
      const observation = entry.resource;
      const code = observation.code.coding[0].code;
      const value = observation?.valueQuantity?.value;
      const referenceRange = observation?.referenceRange[0];
      
      let valueStatus = '';
      
      if (referenceRange && value !== undefined) {
        valueStatus = vitalsDataStatus(value, referenceRange);
      }

      switch (code) {
        case concepts.diastolicBloodPressureUuid:
          processedData.diastolicBP = { value: value, status: valueStatus };
          break;
        case concepts.systolicBloodPressureUuid:
          processedData.systolicBP = { value: value, status: valueStatus };
          break;
        case concepts.temperatureUuid:
          processedData.temperature = { value: value, status: valueStatus };
          break;
        case concepts.pulseUuid:
            processedData.pulse = { value: value, status: valueStatus };
            break;
        case concepts.respiratoryRateUuid:
            processedData.respiratoryRate = { value: value, status: valueStatus };
            break;
        case concepts.oxygenSaturationUuid:
            processedData.oxygenSaturation = { value: value, status: valueStatus };
            break;
      }
    });
    setVitalsData(processedData);
  }
}, [vitals]);

  return {
    vitalsData,
    isLoading,
    error
  };
}