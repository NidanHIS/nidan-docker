import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, fhirBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher, toFhirDateTime } from '../utils';
import { usePatientInfo } from './usePatientInfo';
import { useVisitDetails } from './useVisitDetails';
import { useLatestVisit } from './useLatestVisit';
import { useVitalsData } from './useVitalsData';
import { useBiometricsData } from './useBiometricsData';
import { useConditionsData } from './useConditionsData';
import { useOrdersData } from './useOrdersData';
import type { DiagnosisData } from '../types';

export function usePatientSummaryData(patientUuid: string) {
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);
  const { visitDetails, isLoading: isVisitLoading, error: visitError } = useVisitDetails(patientUuid);
  const { visit: latestVisit, isLoading: isActiveVisitLoading, error: activeVisitError } = useLatestVisit(patientUuid);

  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(
    patientUuid,
    latestVisit?.startDatetime ?? undefined,
    latestVisit?.stopDatetime ?? undefined,
  );
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(
    patientUuid,
    latestVisit?.startDatetime ?? undefined,
    latestVisit?.stopDatetime ?? undefined,
  );
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
    patientUuid,
    latestVisit?.startDatetime ?? undefined,
    latestVisit?.stopDatetime ?? undefined,
  );

  // Fetch encounters for the latest visit to extract observations
  const customRep =
    'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient,obs:(uuid,order:(uuid),concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person)))';
  const { data: encountersData, error: encountersError, isLoading: isEncountersLoading } = useSWR<
    { results: any[] },
    Error
  >(
    patientUuid && latestVisit?.uuid
      ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRep}&order=desc&limit=20&startIndex=0&totalCount=true&fromDate=${latestVisit?.startDatetime}&toDate=${latestVisit?.stopDatetime}`
      : null,
    openmrsFetcher,
  );

  // Chief complaint observation scoped to the latest visit window
  const chiefComplaintUrl = useMemo(() => {
    if (!patientUuid) return null;
    const params = new URLSearchParams({
      'subject:Patient': patientUuid,
      code: 'e32add25-df38-4b2b-85e8-709633467ce2',
      _sort: 'date',
      _count: '100',
      _summary: 'data',
    });
    const fhirStart = toFhirDateTime(latestVisit?.startDatetime);
    const fhirStop = toFhirDateTime(latestVisit?.stopDatetime);
    if (fhirStart) params.append('date', `ge${fhirStart}`);
    if (fhirStop) params.append('date', `le${fhirStop}`);
    return `${fhirBaseUrl}/Observation?${params.toString()}`;
  }, [patientUuid, latestVisit]);

  const { data: chiefComplaintData, error: chiefComplaintError, isLoading: isChiefComplaintLoading } = useSWR<
    any,
    Error
  >(chiefComplaintUrl, openmrsFetcher);

  const chiefComplaint = useMemo(() => {
    if (!chiefComplaintData?.entry || chiefComplaintData.entry.length === 0) return null;
    const entries = [...chiefComplaintData.entry];
    entries.sort((a: any, b: any) => {
      const dateA = new Date(a.resource?.effectiveDateTime || 0).getTime();
      const dateB = new Date(b.resource?.effectiveDateTime || 0).getTime();
      return dateB - dateA;
    });
    return entries[0]?.resource?.valueString || null;
  }, [chiefComplaintData]);

  const diagnosisData = useMemo<DiagnosisData[]>(() => {
    const results: DiagnosisData[] = [];
    const encounters = encountersData?.results ?? [];
    encounters.forEach((enc: any) => {
      enc.diagnoses?.forEach((diagnosis: any) => {
        if (!diagnosis.voided && diagnosis.display) {
          results.push({
            diagnosisName: diagnosis.display,
            rank: diagnosis.rank,
            certainty: diagnosis.certainty,
          });
        }
      });
    });
    return results;
  }, [encountersData]);

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    orders,
    encounters: encountersData?.results || [],
    chiefComplaint,
    isLoading:
      isPatientLoading ||
      isVisitLoading ||
      isActiveVisitLoading ||
      isVitalsLoading ||
      isBiometricsLoading ||
      isConditionsLoading ||
      isOrdersLoading ||
      isEncountersLoading ||
      isChiefComplaintLoading,
    error:
      patientError ||
      visitError ||
      activeVisitError ||
      vitalsError ||
      biometricsError ||
      conditionsError ||
      ordersError ||
      encountersError ||
      chiefComplaintError,
  };
}
