import { usePatientInfo } from "./usePatientInfo";
import { useVisitDetails } from "./useVisitDetails";
import { useVitalsData } from "./useVitalsData";
import { useBiometricsData } from "./useBiometricsData";
import { useConditionsData } from "./useConditionsData";
import { useEncounterData } from "./useEncounterData";
import { useOrdersData } from "./useOrdersData";
export function usePatientSummaryData(patientUuid) {
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);
  const { visitDetails, isLoading: isVisitLoading, error: visitError } = useVisitDetails(patientUuid);
  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(patientUuid);
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(patientUuid);
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);
  const { diagnosisData, clinicalNotes, isEncounterLoading: isEncounterLoading, error: encounterError } = useEncounterData(patientUuid);
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(patientUuid);

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    orders: orders,
    isLoading: isPatientLoading || isVisitLoading || isVitalsLoading || isBiometricsLoading || 
              isConditionsLoading || isEncounterLoading || isOrdersLoading,
    error: patientError || visitError || vitalsError || biometricsError || 
          conditionsError || encounterError || ordersError
  };
}