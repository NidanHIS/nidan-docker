import { useMemo } from 'react';
import { usePatientInfo } from './data/usePatientInfo';
import { useVisitDetails } from './visit/useVisitDetails';
import { useLatestVisit } from './visit/useLatestVisit';
import { useVitalsData } from './data/useVitalsData';
import { useBiometricsData } from './data/useBiometricsData';
import { useConditionsData } from './data/useConditionsData';
import { useOrdersData } from './data/useOrdersData';
import { useEncounters } from './data/useEncounters';
import { useChiefComplaint } from './data/useChiefComplaint';
import { combineHookStates, extractDiagnosesFromEncounters } from '../utils';
import type { DiagnosisData } from '../types';

/**
 * Aggregates all data required to render the Patient Summary document for a
 * patient's most recent visit.
 *
 * Unlike `useVisitSummaryData`, this hook resolves the latest visit
 * internally via `useLatestVisit`. It is used by report slots where the
 * caller does not have a visit object in scope.
 *
 * All data is scoped to the latest visit window
 * (latestVisit.startDatetime → latestVisit.stopDatetime).
 *
 * @param patientUuid - The patient's UUID
 */
export function usePatientSummaryData(patientUuid: string) {
  // ── Patient & visit context ─────────────────────────────────────────────────
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);
  const { visitDetails, isLoading: isVisitLoading, error: visitError } = useVisitDetails(patientUuid);
  const { visit: latestVisit, isLoading: isLatestVisitLoading, error: latestVisitError } = useLatestVisit(patientUuid);

  const startDatetime = latestVisit?.startDatetime ?? undefined;
  const stopDatetime = latestVisit?.stopDatetime ?? undefined;

  // ── Clinical data scoped to the latest visit ────────────────────────────────
  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(
    patientUuid, startDatetime, stopDatetime,
  );
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(
    patientUuid, startDatetime, stopDatetime,
  );
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
    patientUuid, startDatetime, stopDatetime,
  );

  // ── Encounters (full obs + diagnoses) scoped to latest visit ────────────────
  const { encounters, isLoading: isEncountersLoading, error: encountersError } = useEncounters(
    patientUuid,
    { fromDate: startDatetime, toDate: stopDatetime },
  );

  // ── Chief complaint (FHIR, visit-scoped) ───────────────────────────────────
  const { chiefComplaint, isLoading: isChiefComplaintLoading, error: chiefComplaintError } = useChiefComplaint(
    patientUuid, startDatetime, stopDatetime,
  );

  // ── Derived: diagnoses extracted from encounter list ────────────────────────
  const diagnosisData = useMemo((): DiagnosisData[] => {
    return extractDiagnosesFromEncounters(encounters).map(({ diagnosisName, rank, certainty }) => ({
      diagnosisName,
      rank,
      certainty,
    }));
  }, [encounters]);

  const { isLoading, error } = combineHookStates([
    { isLoading: isPatientLoading, error: patientError },
    { isLoading: isVisitLoading, error: visitError },
    { isLoading: isLatestVisitLoading, error: latestVisitError },
    { isLoading: isVitalsLoading, error: vitalsError },
    { isLoading: isBiometricsLoading, error: biometricsError },
    { isLoading: isConditionsLoading, error: conditionsError },
    { isLoading: isOrdersLoading, error: ordersError },
    { isLoading: isEncountersLoading, error: encountersError },
    { isLoading: isChiefComplaintLoading, error: chiefComplaintError },
  ]);

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    orders,
    encounters,
    chiefComplaint,
    isLoading,
    error,
  };
}
