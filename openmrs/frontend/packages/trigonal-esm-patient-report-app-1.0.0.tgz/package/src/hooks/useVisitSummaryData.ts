import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, type Visit, useConfig } from '@openmrs/esm-framework';
import { openmrsFetcher, combineHookStates } from '../utils';
import { usePatientInfo } from './data/usePatientInfo';
import { useVitalsData } from './data/useVitalsData';
import { useBiometricsData } from './data/useBiometricsData';
import { useConditionsData } from './data/useConditionsData';
import { useOrdersData } from './data/useOrdersData';
import { useEncounters } from './data/useEncounters';
import { useChiefComplaint } from './data/useChiefComplaint';
import { CUSTOM_REPS } from '../constants';
import type { ConfigObject } from '../config-schema';
import type { DiagnosisData, ClinicalNote } from '../types';

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Aggregates all data required to render a Patient Summary document for a
 * *specific* visit supplied by the caller.
 *
 * Unlike `usePatientSummaryData`, this hook does not resolve the latest visit
 * internally — it uses the `visit` argument directly. This is used by the
 * visit-action-items slot where the visit object is already in scope.
 *
 * All date-range filtering is scoped to visit.startDatetime → visit.stopDatetime.
 *
 * @param patientUuid - The patient's UUID
 * @param visit       - The specific visit to render the summary for
 */
export function useVisitSummaryData(patientUuid: string, visit: Visit) {
  const { concepts } = useConfig<ConfigObject>();

  const visitUuid = visit?.uuid;
  const startDatetime = visit?.startDatetime;
  const stopDatetime = (visit?.stopDatetime ?? undefined) as string | undefined;

  // ── Patient info ────────────────────────────────────────────────────────────
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);

  // Visit details are derived directly from the visit object — no extra fetch needed
  const visitDetails = useMemo(
    () => ({
      visitType: (visit as any)?.visitType?.display ?? '',
      location: (visit as any)?.location?.display ?? '',
      startDatetime: startDatetime ?? '',
    }),
    [visit, startDatetime],
  );

  // ── Clinical data scoped to this visit ─────────────────────────────────────
  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(
    patientUuid, startDatetime, stopDatetime,
  );
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(
    patientUuid, startDatetime, stopDatetime,
  );
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
    patientUuid, startDatetime, stopDatetime,
  );

  // ── Visit-level encounters (for diagnoses + clinical notes) ─────────────────
  // Uses the VISIT_WITH_ENCOUNTERS rep which nests encounters inside the visit
  // object — a single request that avoids a separate encounter list fetch.
  const { data: visitData, error: visitEncounterError, isLoading: isVisitEncounterLoading } = useSWR<any, Error>(
    patientUuid && visitUuid
      ? `${restBaseUrl}/visit/${visitUuid}?v=${CUSTOM_REPS.VISIT_WITH_ENCOUNTERS}`
      : null,
    openmrsFetcher,
  );

  const { diagnosisData, clinicalNotes } = useMemo(() => {
    const tempDiagnoses: DiagnosisData[] = [];
    const tempNotes: ClinicalNote[] = [];

    for (const enc of visitData?.encounters ?? []) {
      for (const d of enc.diagnoses ?? []) {
        if (d.display) {
          tempDiagnoses.push({ diagnosisName: d.display, rank: d.rank, certainty: d.certainty });
        }
      }
      for (const ob of enc.obs ?? []) {
        if (ob?.concept?.uuid && concepts.notesConceptUuid.includes(ob.concept.uuid) && ob.value) {
          tempNotes.push({ note: ob.value });
        }
      }
    }

    return { diagnosisData: tempDiagnoses, clinicalNotes: tempNotes };
  }, [visitData, concepts.notesConceptUuid]);

  // ── All encounters for obs table (full rep, visit-scoped) ──────────────────
  const { encounters, isLoading: isEncountersLoading, error: encountersError } = useEncounters(
    patientUuid,
    { visitUuid },
  );

  // ── Chief complaint (FHIR, visit-scoped) ───────────────────────────────────
  const { chiefComplaint, isLoading: isChiefComplaintLoading, error: chiefComplaintError } = useChiefComplaint(
    patientUuid, startDatetime, stopDatetime,
  );

  const { isLoading, error } = combineHookStates([
    { isLoading: isPatientLoading, error: patientError },
    { isLoading: isVitalsLoading, error: vitalsError },
    { isLoading: isBiometricsLoading, error: biometricsError },
    { isLoading: isConditionsLoading, error: conditionsError },
    { isLoading: isOrdersLoading, error: ordersError },
    { isLoading: isVisitEncounterLoading, error: visitEncounterError },
    { isLoading: isEncountersLoading, error: encountersError },
    { isLoading: isChiefComplaintLoading, error: chiefComplaintError },
  ]);

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    orders,
    encounters,
    chiefComplaint,
    isLoading,
    error,
  };
}
