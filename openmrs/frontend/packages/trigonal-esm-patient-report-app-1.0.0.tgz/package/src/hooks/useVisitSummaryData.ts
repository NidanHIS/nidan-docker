import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, fhirBaseUrl, type Visit, useConfig } from '@openmrs/esm-framework';
import { openmrsFetcher, toFhirDateTime } from '../utils';
import { usePatientInfo } from './usePatientInfo';
import { useVitalsData } from './useVitalsData';
import { useBiometricsData } from './useBiometricsData';
import { useConditionsData } from './useConditionsData';
import { useOrdersData } from './useOrdersData';
import type { ConfigObject } from '../config-schema';
import type { DiagnosisData, ClinicalNote } from '../types';

/**
 * Fetches all data needed to print a summary for a *specific* visit.
 * Unlike usePatientSummaryData, this hook does not resolve the latest visit —
 * the caller provides the visit object directly (e.g. from the visit-action-items slot).
 */
export function useVisitSummaryData(patientUuid: string, visit: Visit) {
  const { concepts } = useConfig<ConfigObject>();

  const visitUuid = visit?.uuid;
  const startDatetime = visit?.startDatetime;
  const stopDatetime = visit?.stopDatetime ?? undefined;

  // ── Patient info ────────────────────────────────────────────────────────────
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);

  // ── Visit details (type, location, start) ───────────────────────────────────
  const visitDetails = useMemo(
    () => ({
      visitType: (visit as any)?.visitType?.display ?? '',
      location: (visit as any)?.location?.display ?? '',
      startDatetime: startDatetime ?? '',
    }),
    [visit, startDatetime],
  );

  // ── Vitals & biometrics scoped to this visit ────────────────────────────────
  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(
    patientUuid,
    startDatetime,
    stopDatetime,
  );
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(
    patientUuid,
    startDatetime,
    stopDatetime,
  );

  // ── Conditions (patient-level, not visit-scoped) ────────────────────────────
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);

  // ── Orders scoped to this visit ─────────────────────────────────────────────
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
    patientUuid,
    startDatetime,
    stopDatetime,
  );

  // ── Diagnoses & clinical notes from visit's encounters ─────────────────────
  const customVisitRep =
    'custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,rank,certainty,voided,diagnosis),obs:(uuid,concept:(uuid,display),value,obsDatetime),encounterType:(uuid,display)),startDatetime,stopDatetime)';

  const { data: visitWithEncounters, error: visitEncounterError, isLoading: isVisitEncounterLoading } = useSWR<
    { results: any[] },
    Error
  >(
    patientUuid && visitUuid
      ? `${restBaseUrl}/visit/${visitUuid}?v=${customVisitRep}`
      : null,
    openmrsFetcher,
  );

  const { diagnosisData, clinicalNotes } = useMemo(() => {
    const tempDiagnoses: DiagnosisData[] = [];
    const tempNotes: ClinicalNote[] = [];

    const encounters = (visitWithEncounters as any)?.encounters ?? [];
    encounters.forEach((enc: any) => {
      enc.diagnoses?.forEach((d: any) => {
        if (d.display) tempDiagnoses.push({ diagnosisName: d.display, rank: d.rank, certainty: d.certainty });
      });
      enc.obs?.forEach((ob: any) => {
        if (ob && concepts.notesConceptUuid.includes(ob.concept?.uuid) && ob.value) {
          tempNotes.push({ note: ob.value });
        }
      });
    });

    return { diagnosisData: tempDiagnoses, clinicalNotes: tempNotes };
  }, [visitWithEncounters, concepts.notesConceptUuid]);

  // ── All encounters for this visit (for obs table) ──────────────────────────
  const customEncRep =
    'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient,obs:(uuid,order:(uuid),concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person)))';

  const { data: encountersData, error: encountersError, isLoading: isEncountersLoading } = useSWR<
    { results: any[] },
    Error
  >(
    patientUuid && visitUuid
      ? `${restBaseUrl}/encounter?patient=${patientUuid}&visit=${visitUuid}&v=${customEncRep}&order=desc&limit=20&startIndex=0&totalCount=true`
      : null,
    openmrsFetcher,
  );

  // ── Chief complaint scoped to this visit ────────────────────────────────────
  const chiefComplaintUrl = useMemo(() => {
    if (!patientUuid) return null;
    const params = new URLSearchParams({
      'subject:Patient': patientUuid,
      code: 'e32add25-df38-4b2b-85e8-709633467ce2',
      _sort: 'date',
      _count: '100',
      _summary: 'data',
    });
    const fhirStart = toFhirDateTime(startDatetime);
    const fhirStop = toFhirDateTime(stopDatetime);
    if (fhirStart) params.append('date', `ge${fhirStart}`);
    if (fhirStop) params.append('date', `le${fhirStop}`);
    return `${fhirBaseUrl}/Observation?${params.toString()}`;
  }, [patientUuid, startDatetime, stopDatetime]);

  const { data: chiefComplaintData, error: chiefComplaintError, isLoading: isChiefComplaintLoading } = useSWR<
    any,
    Error
  >(chiefComplaintUrl, openmrsFetcher);

  const chiefComplaint = useMemo(() => {
    if (!chiefComplaintData?.entry?.length) return null;
    const entries = [...chiefComplaintData.entry].sort((a: any, b: any) => {
      return (
        new Date(b.resource?.effectiveDateTime || 0).getTime() -
        new Date(a.resource?.effectiveDateTime || 0).getTime()
      );
    });
    return entries[0]?.resource?.valueString ?? null;
  }, [chiefComplaintData]);

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    orders,
    encounters: encountersData?.results ?? [],
    chiefComplaint,
    isLoading:
      isPatientLoading ||
      isVitalsLoading ||
      isBiometricsLoading ||
      isConditionsLoading ||
      isOrdersLoading ||
      isVisitEncounterLoading ||
      isEncountersLoading ||
      isChiefComplaintLoading,
    error:
      patientError ||
      vitalsError ||
      biometricsError ||
      conditionsError ||
      ordersError ||
      visitEncounterError ||
      encountersError ||
      chiefComplaintError,
  };
}
