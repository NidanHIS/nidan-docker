import { useMemo } from 'react';
import { fhirBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import type { PatientConditions, ConditionsData } from '../types';
import { openmrsFetcher } from '../utils';

export function useConditionsData(patientUuid: string) {
  const category = encodeURIComponent(
  "http://terminology.hl7.org/CodeSystem/condition-category|problem-list-item"
);
  const url = patientUuid
  ? `${fhirBaseUrl}/Condition?patient=${patientUuid}&category=${category}&_count=100`
  : null;

  const { data: conditions, error, isLoading, mutate } = useSWR<PatientConditions, Error>(url, openmrsFetcher);

  const conditionsData = useMemo<ConditionsData[]>(() => {
    if (!conditions?.entry) return [];

    return conditions.entry
      .map(({ resource: conditionObs }) => {
        const condition = conditionObs?.code?.coding?.[0]?.display;
        const onsetDateTime = conditionObs?.onsetDateTime;
        const onsetDate = onsetDateTime ?? undefined;
        const clinicalStatus = conditionObs?.clinicalStatus?.coding?.[0]?.code;

        return condition ? { condition, onsetDate, clinicalStatus } : null;
      })
      .filter((item): item is NonNullable<typeof item> => item !== null);
  }, [conditions]);

  return { conditionsData, isLoading, error, mutate };
}