import { useState, useEffect } from 'react';
import { fhirBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { openmrsFetch } from '@openmrs/esm-framework';

export function useConditionsData(patientUuid) {
  const [conditionsData, setConditionsData] = useState<ConditionsData[]>([]);

  const fetchConditions = async (url) => {
    const response = await openmrsFetch(url);
    return response.data;
  };

  const { data: conditions, error, isLoading } = useSWR(
    `${fhirBaseUrl}/Condition?patient=${patientUuid}&_count=100`,
    fetchConditions
  );

  useEffect(() => {
  if (conditions?.entry) {
    const newConditionsData: ConditionsData[] = [];

    conditions.entry.forEach((entry: { resource: ConditionObservation }) => {
      const conditionObs = entry?.resource;
      const condition = conditionObs?.code?.coding?.[0]?.display;
      const onsetDateTime = conditionObs?.onsetDateTime;
      const onsetDate = onsetDateTime && (new Date(onsetDateTime).toLocaleDateString('en-GB'));
      const clinicalStatus = conditionObs?.clinicalStatus?.coding?.[0]?.code;

      if (condition) {
        newConditionsData.push({
          condition,
          onsetDate,
          clinicalStatus,
        });
      }
      setConditionsData(newConditionsData);
    });
  }
  }, [conditions]);

  return {
    conditionsData,
    isLoading,
    error
  };
}