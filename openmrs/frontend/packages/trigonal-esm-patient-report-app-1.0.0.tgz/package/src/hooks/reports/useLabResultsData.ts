import { useMemo } from 'react';
import useSWR from 'swr';
import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher } from '../../utils';

// ── Concept representation (panel structure + normal ranges) ─────────────────
const LAB_CONCEPT_REP =
  'custom:(uuid,display,datatype:(display),set,hiNormal,hiAbsolute,hiCritical,lowNormal,lowAbsolute,lowCritical,units,allowDecimal,' +
  'setMembers:(uuid,display,datatype:(display),set,hiNormal,hiAbsolute,hiCritical,lowNormal,lowAbsolute,lowCritical,units,allowDecimal,setMembers:(uuid)))';

// ── Encounter / obs representation ───────────────────────────────────────────
const LAB_ENCOUNTER_REP =
  'custom:(uuid,encounterDatetime,obs:(uuid,voided,concept:(uuid),order:(uuid),' +
  'value:(uuid,display),groupMembers:(uuid,concept:(uuid),value:(uuid,display),groupMembers:(uuid,concept:(uuid),value:(uuid,display)))))';

export interface LabConceptMember {
  uuid: string;
  display: string;
  hiNormal?: number | null;
  hiCritical?: number | null;
  lowNormal?: number | null;
  lowCritical?: number | null;
  units?: string;
  set?: boolean;
  setMembers?: LabConceptMember[];
}

export interface LabConcept {
  uuid: string;
  display: string;
  set: boolean;
  hiNormal?: number | null;
  lowNormal?: number | null;
  units?: string;
  setMembers?: LabConceptMember[];
}

export interface LabResultRow {
  conceptUuid: string;
  display: string;
  value: string;
  units: string;
  normalRange: string;
  isAbnormal: boolean;
  isPanel: boolean; // true = sub-row inside a panel
}

export interface LabOrderResult {
  orderUuid: string;
  orderDisplay: string;
  dateActivated: string;
  orderer: string;
  rows: LabResultRow[];
}

// ── Fetch concept (same strategy as reference: fetchAllSetMembers) ────────────
async function fetchLabConcept(conceptUuid: string): Promise<LabConcept> {
  const res = await openmrsFetch<LabConcept>(`${restBaseUrl}/concept/${conceptUuid}?v=${LAB_CONCEPT_REP}`);
  return res.data;
}

function useLabConcept(conceptUuid: string | null | undefined) {
  return useSWR<LabConcept, Error>(
    conceptUuid ?? null,
    fetchLabConcept,
  );
}

function useLabEncounter(encounterUuid: string | null | undefined) {
  return useSWR<any, Error>(
    encounterUuid ? `${restBaseUrl}/encounter/${encounterUuid}?v=${LAB_ENCOUNTER_REP}` : null,
    openmrsFetcher,
  );
}

// ── Value formatter ───────────────────────────────────────────────────────────
function formatObsValue(value: any): string {
  if (value === null || value === undefined) return '--';
  if (typeof value === 'number') return String(value);
  if (typeof value === 'string') return value;
  if (typeof value === 'object') {
    if ('display' in value && value.display) return value.display;
    if ('name' in value && typeof value.name === 'string') return value.name;
  }
  return '--';
}

function normalRange(member: LabConceptMember | LabConcept): string {
  const lo = member.lowNormal;
  const hi = member.hiNormal;
  const units = member.units ?? '';
  if (lo != null && hi != null) return `${lo} – ${hi}${units ? ' ' + units : ''}`;
  if (lo != null) return `≥ ${lo}${units ? ' ' + units : ''}`;
  if (hi != null) return `≤ ${hi}${units ? ' ' + units : ''}`;
  return 'N/A';
}

function isAbnormal(value: string, member: LabConceptMember | LabConcept): boolean {
  const num = parseFloat(value);
  if (isNaN(num)) return false;
  const lo = (member as any).lowCritical ?? (member as any).lowNormal;
  const hi = (member as any).hiCritical ?? (member as any).hiNormal;
  if (lo != null && num < lo) return true;
  if (hi != null && num > hi) return true;
  return false;
}

// ── Public hook — one per test order ─────────────────────────────────────────
export function useLabOrderResult(order: {
  uuid?: string;
  display?: string;
  dateActivated?: string | number;
  orderer?: { display: string };
  conceptUuid?: string | null;
  encounterUuid?: string | null;
}): { result: LabOrderResult | null; isLoading: boolean } {
  const { data: concept, isLoading: isLoadingConcept } = useLabConcept(order.conceptUuid);
  const { data: encounterRaw, isLoading: isLoadingEncounter } = useLabEncounter(order.encounterUuid);

  const result = useMemo<LabOrderResult | null>(() => {
    if (!concept) return null;

    // Find the top-level obs for this order in the encounter
    const allObs: any[] = encounterRaw?.obs ?? [];
    const topObs = allObs.find(
      (o: any) => !o.voided && o.concept?.uuid === concept.uuid,
    );

    const rows: LabResultRow[] = [];

    if (concept.set && concept.setMembers?.length) {
      // Panel — iterate members, match groupMembers by concept UUID
      concept.setMembers.forEach((member) => {
        const memberObs = topObs?.groupMembers?.find(
          (gm: any) => gm.concept?.uuid === member.uuid,
        );
        const val = memberObs ? formatObsValue(memberObs.value) : '--';
        rows.push({
          conceptUuid: member.uuid,
          display: member.display,
          value: val,
          units: member.units ?? '',
          normalRange: normalRange(member),
          isAbnormal: isAbnormal(val, member),
          isPanel: true,
        });
      });
    } else {
      // Single test
      const val = topObs ? formatObsValue(topObs.value) : '--';
      rows.push({
        conceptUuid: concept.uuid,
        display: concept.display,
        value: val,
        units: concept.units ?? '',
        normalRange: normalRange(concept),
        isAbnormal: isAbnormal(val, concept),
        isPanel: false,
      });
    }

    return {
      orderUuid: order.uuid ?? '',
      orderDisplay: order.display ?? concept.display,
      dateActivated: order.dateActivated ? String(order.dateActivated) : '',
      orderer: order.orderer?.display ?? '',
      rows,
    };
  }, [concept, encounterRaw, order]);

  return { result, isLoading: isLoadingConcept || isLoadingEncounter };
}
