import { useMemo } from 'react';
import { usePatient, restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useDischargeSummaryData } from './useDischargeSummaryData';
import { useLatestVisit } from '../visit/useLatestVisit';
import { useEncounters } from '../data/useEncounters';
import { useOrdersData } from '../data/useOrdersData';
import { useConditionsData } from '../data/useConditionsData';
import { calculateAge, combineHookStates, extractFhirAddress, openmrsFetcher } from '../../utils';
import { useFormConfig, useObsConceptsConfig } from '../../config-helpers';
import { CUSTOM_REPS } from '../../constants';
import type { BedsApiResponse, ConditionsData, EncounterFull } from '../../types';

// ─── Public Types ─────────────────────────────────────────────────────────────

export interface InsuranceDischargeSummaryData {
  patientName?: string;
  patientGender?: string;
  patientAge?: string;
  patientId?: string;
  hospitalNumber?: string;
  address?: string;
  dateOfBirth?: string;
  ssfId?: string;
  nhisNumber?: string;
  bedNo?: string;
  ward?: string;
  bloodGroup?: string;
  dateOfAdmission?: string;
  dischargeDate?: string;
  totalStay?: string;
  providerName?: string;
  /** Bed number extracted from the Admission Summary Record Note form obs */
  admissionBedNo?: string;
  /** Consultant name extracted from the Admission Summary Record Note form obs */
  admissionConsultant?: string;
  encounters?: EncounterFull[];
  orders?: ReturnType<typeof useOrdersData>['orders'];
  conditionsData?: ConditionsData[];
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

/** Calculates the number of days between two ISO date strings. */
function calculateTotalStayDays(admissionDate?: string, dischargeDate?: string): string {
  if (!admissionDate || !dischargeDate) return '';
  const start = new Date(admissionDate);
  const end = new Date(dischargeDate);
  if (isNaN(start.getTime()) || isNaN(end.getTime())) return '';
  const diffDays = Math.ceil(Math.abs(end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return `${diffDays} days`;
}

/** Resolves the active bed display string from the beds API response. */
function resolveBedDisplay(bedsData?: BedsApiResponse, fallback = ''): string {
  const activeBed = bedsData?.results?.[0];
  if (!activeBed) return fallback;
  const bedNum = activeBed.bedNumber ?? '';
  const bedTypeName = activeBed.bedType?.displayName ?? activeBed.bedType?.name ?? '';
  if (bedNum && bedTypeName) return `${bedNum} - ${bedTypeName}`;
  return bedNum || fallback;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Aggregates all data required to render the Insurance Discharge Summary
 * document for a patient.
 *
 * Data sources:
 *  - FHIR Patient (demographics, address)
 *  - useDischargeSummaryData (form obs: dates, diagnoses, clinical narrative)
 *  - useLatestVisit (visit window for scoping encounters/orders)
 *  - useEncounters (full encounter list with obs, scoped to latest visit)
 *  - useOrdersData (orders scoped to latest visit)
 *  - /beds endpoint (current bed assignment)
 *  - /nidan/encounter with Admission Summary form (bed no + consultant from obs)
 *
 * Form and obs concept UUIDs are read from config so deployments can override
 * them without a code rebuild.
 *
 * @param patientUuid - The patient's UUID
 * @param visitUuid   - Optional override; falls back to latest visit UUID
 */
export function useInsuranceDischargeSummaryData(patientUuid: string, visitUuid?: string) {
  const forms = useFormConfig();
  const obsConcepts = useObsConceptsConfig();

  const { patient, isLoading: isPatientLoading, error: patientError } = usePatient(patientUuid);
  const { visit: latestVisit, isLoading: isVisitLoading, error: visitError } = useLatestVisit(patientUuid);
  const { dischargeSummaryData, isLoading: isDischargeLoading, error: dischargeError } = useDischargeSummaryData(patientUuid);

  const actualVisitUuid = visitUuid ?? latestVisit?.uuid;

  const {
    encounters,
    isLoading: isEncountersLoading,
    error: encountersError,
  } = useEncounters(patientUuid, {
    visitUuid: actualVisitUuid,
    fromDate: latestVisit?.startDatetime,
    toDate: latestVisit?.stopDatetime ?? undefined,
  });

  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
    patientUuid,
    latestVisit?.startDatetime ?? undefined,
    latestVisit?.stopDatetime ?? undefined,
  );

  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);

  const { data: bedsData, error: bedsError, isLoading: isBedsLoading } = useSWR<BedsApiResponse, Error>(
    patientUuid ? `${restBaseUrl}/beds?patientUuid=${patientUuid}` : null,
    openmrsFetcher,
  );

  // Admission Summary form — provides bed no + consultant obs
  const { data: admissionSummaryData, isLoading: isAdmissionSummaryLoading } = useSWR<
    { results: Array<{ obs: Array<{ concept: { uuid: string }; value: string | { display?: string } }> }> },
    Error
  >(
    patientUuid && actualVisitUuid
      ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${forms.admissionSummaryFormUuid}&visit=${actualVisitUuid}&v=${CUSTOM_REPS.ADMISSION_SUMMARY_OBS}&order=desc&limit=10`
      : null,
    openmrsFetcher,
  );

  const data: InsuranceDischargeSummaryData | null = useMemo(() => {
    if (isPatientLoading || !patient) return null;

    const patientName =
      patient.name?.[0]?.text ??
      patient.name?.[0]?.given?.join(' ') ??
      dischargeSummaryData?.patientName ??
      'Unknown';
    const dateOfBirth = patient.birthDate ?? 'Unknown';
    const patientAge = calculateAge(patient.birthDate) ?? dischargeSummaryData?.patientAge ?? 'Unknown';
    const patientGender = patient.gender ?? dischargeSummaryData?.patientGender ?? 'Unknown';
    const address = extractFhirAddress(patient.address as any);

    const hospitalNumber =
      dischargeSummaryData?.hospitalNumber ??
      patient.identifier?.find((id: any) => id.type?.text?.toLowerCase().includes('hospital number'))?.value ??
      patient.identifier?.[0]?.value ??
      '';

    const totalStay = calculateTotalStayDays(
      dischargeSummaryData?.dateOfAdmission,
      dischargeSummaryData?.dischargeDate,
    );

    const bedNo = resolveBedDisplay(bedsData, dischargeSummaryData?.bedNo);

    // Extract Assigned Bed and Consultant from Admission Summary obs
    let admissionBedNo = '';
    let admissionConsultant = '';
    const admissionObs = admissionSummaryData?.results?.[0]?.obs ?? [];
    for (const obs of admissionObs) {
      const val = typeof obs.value === 'string' ? obs.value : (obs.value as any)?.display ?? '';
      if (obs.concept?.uuid === obsConcepts.assignedBedUuid && val) admissionBedNo = val;
      else if (obs.concept?.uuid === obsConcepts.providersUuid && val) admissionConsultant = val;
    }

    return {
      patientName,
      patientGender,
      patientAge,
      patientId: hospitalNumber,
      hospitalNumber,
      address,
      dateOfBirth,
      ssfId: dischargeSummaryData?.ssfId ?? '',
      nhisNumber: dischargeSummaryData?.nhisNumber ?? '',
      bedNo,
      ward: dischargeSummaryData?.ward ?? '',
      dateOfAdmission: dischargeSummaryData?.dateOfAdmission ?? '',
      dischargeDate: dischargeSummaryData?.dischargeDate ?? '',
      totalStay,
      providerName: dischargeSummaryData?.providerName ?? '',
      admissionBedNo,
      admissionConsultant,
      encounters: encounters as EncounterFull[],
      orders,
      conditionsData,
    };
  }, [
    patient,
    isPatientLoading,
    dischargeSummaryData,
    encounters,
    orders,
    bedsData,
    admissionSummaryData,
    obsConcepts,
    conditionsData,
  ]);

  const { isLoading, error } = combineHookStates([
    { isLoading: isPatientLoading, error: patientError },
    { isLoading: isDischargeLoading, error: dischargeError },
    { isLoading: isVisitLoading, error: visitError },
    { isLoading: isEncountersLoading, error: encountersError },
    { isLoading: isOrdersLoading, error: ordersError },
    { isLoading: isBedsLoading, error: bedsError },
    { isLoading: isAdmissionSummaryLoading },
    { isLoading: isConditionsLoading, error: conditionsError },
  ]);

  return { data, isLoading, error };
}
