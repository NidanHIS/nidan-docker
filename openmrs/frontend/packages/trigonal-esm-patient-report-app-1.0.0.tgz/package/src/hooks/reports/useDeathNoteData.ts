import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { extractObsValue, openmrsFetcher } from '../../utils';

export interface DeathNoteData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    placeOfDeath?: string;
    wardOrUnit?: string;
    dateAndTimeOfDeath?: string;
    broughtDead?: string;
    mannerOfDeath?: string;
    deathType?: string;
    immediateCause?: string;
    antecedentCause?: string;
    underlyingCause?: string;
    otherSignificantConditions?: string;
    medicoLegalCase?: string;
    maternalDeathStatus?: string;
    familyInformed?: string;
    briefHospitalCourse?: string;
    postMortemDone?: string;
    postOperativeDeath?: string;
    mdgpNotifiedAt?: string;
    providerName?: string;
    providerQualification?: string;
    providerRegistrationNumber?: string;
    dateSigned?: string;
    encounterDatetime?: string;
}

export function useDeathNoteData(patientUuid: string) {
    const formUuid = 'c5fe5243-2fd5-33d9-9ab7-badf079ac7bd';
    const customRepresentation =
        'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),encounterProviders:(provider:(person:(display))))';

    const { data, error, isLoading, mutate } = useSWR<{ results: any[] }, Error>(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${customRepresentation}&order=desc&limit=1`
            : null,
        openmrsFetcher,
    );

    const deathNoteData: DeathNoteData | null = useMemo(() => {
        if (!data?.results || data.results.length === 0) return null;

        // The API already filters by form, so we take the most recent one
        const deathEncounter = data.results[0];

        return {
            patientName: deathEncounter.patient?.person?.preferredName?.display || deathEncounter.patient?.display,
            patientGender: deathEncounter.patient?.person?.gender,
            patientAge: deathEncounter.patient?.person?.age?.toString(),
            patientId: deathEncounter.patient?.identifiers?.[0]?.display?.split('=')?.[1]?.trim() || deathEncounter.patient?.identifiers?.[0]?.display,
            placeOfDeath: 'Hospital',
            wardOrUnit: deathEncounter.visit?.location?.display,
            dateAndTimeOfDeath: extractObsValue(deathEncounter.obs, 'ebe93dec-73a0-4703-abec-e05164896fe3', 'Pronounced death date and time') || deathEncounter.encounterDatetime,
            broughtDead: extractObsValue(deathEncounter.obs, '53b7d2a5-5df6-4dff-a3b3-9daee6c78ba7', 'Brought dead'),
            mannerOfDeath: extractObsValue(deathEncounter.obs, '', 'Manner of Death'),
            deathType: extractObsValue(deathEncounter.obs, '6a811193-2c82-4585-a938-d053419f3917', 'Death type'),
            immediateCause: extractObsValue(deathEncounter.obs, '0249a235-db19-46c7-abda-7bbd61563821', 'Primary cause of death'),
            antecedentCause: extractObsValue(deathEncounter.obs, '', 'Secondary cause of death'),
            underlyingCause: extractObsValue(deathEncounter.obs, '', 'Tertiary cause of death'),
            otherSignificantConditions: extractObsValue(deathEncounter.obs, 'e7db97e6-89e3-4d19-a21c-6585ea56066f', 'Other co morbidities'),
            medicoLegalCase: extractObsValue(deathEncounter.obs, '', 'Medico legal / police case'),
            maternalDeathStatus: undefined,
            familyInformed: extractObsValue(deathEncounter.obs, 'd2cb9d59-6a37-4a35-9c6c-1d6e652311fa', 'Family aware of death'),
            briefHospitalCourse: extractObsValue(deathEncounter.obs, '1791b581-a9cc-4ecc-9917-00887672772d', 'Hospital course'),
            postMortemDone: extractObsValue(deathEncounter.obs, 'da3173b7-8f7c-4ffa-b9fa-085274c07655', 'Postmortem done'),
            postOperativeDeath: extractObsValue(deathEncounter.obs, '071cf0cc-d5ef-43fe-80e5-00438703cd41', 'Death occured post operative'),
            mdgpNotifiedAt: extractObsValue(deathEncounter.obs, '', 'MDGP notified at'),
            providerName: deathEncounter.encounterProviders?.[0]?.provider?.person?.display || deathEncounter.encounterProviders?.[0]?.provider?.display,
            providerQualification: undefined,
            providerRegistrationNumber: undefined,
            dateSigned: deathEncounter.encounterDatetime,
            encounterDatetime: deathEncounter.encounterDatetime,
        };
    }, [data]);


    return {
        deathNoteData,
        isLoading,
        error,
        mutate,
    };
}
