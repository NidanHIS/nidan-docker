import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import {
  extractObsValue,
  extractPatientIdentifiers,
  getEncounterProviderName,
  openmrsFetcher,
} from '../../utils';
import { useFormConfig, useObsConceptsConfig } from '../../config-helpers';
import { CUSTOM_REPS } from '../../constants';
import type { EncounterWithPatientObs } from '../../types';

// ─── Public Types ─────────────────────────────────────────────────────────────

export interface ReferralReportData {
  patientName?: string;
  patientGender?: string;
  patientAge?: string;
  patientId?: string;
  hospitalNumber?: string;
  encounterDatetime?: string;
  location?: string;
  remarks?: string;
  followUpInstructions?: string;
  treatmentSuggestion?: string;
  referInstitutionName?: string;
  providerName?: string;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Fetches the most recent Referral Report form encounter for a patient and
 * extracts the obs values required for the referral document.
 *
 * Uses the custom `/nidan/encounter` endpoint filtered by the referral form
 * UUID (configurable via `config.forms.referralReportFormUuid`).
 *
 * @param patientUuid - The patient's UUID
 */
export function useReferralReportData(patientUuid: string) {
  const forms = useFormConfig();
  const obsConcepts = useObsConceptsConfig();

  const { data, error, isLoading, mutate } = useSWR<{ results: EncounterWithPatientObs[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${forms.referralReportFormUuid}&v=${CUSTOM_REPS.ENCOUNTER_WITH_PATIENT_OBS}&order=desc&limit=1`
      : null,
    openmrsFetcher,
  );

  const referralReportData: ReferralReportData | null = useMemo(() => {
    if (!data?.results?.length) return null;

    const encounter = data.results[0];
    const { openMrsId, hospitalNumber } = extractPatientIdentifiers(encounter.patient?.identifiers);

    return {
      patientName: encounter.patient?.person?.preferredName?.display ?? encounter.patient?.display,
      patientGender: encounter.patient?.person?.gender,
      patientAge: encounter.patient?.person?.age?.toString(),
      patientId: openMrsId ?? encounter.patient?.identifiers?.[0]?.display,
      hospitalNumber,
      encounterDatetime: encounter.encounterDatetime,
      location: encounter.visit?.location?.display,
      remarks: extractObsValue(encounter.obs, obsConcepts.reasonForReferralUuid),
      followUpInstructions: extractObsValue(encounter.obs, obsConcepts.followUpInstructionsUuid),
      treatmentSuggestion: extractObsValue(encounter.obs, obsConcepts.treatmentGivenUuid),
      referInstitutionName: extractObsValue(encounter.obs, obsConcepts.referInstitutionUuid),
      providerName: getEncounterProviderName(encounter.encounterProviders),
    };
  }, [data, obsConcepts]);

  return { referralReportData, isLoading, error, mutate };
}
