import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, useConfig } from '@openmrs/esm-framework';
import type { DiagnosisData, ClinicalNote, PatientEncounter } from '../../types';
import { ConfigObject } from '../../config-schema';
import { openmrsFetcher } from '../../utils';

interface EncounterApiResponse {
  results: PatientEncounter[];
}

export function useEncounterData(patientUuid: string) {
  const { concepts } = useConfig<ConfigObject>();

  const customRepresentation =
    'custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,rank,certainty,voided,diagnosis),obs:(uuid,concept:(uuid,display),value,obsDatetime),encounterType:(uuid,display)),startDatetime,stopDatetime)';

  const url = patientUuid
    ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=full&order=desc&limit=10`
    : null;

  const { data: encounter, error, isLoading: isEncounterLoading, mutate } = useSWR<EncounterApiResponse, Error>(
    url,
    openmrsFetcher,
  );

  const { diagnosisData, clinicalNotes } = useMemo(() => {
    const tempDiagnosisData: DiagnosisData[] = [];
    const tempClinicalNotes: ClinicalNote[] = [];

    const encounters = encounter?.results?.[0]?.encounters ?? [];
    encounters.forEach((enc) => {
      enc.diagnoses?.forEach((diagnosis) => {
        if (diagnosis.display) {
          tempDiagnosisData.push({ diagnosisName: diagnosis.display, rank: (diagnosis as any).rank, certainty: (diagnosis as any).certainty });
        }
      });
      enc.obs?.forEach((observation) => {
        if (observation && concepts.notesConceptUuid.includes(observation.concept?.uuid) && observation.value) {
          tempClinicalNotes.push({ note: observation.value });
        }
      });
    });

    return { diagnosisData: tempDiagnosisData, clinicalNotes: tempClinicalNotes };
  }, [encounter, concepts.notesConceptUuid]);

  return { diagnosisData, clinicalNotes, isEncounterLoading, error, mutate };
}
