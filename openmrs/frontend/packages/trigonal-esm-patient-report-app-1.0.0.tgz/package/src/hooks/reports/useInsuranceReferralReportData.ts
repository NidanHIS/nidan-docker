import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import {
  calculateAge,
  combineHookStates,
  extractFhirAddress,
  extractObsValue,
  extractPatientIdentifiers,
  getEncounterProviderName,
  openmrsFetcher,
} from '../../utils';
import { useFormConfig, useObsConceptsConfig, useVitalsConceptsConfig, useVitalsConceptsQuery } from '../../config-helpers';
import { useLatestVisit } from '../visit/useLatestVisit';
import { useChiefComplaint } from '../data/useChiefComplaint';
import { useEncountersWithDiagnoses } from '../data/useEncounters';
import { useConditionsData } from '../data/useConditionsData';
import { CUSTOM_REPS } from '../../constants';
import type { ConditionsData, EncounterWithPatientObs, VitalsObsResponse } from '../../types';

// ─── Public Types ─────────────────────────────────────────────────────────────

export interface InsuranceReferralReportData {
  patientName?: string;
  patientGender?: string;
  patientAge?: string;
  patientId?: string;
  hospitalNumber?: string;
  nhisNumber?: string;
  ssfid?: string;
  insuranceNumber?: string;
  address?: string;
  department?: string;
  encounterDatetime?: string;
  location?: string;
  chiefComplaints?: string;
  provisionalDiagnosis?: string;
  treatmentGiven?: string;
  reasonForReferral?: string;
  followUpAdvice?: string;
  referInstitutionName?: string;
  providerName?: string;
  /** Council/NMC registration number — not currently stored in OpenMRS */
  providerCouncilNo?: string;
  systolicBP?: string;
  diastolicBP?: string;
  temperature?: string;
  heartRate?: string;
  spO2?: string;
  respirationRate?: string;
  height?: string;
  weight?: string;
  conditionsData?: ConditionsData[];
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Aggregates all data required to render the Insurance Referral Report
 * (प्रेषण पूर्जी) for a patient.
 *
 * Data sources:
 *  - /nidan/encounter (referral form encounter — obs, patient, visit window)
 *  - useLatestVisit + useEncountersWithDiagnoses (diagnosis aggregation)
 *  - /ws/fhir2/R4/Patient (address)
 *  - useChiefComplaint (FHIR Observation, visit-scoped)
 *  - /obs (recent vitals for the visit window)
 *
 * All form and concept UUIDs are read from config so deployments can override
 * them without a code rebuild.
 *
 * @param patientUuid - The patient's UUID
 */
export function useInsuranceReferralReportData(patientUuid: string) {
  const forms = useFormConfig();
  const obsConcepts = useObsConceptsConfig();
  const vitalsConcepts = useVitalsConceptsConfig();
  const vitalsConceptsQuery = useVitalsConceptsQuery();

  // ── 1. Referral form encounter (patient data + obs) ─────────────────────────
  const {
    data: encounterData,
    error: encounterError,
    isLoading: isEncounterLoading,
  } = useSWR<{ results: EncounterWithPatientObs[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${forms.referralReportFormUuid}&v=${CUSTOM_REPS.ENCOUNTER_REFERRAL}&order=desc&limit=1`
      : null,
    openmrsFetcher,
  );

  // Derived visit window from the referral encounter
  const visitStart = encounterData?.results?.[0]?.visit?.startDatetime;
  const visitStop = encounterData?.results?.[0]?.visit?.stopDatetime ?? undefined;

  // ── 2. Latest visit (for diagnosis query scoping) ───────────────────────────
  const { visit: latestVisit, isLoading: isVisitLoading, error: visitError } = useLatestVisit(patientUuid);

  // ── 3. Encounter list with diagnoses (standard endpoint, visit-scoped) ──────
  const {
    encounters: visitEncounters,
    isLoading: isVisitEncountersLoading,
    error: visitEncountersError,
  } = useEncountersWithDiagnoses(patientUuid, {
    visitUuid: latestVisit?.uuid,
    fromDate: visitStart,
    toDate: visitStop,
  });

  // ── 4. Vitals obs scoped to the visit window ────────────────────────────────
  const vitalsUrl = useMemo(() => {
    if (!patientUuid || !encounterData?.results?.[0]?.encounterDatetime) return null;
    const params = new URLSearchParams({
      patient: patientUuid,
      concept: vitalsConceptsQuery,
      v: CUSTOM_REPS.VITALS_OBS,
      order: 'desc',
      limit: '20',
    });
    if (visitStart) params.set('fromDate', visitStart);
    if (visitStop) params.set('toDate', visitStop);
    return `${restBaseUrl}/obs?${params.toString()}`;
  }, [patientUuid, encounterData, visitStart, visitStop, vitalsConceptsQuery]);

  const {
    data: vitalsData,
    error: vitalsError,
    isLoading: isVitalsLoading,
  } = useSWR<VitalsObsResponse, Error>(vitalsUrl, openmrsFetcher);

  // ── 5. FHIR Patient (address) ───────────────────────────────────────────────
  const {
    data: fhirPatient,
    error: fhirError,
    isLoading: isFhirLoading,
  } = useSWR<any, Error>(
    patientUuid ? `/ws/fhir2/R4/Patient/${patientUuid}` : null,
    openmrsFetcher,
  );

  // ── 6. Chief complaint (shared hook, visit-scoped) ─────────────────────────
  const {
    chiefComplaint,
    isLoading: isChiefComplaintLoading,
    error: chiefComplaintError,
  } = useChiefComplaint(patientUuid, visitStart, visitStop);

  // ── 7. Conditions (patient-level problem list) ──────────────────────────────
  const {
    conditionsData,
    isLoading: isConditionsLoading,
    error: conditionsError,
  } = useConditionsData(patientUuid);

  // ── Derived data ────────────────────────────────────────────────────────────

  const insuranceReferralReportData: InsuranceReferralReportData | null = useMemo(() => {
    if (isEncounterLoading || !encounterData?.results?.length) return null;

    const encounter = encounterData.results[0];

    const { openMrsId, hospitalNumber, nhisNumber, ssfId, insuranceNumber } =
      extractPatientIdentifiers(encounter.patient?.identifiers);

    const address = extractFhirAddress(fhirPatient?.address, '');

    const department =
      encounter.visit?.location?.display ??
      (encounter as any).location?.display ??
      '';

    const reasonForReferral = extractObsValue(encounter.obs, obsConcepts.reasonForReferralUuid);
    const followUpAdvice = extractObsValue(encounter.obs, obsConcepts.followUpInstructionsUuid);
    const treatmentGiven = extractObsValue(encounter.obs, obsConcepts.treatmentGivenUuid);
    const referInstitutionName = extractObsValue(encounter.obs, obsConcepts.referInstitutionUuid);

    // Diagnoses — aggregate from all visit encounters; prefer PROVISIONAL
    const allDiagnoses = visitEncounters.flatMap((enc) =>
      (enc.diagnoses ?? []).filter((d) => !d.voided),
    );
    const provisionalOnly = allDiagnoses.filter((d) => d.certainty === 'PROVISIONAL');
    const diagnosesToShow = provisionalOnly.length > 0 ? provisionalOnly : allDiagnoses;

    const provisionalDiagnosis = diagnosesToShow
      .map((d) => {
        const name =
          d.diagnosis?.coded?.display ??
          d.diagnosis?.nonCoded ??
          d.display ??
          '';
        const rankLabel =
          d.rank === 1 || d.rank === '1' ? ' (Primary)'
          : d.rank === 2 || d.rank === '2' ? ' (Secondary)'
          : '';
        return name + rankLabel;
      })
      .filter(Boolean)
      .join('\n');

    const providerName = getEncounterProviderName(encounter.encounterProviders);

    // Vitals — most recent obs per concept UUID
    const latestVital = (conceptUuid: string): string | undefined => {
      const matches = (vitalsData?.results ?? [])
        .filter((obs) => obs.concept?.uuid === conceptUuid)
        .sort((a, b) => new Date(b.obsDatetime).getTime() - new Date(a.obsDatetime).getTime());
      if (!matches.length) return undefined;
      const val = matches[0].value;
      return val !== null && val !== undefined ? String(val) : undefined;
    };

    return {
      patientName: encounter.patient?.person?.preferredName?.display ?? encounter.patient?.display,
      patientGender: encounter.patient?.person?.gender,
      patientAge:
        encounter.patient?.person?.age?.toString() ??
        (encounter.patient?.person?.birthdate
          ? calculateAge(encounter.patient.person.birthdate)
          : undefined),
      patientId: openMrsId ?? encounter.patient?.identifiers?.[0]?.display,
      hospitalNumber,
      nhisNumber,
      ssfid: ssfId,
      insuranceNumber,
      address,
      department,
      encounterDatetime: encounter.encounterDatetime,
      location: encounter.visit?.location?.display ?? (encounter as any).location?.display,
      chiefComplaints: chiefComplaint ?? undefined,
      provisionalDiagnosis,
      treatmentGiven,
      reasonForReferral,
      followUpAdvice,
      referInstitutionName,
      providerName,
      providerCouncilNo: undefined,
      systolicBP: latestVital(vitalsConcepts.systolicBloodPressureUuid),
      diastolicBP: latestVital(vitalsConcepts.diastolicBloodPressureUuid),
      temperature: latestVital(vitalsConcepts.temperatureUuid),
      heartRate: latestVital(vitalsConcepts.pulseUuid),
      spO2: latestVital(vitalsConcepts.oxygenSaturationUuid),
      respirationRate: latestVital(vitalsConcepts.respiratoryRateUuid),
      height: latestVital(vitalsConcepts.heightUuid),
      weight: latestVital(vitalsConcepts.weightUuid),
      conditionsData,
    };
  }, [
    isEncounterLoading,
    encounterData,
    fhirPatient,
    vitalsData,
    visitEncounters,
    chiefComplaint,
    obsConcepts,
    vitalsConcepts,
    conditionsData,
  ]);

  const { isLoading, error } = combineHookStates([
    { isLoading: isEncounterLoading, error: encounterError },
    { isLoading: isFhirLoading, error: fhirError },
    { isLoading: isVitalsLoading, error: vitalsError },
    { isLoading: isVisitLoading, error: visitError },
    { isLoading: isVisitEncountersLoading, error: visitEncountersError },
    { isLoading: isChiefComplaintLoading, error: chiefComplaintError },
    { isLoading: isConditionsLoading, error: conditionsError },
  ]);

  return { insuranceReferralReportData, isLoading, error };
}
