import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher, extractObsValue, extractPatientIdentifiers, getEncounterProviderName } from '../../utils';
import { useFormConfig, useObsConceptsConfig } from '../../config-helpers';
import { CUSTOM_REPS } from '../../constants';
import type { EncounterWithPatientObs } from '../../types';

// ─── Public Types ─────────────────────────────────────────────────────────────

export interface DischargeSummaryData {
  patientName?: string;
  patientGender?: string;
  patientAge?: string;
  patientId?: string;
  hospitalNumber?: string;
  encounterDatetime?: string;
  dateOfAdmission?: string;
  dischargeDate?: string;
  diagnosis?: string;
  briefHospitalCourse?: string;
  majorSurgery?: string;
  postOpComplications?: string;
  inpatientOutcome?: string;
  medicationOnDischarge?: string;
  followUpInstructions?: string;
  followUpDate?: string;
  dischargedTo?: string;
  providerName?: string;
  ssfId?: string;
  nhisNumber?: string;
  bedNo?: string;
  ward?: string;
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

/**
 * Recursively searches an obs list (including nested groupMembers) for an obs
 * whose concept UUID matches the given value.
 * Returns the first match found, or undefined.
 */
function findObsByConceptUuid(
  obsArray: EncounterWithPatientObs['obs'],
  conceptUuid: string,
): EncounterWithPatientObs['obs'][number] | undefined {
  for (const obs of obsArray) {
    if (obs.concept?.uuid === conceptUuid) return obs;
    if (obs.groupMembers?.length) {
      const found = findObsByConceptUuid(obs.groupMembers, conceptUuid);
      if (found) return found;
    }
  }
  return undefined;
}

/**
 * Iterates encounters in order (latest first) and returns the first non-empty
 * value found for the given concept UUID.
 */
function extractLatestObsValue(
  encounters: EncounterWithPatientObs[],
  conceptUuid: string,
): string | undefined {
  for (const encounter of encounters) {
    const obs = findObsByConceptUuid(encounter.obs ?? [], conceptUuid);
    if (obs?.value != null && obs.value !== '') {
      return typeof obs.value === 'object' ? obs.value.display : String(obs.value);
    }
  }
  return undefined;
}

/**
 * Splits a "Ward - Bed" location display into its constituent parts.
 * e.g. "General Ward - Bed 3" → { ward: "General Ward", bedNo: "3" }
 */
function parseWardAndBed(locationDisplay: string): { ward: string; bedNo: string } {
  if (!locationDisplay.includes(' - ')) return { ward: locationDisplay, bedNo: '' };
  const [wardPart, bedPart] = locationDisplay.split(' - ');
  const bedNo = /bed/i.test(bedPart) ? bedPart.replace(/bed/i, '').trim() : bedPart.trim();
  return { ward: wardPart.trim(), bedNo };
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Fetches the most recent Discharge Summary form encounter for a patient and
 * extracts all clinical obs values required to render the discharge document.
 *
 * Uses the custom `/nidan/encounter` endpoint filtered by the discharge summary
 * form UUID (configurable via `config.forms.dischargeSummaryFormUuid`).
 *
 * @param patientUuid - The patient's UUID
 */
export function useDischargeSummaryData(patientUuid: string) {
  const forms = useFormConfig();
  const obsConcepts = useObsConceptsConfig();

  const { data, error, isLoading, mutate } = useSWR<{ results: EncounterWithPatientObs[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${forms.dischargeSummaryFormUuid}&v=${CUSTOM_REPS.ENCOUNTER_WITH_PATIENT_OBS}&order=desc&limit=100`
      : null,
    openmrsFetcher,
  );

  const dischargeSummaryData: DischargeSummaryData | null = useMemo(() => {
    if (!data?.results?.length) return null;

    const encounters = data.results;
    const latest = encounters[0];

    const { openMrsId, hospitalNumber, ssfId, nhisNumber } = extractPatientIdentifiers(
      latest.patient?.identifiers,
    );

    const { ward, bedNo } = parseWardAndBed(latest.visit?.location?.display ?? '');

    // Aggregate diagnoses: obs-level text + encounter-level diagnosis objects
    const obsDiagnosis = extractLatestObsValue(encounters, obsConcepts.diagnosisUuid);
    const encounterDiagnoses = encounters
      .flatMap((e) => e.diagnoses ?? [])
      .map((d) => d.display ?? d.diagnosis?.display)
      .filter(Boolean) as string[];

    const diagnosis =
      obsDiagnosis && encounterDiagnoses.length > 0
        ? `${obsDiagnosis}\n${encounterDiagnoses.join('\n')}`
        : obsDiagnosis ?? encounterDiagnoses.join('\n') ?? undefined;

    const providerName = encounters.reduce<string | undefined>((found, enc) => {
      return found ?? getEncounterProviderName(enc.encounterProviders) ?? undefined;
    }, undefined);

    return {
      patientName: latest.patient?.person?.preferredName?.display ?? latest.patient?.display,
      patientGender: latest.patient?.person?.gender,
      patientAge: latest.patient?.person?.age?.toString(),
      patientId: openMrsId ?? latest.patient?.identifiers?.[0]?.display,
      hospitalNumber,
      encounterDatetime: latest.encounterDatetime,
      dateOfAdmission:
        extractLatestObsValue(encounters, obsConcepts.dateOfAdmissionUuid) ??
        latest.visit?.startDatetime,
      dischargeDate: extractLatestObsValue(encounters, obsConcepts.dischargeDateUuid),
      diagnosis,
      briefHospitalCourse: extractLatestObsValue(encounters, obsConcepts.briefHospitalCourseUuid),
      majorSurgery: extractLatestObsValue(encounters, obsConcepts.majorSurgeryUuid),
      postOpComplications: extractLatestObsValue(encounters, obsConcepts.postOpComplicationsUuid),
      inpatientOutcome: extractLatestObsValue(encounters, obsConcepts.inpatientOutcomeUuid),
      medicationOnDischarge: extractLatestObsValue(encounters, obsConcepts.medicationOnDischargeUuid),
      followUpInstructions: extractLatestObsValue(encounters, obsConcepts.followUpInstructionsUuid),
      followUpDate: extractLatestObsValue(encounters, obsConcepts.followUpDateUuid),
      dischargedTo: extractLatestObsValue(encounters, obsConcepts.dischargedToUuid),
      providerName,
      ssfId,
      nhisNumber,
      bedNo,
      ward,
    };
  }, [data, obsConcepts]);

  return { dischargeSummaryData, isLoading, error, mutate };
}
