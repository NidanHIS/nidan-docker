import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { openmrsFetcher } from '../utils';

interface VisitResult {
  uuid: string;
  startDatetime: string;
  stopDatetime: string | null;
  visitType: { display: string };
  location: { display: string };
}

export function useVisitDetails(patientUuid: string) {
  const { t } = useTranslation();

  const { data, error, isLoading } = useSWR<{ results: VisitResult[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/visit?patient=${patientUuid}&includeInactive=true&v=custom:(uuid,startDatetime,stopDatetime,visitType:(display),location:(display))&limit=1`
      : null,
    openmrsFetcher,
  );

  const visit = data?.results?.[0] ?? null;

  const visitDetails = useMemo(() => {
    return {
      visitType: visit?.visitType?.display || t('unknownValue', 'Unknown'),
      location: visit?.location?.display || t('unknownValue', 'Unknown'),
      startDatetime: visit?.startDatetime || t('unknownValue', 'Unknown'),
    };
  }, [visit, t]);

  return {
    visitDetails,
    isLoading,
    error,
  };
}
