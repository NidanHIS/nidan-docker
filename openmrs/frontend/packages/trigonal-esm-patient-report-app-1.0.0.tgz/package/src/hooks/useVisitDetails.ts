import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useVisit } from '@openmrs/esm-framework';
export function useVisitDetails(patientUuid: string) {
  const { activeVisit, isLoading, error } = useVisit(patientUuid);
  const { t } = useTranslation();
  
  const formattedVisitDetails = useMemo(() => {
    return {
      visitType: activeVisit?.visitType?.display || t('unknownValue', 'Unknown'),
      location: activeVisit?.location?.display || t('unknownValue', 'Unknown'),
      startDatetime: activeVisit?.startDatetime 
        ? new Date(activeVisit.startDatetime).toLocaleDateString('en-GB') 
        : t('unknownValue', 'Unknown'),
    };
  }, [activeVisit, t]);

  return {
    visitDetails: formattedVisitDetails,
    isLoading,
    error
  };
}

