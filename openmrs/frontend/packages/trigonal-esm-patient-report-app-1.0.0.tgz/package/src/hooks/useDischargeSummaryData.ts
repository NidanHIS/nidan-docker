import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';

export interface DischargeSummaryData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    hospitalNumber?: string;
    encounterDatetime?: string;
    dateOfAdmission?: string;
    dischargeDate?: string;
    diagnosis?: string;
    briefHospitalCourse?: string;
    majorSurgery?: string;
    postOpComplications?: string;
    inpatientOutcome?: string;
    medicationOnDischarge?: string;
    followUpInstructions?: string;
    followUpDate?: string;
    dischargedTo?: string;
    providerName?: string;
}

export function useDischargeSummaryData(patientUuid: string) {
    const formUuid = 'a9d36a3b-71d5-3dfc-9ebb-61db4bbbab2d';
    const customRepresentation =
        'custom:(uuid,display,encounterDatetime,diagnoses:(display,diagnosis:(display)),form:(uuid,name,display),visit:(location:(display),startDatetime),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime,groupMembers:(uuid,concept:(uuid,display),value,display,obsDatetime,groupMembers:(uuid,concept:(uuid,display),value,display,obsDatetime))),encounterProviders:(provider:(person:(display))))';

    const fetchEncounters = async (url: string) => {
        const response = await openmrsFetch(url);
        return response.data;
    };

    const { data, error, isLoading } = useSWR(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${customRepresentation}&order=desc&limit=100`
            : null,
        fetchEncounters
    );

    const dischargeSummaryData: DischargeSummaryData | null = useMemo(() => {
        if (!data?.results || data.results.length === 0) return null;

        const encounters = data.results;
        const latestEncounter = encounters[0];

        const findObsByConcept = (obsArray: any[], conceptUuid: string): any | undefined => {
            for (const obs of obsArray) {
                if (obs.concept?.uuid === conceptUuid) {
                    return obs;
                }
                if (obs.groupMembers && obs.groupMembers.length > 0) {
                    const found = findObsByConcept(obs.groupMembers, conceptUuid);
                    if (found) return found;
                }
            }
            return undefined;
        };

        const extractLatestObsValue = (conceptUuid: string) => {
            for (const encounter of encounters) {
                const obs = findObsByConcept(encounter.obs || [], conceptUuid);
                if (obs && obs.value !== undefined && obs.value !== null && obs.value !== '') {
                    if (typeof obs.value === 'object' && obs.value?.display) {
                        return obs.value.display;
                    }
                    return obs.value;
                }
            }
            return undefined;
        };

        const patientId = latestEncounter.patient?.identifiers?.find((id: any) => id.display.includes('OpenMRS ID'))?.display?.split('=')?.[1]?.trim();
        const hospitalNumber = latestEncounter.patient?.identifiers?.find((id: any) => id.display.includes('Hospital Number'))?.display?.split('=')?.[1]?.trim();

        // Aggregate diagnoses from both observations and the encounter-level diagnoses array
        const getDiagnosis = () => {
            const obsDiag = extractLatestObsValue('600f6ff5-ca78-4928-9fce-e750aafe9641');
            const encounterDiags = encounters
                .flatMap((e: any) => e.diagnoses || [])
                .map((d: any) => d.display || d.diagnosis?.display)
                .filter(Boolean);
            
            if (obsDiag && encounterDiags.length > 0) {
                return `${obsDiag}\n${encounterDiags.join('\n')}`;
            }
            return obsDiag || encounterDiags.join('\n') || undefined;
        };

        const getProviderName = () => {
            for (const encounter of encounters) {
                const provider = encounter.encounterProviders?.[0]?.provider?.person?.display || encounter.encounterProviders?.[0]?.provider?.display;
                if (provider) return provider;
            }
            return undefined;
        };

        return {
            patientName: latestEncounter.patient?.person?.preferredName?.display || latestEncounter.patient?.display,
            patientGender: latestEncounter.patient?.person?.gender,
            patientAge: latestEncounter.patient?.person?.age?.toString(),
            patientId: patientId || latestEncounter.patient?.identifiers?.[0]?.display,
            hospitalNumber: hospitalNumber,
            encounterDatetime: latestEncounter.encounterDatetime,
            dateOfAdmission: extractLatestObsValue('fee07cde-19c9-46a6-a117-2ce8dae3aefb') || latestEncounter.visit?.startDatetime,
            dischargeDate: extractLatestObsValue('f50023bd-feb5-4945-ac00-4f6e8df0b359'),
            diagnosis: getDiagnosis(),
            briefHospitalCourse: extractLatestObsValue('9986de91-7fa2-4e4a-a0cc-9504c342ad87'),
            majorSurgery: extractLatestObsValue('dd53dd9e-f0d3-438e-b08a-c4af65923d91'),
            postOpComplications: extractLatestObsValue('a2fd14a5-6ce1-4fec-aa85-900ab3650ffa'),
            inpatientOutcome: extractLatestObsValue('ca1eee0c-eb4c-4c6c-85ff-e7f644d1af30'),
            medicationOnDischarge: extractLatestObsValue('c5b9574b-7ec3-4808-9a75-c78303fe7ed6'),
            followUpInstructions: extractLatestObsValue('75ca7f0d-a0f4-49b7-9d4c-077839a1f1cf'),
            followUpDate: extractLatestObsValue('f5cda421-be04-4b04-a4e8-85267d32ebe5'),
            dischargedTo: extractLatestObsValue('d70df6f0-46d9-4cd0-aa33-1dd91a4c5c87'),
            providerName: getProviderName(),
        };
    }, [data]);

    return {
        dischargeSummaryData,
        isLoading,
        error,
    };
}
