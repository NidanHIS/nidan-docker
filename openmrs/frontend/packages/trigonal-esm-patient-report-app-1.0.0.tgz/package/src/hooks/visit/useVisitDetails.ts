import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { openmrsFetcher } from '../../utils';
import type { VisitDetails } from '../../types';

interface VisitResult {
  uuid: string;
  startDatetime: string;
  stopDatetime: string | null;
  visitType: { display: string };
  location: { display: string };
}

/**
 * Fetches the most recent visit (including inactive) for a patient and returns
 * the visit type, location, and start datetime for display in report headers.
 *
 * This hook returns the formatted `VisitDetails` object directly — callers
 * do not need to handle raw REST response shapes.
 *
 * Note: For visit-window scoping (startDatetime / stopDatetime), use
 * `useLatestVisit` instead — it returns the raw visit object with timestamps.
 *
 * @param patientUuid - The patient's UUID
 */
export function useVisitDetails(patientUuid: string) {
  const { t } = useTranslation();

  const { data, error, isLoading } = useSWR<{ results: VisitResult[] }, Error>(
    patientUuid
      ? `${restBaseUrl}/visit?patient=${patientUuid}&includeInactive=true&v=custom:(uuid,startDatetime,stopDatetime,visitType:(display),location:(display))&limit=1`
      : null,
    openmrsFetcher,
  );

  const visit = data?.results?.[0] ?? null;

  const visitDetails = useMemo((): VisitDetails => ({
    visitType: visit?.visitType?.display ?? t('unknownValue', 'Unknown'),
    location: visit?.location?.display ?? t('unknownValue', 'Unknown'),
    startDatetime: visit?.startDatetime ?? t('unknownValue', 'Unknown'),
  }), [visit, t]);

  return { visitDetails, isLoading, error };
}
