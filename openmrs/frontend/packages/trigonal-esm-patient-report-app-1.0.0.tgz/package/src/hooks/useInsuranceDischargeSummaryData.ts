import { useMemo } from 'react';
import { usePatient, restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useDischargeSummaryData } from './useDischargeSummaryData';
import { useLatestVisit } from './useLatestVisit';
import { useOrdersData } from './useOrdersData';
import { calculateAge, openmrsFetcher } from '../utils';

export interface InsuranceDischargeSummaryData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    hospitalNumber?: string;
    address?: string;
    dateOfBirth?: string;
    ssfId?: string;
    nhisNumber?: string;
    bedNo?: string;
    ward?: string;
    bloodGroup?: string;
    dateOfAdmission?: string;
    dischargeDate?: string;
    totalStay?: string;
    providerName?: string;
    /** Bed number from the Admission Summary Record Note form */
    admissionBedNo?: string;
    /** Consultant/provider name from the Admission Summary Record Note form */
    admissionConsultant?: string;
    encounters?: any[];
    orders?: any[];
}

export function useInsuranceDischargeSummaryData(patientUuid: string, visitUuid?: string) {
    const { patient, isLoading: isPatientLoading, error: patientError } = usePatient(patientUuid);
    const { visit: latestVisit, isLoading: isVisitLoading, error: visitError } = useLatestVisit(patientUuid);
    const { dischargeSummaryData, isLoading: isEncounterLoading, error: encounterError } = useDischargeSummaryData(patientUuid);
    const { orders: patientOrders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(
        patientUuid,
        latestVisit?.startDatetime ?? undefined,
        latestVisit?.stopDatetime ?? undefined,
    );

    const actualVisitUuid = visitUuid || latestVisit?.uuid;

    const customRep = `custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient,obs:(uuid,order:(uuid),concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person)))`;

    const { data: encountersData, error: encountersError, isLoading: isEncountersLoading } = useSWR<{
        results: any[];
    }, Error>(
        patientUuid && actualVisitUuid
            ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRep}&fromDate=${latestVisit?.startDatetime}&toDate=${latestVisit?.stopDatetime}&order=desc&limit=20&startIndex=0&totalCount=true`
            : null,
        openmrsFetcher,
    );

    const { data: bedsData, error: bedsError, isLoading: isBedsLoading } = useSWR<{
        results: any[];
    }, Error>(
        patientUuid
            ? `${restBaseUrl}/beds?patientUuid=${patientUuid}`
            : null,
        openmrsFetcher,
    );

    // Admission Summary Record Note form (UUID: f9948b4c-1ae2-3246-a34f-a9f396b914b7)
    const admissionSummaryRep = `custom:(uuid,obs:(uuid,concept:(uuid,display),value,display))`;
    const { data: admissionSummaryData, isLoading: isAdmissionSummaryLoading } = useSWR<{
        results: any[];
    }, Error>(
        patientUuid && actualVisitUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=f9948b4c-1ae2-3246-a34f-a9f396b914b7&visit=${actualVisitUuid}&v=${admissionSummaryRep}&order=desc&limit=10`
            : null,
        openmrsFetcher,
    );

    // Concept UUIDs for Admission Summary obs
    const ASSIGNED_BED_CONCEPT_UUID = '71525388-448c-4503-979a-921cd6fdc989';
    const PROVIDERS_CONCEPT_UUID = 'f4f0eec4-5a84-419c-9192-df30ffc72a4c';

    const data: InsuranceDischargeSummaryData | null = useMemo(() => {
        if (isPatientLoading || !patient) return null;

        const patientName = patient?.name?.[0]?.text || patient?.name?.[0]?.given?.join(' ') || dischargeSummaryData?.patientName || 'Unknown';
        const dateOfBirth = patient?.birthDate || 'Unknown';
        const patientAge = calculateAge(patient?.birthDate) || dischargeSummaryData?.patientAge || 'Unknown';
        const patientGender = patient?.gender || dischargeSummaryData?.patientGender || 'Unknown';

        // Extract address from FHIR patient
        let patientAddress = 'Unknown';
        if (patient?.address?.[0]) {
            const addr = patient.address[0];
            const extVal = addr.extension?.[0]?.extension?.[0]?.valueString;
            if (extVal) {
                patientAddress = extVal;
            } else {
                const lines = addr.line ? addr.line.join(', ') : '';
                const city = addr.city || '';
                const state = addr.state || '';
                const country = addr.country || '';
                patientAddress = [lines, city, state, country].filter(Boolean).join(', ') || addr.text || 'Unknown';
            }
        }

        const hospitalNumber = dischargeSummaryData?.hospitalNumber ||
            patient?.identifier?.find((id: any) => id.type?.text?.toLowerCase().includes('hospital number'))?.value ||
            patient?.identifier?.[0]?.value || '';

        // Calculate total stay duration
        let totalStay = '';
        if (dischargeSummaryData?.dateOfAdmission && dischargeSummaryData?.dischargeDate) {
            const start = new Date(dischargeSummaryData.dateOfAdmission);
            const end = new Date(dischargeSummaryData.dischargeDate);
            if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
                const diffTime = Math.abs(end.getTime() - start.getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                totalStay = `${diffDays} days`;
            }
        }

        let bedNo = dischargeSummaryData?.bedNo || '';
        if (bedsData?.results && bedsData.results.length > 0) {
            const activeBed = bedsData.results[0];
            const bedNum = activeBed.bedNumber || '';
            const bedTypeName = activeBed.bedType?.displayName || activeBed.bedType?.name || '';
            if (bedNum && bedTypeName) {
                bedNo = `${bedNum} - ${bedTypeName}`;
            } else if (bedNum) {
                bedNo = bedNum;
            }
        }

        // Extract Assigned Bed and Providers from Admission Summary form obs
        let admissionBedNo = '';
        let admissionConsultant = '';
        const admissionObs: any[] = admissionSummaryData?.results?.[0]?.obs ?? [];
        for (const obs of admissionObs) {
            const conceptUuid = obs.concept?.uuid;
            if (conceptUuid === ASSIGNED_BED_CONCEPT_UUID && obs.value) {
                admissionBedNo = typeof obs.value === 'string' ? obs.value : obs.value?.display ?? '';
            } else if (conceptUuid === PROVIDERS_CONCEPT_UUID && obs.value) {
                admissionConsultant = typeof obs.value === 'string' ? obs.value : obs.value?.display ?? '';
            }
        }

        return {
            patientName,
            patientGender,
            patientAge,
            patientId: hospitalNumber,
            hospitalNumber,
            address: patientAddress,
            dateOfBirth,
            ssfId: dischargeSummaryData?.ssfId || '',
            nhisNumber: dischargeSummaryData?.nhisNumber || '',
            bedNo,
            ward: dischargeSummaryData?.ward || '',
            dateOfAdmission: dischargeSummaryData?.dateOfAdmission || '',
            dischargeDate: dischargeSummaryData?.dischargeDate || '',
            totalStay,
            providerName: dischargeSummaryData?.providerName || '',
            admissionBedNo,
            admissionConsultant,
            encounters: encountersData?.results || [],
            orders: patientOrders || [],
        };
    }, [patient, dischargeSummaryData, isPatientLoading, encountersData, patientOrders, bedsData, admissionSummaryData]);

    return {
        data,
        isLoading: isPatientLoading || isEncounterLoading || isVisitLoading || isEncountersLoading || isOrdersLoading || isBedsLoading || isAdmissionSummaryLoading,
        error: patientError || encounterError || visitError || encountersError || ordersError || bedsError,
    };
}

