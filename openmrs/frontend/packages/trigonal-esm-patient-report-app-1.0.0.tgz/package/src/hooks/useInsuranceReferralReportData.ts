import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, fhirBaseUrl } from '@openmrs/esm-framework';
import { calculateAge, extractObsValue, openmrsFetcher, toFhirDateTime } from '../utils';
import { useLatestVisit } from './useLatestVisit';

export interface InsuranceReferralReportData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    hospitalNumber?: string;
    nhisNumber?: string;
    ssfid?: string;
    insuranceNumber?: string;
    address?: string;
    department?: string;
    encounterDatetime?: string;
    location?: string;
    chiefComplaints?: string;
    provisionalDiagnosis?: string;
    treatmentGiven?: string;
    reasonForReferral?: string;
    followUpAdvice?: string;
    referInstitutionName?: string;
    providerName?: string;
    providerCouncilNo?: string;
    // Vitals
    systolicBP?: string;
    diastolicBP?: string;
    temperature?: string;
    heartRate?: string;
    spO2?: string;
    respirationRate?: string;
    height?: string;
    weight?: string;
}

// Concept UUIDs for referral form obs
const CONCEPT_CHIEF_COMPLAINTS = 'e32add25-df38-4b2b-85e8-709633467ce2';
const CONCEPT_REASON_FOR_REFERRAL = 'bc44de6f-db98-42c7-98b5-5fd059f50d3a'; // TODO: replace with dedicated concept UUID when available
const CONCEPT_FOLLOW_UP_INSTRUCTIONS = '75ca7f0d-a0f4-49b7-9d4c-077839a1f1cf';
const CONCEPT_TREATMENT_GIVEN = '062acf82-584a-4ea3-9c7e-08a955b34da0';
const CONCEPT_REFER_INSTITUTION = 'c0f2ccac-003e-406e-afe2-b0cf97b88916';

// Vitals concept UUIDs
const VITALS_CONCEPTS = {
    systolicBP: '5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    diastolicBP: '5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    temperature: '5088AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    heartRate: '5087AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    spO2: '5092AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    respirationRate: '5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    height: '5090AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    weight: '5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
} as const;

const VITALS_CONCEPTS_QUERY = Object.values(VITALS_CONCEPTS).join(',');

const REFERRAL_FORM_UUID = '55fcfbee-6510-3abb-b2da-dbd0d5353b2e';

// Rep for the /nidan/encounter call — no diagnoses here, fetched separately
const CUSTOM_REP =
    'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(uuid,startDatetime,stopDatetime,location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),location:(display),encounterProviders:(provider:(person:(display))))';

// Same rep used by the discharge summary for the standard /encounter list endpoint
const ENCOUNTER_DIAGNOSIS_REP =
    'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis:(coded:(uuid,display),nonCoded),certainty,voided),encounterDatetime,encounterProviders:(provider:(person:(display))))';

export function useInsuranceReferralReportData(patientUuid: string) {
    // Fetch the latest referral form encounter (custom /nidan endpoint for obs/patient data)
    const { data: encounterData, error: encounterError, isLoading: isEncounterLoading } = useSWR<
        { results: any[] },
        Error
    >(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${REFERRAL_FORM_UUID}&v=${CUSTOM_REP}&order=desc&limit=1`
            : null,
        openmrsFetcher,
    );

    const encounterDatetime = encounterData?.results?.[0]?.encounterDatetime;
    const visitStart = encounterData?.results?.[0]?.visit?.startDatetime;
    const visitStop = encounterData?.results?.[0]?.visit?.stopDatetime;

    // Get the latest visit UUID via the same hook the discharge summary uses
    const { visit: latestVisit, isLoading: isVisitLoading, error: visitError } = useLatestVisit(patientUuid);
    const visitUuid = latestVisit?.uuid;

    // Fetch encounters with diagnoses from the standard /encounter endpoint scoped to the latest visit
    // (same pattern as useInsuranceDischargeSummaryData)
    const { data: visitEncountersData, error: visitEncountersError, isLoading: isVisitEncountersLoading } = useSWR<
        { results: any[] },
        Error
    >(
        patientUuid && visitUuid
            ? `${restBaseUrl}/encounter?patient=${patientUuid}&visit=${visitUuid}&v=${ENCOUNTER_DIAGNOSIS_REP}&order=desc&limit=20&fromDate=${visitStart}&toDate=${visitStop}`
            : null,
        openmrsFetcher,
    );

    const { data: vitalsData, error: vitalsError, isLoading: isVitalsLoading } = useSWR<
        { results: Array<{ uuid: string; concept: { uuid: string }; value: any; obsDatetime: string }> },
        Error
    >(
        patientUuid && encounterDatetime
            ? (() => {
                const params = new URLSearchParams({
                    patient: patientUuid,
                    concept: VITALS_CONCEPTS_QUERY,
                    v: 'custom:(uuid,concept:(uuid),value,obsDatetime)',
                    order: 'desc',
                    limit: '20',
                });
                if (visitStart) params.set('fromDate', visitStart);
                if (visitStop) params.set('toDate', visitStop);
                return `${restBaseUrl}/obs?${params.toString()}`;
            })()
            : null,
        openmrsFetcher,
    );

    // Fetch FHIR patient for address
    const { data: fhirPatient, error: fhirError, isLoading: isFhirLoading } = useSWR<any, Error>(
        patientUuid ? `/ws/fhir2/R4/Patient/${patientUuid}` : null,
        openmrsFetcher,
    );

    // Chief complaint via FHIR Observation, scoped to the latest visit window
    const chiefComplaintUrl = useMemo(() => {
        if (!patientUuid) return null;
        const params = new URLSearchParams({
            'subject:Patient': patientUuid,
            code: 'e32add25-df38-4b2b-85e8-709633467ce2',
            _sort: 'date',
            _count: '100',
            _summary: 'data',
        });
        const fhirStart = toFhirDateTime(visitStart);
        const fhirStop = toFhirDateTime(visitStop);
        if (fhirStart) params.append('date', `ge${fhirStart}`);
        if (fhirStop) params.append('date', `le${fhirStop}`);
        return `${fhirBaseUrl}/Observation?${params.toString()}`;
    }, [patientUuid, visitStart, visitStop]);

    const { data: chiefComplaintData, error: chiefComplaintError, isLoading: isChiefComplaintLoading } = useSWR<
        any,
        Error
    >(chiefComplaintUrl, openmrsFetcher);

    const insuranceReferralReportData: InsuranceReferralReportData | null = useMemo(() => {
        if (isEncounterLoading || !encounterData?.results || encounterData.results.length === 0) return null;

        const encounter = encounterData.results[0];

        // Patient identifiers
        const identifiers: any[] = encounter.patient?.identifiers || [];

        const patientId = identifiers
            .find((id: any) => id.display?.includes('OpenMRS ID'))
            ?.display?.split('=')?.[1]?.trim();

        const hospitalNumber = identifiers
            .find((id: any) => id.display?.toLowerCase().includes('hospital number'))
            ?.display?.split('=')?.[1]?.trim();

        const nhisNumber = identifiers
            .find((id: any) => id.display?.toLowerCase().includes('nhis'))
            ?.display?.split('=')?.[1]?.trim();

        const ssfId = identifiers
            .find((id: any) => id.display?.toLowerCase().includes('ssf id'))
            ?.display?.split('=')?.[1]?.trim();

        const insuranceNumber = identifiers
            .find((id: any) => id.display?.toLowerCase().includes('ssf id'))
            ?.display?.split('=')?.[1]?.trim();

        // Address from FHIR patient
        let address = '';
        if (fhirPatient?.address?.[0]) {
            const addr = fhirPatient.address[0];
            const extVal = addr.extension?.[0]?.extension?.[0]?.valueString;
            if (extVal) {
                address = extVal;
            } else {
                const lines = addr.line ? (addr.line as string[]).join(', ') : '';
                const city = addr.city || '';
                const state = addr.state || '';
                const country = addr.country || '';
                address = [lines, city, state, country].filter(Boolean).join(', ') || addr.text || '';
            }
        }

        // Department from visit location or encounter location
        const department =
            encounter.visit?.location?.display ||
            encounter.location?.display ||
            '';

        // Obs extraction — chief complaints now come from FHIR fetch below
        const chiefComplaints = (() => {
            if (!chiefComplaintData?.entry || chiefComplaintData.entry.length === 0) return undefined;
            const entries = [...chiefComplaintData.entry];
            entries.sort((a: any, b: any) => {
                const dateA = new Date(a.resource?.effectiveDateTime || 0).getTime();
                const dateB = new Date(b.resource?.effectiveDateTime || 0).getTime();
                return dateB - dateA;
            });
            return entries[0]?.resource?.valueString ?? undefined;
        })();
        const reasonForReferral = extractObsValue(encounter.obs, CONCEPT_REASON_FOR_REFERRAL);
        const followUpAdvice = extractObsValue(encounter.obs, CONCEPT_FOLLOW_UP_INSTRUCTIONS);
        const treatmentGiven = extractObsValue(encounter.obs, CONCEPT_TREATMENT_GIVEN);
        const referInstitutionName = extractObsValue(encounter.obs, CONCEPT_REFER_INSTITUTION);

        // Aggregate diagnoses from all encounters in the visit (standard endpoint)
        const allDiagnoses = (visitEncountersData?.results ?? []).flatMap((enc: any) =>
            (enc.diagnoses || []).filter((d: any) => !d.voided),
        );
        console.log('allDiagnoses', allDiagnoses);
        // Prefer PROVISIONAL; fall back to all if none are flagged (e.g. certainty not set)
        const provisionalOnly = allDiagnoses.filter((d: any) => d.certainty === 'PROVISIONAL');
        const diagnosesToShow = provisionalOnly.length > 0 ? provisionalOnly : allDiagnoses;

        const provisionalDiagnosis = diagnosesToShow
            .map((d: any) => {
                const name = d.diagnosis?.coded?.display || d.diagnosis?.nonCoded || d.display || '';
                const rankLabel =
                    d.rank === 1 || d.rank === '1' ? ' (Primary)' :
                        d.rank === 2 || d.rank === '2' ? ' (Secondary)' : '';
                return name + rankLabel;
            })
            .filter(Boolean)
            .join('\n');

        // Provider
        const providerName =
            encounter.encounterProviders?.[0]?.provider?.person?.display ||
            encounter.encounterProviders?.[0]?.provider?.display;

        // Vitals — pick the most recent obs per concept
        const latestVital = (conceptUuid: string): string | undefined => {
            if (!vitalsData?.results) return undefined;
            const matches = vitalsData.results
                .filter((obs) => obs.concept?.uuid === conceptUuid)
                .sort((a, b) => new Date(b.obsDatetime).getTime() - new Date(a.obsDatetime).getTime());
            if (matches.length === 0) return undefined;
            const val = matches[0].value;
            return val !== null && val !== undefined ? String(val) : undefined;
        };

        return {
            patientName:
                encounter.patient?.person?.preferredName?.display ||
                encounter.patient?.display,
            patientGender: encounter.patient?.person?.gender,
            patientAge:
                encounter.patient?.person?.age?.toString() ||
                (encounter.patient?.person?.birthdate
                    ? calculateAge(encounter.patient.person.birthdate)
                    : undefined),
            patientId: patientId || encounter.patient?.identifiers?.[0]?.display,
            hospitalNumber,
            nhisNumber,
            insuranceNumber,
            address,
            department,
            encounterDatetime: encounter.encounterDatetime,
            location: encounter.visit?.location?.display || encounter.location?.display,
            chiefComplaints,
            provisionalDiagnosis,
            treatmentGiven,
            reasonForReferral,
            followUpAdvice,
            referInstitutionName,
            providerName,
            providerCouncilNo: undefined, // not stored in OpenMRS identifiers currently
            // Vitals
            systolicBP: latestVital(VITALS_CONCEPTS.systolicBP),
            diastolicBP: latestVital(VITALS_CONCEPTS.diastolicBP),
            temperature: latestVital(VITALS_CONCEPTS.temperature),
            heartRate: latestVital(VITALS_CONCEPTS.heartRate),
            spO2: latestVital(VITALS_CONCEPTS.spO2),
            respirationRate: latestVital(VITALS_CONCEPTS.respirationRate),
            height: latestVital(VITALS_CONCEPTS.height),
            weight: latestVital(VITALS_CONCEPTS.weight),
        };
    }, [encounterData, fhirPatient, vitalsData, visitEncountersData, chiefComplaintData, isEncounterLoading]);

    return {
        insuranceReferralReportData,
        isLoading: isEncounterLoading || isFhirLoading || isVitalsLoading || isVisitLoading || isVisitEncountersLoading || isChiefComplaintLoading,
        error: encounterError || fhirError || vitalsError || visitError || visitEncountersError || chiefComplaintError,
    };
}
