import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';

export interface ReferralReportData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    hospitalNumber?: string;
    encounterDatetime?: string;
    location?: string;
    remarks?: string;
    followUpInstructions?: string;
    treatmentSuggestion?: string;
    referInstitutionName?: string;
    providerName?: string;
}

export function useReferralReportData(patientUuid: string) {
    const formUuid = '8d952019-a407-399a-869a-92fd525e7e51';
    const customRepresentation =
        'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),encounterProviders:(provider:(person:(display))))';

    const fetchEncounters = async (url: string) => {
        const response = await openmrsFetch(url);
        return response.data;
    };

    const { data, error, isLoading } = useSWR(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${customRepresentation}&order=desc&limit=1`
            : null,
        fetchEncounters
    );

    const referralReportData: ReferralReportData | null = useMemo(() => {
        if (!data?.results || data.results.length === 0) return null;

        const encounter = data.results[0];

        const extractObsValue = (conceptUuid: string) => {
            const obs = encounter.obs?.find((o: any) => o.concept?.uuid === conceptUuid);
            if (!obs) return undefined;

            if (typeof obs.value === 'object' && obs.value?.display) {
                return obs.value.display;
            }
            return obs.value;
        };

        const patientId = encounter.patient?.identifiers?.find((id: any) => id.display.includes('OpenMRS ID'))?.display?.split('=')?.[1]?.trim();
        const hospitalNumber = encounter.patient?.identifiers?.find((id: any) => id.display.includes('Hospital Number'))?.display?.split('=')?.[1]?.trim();

        return {
            patientName: encounter.patient?.person?.preferredName?.display || encounter.patient?.display,
            patientGender: encounter.patient?.person?.gender,
            patientAge: encounter.patient?.person?.age?.toString(),
            patientId: patientId || encounter.patient?.identifiers?.[0]?.display,
            hospitalNumber: hospitalNumber,
            encounterDatetime: encounter.encounterDatetime,
            location: encounter.visit?.location?.display,
            remarks: extractObsValue('bc44de6f-db98-42c7-98b5-5fd059f50d3a'),
            followUpInstructions: extractObsValue('75ca7f0d-a0f4-49b7-9d4c-077839a1f1cf'),
            treatmentSuggestion: extractObsValue('062acf82-584a-4ea3-9c7e-08a955b34da0'),
            referInstitutionName: extractObsValue('c0f2ccac-003e-406e-afe2-b0cf97b88916'),
            providerName: encounter.encounterProviders?.[0]?.provider?.person?.display || encounter.encounterProviders?.[0]?.provider?.display,
        };
    }, [data]);

    return {
        referralReportData,
        isLoading,
        error,
    };
}
