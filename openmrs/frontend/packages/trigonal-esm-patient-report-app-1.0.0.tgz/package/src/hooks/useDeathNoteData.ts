import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';
import dayjs from 'dayjs';

export interface DeathNoteData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    placeOfDeath?: string;
    wardOrUnit?: string;
    dateAndTimeOfDeath?: string;
    broughtDead?: string;
    mannerOfDeath?: string;
    deathType?: string;
    immediateCause?: string;
    antecedentCause?: string;
    underlyingCause?: string;
    otherSignificantConditions?: string;
    medicoLegalCase?: string;
    maternalDeathStatus?: string;
    familyInformed?: string;
    briefHospitalCourse?: string;
    postMortemDone?: string;
    postOperativeDeath?: string;
    mdgpNotifiedAt?: string;
    providerName?: string;
    providerQualification?: string;
    providerRegistrationNumber?: string;
    dateSigned?: string;
    encounterDatetime?: string;
}

export function useDeathNoteData(patientUuid: string) {
    const formUuid = 'c5fe5243-2fd5-33d9-9ab7-badf079ac7bd';
    const customRepresentation =
        'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),encounterProviders:(provider:(person:(display))))';

    const fetchEncounters = async (url: string) => {
        const response = await openmrsFetch(url);
        return response.data;
    };

    const { data, error, isLoading } = useSWR(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${customRepresentation}&order=desc&limit=1`
            : null,
        fetchEncounters
    );

    const deathNoteData: DeathNoteData | null = useMemo(() => {
        if (!data?.results || data.results.length === 0) return null;

        // The API already filters by form, so we take the most recent one
        const deathEncounter = data.results[0];

        const extractObsValue = (conceptUuid: string, conceptDisplay: string) => {
            const obs = deathEncounter.obs?.find((o: any) =>
                o.concept?.uuid === conceptUuid || o.concept?.display === conceptDisplay
            );
            if (!obs) return undefined;

            // Handle different value types
            if (typeof obs.value === 'object' && obs.value?.display) {
                return obs.value.display;
            }
            return obs.value;
        };

        return {
            patientName: deathEncounter.patient?.person?.preferredName?.display || deathEncounter.patient?.display,
            patientGender: deathEncounter.patient?.person?.gender,
            patientAge: deathEncounter.patient?.person?.age?.toString(),
            patientId: deathEncounter.patient?.identifiers?.[0]?.display?.split('=')?.[1]?.trim() || deathEncounter.patient?.identifiers?.[0]?.display,
            placeOfDeath: 'Hospital',
            wardOrUnit: deathEncounter.visit?.location?.display,
            dateAndTimeOfDeath: extractObsValue('ebe93dec-73a0-4703-abec-e05164896fe3', 'Pronounced death date and time') || deathEncounter.encounterDatetime,
            broughtDead: extractObsValue('53b7d2a5-5df6-4dff-a3b3-9daee6c78ba7', 'Brought dead'),
            mannerOfDeath: extractObsValue('', 'Manner of Death'),
            deathType: extractObsValue('6a811193-2c82-4585-a938-d053419f3917', 'Death type'),
            immediateCause: extractObsValue('0249a235-db19-46c7-abda-7bbd61563821', 'Primary cause of death'),
            antecedentCause: extractObsValue('', 'Secondary cause of death'),
            underlyingCause: extractObsValue('', 'Tertiary cause of death'),
            otherSignificantConditions: extractObsValue('e7db97e6-89e3-4d19-a21c-6585ea56066f', 'Other co morbidities'),
            medicoLegalCase: extractObsValue('', 'Medico legal / police case'),
            maternalDeathStatus: undefined,
            familyInformed: extractObsValue('d2cb9d59-6a37-4a35-9c6c-1d6e652311fa', 'Family aware of death'),
            briefHospitalCourse: extractObsValue('1791b581-a9cc-4ecc-9917-00887672772d', 'Hospital course'),
            postMortemDone: extractObsValue('da3173b7-8f7c-4ffa-b9fa-085274c07655', 'Postmortem done'),
            postOperativeDeath: extractObsValue('071cf0cc-d5ef-43fe-80e5-00438703cd41', 'Death occured post operative'),
            mdgpNotifiedAt: extractObsValue('', 'MDGP notified at'),
            providerName: deathEncounter.encounterProviders?.[0]?.provider?.person?.display || deathEncounter.encounterProviders?.[0]?.provider?.display,
            providerQualification: undefined,
            providerRegistrationNumber: undefined,
            dateSigned: deathEncounter.encounterDatetime,
            encounterDatetime: deathEncounter.encounterDatetime,
        };
    }, [data]);


    return {
        deathNoteData,
        isLoading,
        error,
    };
}
