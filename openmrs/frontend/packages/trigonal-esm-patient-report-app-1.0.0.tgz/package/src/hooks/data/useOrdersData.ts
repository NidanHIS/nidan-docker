import { useMemo } from 'react';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import type { Orders } from '../../types';
import { openmrsFetcher } from '../../utils';

// ─── Internal Types ───────────────────────────────────────────────────────────

/**
 * The raw order shape returned by the OpenMRS REST API (/order?v=full).
 * Extends the public `Orders` interface with fields that the API returns
 * but that we access via type assertions in the mapping step.
 */
interface RawOrder extends Orders {
  /** The associated concept UUID (present on non-drug orders) */
  concept?: { uuid: string };
  /** The encounter this order belongs to */
  encounter?: { uuid: string };
}

/** The recognised order type names this hook handles. */
type OrderTypeName =
  | 'Drug Order'
  | 'Test Order'
  | 'Radiology Order'
  | 'Procedure Order'
  | 'Medical Supply Order';

const NON_DRUG_ORDER_TYPES: ReadonlySet<OrderTypeName> = new Set([
  'Test Order',
  'Radiology Order',
  'Procedure Order',
  'Medical Supply Order',
]);

interface OrdersApiResponse {
  results: RawOrder[];
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Fetches and normalises orders for a patient, optionally scoped to a visit
 * window via activation date range parameters.
 *
 * Handles two order categories:
 *  - **Drug Orders** — mapped with dose, frequency, route, and duration fields
 *  - **Non-drug orders** (Test, Radiology, Procedure, Medical Supply) — mapped
 *    with display, urgency, and instructions fields
 *
 * Orders are deduplicated by `orderType::conceptUuid` key, keeping the most
 * recent entry for each concept. The API already returns orders newest-first,
 * so the first occurrence per key is always the latest.
 *
 * @param patientUuid              - The patient's UUID
 * @param activatedOnOrAfterDate   - Lower bound for order activation date (ISO string)
 * @param activatedOnOrBeforeDate  - Upper bound for order activation date (ISO string)
 */
export function useOrdersData(
  patientUuid: string,
  activatedOnOrAfterDate?: string,
  activatedOnOrBeforeDate?: string,
) {
  const { t } = useTranslation();

  const url = useMemo(() => {
    if (!patientUuid) return null;
    const params = new URLSearchParams({ patient: patientUuid, v: 'full' });
    if (activatedOnOrAfterDate) params.set('activatedOnOrAfterDate', activatedOnOrAfterDate);
    if (activatedOnOrBeforeDate) params.set('activatedOnOrBeforeDate', activatedOnOrBeforeDate);
    return `${restBaseUrl}/order?${params.toString()}`;
  }, [patientUuid, activatedOnOrAfterDate, activatedOnOrBeforeDate]);

  const { data, error, isLoading, mutate } = useSWR<OrdersApiResponse, Error>(url, openmrsFetcher);

  const orders = useMemo((): Orders[] => {
    if (!data?.results) return [];

    const mapped = data.results
      .map((order): Orders | null => {
        const typeName = order.orderType?.name as OrderTypeName | undefined;
        // Pull concept/encounter UUIDs with proper types — no (order as any) casts
        const conceptUuid = order.concept?.uuid ?? null;
        const encounterUuid = order.encounter?.uuid ?? null;

        if (typeName === 'Drug Order') {
          return {
            uuid: order.uuid,
            orderType: { name: 'Drug Order' },
            drug: { display: order.drug?.display ?? t('unknownValue', 'Unknown') },
            dose: order.dose ?? '',
            doseUnits: { display: order.doseUnits?.display ?? '' },
            frequency: { display: order.frequency?.display ?? '' },
            dosingInstructions: order.dosingInstructions ?? t('takeAsDirected', 'Take as directed'),
            route: { display: order.route?.display ?? '' },
            duration: order.duration ?? '',
            durationUnits: { display: order.durationUnits?.display ?? '' },
            orderer: { display: order.orderer?.display ?? '' },
            dateActivated: order.dateActivated,
            auditInfo: order.auditInfo,
            conceptUuid,
            encounterUuid,
          };
        }

        if (typeName && NON_DRUG_ORDER_TYPES.has(typeName)) {
          return {
            uuid: order.uuid,
            orderType: { name: typeName },
            drug: { display: order.display ?? '' },
            dose: '',
            doseUnits: { display: '' },
            frequency: { display: '' },
            route: { display: '' },
            duration: '',
            durationUnits: { display: '' },
            orderer: { display: order.orderer?.display ?? '' },
            dateActivated: order.dateActivated ?? '',
            display: order.display,
            urgency: order.urgency ?? t('routineUrgency', 'ROUTINE'),
            instructions: order.instructions ?? '',
            auditInfo: order.auditInfo,
            conceptUuid,
            encounterUuid,
          };
        }

        return null;
      })
      .filter((o): o is Orders => o !== null);

    // Deduplicate: keep only the most recent order per orderType + conceptUuid.
    // The API returns orders sorted newest-first, so the first hit per key wins.
    const seen = new Set<string>();
    return mapped.filter((order) => {
      const key = `${order.orderType.name}::${order.conceptUuid ?? order.uuid}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [data, t]);

  return { orders, isLoading, error, mutate };
}
