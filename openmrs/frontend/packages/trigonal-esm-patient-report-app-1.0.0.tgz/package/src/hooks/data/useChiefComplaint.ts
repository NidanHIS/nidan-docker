import { useMemo } from 'react';
import useSWR from 'swr';
import { fhirBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher, toFhirDateTime } from '../../utils';
import { useObsConceptsConfig } from '../../config-helpers';
import type { FhirObservationBundle } from '../../types';

/**
 * Fetches the most recent chief complaint observation for a patient,
 * optionally scoped to a visit window.
 *
 * Uses the FHIR Observation endpoint rather than the REST obs endpoint because
 * the chief complaint concept is stored as a free-text valueString, which is
 * most reliably retrieved via FHIR.
 *
 * The chief complaint concept UUID is read from
 * `config.obsConcepts.chiefComplaintUuid` so it can be overridden per
 * deployment without a code rebuild.
 *
 * @param patientUuid   - The patient's UUID
 * @param startDatetime - Optional visit start datetime (OpenMRS ISO) to scope the query
 * @param stopDatetime  - Optional visit stop datetime (OpenMRS ISO) to scope the query
 */
export function useChiefComplaint(
  patientUuid: string | null | undefined,
  startDatetime?: string | null,
  stopDatetime?: string | null,
) {
  const { chiefComplaintUuid } = useObsConceptsConfig();

  const url = useMemo(() => {
    if (!patientUuid) return null;

    const params = new URLSearchParams({
      'subject:Patient': patientUuid,
      code: chiefComplaintUuid,
      _sort: 'date',
      _count: '100',
      _summary: 'data',
    });

    const fhirStart = toFhirDateTime(startDatetime);
    const fhirStop = toFhirDateTime(stopDatetime);
    if (fhirStart) params.append('date', `ge${fhirStart}`);
    if (fhirStop) params.append('date', `le${fhirStop}`);

    return `${fhirBaseUrl}/Observation?${params.toString()}`;
  }, [patientUuid, chiefComplaintUuid, startDatetime, stopDatetime]);

  const { data, error, isLoading } = useSWR<FhirObservationBundle, Error>(url, openmrsFetcher);

  const chiefComplaint = useMemo<string | null>(() => {
    if (!data?.entry?.length) return null;

    const sorted = [...data.entry].sort((a, b) => {
      const dateA = new Date(a.resource?.effectiveDateTime ?? 0).getTime();
      const dateB = new Date(b.resource?.effectiveDateTime ?? 0).getTime();
      return dateB - dateA;
    });

    return sorted[0]?.resource?.valueString ?? null;
  }, [data]);

  return { chiefComplaint, isLoading, error };
}
