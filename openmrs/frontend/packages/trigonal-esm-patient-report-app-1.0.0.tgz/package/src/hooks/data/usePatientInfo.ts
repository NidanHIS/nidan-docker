import { useMemo } from 'react';
import { usePatient } from '@openmrs/esm-framework';
import { calculateAge, extractFhirAddress } from '../../utils';
import type { PatientInfo } from '../../types';

/**
 * Resolves and formats core patient demographic information from the FHIR
 * Patient resource returned by `usePatient`.
 *
 * The hook is intentionally lightweight — it owns only the patient identity
 * layer. Visit-scoped data (vitals, orders, encounters) lives in the
 * aggregator hooks that compose this one.
 *
 * Address extraction uses `extractFhirAddress` which handles both the
 * Nepali-style nested extension and standard FHIR address fields.
 *
 * @param patientUuid - The patient's UUID
 * @returns `patientInfo` (null while loading), `isLoading`, `error`
 */
export function usePatientInfo(patientUuid: string) {
  const { patient, isLoading, error } = usePatient(patientUuid);

  const patientInfo = useMemo((): PatientInfo | null => {
    if (!patient) return null;

    // Extract NHIS and SSF identifiers from the FHIR identifier array.
    // FHIR identifiers use type.text as the label; we match case-insensitively.
    const findIdentifier = (predicate: (label: string) => boolean): string | undefined => {
      const match = patient.identifier?.find((id: any) => {
        const label = (id.type?.text ?? id.system ?? '').toLowerCase();
        return predicate(label);
      });
      return match?.value ?? undefined;
    };

    const nhisNumber = findIdentifier((l) => l.includes('nhis'));
    const ssfId = findIdentifier((l) => l.includes('ssf'));

    return {
      name: patient.name?.[0]?.text ?? 'Unknown',
      age: calculateAge(patient.birthDate) ?? 'Unknown',
      birthDate: patient.birthDate ?? 'Unknown',
      gender: patient.gender ?? 'Unknown',
      address: extractFhirAddress(patient.address as any),
      patientId: patient.identifier?.[0]?.value ?? 'Unknown',
      nhisNumber,
      ssfId,
    };
  }, [patient]);

  return { patientInfo, isLoading, error };
}
