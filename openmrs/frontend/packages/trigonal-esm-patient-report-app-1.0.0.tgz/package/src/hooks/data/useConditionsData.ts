import { useMemo } from 'react';
import { fhirBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import type { PatientConditions, ConditionsData } from '../../types';
import { openmrsFetcher } from '../../utils';

/** FHIR category filter for active problem-list conditions */
const PROBLEM_LIST_CATEGORY = encodeURIComponent(
  'http://terminology.hl7.org/CodeSystem/condition-category|problem-list-item',
);

/**
 * Fetches the patient's active problem-list conditions via the FHIR Condition
 * endpoint.
 *
 * Note: Conditions are patient-level data and are NOT scoped to a specific
 * visit. All active conditions are returned regardless of when they were
 * recorded. This is intentional — the report document shows the full
 * problem list, not just visit-specific conditions.
 *
 * @param patientUuid - The patient's UUID
 */
export function useConditionsData(patientUuid: string) {
  const url = patientUuid
    ? `${fhirBaseUrl}/Condition?patient=${patientUuid}&category=${PROBLEM_LIST_CATEGORY}&_count=100`
    : null;

  const { data: conditions, error, isLoading, mutate } = useSWR<PatientConditions, Error>(
    url,
    openmrsFetcher,
  );

  const conditionsData = useMemo<ConditionsData[]>(() => {
    if (!conditions?.entry) return [];

    return conditions.entry
      .map(({ resource }) => {
        const condition = resource?.code?.coding?.[0]?.display;
        if (!condition) return null;
        return {
          condition,
          onsetDate: resource.onsetDateTime ?? undefined,
          clinicalStatus: resource.clinicalStatus?.coding?.[0]?.code,
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null);
  }, [conditions]);

  return { conditionsData, isLoading, error, mutate };
}
