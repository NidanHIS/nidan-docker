import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { openmrsFetcher } from '../../utils';
import { CUSTOM_REPS } from '../../constants';
import type { EncounterFull } from '../../types';

interface EncountersApiResponse {
  results: EncounterFull[];
}

interface UseEncountersOptions {
  /**
   * Limit the results to encounters within this visit.
   * When provided the query uses `&visit=<uuid>` in addition to date range params.
   */
  visitUuid?: string | null;
  /** Filter encounters from this datetime (OpenMRS ISO format, inclusive). */
  fromDate?: string | null;
  /** Filter encounters up to this datetime (OpenMRS ISO format, inclusive). */
  toDate?: string | null;
  /** Max number of encounters to return (default: 20). */
  limit?: number;
}

/**
 * Fetches the encounter list for a patient using the ENCOUNTER_FULL custom
 * representation. Returns encounters with full obs, diagnoses, forms, and
 * provider information.
 *
 * This is the single canonical source for encounter list queries, replacing
 * identical useSWR calls that existed independently in:
 *  - usePatientSummary
 *  - useInsuranceDischargeSummaryData
 *  - useVisitSummaryData
 *
 * All visit-based date-range filtering is preserved via the `fromDate` /
 * `toDate` / `visitUuid` options — callers pass the same values they were
 * previously inlining into the URL string.
 *
 * @param patientUuid - The patient's UUID
 * @param options     - Optional query scope (visit, date range, result limit)
 */
export function useEncounters(
  patientUuid: string | null | undefined,
  options: UseEncountersOptions = {},
) {
  const { visitUuid, fromDate, toDate, limit = 20 } = options;

  const url = (() => {
    if (!patientUuid) return null;

    const params = new URLSearchParams({
      patient: patientUuid,
      v: CUSTOM_REPS.ENCOUNTER_FULL,
      order: 'desc',
      limit: String(limit),
      startIndex: '0',
      totalCount: 'true',
    });

    if (visitUuid) params.set('visit', visitUuid);
    if (fromDate) params.set('fromDate', fromDate);
    if (toDate) params.set('toDate', toDate);

    return `${restBaseUrl}/encounter?${params.toString()}`;
  })();

  const { data, error, isLoading } = useSWR<EncountersApiResponse, Error>(url, openmrsFetcher);

  return {
    encounters: data?.results ?? [],
    isLoading,
    error,
  };
}

/**
 * Fetches encounters for a patient using the ENCOUNTER_DIAGNOSIS_ONLY
 * representation — a lighter payload that includes diagnoses and provider
 * info but omits obs and form details.
 *
 * Used by useInsuranceReferralReportData to aggregate diagnoses from all
 * encounters in a visit without fetching the full obs payload.
 *
 * @param patientUuid - The patient's UUID
 * @param options     - Optional query scope (visit, date range, result limit)
 */
export function useEncountersWithDiagnoses(
  patientUuid: string | null | undefined,
  options: UseEncountersOptions = {},
) {
  const { visitUuid, fromDate, toDate, limit = 20 } = options;

  const url = (() => {
    if (!patientUuid) return null;

    const params = new URLSearchParams({
      patient: patientUuid,
      v: CUSTOM_REPS.ENCOUNTER_DIAGNOSIS_ONLY,
      order: 'desc',
      limit: String(limit),
    });

    if (visitUuid) params.set('visit', visitUuid);
    if (fromDate) params.set('fromDate', fromDate);
    if (toDate) params.set('toDate', toDate);

    return `${restBaseUrl}/encounter?${params.toString()}`;
  })();

  const { data, error, isLoading } = useSWR<EncountersApiResponse, Error>(url, openmrsFetcher);

  return {
    encounters: data?.results ?? [],
    isLoading,
    error,
  };
}
