import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { extractObsValue, openmrsFetcher } from '../utils';

interface NewbornAdmissionData {
    fatherName?: string;
    motherName?: string;
    dateOfDelivery?: string;
    motherId?: string;
    gestationalWeek?: string;
    bodyWeight?: string | number;
    encounterDatetime?: string;
    patientName?: string;
    patientGender?: string;
    patientBirthdate?: string;
}

export function useNewbornAdmissionData(patientUuid: string) {
    const formUuid = '5c013f97-916c-3560-a6ed-5c58a7760043';
    const customRepresentation = 'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),encounterProviders:(provider:(person:(display))))';

    const { data, error, isLoading, mutate } = useSWR<{ results: any[] }, Error>(
        patientUuid
            ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${formUuid}&v=${customRepresentation}&order=desc&limit=1`
            : null,
        openmrsFetcher,
    );
    const newbornData: NewbornAdmissionData | null = useMemo(() => {
        // API already filters by form UUID — take the first result directly
        const newbornEncounter = data?.results?.[0];
        if (!newbornEncounter) return null;

        return {
            fatherName: extractObsValue(newbornEncounter.obs, '38dbc147-faa8-4b81-b4df-2c2e97875aa9', 'Father Name'),
            motherName: extractObsValue(newbornEncounter.obs, '3164ad4e-5c6e-470d-91dd-f29bcffad23a', "Mother's Name"),
            dateOfDelivery: extractObsValue(newbornEncounter.obs, 'd73ef9e6-7286-44d5-bc91-e86d6991199e', 'Delivery Date and Time'),
            motherId: extractObsValue(newbornEncounter.obs, 'a270e58a-1c95-4ad6-a1df-b5973882df0d', 'Mother ID'),
            gestationalWeek: extractObsValue(newbornEncounter.obs, '557e394a-f224-45aa-9520-4efe71df98c0', 'NBA-Gestational week'),
            bodyWeight: extractObsValue(newbornEncounter.obs, '9c18b5bd-c465-4f30-b030-e46575a4153d', 'Neonate weight'),
            encounterDatetime: newbornEncounter.encounterDatetime,
            patientName: newbornEncounter.patient?.person?.preferredName?.display,
            patientGender: newbornEncounter.patient?.person?.gender,
            patientBirthdate: newbornEncounter.patient?.person?.birthdate,
        };

    }, [data]);

    return {
        newbornData,
        isLoading,
        error,
        mutate,
    };
}
