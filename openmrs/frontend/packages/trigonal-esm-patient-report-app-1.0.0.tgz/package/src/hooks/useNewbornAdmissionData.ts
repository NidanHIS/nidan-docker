import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { extractObsValue, openmrsFetcher } from '../utils';

interface NewbornAdmissionData {
    fatherName?: string;
    motherName?: string;
    dateOfDelivery?: string;
    motherId?: string;
    gestationalWeek?: string;
    bodyWeight?: string | number;
    encounterDatetime?: string;
    patientName?: string;
    patientGender?: string;
    patientBirthdate?: string;
}

export function useNewbornAdmissionData(patientUuid: string) {
    const customRepresentation = 'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient:(uuid,display,person:(uuid,display,gender,birthdate,preferredName:(uuid,display))),obs:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person)))';

    const { data, error, isLoading, mutate } = useSWR<{ results: any[] }, Error>(
        patientUuid
            ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRepresentation}&order=desc&limit=20&startIndex=0&totalCount=true`
            : null,
        openmrsFetcher,
    );

    const newbornData: NewbornAdmissionData | null = useMemo(() => {
        if (!data?.results) {
            return null;
        }


        // Filter for "Newborn admission note" form using both name and UUID
        const newbornEncounter = data.results.find(
            (encounter: any) =>
                encounter.form?.uuid === '5c013f97-916c-3560-a6ed-5c58a7760043' ||
                encounter.form?.name === 'Newborn admission note' ||
                encounter.form?.display === 'Newborn admission note'
        );

        if (!newbornEncounter) return null;

        return {
            fatherName: extractObsValue(newbornEncounter.obs, '38dbc147-faa8-4b81-b4df-2c2e97875aa9', 'Father Name'),
            motherName: extractObsValue(newbornEncounter.obs, '3164ad4e-5c6e-470d-91dd-f29bcffad23a', "Mother's Name"),
            dateOfDelivery: extractObsValue(newbornEncounter.obs, 'd73ef9e6-7286-44d5-bc91-e86d6991199e', 'Delivery Date and Time'),
            motherId: extractObsValue(newbornEncounter.obs, 'a270e58a-1c95-4ad6-a1df-b5973882df0d', 'Mother ID'),
            gestationalWeek: extractObsValue(newbornEncounter.obs, '557e394a-f224-45aa-9520-4efe71df98c0', 'NBA-Gestational week'),
            bodyWeight: extractObsValue(newbornEncounter.obs, '9c18b5bd-c465-4f30-b030-e46575a4153d', 'Neonate weight'),
            encounterDatetime: newbornEncounter.encounterDatetime,
            patientName: newbornEncounter.patient?.person?.preferredName?.display,
            patientGender: newbornEncounter.patient?.person?.gender,
            patientBirthdate: newbornEncounter.patient?.person?.birthdate,
        };

    }, [data]);

    return {
        newbornData,
        isLoading,
        error,
        mutate,
    };
}
