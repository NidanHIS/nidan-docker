import { useState, useEffect } from 'react';
import useSWR from 'swr';
import { restBaseUrl } from '@openmrs/esm-framework';
import { useConfig } from '@openmrs/esm-framework';
import type { DiagnosisData, ClinicalNote, PatientEncounter } from '../types';
import { ConfigObject } from '../config-schema';
import { openmrsFetcher } from '../utils';

interface EncounterApiResponse {
  results: PatientEncounter[];
}

export function useEncounterData(patientUuid: string) {
  const [diagnosisData, setDiagnosisData] = useState<DiagnosisData[]>([]);
  const [clinicalNotes, setClinicalNotes] = useState<ClinicalNote[]>([]);
  const { concepts } = useConfig<ConfigObject>();

  const customRepresentation =
    'custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,diagnosis),obs:(uuid,concept:(uuid,display),value,obsDatetime),encounterType:(uuid,display)),startDatetime,stopDatetime)';

  const url = patientUuid
    ? `${restBaseUrl}/visit?patient=${patientUuid}&v=${customRepresentation}&voided=false&limit=1`
    : null;

  const { data: encounter, error, isLoading: isEncounterLoading, mutate } = useSWR<EncounterApiResponse, Error>(
    url,
    openmrsFetcher,
  );

  useEffect(() => {
    const tempDiagnosisData: DiagnosisData[] = [];
    const tempClinicalNotes: ClinicalNote[] = [];

    if (encounter?.results?.[0]?.encounters) {
      encounter.results[0].encounters.forEach((enc) => {
        enc.diagnoses?.forEach((diagnosis) => {
          const diagnosisName = diagnosis.display;
          if (diagnosisName) {
            tempDiagnosisData.push({ diagnosisName });
          }
        });

        enc.obs?.forEach((observation) => {
          if (observation && concepts.notesConceptUuid.includes(observation.concept?.uuid) && observation.value) {
            tempClinicalNotes.push({ note: observation.value });
          }
        });
      });

      setDiagnosisData(tempDiagnosisData);
      setClinicalNotes(tempClinicalNotes);
    }
  }, [encounter, concepts.notesConceptUuid]);

  return { diagnosisData, clinicalNotes, isEncounterLoading, error, mutate };
}
