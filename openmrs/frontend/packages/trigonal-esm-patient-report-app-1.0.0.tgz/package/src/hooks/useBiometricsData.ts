import { useMemo, useEffect, useState } from 'react';
import { fhirBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { openmrsFetch } from '@openmrs/esm-framework';
import { type ConfigObject } from '../config-schema';
import { calculateBMI } from '../utils';

export function useBiometricsData(patientUuid) {
  const { concepts } = useConfig<ConfigObject>();
  const [biometricsData, setBiometricsData] = useState<BiometricsData>({});
  const biometricsConcepts = useMemo(
    () => [concepts.heightUuid,concepts.midUpperArmCircumferenceUuid, concepts.weightUuid],
    [concepts.heightUuid, concepts.midUpperArmCircumferenceUuid, concepts.weightUuid],
  );

  const fetchBiometrics = async (url: string): Promise<VitalsMain> => {
    const response = await openmrsFetch(url);
    return response.data;
  };

  const { data: biometrics, error, isLoading } = useSWR(
    `${fhirBaseUrl}/Observation?subject:Patient=${patientUuid}&code=${biometricsConcepts.join(',')}&_sort=date&_count=100`,
    fetchBiometrics
  );

  useEffect(() => {
  if (biometrics?.entry) {
    const biometricsData: BiometricsData = {};
    
    biometrics.entry.forEach((entry: { resource: VitalObservation }) => {
      const observation = entry.resource;
      const code = observation.code.coding[0].code;
      const value = observation?.valueQuantity?.value;
      const effectiveDate = observation?.effectiveDateTime;
      biometricsData.effectiveDate = new Date(effectiveDate).toLocaleString();

      switch (code) {
        case concepts.weightUuid:
          biometricsData.weight = value;
          break;
        case concepts.heightUuid:
          biometricsData.height = value;
          break;
        case concepts.midUpperArmCircumferenceUuid:
            biometricsData.muac = value;
            break;
      }
    });
    if (biometricsData.weight && biometricsData.height) {       
        const bmiValue = calculateBMI(biometricsData.weight,biometricsData.height);
        biometricsData.bmi = bmiValue;
    }

    setBiometricsData(biometricsData);
  }
  }, [biometrics]);

  return {
    biometricsData,
    isLoading,
    error
  };
}