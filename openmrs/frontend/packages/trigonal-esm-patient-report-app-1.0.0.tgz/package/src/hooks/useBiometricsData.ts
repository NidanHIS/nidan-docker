import { useMemo } from 'react';
import { fhirBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import type { VitalsMain, BiometricsData } from '../types';
import { type ConfigObject } from '../config-schema';
import { calculateBMI, openmrsFetcher } from '../utils';

export function useBiometricsData(patientUuid: string) {
  const { concepts } = useConfig<ConfigObject>();

  const biometricsConcepts = useMemo(
    () => [concepts.heightUuid, concepts.midUpperArmCircumferenceUuid, concepts.weightUuid],
    [concepts],
  );

  const url = patientUuid
    ? `${fhirBaseUrl}/Observation?subject:Patient=${patientUuid}&code=${biometricsConcepts.join(',')}&_sort=date&_count=100`
    : null;

  const { data: biometrics, error, isLoading, mutate } = useSWR<VitalsMain, Error>(url, openmrsFetcher);

  const biometricsData = useMemo<BiometricsData>(() => {
    if (!biometrics?.entry) return {};

    const result: BiometricsData = {};

    biometrics.entry.forEach(({ resource: observation }) => {
      const code = observation.code.coding[0].code;
      const value = observation?.valueQuantity?.value;
      const effectiveDate = observation?.effectiveDateTime;
      result.effectiveDate = new Date(effectiveDate).toLocaleString();

      switch (code) {
        case concepts.weightUuid:
          result.weight = value;
          break;
        case concepts.heightUuid:
          result.height = value;
          break;
        case concepts.midUpperArmCircumferenceUuid:
          result.muac = value;
          break;
      }
    });

    if (result.weight && result.height) {
      result.bmi = calculateBMI(result.weight, result.height);
    }

    return result;
  }, [biometrics, concepts]);

  return { biometricsData, isLoading, error, mutate };
}