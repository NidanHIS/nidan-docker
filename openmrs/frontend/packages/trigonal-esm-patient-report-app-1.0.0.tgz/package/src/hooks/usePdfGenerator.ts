// import { useState, useCallback } from 'react';

// export type PdfGeneratorStatus = 'idle' | 'capturing' | 'rendering' | 'done' | 'error';

// export interface UsePdfGeneratorResult {
//   /** 0–100 integer progress. Only meaningful while status is 'capturing' or 'rendering'. */
//   progress: number;
//   status: PdfGeneratorStatus;
//   /** Generates the PDF and returns the Blob. Throws on failure. */
//   generatePdf: (
//     element: HTMLElement,
//     filename: string,
//   ) => Promise<Blob>;
//   reset: () => void;
// }

// /**
//  * usePdfGenerator
//  *
//  * Converts a live DOM element into a multi-page A4 PDF using html2canvas + jsPDF.
//  *
//  * **Repeating headers/footers:** If the element contains a `<table class="printTable">`
//  * with `<thead>` and/or `<tfoot>`, those sections are captured separately and rendered
//  * on every PDF page, matching the CSS print behavior.
//  *
//  * Progress is tracked across phases:
//  *   - Capturing (html2canvas):  0 → 60 %
//  *   - Rendering  (jsPDF):      60 → 100 %
//  *
//  * The hook does NOT depend on a ref so the caller can pass any HTMLElement.
//  */
// export function usePdfGenerator(): UsePdfGeneratorResult {
//   const [progress, setProgress] = useState(0);
//   const [status, setStatus] = useState<PdfGeneratorStatus>('idle');

//   const reset = useCallback(() => {
//     setProgress(0);
//     setStatus('idle');
//   }, []);

//   const generatePdf = useCallback(async (element: HTMLElement, filename: string): Promise<Blob> => {
//     setStatus('capturing');
//     setProgress(5);

//     try {
//       // ── Dynamic imports so the heavy libs are only loaded when needed ──────
//       const [html2canvasModule, { jsPDF }] = await Promise.all([
//         import('html2canvas'),
//         import('jspdf'),
//       ]);
//       const html2canvas = html2canvasModule.default;

//       setProgress(10);

//       // ── 1. Detect repeating header/footer via table.printTable structure ───
//       const printTable = element.querySelector('table.printTable, table[class*="printTable"]') as HTMLTableElement | null;
//       let headerCanvas: HTMLCanvasElement | null = null;
//       let footerCanvas: HTMLCanvasElement | null = null;
//       let contentElement = element;

//       if (printTable) {
//         const thead = printTable.querySelector('thead');
//         const tfoot = printTable.querySelector('tfoot');
//         const tbody = printTable.querySelector('tbody');

//         if (thead) {
//           headerCanvas = await html2canvas(thead, {
//             scale: 2,
//             useCORS: true,
//             allowTaint: false,
//             logging: false,
//             backgroundColor: '#ffffff',
//           });
//         }

//         if (tfoot) {
//           footerCanvas = await html2canvas(tfoot, {
//             scale: 2,
//             useCORS: true,
//             allowTaint: false,
//             logging: false,
//             backgroundColor: '#ffffff',
//           });
//         }

//         // If we have thead/tfoot, capture only the tbody for page slicing
//         if (tbody && (headerCanvas || footerCanvas)) {
//           contentElement = tbody as HTMLElement;
//         }
//       }

//       setProgress(20);

//       // ── 2. Capture the main content as a high-resolution canvas ────────────
//       const canvas = await html2canvas(contentElement, {
//         scale: 2,            // 2× gives ~144 dpi – good balance of quality/size
//         useCORS: true,       // allow cross-origin images (hospital logo, etc.)
//         allowTaint: false,
//         logging: false,
//         backgroundColor: '#ffffff',
//         scrollX: 0,
//         scrollY: -window.scrollY,
//         windowWidth: contentElement.scrollWidth,
//         windowHeight: contentElement.scrollHeight,
//         onclone: (_doc, clonedElement) => {
//           clonedElement.style.transform = 'none';
//           clonedElement.style.overflow = 'visible';
//         },
//       });

//       setProgress(60);
//       setStatus('rendering');

//       // ── 3. Calculate page dimensions ──────────────────────────────────────
//       const A4_WIDTH_MM = 210;
//       const A4_HEIGHT_MM = 297;
//       const MARGIN_MM = 10;

//       const usableWidth = A4_WIDTH_MM - MARGIN_MM * 2;
//       const usableHeight = A4_HEIGHT_MM - MARGIN_MM * 2;

//       const pdf = new jsPDF({
//         orientation: 'portrait',
//         unit: 'mm',
//         format: 'a4',
//         compress: true,
//       });

//       const canvasWidth = canvas.width;
//       const canvasHeight = canvas.height;

//       // Calculate header/footer heights in mm
//       const headerHeightMm = headerCanvas ? (headerCanvas.height / canvasWidth) * usableWidth : 0;
//       const footerHeightMm = footerCanvas ? (footerCanvas.height / canvasWidth) * usableWidth : 0;

//       // Usable content area per page (excluding header/footer)
//       const contentAreaHeight = usableHeight - headerHeightMm - footerHeightMm;

//       // How many canvas pixels fit in one content area?
//       const pageHeightCanvas = (contentAreaHeight * canvasWidth) / usableWidth;

//       const totalPages = Math.ceil(canvasHeight / pageHeightCanvas);

//       setProgress(70);

//       for (let page = 0; page < totalPages; page++) {
//         if (page > 0) pdf.addPage();

//         let currentY = MARGIN_MM;

//         // ── Add header on every page ────────────────────────────────────────
//         if (headerCanvas) {
//           const headerData = headerCanvas.toDataURL('image/jpeg', 0.92);
//           pdf.addImage(headerData, 'JPEG', MARGIN_MM, currentY, usableWidth, headerHeightMm);
//           currentY += headerHeightMm;
//         }

//         // ── Add content slice ───────────────────────────────────────────────
//         const sliceCanvas = document.createElement('canvas');
//         const sliceHeight = Math.min(pageHeightCanvas, canvasHeight - page * pageHeightCanvas);
//         sliceCanvas.width = canvasWidth;
//         sliceCanvas.height = sliceHeight;

//         const ctx = sliceCanvas.getContext('2d');
//         if (ctx) {
//           ctx.fillStyle = '#ffffff';
//           ctx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
//           ctx.drawImage(
//             canvas,
//             0, page * pageHeightCanvas,
//             canvasWidth, sliceHeight,
//             0, 0,
//             canvasWidth, sliceHeight,
//           );
//         }

//         const contentData = sliceCanvas.toDataURL('image/jpeg', 0.92);
//         const contentHeightMm = (sliceHeight / canvasWidth) * usableWidth;
//         pdf.addImage(contentData, 'JPEG', MARGIN_MM, currentY, usableWidth, contentHeightMm);
//         currentY += contentHeightMm;

//         // ── Add footer on every page ────────────────────────────────────────
//         if (footerCanvas) {
//           // Position footer at bottom of page
//           const footerY = A4_HEIGHT_MM - MARGIN_MM - footerHeightMm;
//           const footerData = footerCanvas.toDataURL('image/jpeg', 0.92);
//           pdf.addImage(footerData, 'JPEG', MARGIN_MM, footerY, usableWidth, footerHeightMm);
//         }

//         setProgress(70 + Math.round(((page + 1) / totalPages) * 28));
//       }

//       setProgress(98);

//       const blob = pdf.output('blob');

//       setProgress(100);
//       setStatus('done');

//       return blob;
//     } catch (err) {
//       setStatus('error');
//       throw err;
//     }
//   }, []);

//   return { progress, status, generatePdf, reset };
// }
