// ─── Global Shared Types ───────────────────────────────────────────────────

export interface PatientInfo {
  name: string;
  age: string | number;
  birthDate: string;
  gender: string;
  address: string;
  patientId?: string;
}

export interface VisitDetails {
  visitType: string;
  location: string;
  startDatetime: string;
}

export interface VitalSigns {
  temperature?: string;
  bloodPressure?: string;
  heartRate?: string;
  respiratoryRate?: string;
  oxygenSaturation?: string;
  height?: string;
  weight?: string;
  bmi?: string;
  dateRecorded?: string;
}

export interface Orders {
  uuid?: string;
  orderType: {
    name: string;
  };
  drug?: {
    display: string;
  };
  dose?: number | string;
  doseUnits?: {
    display: string;
  };
  frequency?: {
    display: string;
  };
  route?: {
    display: string;
  };
  duration?: number | string;
  durationUnits?: {
    display: string;
  };
  orderer?: {
    display: string;
  };
  dosingInstructions?: string;
  dateActivated?: string;
  scheduledDate?: string;
  display?: string;
  urgency?: string;
  instructions?: string;
  auditInfo?: {
    dateCreated: string;
  };
}

// ─── Vitals / FHIR Types ──────────────────────────────────────────────────

export interface VitalCoding {
  system?: string;
  code: string;
  display?: string;
}

export interface VitalCode {
  coding: VitalCoding[];
  text: string;
}

export interface VitalQuantity {
  value: number;
  unit: string;
  system?: string;
  code: string;
}

export interface ReferenceRange {
  low?: {
    value: number;
  };
  high?: {
    value: number;
  };
  type: {
    coding: {
      system: string;
      code: string;
    }[];
  };
}

export interface VitalObservation {
  resourceType: string;
  id: string;
  status: string;
  code: VitalCode;
  effectiveDateTime: string;
  valueQuantity: VitalQuantity;
  referenceRange: ReferenceRange[];
}

export interface VitalsData {
  diastolicBP?: {
    value: number;
    status: string;
  };
  systolicBP?: {
    value: number;
    status: string;
  };
  temperature?: {
    value: number;
    status: string;
  };
  pulse?: {
    value: number;
    status: string;
  };
  generalNote?: {
    value: number;
    status: string;
  };
  respiratoryRate?: {
    value: number;
    status: string;
  };
  oxygenSaturation?: {
    value: number;
    status: string;
  };
}

export interface BiometricsData {
  weight?: number;
  height?: number;
  bmi?: number;
  muac?: number;
  effectiveDate?: string;
}

export interface VitalsMain {
  entry: Array<{
    resource: VitalObservation;
  }>;
}

// ─── Conditions / FHIR Types ─────────────────────────────────────────────

export interface PatientConditions {
  entry: Array<{
    resource: ConditionObservation;
  }>;
}

export interface ConditionObservation {
  resourceType: string;
  id: string;
  status: string;
  code: {
    coding: {
      display: string;
    }[];
  };
  clinicalStatus: {
    coding: {
      code: string;
    }[];
  };
  onsetDateTime: string;
}

export interface ConditionsData {
  condition?: string;
  clinicalStatus?: string;
  onsetDate?: string;
}

// ─── Encounter / Diagnosis Types ─────────────────────────────────────────

export interface PatientEncounter {
  encounters: {
    diagnoses: {
      display: string;
    }[];
    obs: {
      concept: {
        uuid: string;
      };
      value: string;
    }[];
  }[];
}

export interface DiagnosisData {
  diagnosisName: string;
}

export interface ClinicalNote {
  note: string;
}