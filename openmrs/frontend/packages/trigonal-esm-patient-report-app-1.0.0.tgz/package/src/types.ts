interface PatientInfo {
  name: string;
  age: string | number;
  birthDate: string;
  gender: string;
  address: string;
}

interface VisitDetails {
  visitType: string;
  location: string;
  startDatetime: string;
}

interface VitalSigns {
  temperature?: string;
  bloodPressure?: string;
  heartRate?: string;
  respiratoryRate?: string;
  oxygenSaturation?: string;
  height?: string;
  weight?: string;
  bmi?: string;
  dateRecorded?: string;
}

interface Orders {
  orderType: {
    name: string;
  };
  drug: {
    display: string;
  };
  dose: number;
  doseUnits: {
    display: string;
  };
  frequency: {
    display: string;
  };
  route: {
    display: string;
  };
  duration: number;
  durationUnits: {
    display: string;
  };
  dosingInstructions?: string;
  dateActivated?: string;
  scheduledDate?: string;
  display?: string;
  urgency?: string;
  instructions?: string;
  auditInfo?: {
    dateCreated: string;
  }
}
interface VitalCoding {
  system?: string;
  code: string;
  display?: string;
}

interface VitalCode {
  coding: VitalCoding[];
  text: string;
}

interface VitalQuantity {
  value: number;
  unit: string;
  system?: string;
  code: string;
}

interface ReferenceRange {
  low?: {
    value: number;
  };
  high?: {
    value: number;
  };
  type: {
    coding: {
      system: string;
      code: string;
    }[];
  };
}

interface VitalObservation {
  resourceType: string;
  id: string;
  status: string;
  code: VitalCode;
  effectiveDateTime: string;
  valueQuantity: VitalQuantity;
  referenceRange: ReferenceRange[];
}

// interface VitalsData {
//   diastolicBP?: number;
//   systolicBP?: number;
//   temperature?: number;
//   pulse?: number;
//   generalNote?: string;
//   respiratoryRate?: number;
//   oxygenSaturation?: number;
// }

interface VitalsData {
  diastolicBP?: {
    value: number;
    status: string;
  }
  systolicBP?: {
    value: number;
    status: string;
  };
  temperature?: {
    value: number;
    status: string;
  };
  pulse?: {
    value: number;
    status: string;
  };
  generalNote?: {
    value: number;
    status: string;
  };
  respiratoryRate?: {
    value: number;
    status: string;
  };
  oxygenSaturation?: {
    value: number;
    status: string;
  };
}

interface BiometricsData {
  weight?: number;
  height?: number;
  bmi?: number;
  muac?: number;
  effectiveDate?: string;
}

interface VitalsMain {
  entry: Array<{
    resource: VitalObservation;
  }>;
}

interface PatientConditions {
  entry: Array<{
    resource: ConditionObservation;
  }>;
}

interface ConditionObservation {
  resourceType: string;
  id: string;
  status: string;
  code: {
    coding: {
          display: string;
        }[];
  };
  clinicalStatus: {
    coding: {
      code: string;
    }[]
  }
  onsetDateTime: string;
}

interface ConditionsData {
  condition?: string;
  clinicalStatus?: string;
  onsetDate?: string;
}

interface PatientEncounter {
  encounters: {
    diagnoses: {
      display: string;
    }[]
    obs: {
      concept: {
        uuid: string;
      };
      value: string;
    }[]
  }[]
}

interface DiagnosisData {
  diagnosisName: string;
}

interface ClinicalNote {
  note: string;
}