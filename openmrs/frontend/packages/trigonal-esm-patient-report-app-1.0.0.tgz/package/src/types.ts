/**
 * @file types.ts
 *
 * Shared TypeScript interfaces and types for the patient-report module.
 *
 * Sections:
 *  1. Core domain types (patient, visit, orders)
 *  2. Vitals / FHIR types
 *  3. Conditions / FHIR types
 *  4. Encounter / Observation types  ← replaces the heavy use of `any` in hooks
 *  5. Diagnosis types
 *  6. Patient identifier types
 */

// ─── 1. Core Domain Types ────────────────────────────────────────────────────

export interface PatientInfo {
  name: string;
  age: string | number;
  birthDate: string;
  gender: string;
  address: string;
  patientId?: string;
  nhisNumber?: string;
  ssfId?: string;
}

export interface VisitDetails {
  visitType: string;
  location: string;
  startDatetime: string;
}

/** @deprecated Kept for backward compatibility — prefer VitalsData */
export interface VitalSigns {
  temperature?: string;
  bloodPressure?: string;
  heartRate?: string;
  respiratoryRate?: string;
  oxygenSaturation?: string;
  height?: string;
  weight?: string;
  bmi?: string;
  dateRecorded?: string;
}

export interface Orders {
  uuid?: string;
  orderType: { name: string };
  drug?: { display: string };
  dose?: number | string;
  doseUnits?: { display: string };
  frequency?: { display: string };
  route?: { display: string };
  duration?: number | string;
  durationUnits?: { display: string };
  orderer?: { display: string };
  dosingInstructions?: string;
  dateActivated?: string | number;
  scheduledDate?: string;
  display?: string;
  urgency?: string;
  instructions?: string;
  auditInfo?: { dateCreated: string };
  /** UUID of the associated concept (e.g. test or procedure concept) */
  conceptUuid?: string | null;
  /** UUID of the encounter this order belongs to */
  encounterUuid?: string | null;
}

// ─── 2. Vitals / FHIR Types ──────────────────────────────────────────────────

export interface VitalCoding {
  system?: string;
  code: string;
  display?: string;
}

export interface VitalCode {
  coding: VitalCoding[];
  text: string;
}

export interface VitalQuantity {
  value: number;
  unit: string;
  system?: string;
  code: string;
}

export interface ReferenceRange {
  low?: { value: number };
  high?: { value: number };
  type: { coding: { system: string; code: string }[] };
}

export interface VitalObservation {
  resourceType: string;
  id: string;
  status: string;
  code: VitalCode;
  effectiveDateTime: string;
  valueQuantity: VitalQuantity;
  referenceRange: ReferenceRange[];
}

export interface VitalReading {
  value: number;
  status: string;
}

export interface VitalsData {
  diastolicBP?: VitalReading;
  systolicBP?: VitalReading;
  temperature?: VitalReading;
  pulse?: VitalReading;
  generalNote?: VitalReading;
  respiratoryRate?: VitalReading;
  oxygenSaturation?: VitalReading;
}

export interface BiometricsData {
  weight?: number;
  height?: number;
  bmi?: number;
  muac?: number;
  effectiveDate?: string;
}

export interface VitalsMain {
  entry: Array<{ resource: VitalObservation }>;
}

// ─── 3. Conditions / FHIR Types ──────────────────────────────────────────────

export interface PatientConditions {
  entry: Array<{ resource: ConditionObservation }>;
}

export interface ConditionObservation {
  resourceType: string;
  id: string;
  status: string;
  code: { coding: { display: string }[] };
  clinicalStatus: { coding: { code: string }[] };
  onsetDateTime: string;
}

export interface ConditionsData {
  condition?: string;
  clinicalStatus?: string;
  onsetDate?: string;
}

// ─── 4. Encounter / Observation Types ────────────────────────────────────────

/**
 * A single OpenMRS identifier as returned by the REST API.
 * e.g. { display: "OpenMRS ID = 10001" }
 */
export interface PatientIdentifierRaw {
  display: string;
  uuid?: string;
}

/** A parsed patient identifier with both raw display and split value. */
export interface ParsedPatientIdentifier {
  display: string;
  value: string;
}

/** Structured identifiers extracted from raw OpenMRS identifier list. */
export interface PatientIdentifiers {
  openMrsId?: string;
  hospitalNumber?: string;
  nhisNumber?: string;
  ssfId?: string;
  insuranceNumber?: string;
}

/**
 * A single observation as returned by the OpenMRS REST API.
 * Covers both flat obs and grouped obs (groupMembers).
 */
export interface ObsRaw {
  uuid: string;
  concept: {
    uuid: string;
    display?: string;
    conceptClass?: { uuid?: string; display?: string };
  };
  /** Can be a primitive, a coded object, or null */
  value: string | number | null | { uuid: string; display: string };
  display?: string;
  obsDatetime: string;
  order?: { uuid: string };
  groupMembers?: ObsRaw[];
}

/**
 * A single OpenMRS encounter as returned by the ENCOUNTER_FULL custom rep.
 * Used by usePatientSummary, useInsuranceDischargeSummaryData, useVisitSummaryData.
 */
export interface EncounterFull {
  uuid: string;
  display?: string;
  encounterDatetime: string;
  encounterType?: { uuid: string; display: string };
  form?: { uuid: string; name: string; display?: string };
  visit?: {
    uuid: string;
    startDatetime: string;
    stopDatetime?: string | null;
    location?: { display: string };
  };
  patient?: {
    uuid: string;
    display?: string;
    identifiers?: PatientIdentifierRaw[];
    person?: PersonRaw;
  };
  obs: ObsRaw[];
  diagnoses?: EncounterDiagnosisRaw[];
  encounterProviders?: EncounterProviderRaw[];
}

/**
 * Encounter shape returned by the ENCOUNTER_WITH_PATIENT_OBS rep
 * (custom /nidan/encounter endpoint). Used by useDischargeSummaryData,
 * useReferralReportData, useInsuranceReferralReportData.
 */
export interface EncounterWithPatientObs {
  uuid: string;
  display?: string;
  encounterDatetime: string;
  form?: { uuid: string; name: string; display?: string };
  visit?: {
    uuid?: string;
    startDatetime?: string;
    stopDatetime?: string | null;
    location?: { display: string };
  };
  patient?: {
    uuid: string;
    display?: string;
    identifiers?: PatientIdentifierRaw[];
    person?: PersonRaw;
  };
  obs: ObsRaw[];
  diagnoses?: Array<{ display?: string; diagnosis?: { display?: string } }>;
  encounterProviders?: EncounterProviderRaw[];
  location?: { display: string };
}

/**
 * A single provider attribute as returned by the OpenMRS REST API.
 * Used to extract typed attributes (e.g. Medical Council Number) from a provider.
 */
export interface ProviderAttributeRaw {
  attributeType: { uuid: string };
  value: string;
  voided?: boolean;
}

/**
 * Provider as returned by encounterProviders in REST responses.
 */
export interface EncounterProviderRaw {
  provider?: {
    uuid?: string;
    display?: string;
    person?: { display?: string };
    attributes?: ProviderAttributeRaw[];
  };
}

/**
 * A diagnosis as returned on an encounter object from the REST API.
 */
export interface EncounterDiagnosisRaw {
  uuid?: string;
  display?: string;
  rank?: number | string;
  certainty?: string;
  voided?: boolean;
  diagnosis?: {
    uuid?: string;
    display?: string;
    coded?: { uuid?: string; display?: string };
    nonCoded?: string;
  };
}

/**
 * Person sub-object returned inside patient REST responses.
 */
export interface PersonRaw {
  uuid?: string;
  display?: string;
  gender?: string;
  age?: number;
  birthdate?: string;
  preferredName?: { display: string };
}

/**
 * A FHIR Observation entry (used for chief complaint and vitals FHIR queries).
 */
export interface FhirObservationEntry {
  resource: {
    uuid?: string;
    effectiveDateTime?: string;
    valueString?: string;
    valueQuantity?: { value: number; unit?: string };
    code?: { coding?: Array<{ code?: string; display?: string }> };
    concept?: { uuid?: string };
  };
}

/** The FHIR Bundle response shape returned by /ws/fhir2/R4/Observation */
export interface FhirObservationBundle {
  entry?: FhirObservationEntry[];
  total?: number;
}

/**
 * Minimal vitals obs shape from the REST /obs endpoint
 * (used by useInsuranceReferralReportData to fetch vitals).
 */
export interface VitalsObsRaw {
  uuid: string;
  concept: { uuid: string };
  value: number | string | null;
  obsDatetime: string;
}

/** Response shape for the REST /obs list endpoint */
export interface VitalsObsResponse {
  results: VitalsObsRaw[];
}

/** Response shape for the standard /beds endpoint */
export interface BedResult {
  bedNumber?: string;
  bedType?: { displayName?: string; name?: string };
}

export interface BedsApiResponse {
  results: BedResult[];
}

// ─── 5. Diagnosis Types ───────────────────────────────────────────────────────

/** Minimal diagnosis shape for display in report documents */
export interface DiagnosisData {
  diagnosisName: string;
  rank?: number | string;
  certainty?: string;
}

/**
 * Enriched diagnosis that also carries encounter-level metadata.
 * Used when building diagnosis tables in document components.
 */
export interface DiagnosisWithMeta extends DiagnosisData {
  encounterDatetime?: string;
  providerName?: string;
}

export interface ClinicalNote {
  note: string;
}

// ─── 6. Deprecated / Legacy ───────────────────────────────────────────────────

/**
 * @deprecated Use EncounterFull instead
 * Kept for any legacy consumers outside this module.
 */
export interface PatientEncounter {
  encounters: {
    diagnoses: { display: string }[];
    obs: { concept: { uuid: string }; value: string }[];
  }[];
}
