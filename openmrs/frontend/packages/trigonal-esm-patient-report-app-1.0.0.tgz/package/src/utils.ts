import { openmrsFetch } from '@openmrs/esm-framework';

/**
 * Standard O3 SWR fetcher — pass directly as the fetcher argument to useSWR.
 * Returns response.data so hooks receive the typed payload directly.
 */
export const openmrsFetcher = <T>(url: string): Promise<T> =>
  openmrsFetch<T>(url).then((res) => res.data);

/**
 * Process vitals observation data and determine status based on reference ranges
 */
export function vitalsDataStatus(value: number, referenceRange: { low?: { value: number }; high?: { value: number } }): string {
  let valueStatus = '';
  if (referenceRange && value !== undefined) {
    const lowValue = referenceRange.low?.value;
    const highValue = referenceRange.high?.value;

    if (lowValue !== undefined && value < lowValue) {
      valueStatus = 'low';
    } else if (highValue !== undefined && value > highValue) {
      valueStatus = 'high';
    } else {
      valueStatus = 'normal';
    }
  }

  return valueStatus;
}

/**
 * Calculate BMI from height and weight
 */
export function calculateBMI(weight: number, height: number): number | null {
  if (!weight || !height) return null;
  return parseFloat(((weight / Math.pow(height, 2)) * 10000).toFixed(1));
}

/**
 * Calculate age from birth date
 */
export function calculateAge(birthDate: string): string {
  if (!birthDate) return 'Unknown';
  
  const currentDate = new Date();
  const birthDateObj = new Date(birthDate);
  let age = currentDate.getFullYear() - birthDateObj.getFullYear();

  if (
    currentDate.getMonth() < birthDateObj.getMonth() ||
    (currentDate.getMonth() === birthDateObj.getMonth() && currentDate.getDate() < birthDateObj.getDate())
  ) {
    age--;
  }

  return age.toString();
}

/**
 * Format date for display (e.g., 11 May 2026)
 */
export function formatDisplayDate(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'long' });
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
}

/**
 * Format date and time for display
 */
export function formatDisplayDateTime(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    return date.toLocaleString();
}

/**
 * Format time only for display
 */
export function formatDisplayTime(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Capitalize the first letter of a string
 */
export function capitalizeFirstLetter(text?: string): string {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

/**
 * Capitalize the first letter of every word in a string
 */
export function capitalizeWords(text?: string): string {
    if (!text) return '';
    return text
        .split(' ')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
}

/**
 * Shared obs extraction helper — replaces the duplicate local function across
 * useDeathNoteData, useNewbornAdmissionData, useReferralReportData, useDischargeSummaryData.
 *
 * Searches obs array by conceptUuid first, falls back to conceptDisplay match.
 * Handles coded (object with .display) and primitive values.
 */
export function extractObsValue(
  obs: Array<{ concept: { uuid?: string; display?: string }; value: any }> | undefined,
  conceptUuid: string,
  conceptDisplay?: string,
): string | undefined {
  if (!obs) return undefined;
  const match = obs.find(
    (o) =>
      (conceptUuid && o.concept?.uuid === conceptUuid) ||
      (conceptDisplay && o.concept?.display === conceptDisplay),
  );
  if (!match) return undefined;
  return typeof match.value === 'object' && match.value?.display ? match.value.display : match.value;
}
