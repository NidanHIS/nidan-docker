import { openmrsFetch, parseDate, formatDate, formatDatetime } from '@openmrs/esm-framework';

/**
 * Standard O3 SWR fetcher — pass directly as the fetcher argument to useSWR.
 * Returns response.data so hooks receive the typed payload directly.
 */
export const openmrsFetcher = <T>(url: string): Promise<T> =>
  openmrsFetch<T>(url).then((res) => res.data);

/**
 * Extract the Nepali (BS) date portion from a date value, formatting it first
 * via the OpenMRS framework so the Nepali calendar module (if active) can inject
 * the BS date portion.
 *
 * Accepts:
 *  - A raw ISO / OpenMRS datetime string  (e.g. "2026-07-26T10:30:00.000+0545")
 *  - An epoch millisecond number
 *  - An already-formatted string          (e.g. "26-Jul-2026 (BS 2083-04-10)")
 *  - null / undefined → returns '--'
 *
 * When the Nepali calendar module is loaded, formatDate returns strings like:
 *   "26-Jul-2026 (BS 2083-04-10)"
 *
 * This helper returns just the BS date portion ("BS 2083-04-10") when present,
 * otherwise returns the English date with any time component stripped.
 */
export function nepaliDateOnly(dateVal?: string | number | null): string {
  if (dateVal === null || dateVal === undefined || dateVal === '' || dateVal === '--') {
    return '--';
  }

  // Format via the framework so the Nepali calendar module can produce the BS suffix
  const formatted = safeFormatDate(dateVal);
  if (!formatted || formatted === '--') return '--';

  // Match "(BS YYYY-MM-DD)" anywhere in the formatted string
  const bsMatch = formatted.match(/\(BS\s+(\d{4}-\d{2}-\d{2})\)/);
  if (bsMatch) return `BS ${bsMatch[1]}`;

  // No BS portion — return the English date, stripping any time component
  return formatted.split(',')[0].trim();
}

/**
 * Safely format any date value (ISO string, epoch number, or pre-formatted string)
 * using the framework's formatDate for consistent Nepali calendar / locale support.
 * Returns '--' for null/undefined/unparseable values.
 */
export function safeFormatDate(dateVal?: string | number | null): string {
  if (!dateVal) return '--';
  try {
    // Handle epoch milliseconds (number or pure-numeric string from OpenMRS API)
    const asNumber = typeof dateVal === 'number' ? dateVal : Number(dateVal);
    if (!isNaN(asNumber) && asNumber > 100000) {
      return formatDate(new Date(asNumber), { time: false, noToday: true });
    }
  } catch (e) {
    // ignore
  }
  try {
    // Handle ISO / standard date strings via the framework parser
    const parsed = parseDate(String(dateVal));
    if (parsed instanceof Date && !isNaN(parsed.getTime())) {
      return formatDate(parsed, { time: false, noToday: true });
    }
  } catch (e) {
    // ignore
  }
  try {
    const nativeDate = new Date(String(dateVal));
    if (!isNaN(nativeDate.getTime())) {
      return formatDate((nativeDate), { noToday: true });
    }
  } catch (e) {
    // ignore
  }
  return '--';
}

/**
 * Process vitals observation data and determine status based on reference ranges
 */
export function vitalsDataStatus(value: number, referenceRange: { low?: { value: number }; high?: { value: number } }): string {
  let valueStatus = '';
  if (referenceRange && value !== undefined) {
    const lowValue = referenceRange.low?.value;
    const highValue = referenceRange.high?.value;

    if (lowValue !== undefined && value < lowValue) {
      valueStatus = 'low';
    } else if (highValue !== undefined && value > highValue) {
      valueStatus = 'high';
    } else {
      valueStatus = 'normal';
    }
  }

  return valueStatus;
}

/**
 * Calculate BMI from height and weight
 */
export function calculateBMI(weight: number, height: number): number | null {
  if (!weight || !height) return null;
  return parseFloat(((weight / Math.pow(height, 2)) * 10000).toFixed(1));
}

/**
 * Calculate age from birth date
 */
export function calculateAge(birthDate: string): string {
  if (!birthDate) return 'Unknown';

  const currentDate = new Date();
  const birthDateObj = new Date(birthDate);
  let age = currentDate.getFullYear() - birthDateObj.getFullYear();

  if (
    currentDate.getMonth() < birthDateObj.getMonth() ||
    (currentDate.getMonth() === birthDateObj.getMonth() && currentDate.getDate() < birthDateObj.getDate())
  ) {
    age--;
  }

  return age.toString();
}

/**
 * Format date for display (e.g., 11 May 2026)
 */
export function formatDisplayDate(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'long' });
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
}

/**
 * Format date and time for display
 */
export function formatDisplayDateTime(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleString();
}

/**
 * Format time only for display
 */
export function formatDisplayTime(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Capitalize the first letter of a string
 */
export function capitalizeFirstLetter(text?: string): string {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

/**
 * Capitalize the first letter of every word in a string
 */
export function capitalizeWords(text?: string): string {
  if (!text) return '';
  return text
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Shared obs extraction helper — replaces the duplicate local function across
 * useDeathNoteData, useNewbornAdmissionData, useReferralReportData, useDischargeSummaryData.
 *
 * Searches obs array by conceptUuid first, falls back to conceptDisplay match.
 * Handles coded (object with .display) and primitive values.
 */
export function extractObsValue(
  obs: Array<{ concept: { uuid?: string; display?: string }; value: any }> | undefined,
  conceptUuid: string,
  conceptDisplay?: string,
): string | undefined {
  if (!obs) return undefined;
  const match = obs.find(
    (o) =>
      (conceptUuid && o.concept?.uuid === conceptUuid) ||
      (conceptDisplay && o.concept?.display === conceptDisplay),
  );
  if (!match) return undefined;
  return typeof match.value === 'object' && match.value?.display ? match.value.display : match.value;
}

// ─── Obs Display Helpers ──────────────────────────────────────────────────────

/**
 * Regex constants for identifying date/datetime string values in obs.
 * Exported so document components can import them rather than redefine them.
 */
export const ISO_DATE_ONLY_REGEX = /^\d{4}-\d{2}-\d{2}$/;
export const ISO_DATETIME_REGEX = /^\d{4}-\d{2}-\d{2}T/;

/**
 * Normalise an OpenMRS observation value to a display string.
 * Handles all value shapes returned by the REST API:
 *   - primitives (string, number)
 *   - coded values: { uuid, display } or { uuid, name: { name } }
 *   - panel group member obs objects that carry their own display field
 * Returns '--' for null / undefined / unrecognised shapes.
 */
export type ObservationValue =
  | string
  | number
  | null
  | undefined
  | { display?: string; name?: string | { name?: string }; uuid?: string };

export function getObservationDisplayValue(value: ObservationValue): string {
  if (value === null || value === undefined) return '--';
  if (typeof value === 'string') return value || '--';
  if (typeof value === 'number') return value.toString();
  if (typeof value === 'object') {
    if ('display' in value && value.display) return value.display;
    if ('name' in value) {
      const n = value.name;
      if (typeof n === 'string') return n;
      if (n && typeof n === 'object' && 'name' in n && n.name) return n.name;
    }
  }
  return '--';
}

/**
 * Extract the answer portion from an OpenMRS obs display string.
 *
 * OpenMRS returns obs.display in the format "Concept Name: Answer Value".
 * This function returns the text after the first colon, trimmed.
 * Returns an empty string if no colon is present.
 *
 * @example
 * getAnswerFromDisplay('Blood Pressure: 120/80') // → '120/80'
 */
export function getAnswerFromDisplay(display: string): string {
  const colonIndex = display.indexOf(':');
  if (colonIndex === -1) return '';
  return display.substring(colonIndex + 1).trim();
}

/**
 * Resolve a single obs to a human-readable display string.
 *
 * Handles three cases:
 *  - Date string values → formatted via the framework's formatDate (Nepali calendar aware)
 *  - Datetime string values → formatted via formatDatetime
 *  - Everything else → extracted from obs.display via getAnswerFromDisplay
 *
 * Used in the Observations (Form Data) tables rendered in document components.
 */
export function getObsValue(obs: {
  concept?: { conceptClass?: { display?: string } };
  value?: unknown;
  display?: string;
}): string {
  const conceptClass = obs.concept?.conceptClass?.display;
  if (typeof obs.value === 'string' && obs.value) {
    if (conceptClass === 'Date' || ISO_DATE_ONLY_REGEX.test(obs.value)) {
      return formatDate(parseDate(obs.value), { mode: 'wide', time: false, noToday: true });
    }
    if (conceptClass === 'Datetime' || ISO_DATETIME_REGEX.test(obs.value)) {
      return formatDatetime(parseDate(obs.value), { mode: 'wide', noToday: true });
    }
  }
  return getAnswerFromDisplay(obs.display ?? '');
}

// ─── Document Date Formatting ─────────────────────────────────────────────────

/**
 * Render a full datetime string using the OpenMRS framework formatter.
 * Handles both ISO strings and epoch milliseconds as input.
 * Returns an empty string for falsy input.
 *
 * Used in document components that need "date + time" display (e.g. encounter tables).
 */
export function renderDateTime(dateStr?: string | number | null): string {
  if (!dateStr) return '';
  try {
    const d = typeof dateStr === 'number' ? new Date(dateStr) : parseDate(String(dateStr));
    return formatDatetime(d, { mode: 'wide', noToday: true });
  } catch {
    return String(dateStr);
  }
}

/**
 * Render a date-only string (no time component) using the OpenMRS framework formatter.
 * Handles both ISO strings and epoch milliseconds as input.
 * Returns an empty string for falsy input.
 *
 * Used in document components that need "date only" display (e.g. order tables).
 */
export function renderDateOnly(dateStr?: string | number | null): string {
  if (!dateStr) return '';
  try {
    const d = typeof dateStr === 'number' ? new Date(dateStr) : parseDate(String(dateStr));
    return formatDate(d, { mode: 'wide', time: false, noToday: true });
  } catch {
    return String(dateStr);
  }
}

// ─── FHIR Helpers ─────────────────────────────────────────────────────────────

/**
 * Convert an OpenMRS datetime string to a valid FHIR dateTime string.
 *
 * OpenMRS returns offsets without a colon separator, e.g. `2024-05-01T08:30:00.000+0545`.
 * FHIR requires a colon in the offset: `2024-05-01T08:30:00.000+05:45`.
 * This function inserts the colon when missing and strips milliseconds so the
 * resulting string matches the FHIR dateTime regex: YYYY-MM-DDTHH:mm:ss+HH:MM
 *
 * Returns undefined if the input is falsy or cannot be parsed.
 */
export function toFhirDateTime(dateStr?: string | null): string | undefined {
  if (!dateStr) return undefined;
  // Coerce to string in case a non-string value (e.g. number) slips through
  const str = String(dateStr);
  // Normalise offset: match ±HHMM at end (no colon) and insert colon → ±HH:MM
  const normalised = str.replace(/([+-])(\d{2})(\d{2})$/, '$1$2:$3');
  const date = new Date(normalised);
  if (isNaN(date.getTime())) return undefined;
  // Return as ISO 8601 with the normalised offset (keep original offset, not UTC)
  // Re-use the normalised string but strip milliseconds for a cleaner FHIR value
  return normalised.replace(/\.\d{1,3}(?=[+-Z])/, '');
}

// ─── Patient Identifier Helpers ───────────────────────────────────────────────

/**
 * Extract the value portion from a raw OpenMRS identifier display string.
 *
 * OpenMRS returns identifiers as `{ display: "Label = Value" }`.
 * This function splits on `=` and returns the trimmed right-hand side.
 * Returns an empty string when no `=` is present.
 *
 * @example
 * parseIdentifierValue('OpenMRS ID = 10001') // → '10001'
 */
export function parseIdentifierValue(display: string): string {
  const eqIndex = display.indexOf('=');
  if (eqIndex === -1) return '';
  return display.substring(eqIndex + 1).trim();
}

/**
 * Extract well-known patient identifiers from the raw identifier array returned
 * by the OpenMRS REST API.
 *
 * The matching is done case-insensitively on the display label portion
 * (before the `=` sign), so it is resilient to minor label variations.
 *
 * This replaces the repeated `identifiers.find(...)` chains that existed
 * independently in useInsuranceDischargeSummaryData, useInsuranceReferralReportData,
 * useDischargeSummaryData, and useReferralReportData.
 *
 * @param identifiers - Raw identifier array from the patient REST response
 * @returns Structured object with each known identifier type (undefined when absent)
 *
 * @example
 * const { hospitalNumber, nhisNumber } = extractPatientIdentifiers(patient.identifiers);
 */
export function extractPatientIdentifiers(
  identifiers: Array<{ display: string }> | undefined,
): import('./types').PatientIdentifiers {
  if (!identifiers?.length) return {};

  const find = (predicate: (label: string) => boolean): string | undefined => {
    const match = identifiers.find((id) => {
      const label = id.display.split('=')?.[0]?.trim().toLowerCase() ?? '';
      return predicate(label);
    });
    return match ? parseIdentifierValue(match.display) || undefined : undefined;
  };

  const openMrsId = find((l) => l.includes('openmrs id') || l.includes('openmrs'));
  const hospitalNumber = find((l) => l.includes('hospital number') || l.includes('hospital no'));
  const nhisNumber = find((l) => l.includes('nhis'));
  const ssfId = find((l) => l.includes('ssf id') || l.includes('ssf'));

  return {
    openMrsId,
    hospitalNumber,
    nhisNumber,
    ssfId,
    // SSF ID is also exposed as insuranceNumber in the referral report
    insuranceNumber: ssfId,
  };
}

/**
 * Extract the display name of the first encounter provider.
 *
 * OpenMRS returns provider info nested as:
 *   encounterProviders[0].provider.person.display  (preferred)
 *   encounterProviders[0].provider.display          (fallback)
 *
 * This helper centralises the two-step optional-chain lookup.
 *
 * @param encounterProviders - The encounterProviders array from an encounter object
 * @returns Provider display name, or undefined when not present
 */
export function getEncounterProviderName(
  encounterProviders: Array<{
    provider?: { person?: { display?: string }; display?: string };
  }> | undefined,
): string | undefined {
  const provider = encounterProviders?.[0]?.provider;
  return provider?.person?.display ?? provider?.display ?? undefined;
}

/**
 * Build a provider display string that includes the Medical Council Number
 * when available, formatted as "Doctor Name (NMC123)".
 *
 * Falls back to just the provider name when no matching attribute is found,
 * and to undefined when no provider is present at all.
 *
 * The `medicalCouncilNumberAttributeTypeUuid` comes from module config so it
 * can be overridden per deployment without a code rebuild.
 *
 * @param encounterProviders  - The encounterProviders array from an encounter object
 * @param nmcAttributeTypeUuid - UUID of the Medical Council Number attribute type
 * @returns "Name (NMC123)" or "Name" or undefined
 *
 * @example
 * const display = getEncounterProviderDisplay(enc.encounterProviders, nmcUuid);
 * // → "Dr. John Smith (NMC111)"
 */
export function getEncounterProviderDisplay(
  encounterProviders: Array<{
    provider?: {
      person?: { display?: string };
      display?: string;
      attributes?: Array<{ attributeType: { uuid: string }; value: string; voided?: boolean }>;
    };
  }> | undefined,
  nmcAttributeTypeUuid: string,
): string | undefined {
  const provider = encounterProviders?.[0]?.provider;
  if (!provider) return undefined;

  const name = provider.person?.display ?? provider.display;
  if (!name) return undefined;

  const nmcAttr = provider.attributes?.find(
    (a) => !a.voided && a.attributeType?.uuid === nmcAttributeTypeUuid,
  );

  return nmcAttr?.value ? `${name} (${nmcAttr.value})` : name;
}

/**
 * Extract a patient's address string from a FHIR Patient resource.
 *
 * Tries the Nepali-style extension first (valueString on the first extension),
 * then falls back to concatenating standard FHIR address fields.
 * Returns 'Unknown' when no address data is present.
 *
 * This replaces identical address extraction blocks in usePatientInfo and
 * useInsuranceDischargeSummaryData.
 *
 * @param address - The address array from a FHIR Patient resource
 */
export function extractFhirAddress(
  address: Array<{
    extension?: Array<{ extension?: Array<{ valueString?: string }> }>;
    line?: string[];
    city?: string;
    state?: string;
    country?: string;
    text?: string;
  }> | undefined,
  fallback = 'Unknown',
): string {
  const addr = address?.[0];
  if (!addr) return fallback;

  // Preferred: Nepali-style nested extension value
  const extVal = addr.extension?.[0]?.extension?.[0]?.valueString;
  if (extVal) return extVal;

  // Fallback: standard FHIR address fields
  const parts = [
    ...(addr.line ?? []),
    addr.city,
    addr.state,
    addr.country,
  ].filter(Boolean);

  return parts.join(', ') || addr.text || fallback;
}

// ─── Hook State Aggregation ───────────────────────────────────────────────────

/**
 * Aggregates the `isLoading` and `error` states from multiple SWR hooks into
 * a single pair, replacing the repetitive manual OR chains like:
 *
 * ```ts
 * // Before
 * isLoading: isALoading || isBLoading || isCLoading,
 * error: aError || bError || cError,
 *
 * // After
 * const { isLoading, error } = combineHookStates([
 *   { isLoading: isALoading, error: aError },
 *   { isLoading: isBLoading, error: bError },
 *   { isLoading: isCLoading, error: cError },
 * ]);
 * ```
 *
 * Returns `isLoading: true` when any slice is loading, and the first
 * non-null error when one is present (mirrors the previous OR behaviour).
 */
export function combineHookStates(
  slices: Array<{ isLoading: boolean; error?: Error | null | unknown }>,
): { isLoading: boolean; error: Error | null } {
  const isLoading = slices.some((s) => s.isLoading);
  const error = slices.find((s) => s.error != null)?.error ?? null;
  return { isLoading, error: error as Error | null };
}

// ─── Diagnosis Aggregation ────────────────────────────────────────────────────

/**
 * Aggregates and deduplicates diagnoses from an array of encounter objects.
 *
 * Each encounter in the array is expected to have a `diagnoses` array and
 * optional `encounterDatetime` / `encounterProviders` fields. The function:
 *  1. Flattens all non-voided diagnoses across encounters
 *  2. Deduplicates by diagnosis UUID (or by display text as fallback)
 *  3. Enriches each diagnosis with its encounter datetime and provider name
 *
 * This replaces the repeated diagnosis-flattening logic in:
 *  - usePatientSummary (diagnosisData memo)
 *  - useInsuranceDischargeSummaryData (allDiagnoses / uniqueDiagnoses)
 *  - useInsuranceReferralReportData (allDiagnoses provisionalDiagnosis)
 *
 * @param encounters - Array of encounter objects (EncounterFull or compatible shape)
 * @returns Deduplicated array of DiagnosisWithMeta
 */
export function extractDiagnosesFromEncounters(
  encounters: Array<{
    encounterDatetime?: string;
    encounterProviders?: Array<{
      provider?: { person?: { display?: string }; display?: string };
    }>;
    diagnoses?: Array<{
      uuid?: string;
      display?: string;
      rank?: number | string;
      certainty?: string;
      voided?: boolean;
      diagnosis?: {
        uuid?: string;
        display?: string;
        coded?: { uuid?: string; display?: string };
        nonCoded?: string;
      };
    }>;
  }>,
): import('./types').DiagnosisWithMeta[] {
  const seen = new Set<string>();
  const result: import('./types').DiagnosisWithMeta[] = [];

  for (const encounter of encounters) {
    const providerName = getEncounterProviderName(encounter.encounterProviders);

    for (const diagnosis of encounter.diagnoses ?? []) {
      if (diagnosis.voided) continue;

      // Prefer the diagnosis-level display; fall back to encounter-level display
      const name =
        diagnosis.diagnosis?.coded?.display ??
        diagnosis.diagnosis?.nonCoded ??
        diagnosis.diagnosis?.display ??
        diagnosis.display ??
        '';

      if (!name) continue;

      // Deduplicate: use diagnosis UUID when available, otherwise the name
      const dedupeKey = diagnosis.diagnosis?.uuid ?? diagnosis.uuid ?? name;
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);

      result.push({
        diagnosisName: name,
        rank: diagnosis.rank,
        certainty: diagnosis.certainty,
        encounterDatetime: encounter.encounterDatetime,
        providerName,
      });
    }
  }

  return result;
}

// ─── Error Handling ───────────────────────────────────────────────────────────

/**
 * Safely extracts a human-readable message from any error value.
 *
 * SWR errors can arrive as:
 *  - A standard `Error` object (most common)
 *  - A `Response` object when the fetch failed with an HTTP error status
 *  - A plain string
 *  - An unknown object shape
 *
 * Returns a sensible fallback string when the shape is not recognised.
 *
 * @example
 * const { error } = useSWR(url, fetcher);
 * if (error) console.error(getErrorMessage(error));
 */
export function getErrorMessage(error: unknown): string {
  if (!error) return '';
  if (typeof error === 'string') return error;
  if (error instanceof Error) return error.message;
  if (typeof error === 'object') {
    // HTTP Response shape (e.g. from openmrsFetch on non-2xx status)
    if ('statusText' in error && typeof (error as any).statusText === 'string') {
      return (error as any).statusText;
    }
    if ('message' in error && typeof (error as any).message === 'string') {
      return (error as any).message;
    }
  }
  return 'An unexpected error occurred.';
}
