
/**
 * Process vitals observation data and determine status based on reference ranges
 */
export function vitalsDataStatus(value, referenceRange) {  
  let valueStatus = '';
  if (referenceRange && value !== undefined) {
    const lowValue = referenceRange.low?.value;
    const highValue = referenceRange.high?.value;

    if (lowValue !== undefined && value < lowValue) {
      valueStatus = 'low';
    } else if (highValue !== undefined && value > highValue) {
      valueStatus = 'high';
    } else {
      valueStatus = 'normal';
    }
  }

  return valueStatus;
}

/**
 * Calculate BMI from height and weight
 */
export function calculateBMI(weight, height) {
  if (!weight || !height) return null;
  return parseFloat(((weight / Math.pow(height, 2)) * 10000).toFixed(1));
}

/**
 * Calculate age from birth date
 */
export function calculateAge(birthDate) {
  if (!birthDate) return 'Unknown';
  
  const currentDate = new Date();
  const birthDateObj = new Date(birthDate);
  let age = currentDate.getFullYear() - birthDateObj.getFullYear();

  if (
    currentDate.getMonth() < birthDateObj.getMonth() ||
    (currentDate.getMonth() === birthDateObj.getMonth() && currentDate.getDate() < birthDateObj.getDate())
  ) {
    age--;
  }

  return age.toString();
}

/**
 * Format date for display (e.g., 11 May 2026)
 */
export function formatDisplayDate(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'long' });
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
}

/**
 * Format date and time for display
 */
export function formatDisplayDateTime(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    return date.toLocaleString();
}

/**
 * Format time only for display
 */
export function formatDisplayTime(dateString?: string): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Capitalize the first letter of a string
 */
export function capitalizeFirstLetter(text?: string): string {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

/**
 * Capitalize the first letter of every word in a string
 */
export function capitalizeWords(text?: string): string {
    if (!text) return '';
    return text
        .split(' ')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
}
