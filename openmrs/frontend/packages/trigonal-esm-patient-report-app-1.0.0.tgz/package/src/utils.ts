import { openmrsFetch, parseDate, formatDate } from '@openmrs/esm-framework';

/**
 * Standard O3 SWR fetcher — pass directly as the fetcher argument to useSWR.
 * Returns response.data so hooks receive the typed payload directly.
 */
export const openmrsFetcher = <T>(url: string): Promise<T> =>
  openmrsFetch<T>(url).then((res) => res.data);

/**
 * Safely format any date value (ISO string, epoch number, or pre-formatted string)
 * using the framework's formatDate for consistent Nepali calendar / locale support.
 * Returns '--' for null/undefined/unparseable values.
 */
export function safeFormatDate(dateVal?: string | number | null): string {
  if (!dateVal) return '--';
  try {
    // Handle epoch milliseconds (number or pure-numeric string from OpenMRS API)
    const asNumber = typeof dateVal === 'number' ? dateVal : Number(dateVal);
    if (!isNaN(asNumber) && asNumber > 100000) {
      return formatDate(new Date(asNumber), { time: false, noToday: true });
    }
  } catch (e) {
    // ignore
  }
  try {
    // Handle ISO / standard date strings via the framework parser
    const parsed = parseDate(String(dateVal));
    if (parsed instanceof Date && !isNaN(parsed.getTime())) {
      return formatDate(parsed, { time: false, noToday: true });
    }
  } catch (e) {
    // ignore
  }
  try {
    const nativeDate = new Date(String(dateVal));
    if (!isNaN(nativeDate.getTime())) {
      return formatDate((nativeDate), { noToday: true });
    }
  } catch (e) {
    // ignore
  }
  return '--';
}

/**
 * Process vitals observation data and determine status based on reference ranges
 */
export function vitalsDataStatus(value: number, referenceRange: { low?: { value: number }; high?: { value: number } }): string {
  let valueStatus = '';
  if (referenceRange && value !== undefined) {
    const lowValue = referenceRange.low?.value;
    const highValue = referenceRange.high?.value;

    if (lowValue !== undefined && value < lowValue) {
      valueStatus = 'low';
    } else if (highValue !== undefined && value > highValue) {
      valueStatus = 'high';
    } else {
      valueStatus = 'normal';
    }
  }

  return valueStatus;
}

/**
 * Calculate BMI from height and weight
 */
export function calculateBMI(weight: number, height: number): number | null {
  if (!weight || !height) return null;
  return parseFloat(((weight / Math.pow(height, 2)) * 10000).toFixed(1));
}

/**
 * Calculate age from birth date
 */
export function calculateAge(birthDate: string): string {
  if (!birthDate) return 'Unknown';

  const currentDate = new Date();
  const birthDateObj = new Date(birthDate);
  let age = currentDate.getFullYear() - birthDateObj.getFullYear();

  if (
    currentDate.getMonth() < birthDateObj.getMonth() ||
    (currentDate.getMonth() === birthDateObj.getMonth() && currentDate.getDate() < birthDateObj.getDate())
  ) {
    age--;
  }

  return age.toString();
}

/**
 * Format date for display (e.g., 11 May 2026)
 */
export function formatDisplayDate(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'long' });
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
}

/**
 * Format date and time for display
 */
export function formatDisplayDateTime(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleString();
}

/**
 * Format time only for display
 */
export function formatDisplayTime(dateString?: string): string {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Capitalize the first letter of a string
 */
export function capitalizeFirstLetter(text?: string): string {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

/**
 * Capitalize the first letter of every word in a string
 */
export function capitalizeWords(text?: string): string {
  if (!text) return '';
  return text
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Shared obs extraction helper — replaces the duplicate local function across
 * useDeathNoteData, useNewbornAdmissionData, useReferralReportData, useDischargeSummaryData.
 *
 * Searches obs array by conceptUuid first, falls back to conceptDisplay match.
 * Handles coded (object with .display) and primitive values.
 */
export function extractObsValue(
  obs: Array<{ concept: { uuid?: string; display?: string }; value: any }> | undefined,
  conceptUuid: string,
  conceptDisplay?: string,
): string | undefined {
  if (!obs) return undefined;
  const match = obs.find(
    (o) =>
      (conceptUuid && o.concept?.uuid === conceptUuid) ||
      (conceptDisplay && o.concept?.display === conceptDisplay),
  );
  if (!match) return undefined;
  return typeof match.value === 'object' && match.value?.display ? match.value.display : match.value;
}

/**
 * Normalise an OpenMRS observation value to a display string.
 * Handles all value shapes returned by the REST API:
 *   - primitives (string, number)
 *   - coded values: { uuid, display } or { uuid, name: { name } }
 *   - panel group member obs objects that carry their own display field
 * Returns '--' for null / undefined / unrecognised shapes.
 */
export type ObservationValue =
  | string
  | number
  | null
  | undefined
  | { display?: string; name?: string | { name?: string }; uuid?: string };

export function getObservationDisplayValue(value: ObservationValue): string {
  if (value === null || value === undefined) return '--';
  if (typeof value === 'string') return value || '--';
  if (typeof value === 'number') return value.toString();
  if (typeof value === 'object') {
    if ('display' in value && value.display) return value.display;
    if ('name' in value) {
      const n = value.name;
      if (typeof n === 'string') return n;
      if (n && typeof n === 'object' && 'name' in n && n.name) return n.name;
    }
  }
  return '--';
}

/**
 * Convert an OpenMRS datetime string to a valid FHIR dateTime string.
 *
 * OpenMRS returns offsets without a colon separator, e.g. `2024-05-01T08:30:00.000+0545`.
 * FHIR requires a colon in the offset: `2024-05-01T08:30:00.000+05:45`.
 * This function inserts the colon when missing and strips milliseconds so the
 * resulting string matches the FHIR dateTime regex: YYYY-MM-DDTHH:mm:ss+HH:MM
 *
 * Returns undefined if the input is falsy or cannot be parsed.
 */
export function toFhirDateTime(dateStr?: string | null): string | undefined {
  if (!dateStr) return undefined;
  // Coerce to string in case a non-string value (e.g. number) slips through
  const str = String(dateStr);
  // Normalise offset: match ±HHMM at end (no colon) and insert colon → ±HH:MM
  const normalised = str.replace(/([+-])(\d{2})(\d{2})$/, '$1$2:$3');
  const date = new Date(normalised);
  if (isNaN(date.getTime())) return undefined;
  // Return as ISO 8601 with the normalised offset (keep original offset, not UTC)
  // Re-use the normalised string but strip milliseconds for a cleaner FHIR value
  return normalised.replace(/\.\d{1,3}(?=[+-Z])/, '');
}
