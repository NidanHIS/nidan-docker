
/**
 * Process vitals observation data and determine status based on reference ranges
 */
export function vitalsDataStatus(value, referenceRange) {  
  let valueStatus = '';
  if (referenceRange && value !== undefined) {
    const lowValue = referenceRange.low?.value;
    const highValue = referenceRange.high?.value;

    if (lowValue !== undefined && value < lowValue) {
      valueStatus = 'low';
    } else if (highValue !== undefined && value > highValue) {
      valueStatus = 'high';
    } else {
      valueStatus = 'normal';
    }
  }

  return valueStatus;
}

/**
 * Calculate BMI from height and weight
 */
export function calculateBMI(weight, height) {
  if (!weight || !height) return null;
  return parseFloat(((weight / Math.pow(height, 2)) * 10000).toFixed(1));
}

/**
 * Calculate age from birth date
 */
export function calculateAge(birthDate) {
  if (!birthDate) return 'Unknown';
  
  const currentDate = new Date();
  const birthDateObj = new Date(birthDate);
  let age = currentDate.getFullYear() - birthDateObj.getFullYear();

  if (
    currentDate.getMonth() < birthDateObj.getMonth() ||
    (currentDate.getMonth() === birthDateObj.getMonth() && currentDate.getDate() < birthDateObj.getDate())
  ) {
    age--;
  }

  return age.toString();
}


