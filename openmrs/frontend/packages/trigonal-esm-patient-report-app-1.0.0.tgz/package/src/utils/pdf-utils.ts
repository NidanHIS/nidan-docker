// import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

// // ─── Types ────────────────────────────────────────────────────────────────────

// export interface AttachmentUploadPayload {
//   patientUuid: string;
//   fileCaption: string;
//   blob: Blob;
//   filename: string;
// }

// export interface AttachmentUploadResponse {
//   uuid: string;
//   comment: string;
//   filename: string;
//   dateTime: string;
//   bytesMimeType: string;
//   bytesContentFamily: string;
//   links?: Array<{ rel: string; uri: string }>;
// }

// // ─── Filename generation ──────────────────────────────────────────────────────

// /**
//  * Generates a safe, descriptive filename for a PDF report.
//  * Replaces any non-alphanumeric character in the patient name with an underscore
//  * and appends today's ISO date so files sort naturally.
//  *
//  * @example
//  * generateReportFilename('Discharge Summary', 'John Doe')
//  * // → 'discharge_summary_John_Doe_2026-09-03.pdf'
//  */
// export function generateReportFilename(reportType: string, patientName?: string | null): string {
//   const safeName = (patientName ?? 'report').replace(/[^a-zA-Z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
//   const safeType = reportType.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
//   const dateStr = new Date().toISOString().split('T')[0];
//   return `${safeType}_${safeName}_${dateStr}.pdf`;
// }

// // ─── Download ─────────────────────────────────────────────────────────────────

// /**
//  * Triggers a browser file-save dialog for a PDF Blob.
//  * Creates a temporary <a> element, clicks it, then cleans up immediately.
//  */
// export function downloadPdf(blob: Blob, filename: string): void {
//   const url = URL.createObjectURL(blob);
//   const link = document.createElement('a');
//   link.href = url;
//   link.download = filename;
//   link.style.display = 'none';
//   document.body.appendChild(link);
//   link.click();
//   document.body.removeChild(link);
//   // Revoke after a tick to allow the download to start
//   setTimeout(() => URL.revokeObjectURL(url), 1000);
// }

// // ─── Upload to OpenMRS Attachments ────────────────────────────────────────────

// /**
//  * Uploads a PDF blob to the OpenMRS attachment API.
//  *
//  * Endpoint: POST /openmrs/ws/rest/v1/attachment
//  * Body: multipart/form-data with fields:
//  *   - patient:     patient UUID
//  *   - fileCaption: optional description string
//  *   - file:        the PDF blob with filename
//  *
//  * @throws Will throw if the HTTP response is not 2xx.
//  */
// export async function uploadPdfAsAttachment(
//   payload: AttachmentUploadPayload,
// ): Promise<AttachmentUploadResponse> {
//   const { patientUuid, fileCaption, blob, filename } = payload;

//   const formData = new FormData();
//   formData.append('patient', patientUuid);
//   formData.append('fileCaption', fileCaption ?? '');
//   formData.append('file', new File([blob], filename, { type: 'application/pdf' }));

//   // openmrsFetch sets the Authorization header and handles CSRF automatically.
//   // We must NOT set Content-Type manually — the browser sets the correct
//   // multipart boundary when we pass FormData.
//   const response = await openmrsFetch<AttachmentUploadResponse>(
//     `${restBaseUrl}/attachment`,
//     {
//       method: 'POST',
//       body: formData,
//     },
//   );

//   return response.data;
// }

// // ─── Error message helper ─────────────────────────────────────────────────────

// /**
//  * Extracts a human-readable error message from any thrown value,
//  * with a sensible fallback.
//  */
// export function extractErrorMessage(err: unknown, fallback = 'An unexpected error occurred.'): string {
//   if (!err) return fallback;
//   if (typeof err === 'string') return err;
//   if (err instanceof Error) return err.message;
//   if (typeof err === 'object') {
//     const e = err as Record<string, unknown>;
//     if (typeof e['message'] === 'string') return e['message'];
//     if (typeof e['statusText'] === 'string') return e['statusText'];
//   }
//   return fallback;
// }
