import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useDeathNoteData } from '../hooks/useDeathNoteData';
import { DeathCertificateDocument } from './patient-report-document/death-certificate-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface DeathCertificateModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const DeathCertificateModal: React.FC<DeathCertificateModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { deathNoteData, isLoading, error } = useDeathNoteData(patientUuid);

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading death certificate data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `death_certificate_${deathNoteData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'certificate'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !deathNoteData && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noDeathNoteFound', 'No Death Note found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && deathNoteData && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <DeathCertificateDocument data={deathNoteData} />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !deathNoteData}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default DeathCertificateModal;
