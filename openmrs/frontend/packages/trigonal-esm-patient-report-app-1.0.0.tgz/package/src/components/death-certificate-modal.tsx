import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { useDeathNoteData } from '../hooks/useDeathNoteData';
import { DeathCertificateDocument } from './patient-report-document/death-certificate-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface DeathCertificateModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const DeathCertificateModal: React.FC<DeathCertificateModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { deathNoteData, isLoading, error } = useDeathNoteData(patientUuid);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `death_certificate_${deathNoteData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'certificate'}_${new Date().toISOString().split('T')[0]}`,
    });

    if (isLoading) {
        return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
    }

    if (error) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
                <ModalBody>
                    <p>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    if (!deathNoteData) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
                <ModalBody>
                    <p>{t('noDeathNoteFound', 'No Death Note found for this patient.')}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
            <ModalBody>
                <div className={sharedStyles.printPreviewContainer}>
                    <div className={sharedStyles.printPreviewScaleWrapper}>
                        <div ref={contentRef}>
                            <DeathCertificateDocument
                                data={deathNoteData}
                            />
                        </div>
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default DeathCertificateModal;
