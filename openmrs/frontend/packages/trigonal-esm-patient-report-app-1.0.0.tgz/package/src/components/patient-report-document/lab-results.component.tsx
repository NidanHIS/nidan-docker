import React from 'react';
import { useTranslation } from 'react-i18next';
import { useLabOrderResult } from '../../hooks/useLabResultsData';
import { safeFormatDate } from '../../utils';
import styles from './lab-results.module.scss';

interface LabResultsProps {
  orders: Array<{
    uuid?: string;
    display?: string;
    dateActivated?: string | number;
    orderer?: { display: string };
    orderType: { name: string };
    conceptUuid?: string | null;
    encounterUuid?: string | null;
  }>;
}

// ── Single order result block ─────────────────────────────────────────────────
const LabOrderBlock: React.FC<{
  order: LabResultsProps['orders'][number];
}> = ({ order }) => {
  const { t } = useTranslation();
  const { result, isLoading } = useLabOrderResult(order);

  if (isLoading) {
    return (
      <tr>
        <td colSpan={5} className={styles.loading}>
          {t('loadingResults', 'Loading...')}
        </td>
      </tr>
    );
  }

  if (!result || result.rows.length === 0) {
    return (
      <tr>
        <td className={styles.orderName} colSpan={2}>
          <strong>{order.display || '—'}</strong>
        </td>
        <td colSpan={3} className={styles.pending}>
          {t('pending', 'Pending')}
        </td>
      </tr>
    );
  }

  return (
    <>
      {result.rows.map((row, i) => (
        <tr key={row.conceptUuid + i}>
          {/* Order name only on first row */}
          {i === 0 ? (
            <td className={styles.orderName} rowSpan={result.rows.length}>
              <strong>{result.orderDisplay}</strong>
              <div className={styles.orderMeta}>
                {safeFormatDate(result.dateActivated)}
                {result.orderer && <span> · {result.orderer}</span>}
              </div>
            </td>
          ) : null}
          <td className={`${styles.memberName} ${row.isPanel ? styles.indented : ''}`}>
            {row.isPanel ? row.display : ''}
          </td>
          <td className={`${styles.resultValue} ${row.isAbnormal ? styles.abnormal : ''}`}>
            {row.value}
          </td>
          <td className={styles.units}>{row.units || '—'}</td>
          <td className={styles.normalRange}>{row.normalRange}</td>
        </tr>
      ))}
    </>
  );
};

// ── Section ───────────────────────────────────────────────────────────────────
export const LabResults: React.FC<LabResultsProps> = ({ orders }) => {
  const { t } = useTranslation();

  const testOrders = orders.filter((o) => o.orderType.name === 'Test Order');

  if (testOrders.length === 0) return null;

  return (
    <div className={styles.section}>
      <div className={styles.sectionTitle}>{t('labResults', 'LAB RESULTS')}</div>
      <table className={styles.table}>
        <thead>
          <tr>
            <th className={styles.thOrder}>{t('test', 'Test')}</th>
            <th className={styles.thMember}>{t('component', 'Component')}</th>
            <th className={styles.thResult}>{t('result', 'Result')}</th>
            <th className={styles.thUnits}>{t('units', 'Units')}</th>
            <th className={styles.thRange}>{t('normalRange', 'Normal Range')}</th>
          </tr>
        </thead>
        <tbody>
          {testOrders.map((order) => (
            <LabOrderBlock key={order.uuid} order={order} />
          ))}
        </tbody>
      </table>
    </div>
  );
};
