import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './patient-conditions-history.module.scss';

interface ConditionsDataProps {
  conditionsData: ConditionsData[];
}

export const ConditionsData: React.FC<ConditionsDataProps> = ({ conditionsData }) => {
  const { t } = useTranslation();
  return (
    <div>
      <div className={styles.printSectionTitle}>{t('historyOfPresentIllness', 'HISTORY OF PRESENT ILLNESS')}</div>

      <div className={styles.printSectionContent}>
        <table className={styles.printTable}>
          <thead>
            <tr>
              <th className={styles.printCol35}>{t('conditionLabel', 'Condition')}</th>
              <th className={styles.printCol20}>{t('dateOfOnset', 'Date of onset')}</th>
              <th className={styles.printCol20}>{t('statusLabel', 'Status')}</th>
            </tr>
          </thead>
          <tbody>
            {conditionsData?.map((conditionItem, index) => (
              <tr key={index}>
                <td className={styles.printCol35}>{conditionItem.condition || '--'}</td>
                <td className={styles.printCol20}>{conditionItem.onsetDate || '--'}</td>
                <td className={styles.printCol20}>{conditionItem.clinicalStatus || '--'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
