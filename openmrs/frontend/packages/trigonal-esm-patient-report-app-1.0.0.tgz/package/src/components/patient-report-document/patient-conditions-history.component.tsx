import React from 'react';
import { useTranslation } from 'react-i18next';
import type { ConditionsData as ConditionsDataItem } from '../../types';
import { safeFormatDate } from '../../utils';
import styles from './patient-conditions-history.module.scss';

interface ConditionsDataProps {
  conditionsData: ConditionsDataItem[];
}

export const ConditionsData: React.FC<ConditionsDataProps> = ({ conditionsData }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printSection}>
      <div className={styles.printSectionTitle}>{t('conditions', 'CONDITIONS')}</div>

      <div className={styles.printSectionContent}>
        <table className={styles.printTable}>
          <thead>
            <tr>
              <th className={styles.printColCondition}>{t('conditionLabel', 'Condition')}</th>
              <th className={styles.printColDate}>{t('dateOfOnset', 'Date of onset')}</th>
              <th className={styles.printColStatus}>{t('statusLabel', 'Status')}</th>
            </tr>
          </thead>
          <tbody>
            {conditionsData && conditionsData.length > 0 ? (
              conditionsData.map((conditionItem, index) => (
                <tr key={index}>
                  <td className={styles.printColCondition}>{conditionItem.condition || '--'}</td>
                  <td className={styles.printColDate}>{safeFormatDate(conditionItem.onsetDate)}</td>
                  <td className={styles.printColStatus}>
                    <span className={styles.statusBadge}>{conditionItem.clinicalStatus || '--'}</span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3} className={styles.noData}>
                  {t('noConditionsRecorded', 'No conditions recorded')}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
