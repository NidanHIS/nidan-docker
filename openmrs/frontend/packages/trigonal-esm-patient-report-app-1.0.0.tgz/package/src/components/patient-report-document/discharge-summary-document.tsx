import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './discharge-summary-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { formatDisplayDateTime, formatDisplayDate } from '../../utils';
import { DischargeSummaryData } from '../../hooks/useDischargeSummaryData';

interface DischargeSummaryDocumentProps {
    data: DischargeSummaryData;
}

export const DischargeSummaryDocument: React.FC<DischargeSummaryDocumentProps> = ({ data }) => {
    const { t } = useTranslation();

    return (
        <div className={styles.dischargeSummary}>
            <div className={styles.watermark}>
                <img src="/openmrs/frontend/hospital-logo.png" alt="watermark" />
            </div>

            <EncounterPrintLetterhead />
            
            <div className={styles.reportHeader}>
                <div className={styles.reportTitle}>
                    {t('dischargeSummaryTitle', 'Discharge Summary')}
                </div>
            </div>

            {/* Patient Information */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('patientInformation', 'I. Patient Information')}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('fullName', 'Full Name')}</span>
                        <span className={styles.value}>{data.patientName}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('gender', 'Gender')}</span>
                        <span className={styles.value}>{data.patientGender}</span>
                    </div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('patientId', 'Patient ID')}</span>
                        <span className={styles.value}>{data.patientId}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('age', 'Age')}</span>
                        <span className={styles.value}>{data.patientAge}</span>
                    </div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('hospitalNumber', 'Hospital Number')}</span>
                        <span className={styles.value}>{data.hospitalNumber}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('admissionDate', 'Admission Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.dateOfAdmission)}</span>
                    </div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('dischargeDate', 'Discharge Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.dischargeDate)}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('inpatientOutcome', 'Outcome')}</span>
                        <span className={styles.value}>{data.inpatientOutcome || t('notSpecified', 'Not Specified')}</span>
                    </div>
                </div>
            </div>

            {/* Clinical Details */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('clinicalDetails', 'II. Clinical Details')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('diagnosis', 'Final Diagnosis')}</span>
                    <div className={styles.longText}>{data.diagnosis || t('notSpecified', 'Not Specified')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('briefHospitalCourse', 'Brief Hospital Course')}</span>
                    <div className={styles.longText}>{data.briefHospitalCourse}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('majorSurgery', 'Major Surgery')}</span>
                        <span className={styles.value}>{data.majorSurgery || t('none', 'None')}</span>
                    </div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('postOpComplications', 'Post Operative Complications')}</span>
                    <div className={styles.longText}>{data.postOpComplications || t('none', 'None')}</div>
                </div>
            </div>

            {/* Discharge Instructions */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('dischargeInstructions', 'III. Discharge Instructions')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('medicationOnDischarge', 'Medications on Discharge')}</span>
                    <div className={styles.longText}>{data.medicationOnDischarge}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('followUpInstructions', 'Follow-up Instructions')}</span>
                    <div className={styles.longText}>{data.followUpInstructions}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('followUpDate', 'Follow-up Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.followUpDate)}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('dischargedTo', 'Discharged To')}</span>
                        <span className={styles.value}>{data.dischargedTo}</span>
                    </div>
                </div>
            </div>

            {/* Footer / Signatures */}
            <div className={styles.footer}>
                <div className={styles.signatureBox}>
                    <div className={styles.officialStamp}>{t('officialStamp', 'Official Stamp')}</div>
                </div>
                <div className={styles.signatureBox}>
                    <div className={styles.signatureLine}>
                        {t('physicianSignature', 'Physician Signature')}
                    </div>
                    <div className={styles.signatureDetails}>
                        <div className={styles.signatureDetailItem}>
                            <span className={styles.signatureLabel}>{t('name', 'Name')}:</span>
                            <span className={styles.signatureValue}>{data.providerName}</span>
                        </div>
                        <div className={styles.signatureDetailItem}>
                            <span className={styles.signatureLabel}>{t('date', 'Date')}:</span>
                            <span className={styles.signatureValue}>{formatDisplayDate(new Date().toISOString())}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
