import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession, formatDate, formatDatetime, parseDate } from '@openmrs/esm-framework';
import type { PatientInfo, VisitDetails, Orders, VitalsData, BiometricsData, ConditionsData, DiagnosisData, ClinicalNote } from '../../types';
import { ConfigObject } from '../../config-schema';
import styles from './patient-summary-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { safeFormatDate } from '../../utils';

import { ReportHeader as ReportHeaderComponent } from './patient-report-header.component';
import { VitalsBioData as VitalsBioDataComponent } from './patient-vitals-bio.component';
import { ConditionsData as ConditionsDataComponent } from './patient-conditions-history.component';
import { DiagnosisAndClinicalNotes as DiagnosisAndClinicalNotesComponent } from './patient-encounters.components';
import { OrdersData as OrdersDataComponent } from './patient-orders.component';
import { LabResults as LabResultsComponent } from './lab-results.component';

interface PatientSummaryDocumentProps {
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
  orders: Orders[];
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
  conditionsData: ConditionsData[];
  diagnosisData: DiagnosisData[];
  providerName?: string;
  encounters?: any[];
  chiefComplaint?: string | null;
}

function getAnswerFromDisplay(display: string): string {
  const colonIndex = display.indexOf(':');
  if (colonIndex === -1) {
    return '';
  }
  return display.substring(colonIndex + 1).trim();
}

const ISO_DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;
const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T/;

function getObsValue(obs: any): string {
  const conceptClass = obs.concept?.conceptClass?.display;
  if (typeof obs.value === 'string' && obs.value) {
    if (conceptClass === 'Date' || ISO_DATE_ONLY.test(obs.value)) {
      return formatDate(parseDate(obs.value), { mode: 'wide', time: false, noToday: true });
    }
    if (conceptClass === 'Datetime' || ISO_DATETIME.test(obs.value)) {
      return formatDatetime(parseDate(obs.value), { mode: 'wide', noToday: true });
    }
  }
  return getAnswerFromDisplay(obs.display);
}

export const PatientSummaryDocument: React.FC<PatientSummaryDocumentProps> = ({
  patientInfo,
  visitDetails,
  orders,
  vitalsData,
  biometricsData,
  conditionsData,
  diagnosisData,
  providerName,
  encounters = [],
  chiefComplaint,
}) => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();
  const printLetterhead = config?.printLetterhead;
  const letterhead = <EncounterPrintLetterhead />;

  const session = useSession();
  const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
  const printedAt = new Date().toLocaleString();

  const excludeObsForms = config.patientSummaryDocument?.excludeObsForms ?? [];

  // Group encounters that have observations, filtered to only "Consultation" encounter type
  // and excluding encounters whose form UUID is in the excludeObsForms config list
  const encountersWithObs = (encounters || [])
    .filter((encounter) => encounter.encounterType?.display === 'Consultation')
    .filter(encounter => encounter.form != null)
    .filter(encounter => !excludeObsForms.includes(encounter.form?.uuid))
    .map((encounter) => {
      const pName =
        encounter.encounterProviders?.[0]?.provider?.person?.display ||
        encounter.encounterProviders?.[0]?.provider?.display ||
        '';
      return {
        encounterId: encounter.uuid,
        encounterType: encounter.form?.name || 'Encounter',
        encounterDatetime: encounter.encounterDatetime,
        providerName: pName,
        observations: encounter.obs || [],
      };
    })
    .filter((e) => e.observations.length > 0);

  // Extract History of Present Illness from concept 1390AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
  const HPI_CONCEPT_UUID = '1390AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
  const hpiEntries: { value: string; obsDatetime: string }[] = (encounters || [])
    .filter((encounter) => encounter.encounterType?.display === 'Consultation')
    .flatMap((encounter) => {
      const findHpi = (obsList: any[]): { value: string; obsDatetime: string }[] => {
        const found: { value: string; obsDatetime: string }[] = [];
        obsList?.forEach((obs) => {
          if (obs?.concept?.uuid === HPI_CONCEPT_UUID && obs.value != null && obs.value !== '') {
            const val = typeof obs.value === 'object'
              ? obs.value.display || obs.value.name || JSON.stringify(obs.value)
              : String(obs.value);
            found.push({ value: val, obsDatetime: obs.obsDatetime });
          }
          if (obs?.groupMembers?.length) {
            found.push(...findHpi(obs.groupMembers));
          }
        });
        return found;
      };
      return findHpi(encounter.obs || []);
    });

  const footer = (
    <div className={styles.repeatingFooter}>
      <span>
        {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
      </span>
    </div>
  );

  const signatureSection = (
    <div className={styles.printFooter}>
      <div className={styles.signatureSection}>
        <div className={styles.signatureBox}>
          <div className={styles.signatureLine}>
            {t('medicalOfficerSignature', 'Medical Officer Signature')}
          </div>
          <div className={styles.signatureDetails}>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('doctorName', 'Name')}:</span>
              <span className={styles.signatureValue}>
                {providerName || '________________________'}
              </span>
            </div>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('registrationNo', 'Reg No')}:</span>
              <span className={styles.signatureValue}>________________________</span>
            </div>
          </div>
        </div>
        <div className={styles.stampBox}>
          <div className={styles.officialStamp}>
            {t('officialStamp', 'Official Stamp')}
          </div>
        </div>
      </div>
    </div>
  );

  const mainContent = (
    <div className={styles.printMainContent}>
      <h1 className={styles.printTitle}>{t('patientReportTitle', 'Patient Report')}</h1>

      <ReportHeaderComponent
        patientInfo={patientInfo}
        visitDetails={visitDetails}
      />

      <hr className={styles.printHr} />

      {/* Chief Complaint Section */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>{t('chiefComplaint', 'Chief Complaint')}</div>
        <div className={styles.printSectionContent}>
          {chiefComplaint ? (
            <div className={styles.chiefComplaintValue}>{chiefComplaint}</div>
          ) : (
            <span className={styles.noData}>{t('noChiefComplaintRecorded', 'No chief complaint recorded')}</span>
          )}
        </div>
      </div>

      {/* History of Present Illness Section */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>{t('historyOfPresentIllness', 'History of Present Illness')}</div>
        <div className={styles.printSectionContent}>
          {hpiEntries.length > 0 ? (
            hpiEntries.map((entry, idx) => (
              <div key={idx} className={styles.hpiEntry}>
                <span className={styles.hpiValue}>{entry.value}</span>
                {entry.obsDatetime && (
                  <span className={styles.hpiDate}> — {safeFormatDate(entry.obsDatetime)}</span>
                )}
              </div>
            ))
          ) : (
            <span className={styles.noData}>{t('noHpiRecorded', 'No history of present illness recorded')}</span>
          )}
        </div>
      </div>

      <VitalsBioDataComponent
        vitalsData={vitalsData}
        biometricsData={biometricsData}
      />

      <ConditionsDataComponent
        conditionsData={conditionsData}
      />

      <DiagnosisAndClinicalNotesComponent
        diagnosisData={diagnosisData}
      />

      <OrdersDataComponent
        orders={orders}
      />

      <LabResultsComponent orders={orders} />

      {/* Observations (Form Data) Section */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>{t('observationsFormData', 'Observations (Form Data)')}</div>
        <div className={styles.printSectionContent}>
          {encountersWithObs.length > 0 ? (
            <table className={styles.printObsTable}>
              <thead>
                <tr>
                  <th style={{ width: '40%' }}>{t('field', 'Field / Question')}</th>
                  <th style={{ width: '40%' }}>{t('value', 'Value / Answer')}</th>
                  <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
                </tr>
              </thead>
              <tbody>
                {encountersWithObs.map((enc) => (
                  <React.Fragment key={enc.encounterId}>
                    {/* Form Name Header Row */}
                    <tr className={styles.formNameRow}>
                      <td colSpan={3}>
                        <strong>{enc.encounterType}</strong> {enc.providerName && `(Filled by: ${enc.providerName})`}
                      </td>
                    </tr>
                    {/* Observation Rows */}
                    {enc.observations.map((obs: any, obsIndex: number) => {
                      if (obs.groupMembers) {
                        return (
                          <React.Fragment key={obs.uuid || obsIndex}>
                            {/* Group parent header row */}
                            <tr>
                              <td colSpan={3} style={{ paddingLeft: '20px', fontWeight: 'bold' }}>
                                {obs.concept?.display}
                              </td>
                            </tr>
                            {/* Group member rows */}
                            {obs.groupMembers.map((member: any) => (
                              <tr key={member.uuid}>
                                <td style={{ paddingLeft: '40px' }}>{member.concept?.display}</td>
                                <td>
                                  <strong>{getObsValue(member)}</strong>
                                </td>
                                <td>{safeFormatDate(member.obsDatetime)}</td>
                              </tr>
                            ))}
                          </React.Fragment>
                        );
                      }
                      return (
                        <tr key={obs.uuid || obsIndex}>
                          <td style={{ paddingLeft: '20px' }}>{obs.concept?.display}</td>
                          <td>
                            <strong>{getObsValue(obs)}</strong>
                          </td>
                          <td>{safeFormatDate(obs.obsDatetime)}</td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          ) : (
            <span className={styles.noData}>{t('noObservationsRecorded', 'No form observations recorded for this visit.')}</span>
          )}
        </div>
      </div>

      {signatureSection}
    </div>
  );

  return (
    <div className={styles.printableDocument}>
      <table className={styles.printTable}>
        <thead>
          <tr>
            <td>
              <div className={styles.headerSpacer}>
                {printLetterhead && letterhead}
              </div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              {mainContent}
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className={styles.footerSpacer}>
                {footer}
              </div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default PatientSummaryDocument;
