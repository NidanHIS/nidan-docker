import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './patient-summary-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';

import { ReportHeader } from './patient-report-header.component';
import { VitalsBioData } from './patient-vitals-bio.component';
import { ConditionsData } from './patient-conditions-history.component';
import { DiagnosisAndClinicalNotes } from './patient-encounters.components';
import { OrdersData } from './patient-orders.component';

interface PatientSummaryDocumentProps {
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
  orders: Orders[];
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
  conditionsData: ConditionsData[];
  diagnosisData: DiagnosisData[];
  clinicalNotes: ClinicalNote[];
}

export const PatientSummaryDocument: React.FC<PatientSummaryDocumentProps> = ({
  patientInfo,
  visitDetails,
  orders,
  vitalsData,
  biometricsData,
  conditionsData,
  diagnosisData,
  clinicalNotes,
}) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printableDocument}>
      <EncounterPrintLetterhead />
      <h1 className={styles.printTitle}>{t('patientReportTitle', 'Patient Report')}</h1>

      <ReportHeader
        patientInfo={patientInfo}
        visitDetails={visitDetails}
      />

      <hr className={styles.printHr} />

      <div className={styles.printMainContent}>
        <VitalsBioData
          vitalsData={vitalsData}
          biometricsData={biometricsData}
        />

        <ConditionsData
          conditionsData={conditionsData}
        />

        <DiagnosisAndClinicalNotes
          diagnosisData={diagnosisData}
          clinicalNotes={clinicalNotes}
        />

        <OrdersData
          orders={orders}
        />
      </div>
    </div>
  );
};
