import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession } from '@openmrs/esm-framework';
import type { PatientInfo, VisitDetails, Orders, VitalsData, BiometricsData, ConditionsData, DiagnosisData, ClinicalNote } from '../../types';
import { ConfigObject } from '../../config-schema';
import styles from './patient-summary-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';

import { ReportHeader as ReportHeaderComponent } from './patient-report-header.component';
import { VitalsBioData as VitalsBioDataComponent } from './patient-vitals-bio.component';
import { ConditionsData as ConditionsDataComponent } from './patient-conditions-history.component';
import { DiagnosisAndClinicalNotes as DiagnosisAndClinicalNotesComponent } from './patient-encounters.components';
import { OrdersData as OrdersDataComponent } from './patient-orders.component';

interface PatientSummaryDocumentProps {
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
  orders: Orders[];
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
  conditionsData: ConditionsData[];
  diagnosisData: DiagnosisData[];
  clinicalNotes: ClinicalNote[];
  providerName?: string;
}

export const PatientSummaryDocument: React.FC<PatientSummaryDocumentProps> = ({
  patientInfo,
  visitDetails,
  orders,
  vitalsData,
  biometricsData,
  conditionsData,
  diagnosisData,
  clinicalNotes,
  providerName,
}) => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();
  const printLetterhead = config?.printLetterhead;
  const letterhead = <EncounterPrintLetterhead />;

  const session = useSession();
  const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
  const printedAt = new Date().toLocaleString();

  const footer = (
    <div className={styles.repeatingFooter}>
      <span>
        {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
      </span>
    </div>
  );

  const signatureSection = (
    <div className={styles.printFooter}>
      <div className={styles.signatureSection}>
        <div className={styles.signatureBox}>
          <div className={styles.signatureLine}>
            {t('medicalOfficerSignature', 'Medical Officer Signature')}
          </div>
          <div className={styles.signatureDetails}>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('doctorName', 'Name')}:</span>
              <span className={styles.signatureValue}>
                {providerName || '________________________'}
              </span>
            </div>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('registrationNo', 'Reg No')}:</span>
              <span className={styles.signatureValue}>________________________</span>
            </div>
          </div>
        </div>
        <div className={styles.stampBox}>
          <div className={styles.officialStamp}>
            {t('officialStamp', 'Official Stamp')}
          </div>
        </div>
      </div>
    </div>
  );

  const mainContent = (
    <div className={styles.printMainContent}>
      <h1 className={styles.printTitle}>{t('patientReportTitle', 'Patient Report')}</h1>

      <ReportHeaderComponent
        patientInfo={patientInfo}
        visitDetails={visitDetails}
      />

      <hr className={styles.printHr} />

      <VitalsBioDataComponent
        vitalsData={vitalsData}
        biometricsData={biometricsData}
      />

      <ConditionsDataComponent
        conditionsData={conditionsData}
      />

      <DiagnosisAndClinicalNotesComponent
        diagnosisData={diagnosisData}
        clinicalNotes={clinicalNotes}
      />

      <OrdersDataComponent
        orders={orders}
      />

      {signatureSection}
    </div>
  );

  return (
    <div className={styles.printableDocument}>
      <table className={styles.printTable}>
        <thead>
          <tr>
            <td>
              <div className={styles.headerSpacer}>
                {letterhead}
              </div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              {mainContent}
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className={styles.footerSpacer}>
                {footer}
              </div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default PatientSummaryDocument;
