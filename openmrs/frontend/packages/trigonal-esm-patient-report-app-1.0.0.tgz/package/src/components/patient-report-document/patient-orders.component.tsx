import React from 'react';
import { useTranslation } from 'react-i18next';
import type { Orders } from '../../types';
import styles from './patient-orders.module.scss';

interface OrdersDataProps {
  orders: Orders[];
}

export const OrdersData: React.FC<OrdersDataProps> = ({ orders }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printSection}>
      {/* Drug Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Drug Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('medicationsTitle', 'MEDICATIONS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.colDate}>{t('startDate', 'Start Date')}</th>
                  <th className={styles.colMedication}>{t('medicationLabel', 'Medication')}</th>
                  <th className={styles.colDose}>{t('doseLabel', 'Dose/Freq')}</th>
                  <th className={styles.colInstructions}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.colOrderer}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Drug Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.colDate}>
                          {order.auditInfo?.dateCreated ? new Date(order.auditInfo.dateCreated).toLocaleDateString('en-GB') : '--'}
                        </td>
                        <td className={styles.colMedication}>
                          <strong>{order.drug?.display || order.display}</strong>
                        </td>
                        <td className={styles.colDose}>
                          {order.dose} {order.doseUnits?.display} / {order.frequency?.display}
                          <div className={styles.durationText}>{order.duration} {order.durationUnits?.display}</div>
                        </td>
                        <td className={styles.colInstructions}>
                          {order.dosingInstructions || t('takeAsDirected', 'Take as Directed')}
                          <div className={styles.routeText}>({order.route?.display})</div>
                        </td>
                        <td className={styles.colOrderer}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Test Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Test Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('testOrdersTitle', 'TEST ORDERS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.colDate}>{t('dateOfOrder', 'Date')}</th>
                  <th className={styles.colTest}>{t('orderType', 'Test / Procedure')}</th>
                  <th className={styles.colUrgency}>{t('urgencyLabel', 'Urgency')}</th>
                  <th className={styles.colInstructions}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.colOrderer}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Test Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.colDate}>
                          {order.dateActivated ? new Date(order.dateActivated).toLocaleDateString('en-GB') : '--'}
                        </td>
                        <td className={styles.colTest}>
                          <strong>{order.display || '--'}</strong>
                        </td>
                        <td className={styles.colUrgency}>
                          <span className={`${styles.urgencyBadge} ${order.urgency === 'STAT' ? styles.stat : ''}`}>
                            {order.urgency || '--'}
                          </span>
                        </td>
                        <td className={styles.colInstructions}>{order.instructions || '--'}</td>
                        <td className={styles.colOrderer}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Radiology Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Radiology Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('radiologyOrdersTitle', 'RADIOLOGY ORDERS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.colDate}>{t('dateOfOrder', 'Date')}</th>
                  <th className={styles.colTest}>{t('orderType', 'Radiology Test')}</th>
                  <th className={styles.colUrgency}>{t('urgencyLabel', 'Urgency')}</th>
                  <th className={styles.colInstructions}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.colOrderer}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Radiology Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.colDate}>
                          {order.dateActivated ? new Date(order.dateActivated).toLocaleDateString('en-GB') : '--'}
                        </td>
                        <td className={styles.colTest}>
                          <strong>{order.display || '--'}</strong>
                        </td>
                        <td className={styles.colUrgency}>
                          <span className={`${styles.urgencyBadge} ${order.urgency === 'STAT' ? styles.stat : ''}`}>
                            {order.urgency || '--'}
                          </span>
                        </td>
                        <td className={styles.colInstructions}>{order.instructions || '--'}</td>
                        <td className={styles.colOrderer}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Procedure Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Procedure Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('procedureOrdersTitle', 'PROCEDURE ORDERS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.colDate}>{t('dateOfOrder', 'Date')}</th>
                  <th className={styles.colTest}>{t('orderType', 'Procedure')}</th>
                  <th className={styles.colUrgency}>{t('urgencyLabel', 'Urgency')}</th>
                  <th className={styles.colInstructions}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.colOrderer}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Procedure Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.colDate}>
                          {order.dateActivated ? new Date(order.dateActivated).toLocaleDateString('en-GB') : '--'}
                        </td>
                        <td className={styles.colTest}>
                          <strong>{order.display || '--'}</strong>
                        </td>
                        <td className={styles.colUrgency}>
                          <span className={`${styles.urgencyBadge} ${order.urgency === 'STAT' ? styles.stat : ''}`}>
                            {order.urgency || '--'}
                          </span>
                        </td>
                        <td className={styles.colInstructions}>{order.instructions || '--'}</td>
                        <td className={styles.colOrderer}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Medical Supply Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Medical Supply Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('medicalSupplyOrdersTitle', 'MEDICAL SUPPLY ORDERS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.colDate}>{t('dateOfOrder', 'Date')}</th>
                  <th className={styles.colTest}>{t('orderType', 'Supply Item')}</th>
                  <th className={styles.colUrgency}>{t('urgencyLabel', 'Urgency')}</th>
                  <th className={styles.colInstructions}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.colOrderer}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Medical Supply Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.colDate}>
                          {order.dateActivated ? new Date(order.dateActivated).toLocaleDateString('en-GB') : '--'}
                        </td>
                        <td className={styles.colTest}>
                          <strong>{order.display || '--'}</strong>
                        </td>
                        <td className={styles.colUrgency}>
                          <span className={`${styles.urgencyBadge} ${order.urgency === 'STAT' ? styles.stat : ''}`}>
                            {order.urgency || '--'}
                          </span>
                        </td>
                        <td className={styles.colInstructions}>{order.instructions || '--'}</td>
                        <td className={styles.colOrderer}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
