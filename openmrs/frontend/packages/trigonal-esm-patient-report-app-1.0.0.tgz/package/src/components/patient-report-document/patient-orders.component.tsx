import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './patient-orders.module.scss';

interface OrdersDataProps {
  orders: Orders[];
}

export const OrdersData: React.FC<OrdersDataProps> = ({ orders }) => {
  const { t } = useTranslation();
  return (
    <div>
      {/* Drug Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Drug Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('medicationsTitle', 'MEDICATIONS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.printCol15}>{t('startDate', 'Start Date')}</th>
                  <th className={styles.printCol20}>{t('medicationLabel', 'Medication')}</th>
                  <th className={styles.printCol15}>{t('doseLabel', 'Dose')}</th>
                  <th className={styles.printCol15}>{t('frequencyLabel', 'Frequency')}</th>
                  <th className={styles.printCol25}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.printCol15}>{t('durationLabel', 'Duration')}</th>
                  <th className={styles.printCol20}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Drug Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.printCol15}>{new Date(order.auditInfo?.dateCreated).toLocaleDateString('en-GB')}</td>
                        <td className={styles.printCol20}>{order.drug.display}</td>
                        <td className={styles.printCol15}>{order.dose} {order.doseUnits.display}</td>
                        <td className={styles.printCol15}>{order.frequency.display}</td>
                        <td className={styles.printCol25}>
                          {order.dosingInstructions || t('takeAsDirected', 'Take as Directed')} ({order.route.display})
                        </td>
                        <td className={styles.printCol15}>{order?.duration || '--'} {order.durationUnits.display}</td>
                        <td className={styles.printCol20}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Test Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Test Order') && (
        <div className={styles.printOrderSection}>
          <div className={styles.printSectionTitle}>{t('testOrdersTitle', 'TEST ORDERS')}</div>
          <div className={styles.printSectionContent}>
            <table className={styles.printTable}>
              <thead>
                <tr>
                  <th className={styles.printCol20}>{t('dateOfOrder', 'Date of order')}</th>
                  <th className={styles.printCol25}>{t('orderType', 'Order Type')}</th>
                  <th className={styles.printCol20}>{t('urgencyLabel', 'Urgency')}</th>
                  <th className={styles.printCol15}>{t('scheduledDate', 'Scheduled Date')}</th>
                  <th className={styles.printCol20}>{t('instructionsLabel', 'Instructions')}</th>
                  <th className={styles.printCol20}>{t('orderedBy', 'Ordered By')}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => {
                  if (order.orderType.name === 'Test Order') {
                    return (
                      <tr key={index}>
                        <td className={styles.printCol20}>{new Date(order.dateActivated).toLocaleDateString('en-GB') || '--'}</td>
                        <td className={styles.printCol25}>{order.display || '--'}</td>
                        <td className={styles.printCol20}>{order.urgency || '--'}</td>
                        <td className={styles.printCol15}>{order.scheduledDate ? (new Date(order.scheduledDate).toLocaleDateString('en-GB')) : '--'}</td>
                        <td className={styles.printCol20}>{order.instructions || '--'}</td>
                        <td className={styles.printCol20}>{order.orderer?.display || '--'}</td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
