import React from 'react';
import { Document, Page, Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';

export const ReportHeader = ({ patientInfo, visitDetails, translatedTexts }) => {

  return (

    <View style={styles.header}>
      <View style={styles.leftColumn}>
        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.patientName}:</Text>
          <Text style={styles.value}>{patientInfo.name}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.patientDob}:</Text>
          <Text style={styles.value}>{patientInfo.birthDate}</Text>
          <Text style={styles.spacing}>
            <Text style={styles.label}>{translatedTexts.patientAgeSex}:</Text>
            <Text style={styles.value}>{patientInfo.age}Y / {patientInfo.gender}</Text>
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.patientAddress}:</Text>
          <Text style={styles.value}>{patientInfo.address}</Text>
        </View>
      </View>

      <View style={styles.rightColumn}>
        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.visitType}:</Text>
          <Text style={styles.value}>{visitDetails.visitType}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.visitLocation}:</Text>
          <Text style={styles.value}>{visitDetails.location}</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.label}>{translatedTexts.visitDate}:</Text>
          <Text style={styles.value}>{visitDetails.startDatetime}</Text>
        </View>
      </View>
    </View>
  );
};
