import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession, formatDate, parseDate } from '@openmrs/esm-framework';
import { ConfigObject } from '../../config-schema';
import styles from './insurance-referral-report-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { InsuranceReferralReportData } from '../../hooks/useInsuranceReferralReportData';

interface InsuranceReferralReportDocumentProps {
    data: InsuranceReferralReportData;
}

export const InsuranceReferralReportDocument: React.FC<InsuranceReferralReportDocumentProps> = ({ data }) => {
    const { t } = useTranslation();
    const config = useConfig<ConfigObject>();

    const session = useSession();
    const printedBy =
        session?.user?.person?.display ||
        session?.user?.username ||
        session?.user?.display ||
        t('unknownUser', 'Unknown User');
    const printedAt = new Date().toLocaleString();

    const dash = '—';

    const renderDateOnly = (dateStr?: string | number) => {
        if (!dateStr) return dash;
        try {
            const d = typeof dateStr === 'number' ? new Date(dateStr) : parseDate(String(dateStr));
            return formatDate(d, { mode: 'wide', time: false, noToday: true });
        } catch {
            return String(dateStr);
        }
    };

    const letterhead = <EncounterPrintLetterhead />;

    const footer = (
        <div className={styles.repeatingFooter}>
            <span>
                {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
            </span>
        </div>
    );

    const mainContent = (
        <div>
            {/* ── Form title block ── */}
            {/* <div className={styles.formTitleBlock}>
                <span className={styles.formTitle}>अनुसूची-९</span>
                <span className={styles.formSubtitle}>(नियम २० को उपनियम (३) सँग सम्बन्धित)</span>
                <span className={styles.formTitle}>प्रेषण पूर्जी</span>
            </div>
            <hr className={styles.formTitleDivider} /> */}

            {/* ── Top-right info ── */}
            <div className={styles.topRightInfo}>
                <div className={styles.refNoRow}>
                    <span>
                        <span className={styles.refLabel}>रिफरल नं:</span>{' '}
                        <span className={styles.refValue}>&nbsp;</span>
                    </span>
                </div>
                <div className={styles.refNoRow}>
                    <span>
                        <span className={styles.refLabel}>मिति:</span>{' '}
                        <span className={styles.refValue}>{renderDateOnly(data.encounterDatetime)}</span>
                    </span>
                </div>
            </div>

            {/* ── Recipient intro ── */}
            <div className={styles.recipientBlock}>
                <div className={styles.recipientTitle}>
                    श्री {data.referInstitutionName || 'Health Institution'}
                </div>
                <div className={styles.recipientText}>
                    स्वास्थ्य बीमा कार्यक्रमका बीमितलाई त्यस स्वास्थ्य संस्था/अस्पतालसँग भएको सम्झौत बमोजिम स्वास्थ्य
                    सेवा उपलब्ध गराई दिनहुन अनुरोध गरिन्छ ।
                </div>
            </div>

            {/* ── Patient details header ── */}
            <div className={styles.patientDetailHeader}>बिरामीको विवरण</div>

            {/* ── Patient info grid ── */}
            <div className={styles.patientInfoGrid}>
                {/* Row: Insurance No | NHIS */}
                <div className={styles.infoRow}>
                    <div>
                        <span className={styles.infoLabel}>बीमा नं: </span>
                        <span className={styles.infoValue}>{data.nhisNumber || dash}</span>
                    </div>
                    <div>
                        <span className={styles.infoLabel}>NHIS: </span>
                        <span className={styles.infoValue}>{data.nhisNumber || dash}</span>
                    </div>
                    <div>
                        <span className={styles.infoLabel}>SSF ID: </span>
                        <span className={styles.infoValue}>{data.ssfid || dash}</span>
                    </div>
                </div>

                {/* Row: Name | (empty) */}
                <div className={styles.infoRow}>
                    <div>
                        <span className={styles.infoLabel}>Name: </span>
                        <span className={styles.infoValue}>
                            {data.patientName || dash}
                            {data.hospitalNumber ? ` [${data.hospitalNumber}]` : ''}
                        </span>
                    </div>
                    <div>
                        <span className={styles.infoLabel}>Age/Sex: </span>
                        <span className={styles.infoValue}>
                            {data.patientAge ? `${data.patientAge}Y` : dash} /{' '}
                            {data.patientGender || dash}
                        </span>
                    </div>
                    <div>
                        <span className={styles.infoLabel}>Address: </span>
                        <span className={styles.infoValue}>{data.address || dash}</span>
                    </div>
                </div>


                {/* Row: Department */}
                <div className={styles.infoRow}>
                    <span>
                        <span className={styles.infoLabel}>Department: </span>
                        <span className={styles.infoValue}>{data.department || dash}</span>
                    </span>
                    <span />
                </div>
            </div>

            {/* ── Chief Complaints ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Chief Complaints</div>
                <div className={styles.sectionContent}>{data.chiefComplaints || dash}</div>
            </div>

            {/* ── Clinical Findings / Vitals ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Clinical Findings</div>
                <div className={styles.sectionContent}>
                    <div className={styles.vitalsRow}>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>BP:</span>
                            <span>
                                {data.systolicBP || dash}/{data.diastolicBP || dash}
                            </span>
                        </div>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>Temperature:</span>
                            <span>{data.temperature || dash}</span>
                        </div>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>Heart Rate:</span>
                            <span>{data.heartRate || dash}</span>
                        </div>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>SpO2:</span>
                            <span>{data.spO2 ? `${data.spO2} %` : dash}</span>
                        </div>
                    </div>
                    <div className={styles.vitalsRow}>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>Respiration Rate:</span>
                            <span>{data.respirationRate || dash}</span>
                        </div>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>Height (cm):</span>
                            <span>{data.height || dash}</span>
                        </div>
                        <div className={styles.vitalItem}>
                            <span className={styles.vitalLabel}>Weight (kg):</span>
                            <span>{data.weight || dash}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* ── Provisional Diagnosis ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Provisional Diagnosis</div>
                <div className={styles.sectionContent}>
                    {data.provisionalDiagnosis
                        ? data.provisionalDiagnosis.split('\n').map((line, i) => (
                            <div key={i}>{line}</div>
                        ))
                        : dash}
                </div>
            </div>

            {/* ── Treatment Given ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Treatment Given</div>
                <div className={styles.sectionContent}>{data.treatmentGiven || dash}</div>
            </div>

            {/* ── Reason for Referral ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Reason for Referral</div>
                <div className={styles.sectionContent}>{data.reasonForReferral || dash}</div>
            </div>

            {/* ── Follow Up / Advice ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Follow Up / Advice</div>
                <div className={styles.sectionContent}>{data.followUpAdvice || dash}</div>
            </div>

            {/* ── Referred By ── */}
            <div className={styles.sectionBlock}>
                <div className={styles.sectionTitle}>Referred By</div>
                <div className={styles.referredByGrid}>
                    <div className={styles.referredByRow}>
                        <span>
                            <span className={styles.refByLabel}>DR'S NAME: </span>
                            <span className={styles.refByValue}>{data.providerName || '\u00a0'}</span>
                        </span>
                        <span>
                            <span className={styles.refByLabel}>COUNCIL NO: </span>
                            <span className={styles.refByValue}>{data.providerCouncilNo || '\u00a0'}</span>
                        </span>
                    </div>
                    <div className={styles.referredByRow}>
                        <span>
                            <span className={styles.refByLabel}>DEPARTMENT: </span>
                            <span className={styles.infoValue}>{data.department || dash}</span>
                        </span>
                        <span>
                            <span className={styles.refByLabel}>INSTITUTION: </span>
                            <span className={styles.infoValue}>
                                {/* {data.location || 'Electronic Medical Recording System'} */}
                            </span>
                        </span>
                    </div>
                    <div className={styles.referredByRow}>
                        <span>
                            <span className={styles.refByLabel}>SIGNATURE: </span>
                            <span className={styles.refByValue}>&nbsp;</span>
                        </span>
                        <span />
                    </div>
                </div>
            </div>
        </div>
    );

    return (
        <div className={styles.insuranceReferralReport}>
            <div className={styles.watermark}>
                <img src="/openmrs/frontend/hospital-logo.png" alt="watermark" />
            </div>

            <table className={styles.printTable}>
                <thead>
                    <tr>
                        <td>
                            <div className={styles.headerSpacer}>{letterhead}</div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{mainContent}</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>
                            <div className={styles.footerSpacer}>{footer}</div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default InsuranceReferralReportDocument;
