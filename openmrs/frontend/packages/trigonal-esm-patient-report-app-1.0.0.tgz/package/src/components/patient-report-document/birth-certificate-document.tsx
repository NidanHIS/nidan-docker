import { useTranslation } from 'react-i18next';
import React from 'react';
import { useConfig } from '@openmrs/esm-framework';
import styles from './birth-certificate-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { formatDisplayDate, formatDisplayTime, capitalizeFirstLetter, capitalizeWords } from '../../utils';

const hospitalLogoPath = require('../../images/hospital-logo.png');

interface BirthCertificateDocumentProps {
    newbornData: {
        fatherName?: string;
        motherName?: string;
        dateOfDelivery?: string;
        bodyWeight?: number;
        patientName?: string;
    };
    patientGender?: string;
    certificateNumber?: string;
    patientNumber?: string;
}

export const BirthCertificateDocument: React.FC<BirthCertificateDocumentProps> = ({
    newbornData,
    patientGender,
    certificateNumber,
    patientNumber,
}) => {
    const { t } = useTranslation();
    const config = useConfig();
    const { hospitalName, hospitalAddress } = (config as any) || {};

    const genderText = patientGender?.toLowerCase() === 'm' || patientGender?.toLowerCase() === 'male'
        ? t('male', 'male')
        : t('female', 'female');

    const currentDate = formatDisplayDate(new Date().toISOString());

    return (
        <div className={styles.certificateDocument}>
            {/* Watermark Logo */}
            <div className={styles.watermark}>
                <img src={hospitalLogoPath} alt="Watermark" />
            </div>

            <EncounterPrintLetterhead />

            <div className={styles.contentContainer}>
                {/* Certificate Title */}
                <div className={styles.birthCertTitleSection}>
                    <div className={styles.birthCertTitle}>{t('birthCertificateTitle', 'Birth Certificate')}</div>
                    <div className={styles.diamondSeparator}>
                        <span className={styles.diamond}>♦</span>
                    </div>
                </div>

                {/* Metadata Row */}
                <div className={styles.birthCertRefSection}>
                    <div className={styles.refItem}>
                        <span className={styles.refLabel}>{t('dateLabel', 'Date')}</span>
                        <span className={styles.refValue}>{currentDate}</span>
                    </div>
                    <div className={styles.refItem}>
                        <span className={styles.refLabel}>{t('certificateNo', 'Certificate No')}</span>
                        <span className={styles.refValue}>{certificateNumber || 'N/A'}</span>
                    </div>
                    <div className={styles.refItem}>
                        <span className={styles.refLabel}>{t('patientNo', 'Patient No')}</span>
                        <span className={styles.refValue}>{patientNumber || 'PAT-000002'}</span>
                    </div>
                </div>

                {/* Main Certification Text */}
                <div className={styles.birthCertBody}>
                    <p className={styles.birthCertMainText}>
                        This is to certify that a <strong>{capitalizeFirstLetter(genderText)}</strong> child was born to
                        Ms. <strong>{capitalizeWords(newbornData.motherName) || 'N/A'}</strong>, wife of{' '}
                        <strong>{capitalizeWords(newbornData.fatherName) || 'N/A'}</strong>, on{' '}
                        <strong>{formatDisplayDate(newbornData.dateOfDelivery)}</strong> at{' '}
                        <strong>{hospitalName || t('hospitalName', 'this Hospital')}</strong>, {hospitalAddress || t('hospitalAddress', 'Hospital Address')}.
                    </p>

                    <div className={styles.detailsDivider}>
                        <span>{t('birthDetails', 'Details of Birth')}</span>
                    </div>

                    <div className={styles.birthCertDataSection}>
                        <div className={styles.birthCertDataRow}>
                            <span className={styles.birthCertDataLabel}>{t('dateOfBirth', 'Date of Birth')}</span>
                            <span className={styles.birthCertDataValue}>{formatDisplayDate(newbornData.dateOfDelivery)}</span>
                        </div>
                        <div className={styles.birthCertDataRow}>
                            <span className={styles.birthCertDataLabel}>{t('timeOfBirth', 'Time of Birth')}</span>
                            <span className={styles.birthCertDataValue}>{formatDisplayTime(newbornData.dateOfDelivery)}</span>
                        </div>
                        <div className={styles.birthCertDataRow}>
                            <span className={styles.birthCertDataLabel}>{t('bodyWeightAtBirth', 'Body Weight at Birth')}</span>
                            <span className={styles.birthCertDataValue}>
                                {newbornData.bodyWeight ? `${newbornData.bodyWeight} ${t('kg', 'kg')}` : 'N/A'}
                            </span>
                        </div>
                    </div>

                    <div className={styles.validityStatement}>
                        {t('validityStatement', 'This certificate is issued based on the information recorded in the hospital database.')}
                    </div>
                </div>

                {/* Seal and Signature Section */}
                <div className={styles.footerBranding}>
                    <div className={styles.sealArea}>
                        <div className={styles.sealCircle}>
                            <span>{t('officialSeal', 'OFFICIAL SEAL')}</span>
                        </div>
                    </div>

                    <div className={styles.birthCertFooter}>
                        <div className={styles.signatureBlock}>
                            <div className={styles.signatureLine}></div>
                            <div className={styles.signatureLabel}>{t('nurseSignature', 'Nurse Signature')}</div>
                            <div className={styles.signatureInfo}>
                                <div className={styles.infoRow}>
                                    <span>{t('nurseName', 'Name')}:</span>
                                    <div className={styles.infoLine}></div>
                                </div>
                                <div className={styles.infoRow}>
                                    <span></span>
                                    <div className={styles.infoLine}></div>
                                </div>
                            </div>
                        </div>

                        <div className={styles.signatureBlock}>
                            <div className={styles.signatureLine}></div>
                            <div className={styles.signatureLabel}>{t('doctorSignature', "Doctor's Signature")}</div>
                            <div className={styles.signatureInfo}>
                                <div className={styles.infoRow}>
                                    <span>{t('doctorName', 'Name')}:</span>
                                    <div className={styles.infoLine}></div>
                                </div>
                                <div className={styles.infoRow}>
                                    <span>{t('nmcNumber', 'NMC No')}:</span>
                                    <div className={styles.infoLine}></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className={styles.issueDateSection}>
                {t('dateOfIssue', 'Date of Issue')}: <strong>{currentDate}</strong>
            </div>
        </div>
    );
};
