import React from 'react';
import { useTranslation } from 'react-i18next';
import useSWR from 'swr';
import { useConfig, useSession, restBaseUrl, formatDate, formatDatetime, parseDate } from '@openmrs/esm-framework';
import { ConfigObject } from '../../config-schema';
import styles from './insurance-discharge-summary-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { openmrsFetcher, getObservationDisplayValue } from '../../utils';
import { InsuranceDischargeSummaryData } from '../../hooks/useInsuranceDischargeSummaryData';
import { LabResults as LabResultsComponent } from './lab-results.component';

// ─── Procedure row with lazy concept-mapping fetch ───────────────────────────
interface ProcedureOrderRowProps {
    order: any;
    index: number;
}

const ProcedureOrderRow: React.FC<ProcedureOrderRowProps> = ({ order, index }) => {
    const { data: conceptData } = useSWR<{ mappings: { display: string }[] }, Error>(
        order.conceptUuid
            ? `${restBaseUrl}/concept/${order.conceptUuid}?v=custom:(mappings:(display))`
            : null,
        openmrsFetcher,
    );

    // Parse code from e.g. "HIB-ITEMCODE: SGI19" → "SGI19"
    const code = React.useMemo(() => {
        if (!conceptData?.mappings?.length) return null;
        for (const m of conceptData.mappings) {
            const parts = m.display?.split(':');
            if (parts && parts.length >= 2) {
                const code = parts[parts.length - 1].trim();
                if (code) return code;
            }
        }
        return null;
    }, [conceptData]);

    return (
        <tr key={order.uuid || index}>
            <td>{formatDate(parseDate(order.dateActivated), { noToday: true }) || '--'}</td>
            <td>
                <strong>{order.display || '--'}</strong>
            </td>
            <td>{code ?? '--'}</td>
            {/* <td>{order.urgency || 'ROUTINE'}</td> */}
            {/* <td>{order.instructions || '--'}</td> */}
            <td>{order.orderer?.display || '--'}</td>
        </tr>
    );
};

interface InsuranceDischargeSummaryDocumentProps {
    data: InsuranceDischargeSummaryData;
}

function getAnswerFromDisplay(display: string): string {
    const colonIndex = display.indexOf(':');
    if (colonIndex === -1) {
        return '';
    }
    return display.substring(colonIndex + 1).trim();
}

const ISO_DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;
const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T/;

function getObsValue(obs: any): string {
    const conceptClass = obs.concept?.conceptClass?.display;
    if (typeof obs.value === 'string' && obs.value) {
        if (conceptClass === 'Date' || ISO_DATE_ONLY.test(obs.value)) {
            return formatDate(parseDate(obs.value), { mode: 'wide', time: false, noToday: true });
        }
        if (conceptClass === 'Datetime' || ISO_DATETIME.test(obs.value)) {
            return formatDatetime(parseDate(obs.value), { mode: 'wide', noToday: true });
        }
    }
    return getAnswerFromDisplay(obs.display);
}

export const InsuranceDischargeSummaryDocument: React.FC<InsuranceDischargeSummaryDocumentProps> = ({ data }) => {
    const { t } = useTranslation();
    const config = useConfig<ConfigObject>();

    const session = useSession();
    const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
    const printedAt = new Date().toLocaleString();

    const letterhead = <EncounterPrintLetterhead />;

    const footer = (
        <div className={styles.repeatingFooter}>
            <span>
                {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
            </span>
        </div>
    );

    // Renders a full datetime string using the OpenMRS framework formatter
    const renderDate = (dateStr?: string | number) => {
        if (!dateStr) return '';
        try {
            const d = typeof dateStr === 'number' ? new Date(dateStr) : parseDate(String(dateStr));
            return formatDatetime(d, { mode: 'wide', noToday: true });
        } catch {
            return String(dateStr);
        }
    };

    // Renders a date-only string (no time component)
    const renderDateOnly = (dateStr?: string | number) => {
        if (!dateStr) return '';
        try {
            const d = typeof dateStr === 'number' ? new Date(dateStr) : parseDate(String(dateStr));
            return formatDate(d, { mode: 'wide', time: false, noToday: true });
        } catch {
            return String(dateStr);
        }
    };

    const encounters = data.encounters || [];

    // Aggregate unique active diagnoses
    const allDiagnoses = encounters.flatMap(encounter => {
        const providerName = encounter.encounterProviders?.[0]?.provider?.person?.display || encounter.encounterProviders?.[0]?.provider?.display || 'N/A';
        return (encounter.diagnoses || [])
            .filter((d: any) => !d.voided)
            .map((d: any) => ({
                ...d,
                encounterDatetime: encounter.encounterDatetime,
                providerName: providerName,
            }));
    });

    const uniqueDiagnoses = allDiagnoses.filter((diag, index, self) =>
        self.findIndex(d => (d.diagnosis?.uuid && d.diagnosis.uuid === diag.diagnosis?.uuid) || d.display === diag.display) === index
    );

    const excludeObsForms = config.dischargeNote?.excludeObsForms ?? [];

    // Group encounters that have observations, filtered to only "Consultation" encounter type
    // and excluding encounters whose form UUID is in the excludeObsForms config list
    const encountersWithObs = encounters
        .filter(encounter => encounter.form != null)
        .filter(encounter => !excludeObsForms.includes(encounter.form?.uuid))
        .map(encounter => {
            const providerName = encounter.encounterProviders?.[0]?.provider?.person?.display || encounter.encounterProviders?.[0]?.provider?.display || '';
            return {
                encounterId: encounter.uuid,
                encounterType: encounter.form?.name || 'Encounter',
                encounterDatetime: encounter.encounterDatetime,
                providerName: providerName,
                observations: encounter.obs || [],
            };
        }).filter(e => e.observations.length > 0);

    const provisionalDiagnoses = uniqueDiagnoses.filter((d: any) => d.certainty === 'PROVISIONAL');
    const finalDiagnoses = uniqueDiagnoses.filter((d: any) => d.certainty !== 'PROVISIONAL');

    const renderDiagnosisTable = (list: typeof uniqueDiagnoses) => (
        <table className={styles.dataTable}>
            <thead>
                <tr>
                    <th>{t('diagnosis', 'Diagnosis')}</th>
                    <th style={{ width: '12%' }}>{t('rank', 'Type')}</th>
                    <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
                    <th style={{ width: '20%' }}>{t('recordedBy', 'Recorded By')}</th>
                </tr>
            </thead>
            <tbody>
                {list.map((diag: any, index: number) => (
                    <tr key={diag.uuid || index}>
                        <td>
                            <strong>{diag.diagnosis?.display || diag.display}</strong>
                        </td>
                        <td>{
                            diag.rank === 1 || diag.rank === '1'
                                ? t('primary', 'Primary')
                                : diag.rank === 2 || diag.rank === '2'
                                    ? t('secondary', 'Secondary')
                                    : diag.rank || 'N/A'
                        }</td>
                        <td>{renderDate(diag.encounterDatetime)}</td>
                        <td>{diag.providerName}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    );

    const drugOrders = (data.orders || []).filter((order: any) => order.orderType?.name === 'Drug Order');
    const testOrders = (data.orders || []).filter((order: any) => order.orderType?.name === 'Test Order');
    const radiologyOrders = (data.orders || []).filter((order: any) => order.orderType?.name === 'Radiology Order');
    const procedureOrders = (data.orders || []).filter((order: any) => order.orderType?.name === 'Procedure Order');

    const findOrderResult = (orderUuid?: string): string | null => {
        if (!orderUuid) return null;
        for (const encounter of encounters) {
            const results: string[] = [];
            const searchObs = (obs: any) => {
                if (!obs) return;
                if (obs.order?.uuid === orderUuid) {
                    const val = getObservationDisplayValue(obs.value ?? obs);
                    if (val && val !== '--') results.push(val);
                }
                if (obs.groupMembers?.length > 0) obs.groupMembers.forEach(searchObs);
            };
            if (encounter.obs) encounter.obs.forEach(searchObs);
            if (results.length > 0) return results.join(', ');
        }
        return null;
    };

    const mainContent = (
        <div className={styles.mainContent}>
            <div className={styles.reportHeader}>
                <div className={styles.reportTitle}>
                    {t('dischargeSummaryInsuranceTitle', 'Discharge Summary')}
                </div>
            </div>

            {/* Custom Patient Insurance Header Block */}
            <div className={styles.patientHeaderBlock}>
                <div className={styles.patientHeaderLine}>
                    <span className={styles.patientName}>{data.patientName}</span>
                    <span className={styles.patientId}>[{data.hospitalNumber || data.patientId}]</span>
                    <span className={styles.patientAddress}> - {data.address}</span>
                </div>

                <div className={styles.infoGrid}>
                    {/* Column 1 */}
                    <div className={styles.infoCol}>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('dateOfBirth', 'Date of Birth')}:</span>
                            <span className={styles.value}>{data.dateOfBirth}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('age', 'Age')}:</span>
                            <span className={styles.value}>{data.patientAge}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('bloodGroup', 'Blood Group')}:</span>
                            <span className={styles.value}>{data.bloodGroup || 'N/A'}</span>
                        </div>
                    </div>

                    {/* Column 2 */}
                    <div className={styles.infoCol}>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('nhisNumber', 'NHIS Number')}:</span>
                            <span className={styles.value}>{data.nhisNumber || 'N/A'}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('ssf', 'SSF ID')}:</span>
                            <span className={styles.value}>{data.ssfId || 'N/A'}</span>
                        </div>
                    </div>

                    {/* Column 3 */}
                    <div className={styles.infoCol}>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('bedNo', 'Bed No')}:</span>
                            <span className={styles.value}>{data.admissionBedNo || 'N/A'}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('ward', 'Ward')}:</span>
                            <span className={styles.value}>{data.ward || 'N/A'}</span>
                        </div>
                    </div>

                    {/* Column 4 */}
                    <div className={styles.infoCol}>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('dateOfAdmission', 'Date of Admission')}:</span>
                            <span className={styles.value}>{renderDateOnly(data.dateOfAdmission)}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('dateOfDischarge', 'Date of Discharge')}:</span>
                            <span className={styles.value}>{renderDateOnly(data.dischargeDate)}</span>
                        </div>
                        <div className={styles.infoItem}>
                            <span className={styles.label}>{t('totalStay', 'Total Stay')}:</span>
                            <span className={styles.value}>{data.totalStay || 'N/A'}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Diagnoses Section */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('diagnoses', 'Diagnoses')}</div>
                </div>

                {/* Provisional Diagnosis */}
                <div className={styles.diagnosisSubSection}>
                    <div className={styles.diagnosisSubTitle}>{t('provisionalDiagnosis', 'Provisional Diagnosis')}</div>
                    {provisionalDiagnoses.length > 0 ? (
                        renderDiagnosisTable(provisionalDiagnoses)
                    ) : (
                        <div className={styles.noDataText}>
                            {t('noProvisionalDiagnosis', 'No provisional diagnoses recorded.')}
                        </div>
                    )}
                </div>

                {/* Final Diagnosis */}
                <div className={styles.diagnosisSubSection}>
                    <div className={styles.diagnosisSubTitle}>{t('finalDiagnosis', 'Final Diagnosis')}</div>
                    {finalDiagnoses.length > 0 ? (
                        renderDiagnosisTable(finalDiagnoses)
                    ) : (
                        <div className={styles.noDataText}>
                            {t('noFinalDiagnosis', 'No final diagnoses recorded.')}
                        </div>
                    )}
                </div>
            </div>

            {/* Medications Section */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('medications', 'Medications')}</div>
                </div>
                {drugOrders.length > 0 ? (
                    <table className={styles.dataTable}>
                        <thead>
                            <tr>
                                <th style={{ width: '15%' }}>{t('startDate', 'Start Date')}</th>
                                <th style={{ width: '30%' }}>{t('medication', 'Medication')}</th>
                                <th style={{ width: '20%' }}>{t('doseFreq', 'Dose / Freq')}</th>
                                <th style={{ width: '20%' }}>{t('instructions', 'Instructions')}</th>
                                <th style={{ width: '15%' }}>{t('orderedBy', 'Ordered By')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {drugOrders.map((order: any, index: number) => (
                                <tr key={order.uuid || index}>
                                    <td>
                                        {order.auditInfo?.dateCreated ? renderDateOnly(order.auditInfo.dateCreated) : '--'}
                                    </td>
                                    <td>
                                        <strong>{order.drug?.display || order.display}</strong>
                                    </td>
                                    <td>
                                        {order.dose} {order.doseUnits?.display} {order.frequency?.display ? `/ ${order.frequency.display}` : ''}
                                        {order.duration && <div className={styles.durationText}>{order.duration} {order.durationUnits?.display}</div>}
                                    </td>
                                    <td>
                                        {order.dosingInstructions || t('takeAsDirected', 'Take as Directed')}
                                        {order.route?.display && <div className={styles.routeText}>({order.route.display})</div>}
                                    </td>
                                    <td>{order.orderer?.display || '--'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className={styles.noDataText}>
                        {t('noMedicationsOrdered', 'No active medications ordered.')}
                    </div>
                )}
            </div>

            {/* Lab Results Section */}
            <div className={styles.section}>
                <LabResultsComponent orders={data.orders || []} />
            </div>

            {/* Radiology Orders Section */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('radiologyOrders', 'Radiology Orders')}</div>
                </div>
                {radiologyOrders.length > 0 ? (
                    <table className={styles.dataTable}>
                        <thead>
                            <tr>
                                <th style={{ width: '15%' }}>{t('date', 'Date')}</th>
                                <th style={{ width: '30%' }}>{t('testName', 'Radiology Test')}</th>
                                <th style={{ width: '15%' }}>{t('urgency', 'Urgency')}</th>
                                <th style={{ width: '15%' }}>{t('orderedBy', 'Ordered By')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {radiologyOrders.map((order: any, index: number) => {
                                return (
                                    <tr key={order.uuid || index}>
                                        <td>{formatDate(parseDate(order.dateActivated), { noToday: true }) || '--'}</td>
                                        <td>
                                            <strong>{order.display || '--'}</strong>
                                        </td>
                                        <td>{order.urgency || 'ROUTINE'}</td>
                                        <td>{order.orderer?.display || '--'}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                ) : (
                    <div className={styles.noDataText}>
                        {t('noRadiologyOrdersPlaced', 'No radiology orders placed.')}
                    </div>
                )}
            </div>

            {/* Procedure Orders Section */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('procedureOrders', 'Package')}</div>
                </div>
                {procedureOrders.length > 0 ? (
                    <table className={styles.dataTable}>
                        <thead>
                            <tr>
                                <th style={{ width: '12%' }}>{t('date', 'Date')}</th>
                                <th style={{ width: '35%' }}>{t('procedure', 'Package')}</th>
                                <th style={{ width: '13%' }}>{t('code', 'Code')}</th>
                                {/* <th style={{ width: '13%' }}>{t('urgency', 'Urgency')}</th> */}
                                {/* <th style={{ width: '13%' }}>{t('instructions', 'Instructions')}</th> */}
                                <th style={{ width: '14%' }}>{t('orderedBy', 'Ordered By')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {procedureOrders.map((order: any, index: number) => (
                                <ProcedureOrderRow key={order.uuid || index} order={order} index={index} />
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className={styles.noDataText}>
                        {t('noProcedureOrdersPlaced', 'No procedure orders placed.')}
                    </div>
                )}
            </div>

            {/* Observations (Form Data) Section */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('observationsFormData', 'Observations (Form Data)')}</div>
                </div>
                {encountersWithObs.length > 0 ? (
                    <table className={styles.dataTable}>
                        <thead>
                            <tr>
                                <th style={{ width: '40%' }}>{t('field', 'Field / Question')}</th>
                                <th style={{ width: '40%' }}>{t('value', 'Value / Answer')}</th>
                                <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {encountersWithObs.map(enc => (
                                <React.Fragment key={enc.encounterId}>
                                    {/* Form Name Header Row */}
                                    <tr className={styles.formNameRow}>
                                        <td colSpan={3}>
                                            <strong>{enc.encounterType}</strong> {enc.providerName && `(Filled by: ${enc.providerName})`}
                                        </td>
                                    </tr>
                                    {/* Observation Rows */}
                                    {enc.observations.map((obs: any, obsIndex: number) => {
                                        if (obs.groupMembers) {
                                            return (
                                                <React.Fragment key={obs.uuid || obsIndex}>
                                                    {/* Group parent header row */}
                                                    <tr>
                                                        <td colSpan={3} style={{ paddingLeft: '20px', fontWeight: 'bold' }}>
                                                            {obs.concept?.display}
                                                        </td>
                                                    </tr>
                                                    {/* Group member rows */}
                                                    {obs.groupMembers.map((member: any) => (
                                                        <tr key={member.uuid}>
                                                            <td style={{ paddingLeft: '40px' }}>{member.concept?.display}</td>
                                                            <td>
                                                                <strong>{getObsValue(member)}</strong>
                                                            </td>
                                                            <td>{renderDate(member.obsDatetime)}</td>
                                                        </tr>
                                                    ))}
                                                </React.Fragment>
                                            );
                                        }
                                        return (
                                            <tr key={obs.uuid || obsIndex}>
                                                <td style={{ paddingLeft: '20px' }}>{obs.concept?.display}</td>
                                                <td>
                                                    <strong>{getObsValue(obs)}</strong>
                                                </td>
                                                <td>{renderDate(obs.obsDatetime)}</td>
                                            </tr>
                                        );
                                    })}
                                </React.Fragment>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className={styles.noDataText}>
                        {t('noObservationsRecorded', 'No form observations recorded for this visit.')}
                    </div>
                )}
            </div>

            {/* Signatures Section */}
            <div className={styles.signaturesContainer}>
                <div className={styles.signatureCol}>
                    <div className={styles.sigTitle}>{t('preparedBy', 'PREPARED BY:')}</div>
                    <div className={styles.sigLine}>{t('drNameLabel', 'Dr. Name:')}</div>
                    <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC NO:')}</div>
                    <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
                </div>
                <div className={styles.signatureCol}>
                    <div className={styles.sigTitle}>{t('checkedBy', 'CHECKED BY:')}</div>
                    <div className={styles.sigLine}>
                        {t('drNameLabel', 'Dr. Name:')}
                    </div>
                    <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC NO:')}</div>
                    <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
                </div>
                <div className={styles.signatureCol}>
                    <div className={styles.sigTitle}>{t('consultant', 'CONSULTANT:')}</div>
                    <div className={styles.sigLine}>{t('drNameLabel', 'Dr. Name:')} {data.admissionConsultant || ''}</div>
                    <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC No:')}</div>
                    <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
                </div>
            </div>
        </div>
    );

    return (
        <div className={styles.dischargeSummary}>
            <div className={styles.watermark}>
                <img src="/openmrs/frontend/hospital-logo.png" alt="watermark" />
            </div>

            <table className={styles.printTable}>
                <thead>
                    <tr>
                        <td>
                            <div className={styles.headerSpacer}>
                                {letterhead}
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {mainContent}
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>
                            <div className={styles.footerSpacer}>
                                {footer}
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default InsuranceDischargeSummaryDocument;
