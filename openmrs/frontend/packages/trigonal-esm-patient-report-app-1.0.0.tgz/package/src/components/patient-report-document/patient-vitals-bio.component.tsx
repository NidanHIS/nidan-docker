import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './patient-vitals-bio.module.scss';

const isAbnormal = (status?: string) => status === 'low' || status === 'high';

interface VitalsBioDataProps {
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
}

export const VitalsBioData: React.FC<VitalsBioDataProps> = ({ biometricsData, vitalsData }) => {
  const { t } = useTranslation();
  return (
    <div>
      <div className={styles.printSectionTitle}>{t('vitalsBioTitle', 'VITALS AND BIOMETRICS')}</div>

      {biometricsData.effectiveDate && (
        <div className={styles.printVitalRowRight}>
          <span className={styles.printLabel}>{t('recordedDate', 'Recorded At')}:</span>
          <span className={styles.printValue}>{biometricsData.effectiveDate}</span>
        </div>
      )}

      <div className={styles.printVitalsContent}>
        {/* Vitals Data Section */}
        <div>
          {vitalsData.diastolicBP && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('diastolicBp', 'Diastolic Blood Pressure')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.diastolicBP.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.diastolicBP.value} mmHg ({vitalsData.diastolicBP.status})
              </span>
            </div>
          )}

          {vitalsData.systolicBP && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('systolicBp', 'Systolic Blood Pressure')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.systolicBP.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.systolicBP.value} mmHg
              </span>
            </div>
          )}

          {vitalsData.temperature && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('temperatureLabel', 'Temperature')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.temperature.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.temperature.value}°C
              </span>
            </div>
          )}

          {vitalsData.pulse && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('pulseLabel', 'Pulse')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.pulse.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.pulse.value} bpm
              </span>
            </div>
          )}

          {vitalsData.respiratoryRate && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('respiratoryRate', 'Respiratory Rate')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.respiratoryRate.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.respiratoryRate.value} /min
              </span>
            </div>
          )}

          {vitalsData.oxygenSaturation && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('oxygenSaturation', 'Oxygen Saturation')}:</span>
              <span className={`${styles.printValue} ${isAbnormal(vitalsData.oxygenSaturation.status) ? styles.printAbnormalValue : ''}`}>
                {vitalsData.oxygenSaturation.value}%
              </span>
            </div>
          )}
        </div>

        {/* Biometrics Data Section */}
        <div>
          {biometricsData.weight && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('weightLabel', 'Weight')}:</span>
              <span className={styles.printValue}>{biometricsData.weight} kg</span>
            </div>
          )}

          {biometricsData.height && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('heightLabel', 'Height')}:</span>
              <span className={styles.printValue}>{biometricsData.height} cm</span>
            </div>
          )}

          {biometricsData.bmi && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('bmiLabel', 'BMI')}:</span>
              <span className={styles.printValue}>{biometricsData.bmi} kg / m²</span>
            </div>
          )}

          {biometricsData.muac && (
            <div className={styles.printVitalRow}>
              <span className={styles.printLabel}>{t('muacLabel', 'MUAC')}:</span>
              <span className={styles.printValue}>{biometricsData.muac} cm</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
