import React from 'react';
import { Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';
import { useTranslation } from 'react-i18next';

export const VitalsBioData = ({ biometricsData, vitalsData, translatedTexts }) => {
  const { t } = useTranslation();

  return (
    <View>
      <Text style={styles.sectionTitle}>{translatedTexts.vitalsBioTitle}</Text>

      {biometricsData.effectiveDate && (
        <View style={[styles.vitalRow, styles.right]}>
          <Text style={styles.label}>{translatedTexts.recordedDate}:</Text>
          <Text style={styles.value}>{biometricsData.effectiveDate}</Text>
        </View>
      )}

      <View style={styles.vitalContent}>
        {/* Vitals Data Section */}
        <View>
          {vitalsData.diastolicBP && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.diastolicBp}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.diastolicBP.status === 'low' || vitalsData.diastolicBP.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.diastolicBP.value} mmHg ({vitalsData.diastolicBP.status})
              </Text>
            </View>
          )}

          {vitalsData.systolicBP && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.systolicBp}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.systolicBP.status === 'low' || vitalsData.systolicBP.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.systolicBP.value} mmHg
              </Text>
            </View>
          )}

          {vitalsData.temperature && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.temperatureLabel}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.temperature.status === 'low' || vitalsData.temperature.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.temperature.value}°C
              </Text>
            </View>
          )}

          {vitalsData.pulse && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.pulseLabel}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.pulse.status === 'low' || vitalsData.pulse.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.pulse.value} bpm
              </Text>
            </View>
          )}

          {vitalsData.respiratoryRate && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.respiratoryRate}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.respiratoryRate.status === 'low' || vitalsData.respiratoryRate.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.respiratoryRate.value} /min
              </Text>
            </View>
          )}

          {vitalsData.oxygenSaturation && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.oxygenSaturation}:</Text>
              <Text
                style={[
                  styles.value,
                  (vitalsData.oxygenSaturation.status === 'low' || vitalsData.oxygenSaturation.status === 'high') 
                    ? styles.abnormalValue 
                    : null,
                ]}
              >
                {vitalsData.oxygenSaturation.value}%
              </Text>
            </View>
          )}
        </View>

        {/* Biometrics Data Section */}
        <View>
          {biometricsData.weight && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.weightLabel}:</Text>
              <Text style={styles.value}>{biometricsData.weight} kg</Text>
            </View>
          )}

          {biometricsData.height && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.heightLabel}:</Text>
              <Text style={styles.value}>{biometricsData.height} cm</Text>
            </View>
          )}

          {biometricsData.bmi && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.bmiLabel}:</Text>
              <Text style={styles.value}>{biometricsData.bmi} kg / m²</Text>
            </View>
          )}

          {biometricsData.muac && (
            <View style={styles.vitalRow}>
              <Text style={styles.label}>{translatedTexts.muacLabel}:</Text>
              <Text style={styles.value}>{biometricsData.muac} cm</Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
};
