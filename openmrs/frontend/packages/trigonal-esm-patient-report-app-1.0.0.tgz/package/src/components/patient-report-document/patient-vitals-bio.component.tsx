import React from 'react';
import { useTranslation } from 'react-i18next';
import type { VitalsData, BiometricsData } from '../../types';
import styles from './patient-vitals-bio.module.scss';

const isAbnormal = (status?: string) => status === 'low' || status === 'high';

interface VitalsBioDataProps {
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
}

export const VitalsBioData: React.FC<VitalsBioDataProps> = ({ biometricsData, vitalsData }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printSection}>
      <div className={styles.printSectionTitle}>{t('vitalsBioTitle', 'VITALS AND BIOMETRICS')}</div>

      <div className={styles.printSectionContent}>
        {biometricsData.effectiveDate && (
          <div className={styles.recordedAtRow}>
            <span className={styles.printLabel}>{t('recordedDate', 'Recorded At')}:</span>
            <span className={styles.printValue}>{biometricsData.effectiveDate}</span>
          </div>
        )}

        <div className={styles.vitalsGrid}>
          {/* Vitals Data Column */}
          <div className={styles.vitalsColumn}>
            <div className={styles.subHeader}>{t('vitalsTitle', 'Vitals')}</div>
            <div className={styles.dataRows}>
              {vitalsData.diastolicBP && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('diastolicBp', 'Diastolic BP')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.diastolicBP.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.diastolicBP.value} mmHg
                  </span>
                </div>
              )}

              {vitalsData.systolicBP && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('systolicBp', 'Systolic BP')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.systolicBP.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.systolicBP.value} mmHg
                  </span>
                </div>
              )}

              {vitalsData.temperature && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('temperatureLabel', 'Temperature')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.temperature.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.temperature.value}°C
                  </span>
                </div>
              )}

              {vitalsData.pulse && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('pulseLabel', 'Pulse')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.pulse.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.pulse.value} bpm
                  </span>
                </div>
              )}

              {vitalsData.respiratoryRate && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('respiratoryRate', 'Resp. Rate')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.respiratoryRate.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.respiratoryRate.value} /min
                  </span>
                </div>
              )}

              {vitalsData.oxygenSaturation && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('oxygenSaturation', 'SpO2')}:</span>
                  <span className={`${styles.printValue} ${isAbnormal(vitalsData.oxygenSaturation.status) ? styles.printAbnormalValue : ''}`}>
                    {vitalsData.oxygenSaturation.value}%
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Biometrics Data Column */}
          <div className={styles.vitalsColumn}>
            <div className={styles.subHeader}>{t('biometricsTitle', 'Biometrics')}</div>
            <div className={styles.dataRows}>
              {biometricsData.weight && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('weightLabel', 'Weight')}:</span>
                  <span className={styles.printValue}>{biometricsData.weight} kg</span>
                </div>
              )}

              {biometricsData.height && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('heightLabel', 'Height')}:</span>
                  <span className={styles.printValue}>{biometricsData.height} cm</span>
                </div>
              )}

              {biometricsData.bmi && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('bmiLabel', 'BMI')}:</span>
                  <span className={styles.printValue}>{biometricsData.bmi} kg/m²</span>
                </div>
              )}

              {biometricsData.muac && (
                <div className={styles.printVitalRow}>
                  <span className={styles.printLabel}>{t('muacLabel', 'MUAC')}:</span>
                  <span className={styles.printValue}>{biometricsData.muac} cm</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
