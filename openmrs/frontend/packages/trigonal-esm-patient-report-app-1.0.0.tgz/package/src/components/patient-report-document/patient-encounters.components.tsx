import React from 'react';
import { useTranslation } from 'react-i18next';
import type { DiagnosisData, ClinicalNote } from '../../types';
import styles from './patient-encounters.module.scss';

interface DiagnosisAndClinicalNotesProps {
  diagnosisData: DiagnosisData[];
  clinicalNotes: ClinicalNote[];
}

export const DiagnosisAndClinicalNotes: React.FC<DiagnosisAndClinicalNotesProps> = ({ diagnosisData, clinicalNotes }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printSection}>
      {/* Diagnosis Section */}
      <div className={styles.subSection}>
        <div className={styles.printSectionTitle}>{t('diagnosisLabel', 'DIAGNOSIS')}</div>
        <div className={styles.printSectionContent}>
          {diagnosisData && diagnosisData.length > 0 ? (
            <div className={styles.diagnosisGrid}>
              {diagnosisData.map((diagnosis, index) => (
                <div className={styles.diagnosisItem} key={index}>
                  <span className={styles.bullet}>•</span>
                  <span className={styles.diagnosisValue}>{diagnosis.diagnosisName || '--'}</span>
                </div>
              ))}
            </div>
          ) : (
            <span className={styles.noData}>{t('noDiagnosisAvailable', 'No diagnosis recorded')}</span>
          )}
        </div>
      </div>

      {/* Clinical Notes Section */}
      <div className={styles.subSection}>
        <div className={styles.printSectionTitle}>{t('clinicalNotes', 'CLINICAL NOTES')}</div>
        <div className={styles.printSectionContent}>
          {clinicalNotes && clinicalNotes.length > 0 ? (
            <div className={styles.notesList}>
              {clinicalNotes.map((clinicalNote, index) => (
                <div className={styles.noteItem} key={index}>
                  {/* <div className={styles.noteMetadata}>
                    {clinicalNote.dateTime && <span className={styles.noteDate}>{clinicalNote.dateTime}</span>}
                  </div> */}
                  <div className={styles.noteContent}>{clinicalNote.note || '--'}</div>
                </div>
              ))}
            </div>
          ) : (
            <span className={styles.noData}>{t('noClinicalNotesAvailable', 'No clinical notes recorded')}</span>
          )}
        </div>
      </div>
    </div>
  );
};
