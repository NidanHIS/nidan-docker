import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './patient-encounters.module.scss';

interface DiagnosisAndClinicalNotesProps {
  diagnosisData: DiagnosisData[];
  clinicalNotes: ClinicalNote[];
}

export const DiagnosisAndClinicalNotes: React.FC<DiagnosisAndClinicalNotesProps> = ({ diagnosisData, clinicalNotes }) => {
  const { t } = useTranslation();
  return (
    <div>
      {/* Diagnosis Section */}
      <div>
        <div className={styles.printSectionTitle}>{t('diagnosisLabel', 'DIAGNOSIS')}</div>
        <div className={styles.printSectionContent}>
          {diagnosisData && diagnosisData.length > 0 ? (
            diagnosisData.map((diagnosis, index) => (
              <div className={styles.printBulletRow} key={index}>
                <span className={styles.printBullet}>•</span>
                <span>{diagnosis.diagnosisName || '--'}</span>
              </div>
            ))
          ) : (
            <span className={styles.printValue}>{t('noDataAvailableMessage', 'No data available')}</span>
          )}
        </div>
      </div>

      {/* Clinical Notes Section */}
      <div>
        <div className={styles.printSectionTitle}>{t('clinicalNotes', 'CLINICAL NOTES')}</div>
        <div className={styles.printSectionContent}>
          {clinicalNotes && clinicalNotes.length > 0 ? (
            clinicalNotes.map((clinicalNote, index) => (
              <div className={styles.printBulletRow} key={index}>
                <span className={styles.printBullet}>•</span>
                <span>{clinicalNote.note || '--'}</span>
              </div>
            ))
          ) : (
            <span>{t('noDataAvailableMessage', 'No data available')}</span>
          )}
        </div>
      </div>
    </div>
  );
};
