import React from 'react';
import { useTranslation } from 'react-i18next';
import type { DiagnosisData, ClinicalNote } from '../../types';
import styles from './patient-encounters.module.scss';

interface DiagnosisAndClinicalNotesProps {
  diagnosisData: DiagnosisData[];
}

const rankLabel = (rank: number | string | undefined, t: (key: string, fallback: string) => string): string => {
  if (rank === 1 || rank === '1') return t('primary', 'Primary');
  if (rank === 2 || rank === '2') return t('secondary', 'Secondary');
  return '';
};

export const DiagnosisAndClinicalNotes: React.FC<DiagnosisAndClinicalNotesProps> = ({ diagnosisData }) => {
  const { t } = useTranslation();

  const provisionalDiagnoses = (diagnosisData || []).filter(d => d.certainty === 'PROVISIONAL');
  const finalDiagnoses = (diagnosisData || []).filter(d => d.certainty !== 'PROVISIONAL' && d.certainty !== undefined);
  // Diagnoses with no certainty info fall back to a simple list
  const unknownCertainty = (diagnosisData || []).filter(d => d.certainty === undefined);

  const renderDiagnosisList = (list: DiagnosisData[]) => (
    <div className={styles.diagnosisGrid}>
      {list.map((diagnosis, index) => {
        const label = rankLabel(diagnosis.rank, t);
        return (
          <div className={styles.diagnosisItem} key={index}>
            <span className={styles.bullet}>•</span>
            {label && <span className={styles.rankLabel}>({label})</span>}
            <span className={styles.diagnosisValue}>{diagnosis.diagnosisName || '--'}</span>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className={styles.printSection}>
      {/* Diagnosis Section */}
      <div className={styles.subSection}>
        <div className={styles.printSectionTitle}>{t('diagnosisLabel', 'DIAGNOSIS')}</div>
        <div className={styles.printSectionContent}>
          {diagnosisData && diagnosisData.length > 0 ? (
            <>
              {/* Provisional Diagnosis sub-section */}
              <div className={styles.diagnosisSubSection}>
                <div className={styles.diagnosisSubTitle}>{t('provisionalDiagnosis', 'Provisional Diagnosis')}</div>
                {provisionalDiagnoses.length > 0 ? (
                  renderDiagnosisList(provisionalDiagnoses)
                ) : (
                  <span className={styles.noData}>{t('noProvisionalDiagnosis', 'No provisional diagnoses recorded')}</span>
                )}
              </div>

              {/* Final Diagnosis sub-section */}
              <div className={styles.diagnosisSubSection}>
                <div className={styles.diagnosisSubTitle}>{t('finalDiagnosis', 'Final Diagnosis')}</div>
                {finalDiagnoses.length > 0 ? (
                  renderDiagnosisList(finalDiagnoses)
                ) : (
                  <span className={styles.noData}>{t('noFinalDiagnosis', 'No final diagnoses recorded')}</span>
                )}
              </div>

              {/* Fallback for diagnoses without certainty info (legacy data) */}
              {unknownCertainty.length > 0 && renderDiagnosisList(unknownCertainty)}
            </>
          ) : (
            <span className={styles.noData}>{t('noDiagnosisAvailable', 'No diagnosis recorded')}</span>
          )}
        </div>
      </div>
    </div>
  );
};
