import React from 'react';
import { Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';

export const DiagnosisAndClinicalNotes = ({ diagnosisData, clinicalNotes, translatedTexts }) => {

  return (
    <View>
      {/* Diagnosis Section */}
      <View wrap={false}>
        <Text style={styles.sectionTitle}>{translatedTexts.diagnosisLabel}</Text>
        <View style={styles.sectionContent}>
          {diagnosisData && diagnosisData.length > 0 ? (
            diagnosisData.map((diagnosis, index) => (
              <View style={styles.tableRow} key={index}>
                <Text style={styles.bullet}>•</Text>
                <Text>{diagnosis.diagnosisName || '--'}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.value}>{translatedTexts.noDataAvailableMessage}</Text>
          )}
        </View>
      </View>

      {/* Clinical Notes Section */}
      <View wrap={false}>
        <Text style={styles.sectionTitle}>{translatedTexts.clinicalNotes}</Text>
        <View style={styles.sectionContent}>
          {clinicalNotes && clinicalNotes.length > 0 ? (
            clinicalNotes.map((clinicalNote, index) => (
              <View style={styles.tableRow} key={index}>
                <Text style={styles.bullet}>•</Text>
                <Text>{clinicalNote.note || '--'}</Text>
              </View>
            ))
          ) : (
            <Text>{translatedTexts.noDataAvailableMessage}</Text>
          )}
        </View>
      </View>
    </View>
  );
};
