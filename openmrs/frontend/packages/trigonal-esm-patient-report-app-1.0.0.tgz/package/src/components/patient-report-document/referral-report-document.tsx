import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession } from '@openmrs/esm-framework';
import { ConfigObject } from '../../config-schema';
import styles from './referral-report-document.module.scss';
import EncounterPrintLetterhead from '../../encounter-print-letterhead.component';
import { formatDisplayDateTime } from '../../utils';
import { ReferralReportData } from '../../hooks/useReferralReportData';

interface ReferralReportDocumentProps {
    data: ReferralReportData;
}

export const ReferralReportDocument: React.FC<ReferralReportDocumentProps> = ({ data }) => {
    const { t } = useTranslation();
    const config = useConfig<ConfigObject>();
    const printLetterhead = config?.printLetterhead;

    const session = useSession();
    const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
    const printedAt = new Date().toLocaleString();

    const letterhead = <EncounterPrintLetterhead />;

    const footer = (
        <div className={styles.repeatingFooter}>
            <span>
                {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
            </span>
        </div>
    );

    const signatureSection = (
        <div className={styles.footer}>
            <div className={styles.signatureBox}>
                <div className={styles.officialStamp}>{t('officialStamp', 'Official Stamp')}</div>
            </div>
            <div className={styles.signatureBox}>
                <div className={styles.signatureLine}>
                    {t('referringPhysicianSignature', 'Referring Physician Signature')}
                </div>
                <div className={styles.signatureDetails}>
                    <div className={styles.signatureDetailItem}>
                        <span className={styles.signatureLabel}>{t('name', 'Name')}:</span>
                        <span className={styles.signatureValue}>{data.providerName}</span>
                    </div>
                    <div className={styles.signatureDetailItem}>
                        <span className={styles.signatureLabel}>{t('date', 'Date')}:</span>
                        <span className={styles.signatureValue}>{formatDisplayDateTime(new Date().toISOString())}</span>
                    </div>
                </div>
            </div>
        </div>
    );

    const mainContent = (
        <div className={styles.mainContent}>
            <div className={styles.reportHeader}>
                <div className={styles.reportTitle}>
                    {t('referralReportTitle', 'Patient Referral Report')}
                </div>
            </div>

            {/* Patient Information */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('patientInformation', 'I. Patient Information')}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('fullName', 'Full Name')}</span>
                        <span className={styles.value}>{data.patientName}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('gender', 'Gender')}</span>
                        <span className={styles.value}>{data.patientGender}</span>
                    </div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('patientId', 'Patient ID')}</span>
                        <span className={styles.value}>{data.patientId}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('age', 'Age')}</span>
                        <span className={styles.value}>{data.patientAge}</span>
                    </div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('hospitalNumber', 'Hospital Number')}</span>
                        <span className={styles.value}>{data.hospitalNumber}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('referralDate', 'Referral Date & Time')}</span>
                        <span className={styles.value}>{formatDisplayDateTime(data.encounterDatetime)}</span>
                    </div>
                </div>
            </div>

            {/* Referral Details */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('referralDetails', 'II. Referral Details')}</div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('referInstitutionName', 'Referred To (Institution)')}</span>
                        <span className={styles.value}>{data.referInstitutionName || t('notSpecified', 'Not Specified')}</span>
                    </div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('remarks', 'Clinical Remarks / Reason for Referral')}</span>
                    <div className={styles.longText}>{data.remarks}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('treatmentSuggestion', 'Treatment Provided / Suggestions')}</span>
                    <div className={styles.longText}>{data.treatmentSuggestion}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('followUpInstructions', 'Follow-up Instructions')}</span>
                    <div className={styles.longText}>{data.followUpInstructions}</div>
                </div>
            </div>
            {signatureSection}
        </div>
    );

    return (
        <div className={styles.referralReport}>
            <div className={styles.watermark}>
                <img src="/openmrs/frontend/hospital-logo.png" alt="watermark" />
            </div>

            <table className={styles.printTable}>
                <thead>
                    <tr>
                        <td>
                            <div className={styles.headerSpacer}>
                                {letterhead}
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {mainContent}
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>
                            <div className={styles.footerSpacer}>
                                {footer}
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default ReferralReportDocument;
