import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { useDischargeSummaryData } from '../hooks/useDischargeSummaryData';
import { DischargeSummaryDocument } from './patient-report-document/discharge-summary-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface DischargeSummaryModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const DischargeSummaryModal: React.FC<DischargeSummaryModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { dischargeSummaryData, isLoading, error } = useDischargeSummaryData(patientUuid);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `discharge_summary_${dischargeSummaryData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    if (isLoading) {
        return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
    }

    if (error) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('dischargeSummary', 'Discharge Summary')} />
                <ModalBody>
                    <p>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    if (!dischargeSummaryData) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('dischargeSummary', 'Discharge Summary')} />
                <ModalBody>
                    <p>{t('noDischargeSummaryData', 'No discharge summary data found for this patient.')}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('dischargeSummary', 'Discharge Summary')} />
            <ModalBody>
                <div className={sharedStyles.printPreviewContainer}>
                    <div className={sharedStyles.printPreviewScaleWrapper}>
                        <div ref={contentRef}>
                            <DischargeSummaryDocument data={dischargeSummaryData} />
                        </div>
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default DischargeSummaryModal;
