import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useDischargeSummaryData } from '../hooks/useDischargeSummaryData';
import { DischargeSummaryDocument } from './patient-report-document/discharge-summary-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface DischargeSummaryModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const DischargeSummaryModal: React.FC<DischargeSummaryModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { dischargeSummaryData, isLoading, error } = useDischargeSummaryData(patientUuid);

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading discharge summary data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `discharge_summary_${dischargeSummaryData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('dischargeSummary', 'Discharge Summary')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !dischargeSummaryData && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noDischargeSummaryData', 'No discharge summary data found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && dischargeSummaryData && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <DischargeSummaryDocument data={dischargeSummaryData} />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !dischargeSummaryData}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default DischargeSummaryModal;
