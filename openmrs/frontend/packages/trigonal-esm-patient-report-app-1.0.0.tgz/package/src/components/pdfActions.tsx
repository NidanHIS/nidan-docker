import React from 'react';
import { BlobProvider } from '@react-pdf/renderer';
import { Button } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { PatientSummaryDocument } from './patient-report-document/PatientSummaryDocument'

interface PDFActionsProps {
  patientInfo: {
    name: string;
    age: string | number;
    birthDate: string;
    gender: string;
    address: string;
  };
  visitDetails: {
    visitType: string;
    location: string;
    startDatetime: string;
  };
  orders: Array<{
    orderType: {
    name: string;
  };
  drug: {
    display: string;
  };
  dose: number;
  doseUnits: {
    display: string;
  };
  frequency: {
    display: string;
  };
  route: {
    display: string;
  };
  duration: number;
  durationUnits: {
    display: string;
  };
  dosingInstructions?: string;
  dateActivated?: string;
  scheduledDate?: string;
  display?: string;
  urgency?: string;
  instructions?: string;
  auditInfo?: {
    dateCreated: string;
  }
  }>;
  vitalsData: {
    diastolicBP?: {
    value: number;
    status: string;
  }
  systolicBP?: {
    value: number;
    status: string;
  };
  temperature?: {
    value: number;
    status: string;
  };
  pulse?: {
    value: number;
    status: string;
  };
  generalNote?: {
    value: number;
    status: string;
  };
  respiratoryRate?: {
    value: number;
    status: string;
  };
  oxygenSaturation?: {
    value: number;
    status: string;
  };
};
  biometricsData: {
    weight?: number;
    height?: number;
    bmi?: number;
    muac?: number;
    effectiveDate?: string;
  };
  conditionsData: {
    condition?: string;
    clinicalStatus?: string;
  }[];
  clinicalNotes: {
    note: string;
  }[];
  diagnosisData: {
    diagnosisName: string;
  }[];
}

interface PDFRenderProps {
  blob: Blob | null;
  url: string | null;
  loading: boolean;
  error: Error | null;
}

const PDFActions: React.FC<PDFActionsProps> = ({ patientInfo, visitDetails, orders, vitalsData, biometricsData, conditionsData, diagnosisData, clinicalNotes }) => {
  
  const { t } = useTranslation();
  const translatedTexts = {
    patientReportTitle: t('patientReportTitle', 'Patient Report'),
    patientName: t('patientName', 'Name'),
    patientDob: t('patientDob', 'DOB'),
    patientAgeSex: t('patientAgeSex', 'Age/Sex'),
    patientAddress: t('patientAddress', 'Address'),
    visitType: t('visitType', 'Visit Type'),
    visitLocation: t('visitLocation', 'Location'),
    visitDate: t('visitDate', 'Visit Date'),
    vitalsBioTitle: t('vitalsBioTitle', 'VITALS AND BIOMETRICS'),
    recordedDate: t('recordedDate', 'Recorded At'),
    diastolicBp: t('diastolicBp', 'Diastolic Blood Pressure'),
    systolicBp: t('systolicBp', 'Systolic Blood Pressure'),
    temperatureLabel: t('temperatureLabel', 'Temperature'),
    pulseLabel: t('pulseLabel', 'Pulse'),
    respiratoryRate: t('respiratoryRate', 'Respiratory Rate'),
    oxygenSaturation: t('oxygenSaturation', 'Oxygen Saturation'),
    weightLabel: t('weightLabel', 'Weight'),
    heightLabel: t('heightLabel', 'Height'),
    bmiLabel: t('bmiLabel', 'BMI'),
    muacLabel: t('muacLabel', 'MUAC'),
    historyOfPresentIllness: t('historyOfPresentIllness', 'HISTORY OF PRESENT ILLNESS'),
    dateOfOnset: t('dateOfOnset', 'Date of onset'),
    conditionLabel: t('conditionLabel', 'Condition'),
    statusLabel: t('statusLabel', 'Status'),
    diagnosisLabel: t('diagnosisLabel', 'DIAGNOSIS'),
    noDataAvailableMessage: t('noDataAvailableMessage', 'No data available'),
    clinicalNotes: t('clinicalNotes', 'CLINICAL NOTES'),
    medicationsTitle: t('medicationsTitle', 'MEDICATIONS'),
    startDate: t('startDate', 'Start Date'),
    medicationLabel: t('medicationLabel', 'Medication'),
    doseLabel: t('doseLabel', 'Dose'),
    frequencyLabel: t('frequencyLabel', 'Frequency'),
    instructionsLabel: t('instructionsLabel', 'Instructions'),
    durationLabel: t('durationLabel', 'Duration'),
    takeAsDirected: t('takeAsDirected', 'Take as Directed'),
    testOrdersTitle: t('testOrdersTitle', 'TEST ORDERS'),
    dateOfOrder: t('dateOfOrder', 'Date of order'),
    orderType: t('orderType', 'Order Type'),
    urgencyLabel: t('urgencyLabel', 'Urgency'),
    scheduledDate: t('scheduledDate', 'Scheduled Date'),
  };
  

  const handlePreview = (url: string | null) => {
    if (url) {
      window.open(url, '_blank');
    }
  };

  const handleDownload = (url: string | null) => {
    if (url) {
      const link = document.createElement('a');     
      const reportName= t('reportName', 'patient_report')
      link.href = url;
      const cleanName = patientInfo.name.replace(/[^a-zA-Z0-9]/g, '_');
      const date = new Date().toISOString().split('T')[0];
      link.download = `${reportName}_${cleanName}_${date}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <BlobProvider
      document={
        <PatientSummaryDocument
          patientInfo={patientInfo}
          visitDetails={visitDetails}
          orders={orders}
          vitalsData={vitalsData}
          biometricsData={biometricsData}
          conditionsData={conditionsData}
          diagnosisData={diagnosisData}
          clinicalNotes={clinicalNotes}
          translatedTexts={translatedTexts}
        />
      }
    >
      {({ blob, url, loading, error }: PDFRenderProps) => (
        <>
            <Button 
              kind="primary"
              disabled={loading || !!error}
              onClick={() => url && handlePreview(url)}
            >
              {t('previewSummary', 'Preview Report')}
            </Button>
            <Button 
              kind="secondary" 
              disabled={loading || !!error}
              onClick={() => url && handleDownload(url)}
            >
            {loading 
              ? `${t('loading', 'Loading')}...` 
              : error 
                ? t('error', 'Error generating PDF')
                : t('printSummaryTitle', 'Download Report')
            }
          </Button>
          </>
      )}
    </BlobProvider>
  );
};

export default PDFActions;
