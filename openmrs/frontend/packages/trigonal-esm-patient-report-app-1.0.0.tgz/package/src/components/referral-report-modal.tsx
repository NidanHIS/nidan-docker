import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { useReferralReportData } from '../hooks/useReferralReportData';
import { ReferralReportDocument } from './patient-report-document/referral-report-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface ReferralReportModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const ReferralReportModal: React.FC<ReferralReportModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { referralReportData, isLoading, error } = useReferralReportData(patientUuid);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `referral_report_${referralReportData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    if (isLoading) {
        return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
    }

    if (error) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('referralReport', 'Referral Report')} />
                <ModalBody>
                    <p>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    if (!referralReportData) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('referralReport', 'Referral Report')} />
                <ModalBody>
                    <p>{t('noReferralData', 'No referral data found for this patient.')}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('referralReport', 'Referral Report')} />
            <ModalBody>
                <div className={sharedStyles.printPreviewContainer}>
                    <div className={sharedStyles.printPreviewScaleWrapper}>
                        <div ref={contentRef}>
                            <ReferralReportDocument data={referralReportData} />
                        </div>
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default ReferralReportModal;
