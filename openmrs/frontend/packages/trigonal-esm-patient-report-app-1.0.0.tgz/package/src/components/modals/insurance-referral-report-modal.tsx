import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useInsuranceReferralReportData } from '../../hooks/useInsuranceReferralReportData';
import { InsuranceReferralReportDocument } from '../documents/insurance-referral-report-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../../styles/print-styles.module.scss';

interface InsuranceReferralReportModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const InsuranceReferralReportModal: React.FC<InsuranceReferralReportModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { insuranceReferralReportData, isLoading, error } = useInsuranceReferralReportData(patientUuid);

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading referral report data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `insurance_referral_report_${insuranceReferralReportData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('referralReportInsurance', 'Referral Report (Insurance)')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !insuranceReferralReportData && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noInsuranceReferralData', 'No referral data found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && insuranceReferralReportData && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <InsuranceReferralReportDocument data={insuranceReferralReportData} />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !insuranceReferralReportData}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default InsuranceReferralReportModal;
