import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useReferralReportData } from '../../hooks/reports/useReferralReportData';
import ReferralReportDocument from '../documents/referral-report-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../../styles/print-styles.module.scss';

interface ReferralReportModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const ReferralReportModal: React.FC<ReferralReportModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { referralReportData, isLoading, error } = useReferralReportData(patientUuid);

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading referral report data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `referral_report_${referralReportData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('referralReport', 'Referral Report')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !referralReportData && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noReferralData', 'No referral data found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && referralReportData && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <ReferralReportDocument data={referralReportData} />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !referralReportData}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default ReferralReportModal;
