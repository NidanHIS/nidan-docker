// import React, { useState } from 'react';
// import { useTranslation } from 'react-i18next';
// import {
//   Button,
//   ModalBody,
//   ModalFooter,
//   ModalHeader,
//   TextArea,
//   InlineLoading,
//   ProgressBar,
//   InlineNotification,
//   Form,
//   FormGroup,
//   Stack,
// } from '@carbon/react';
// import { showSnackbar } from '@openmrs/esm-framework';
// import { uploadPdfAsAttachment, extractErrorMessage } from '../../utils/pdf-utils';

// // ─── Props ────────────────────────────────────────────────────────────────────

// interface UploadAttachmentModalProps {
//   /** The PDF blob to upload. */
//   pdfBlob: Blob;
//   /** Suggested filename (e.g. "discharge_summary_John_Doe_2026-09-03.pdf") */
//   filename: string;
//   /** Patient UUID — sent as the "patient" field in the multipart body. */
//   patientUuid: string;
//   /** Human-readable report type shown in the modal title (e.g. "Discharge Summary") */
//   reportType: string;
//   /** Called when the modal should close (success or cancel). */
//   closeModal: () => void;
// }

// // ─── Component ────────────────────────────────────────────────────────────────

// const UploadAttachmentModal: React.FC<UploadAttachmentModalProps> = ({
//   pdfBlob,
//   filename,
//   patientUuid,
//   reportType,
//   closeModal,
// }) => {
//   const { t } = useTranslation();

//   const [fileCaption, setFileCaption] = useState('');
//   const [isUploading, setIsUploading] = useState(false);
//   const [uploadError, setUploadError] = useState<string | null>(null);

//   // ── Handlers ──────────────────────────────────────────────────────────────

//   const handleUpload = async () => {
//     setIsUploading(true);
//     setUploadError(null);

//     try {
//       await uploadPdfAsAttachment({
//         patientUuid,
//         fileCaption: fileCaption.trim(),
//         blob: pdfBlob,
//         filename,
//       });

//       showSnackbar({
//         title: t('uploadSuccess', 'Upload successful'),
//         subtitle: t(
//           'uploadSuccessSubtitle',
//           '{{filename}} has been saved to patient attachments.',
//           { filename },
//         ),
//         kind: 'success',
//         isLowContrast: true,
//       });

//       closeModal();
//     } catch (err) {
//       const msg = extractErrorMessage(
//         err,
//         t('uploadFailedFallback', 'Failed to upload the attachment. Please try again.'),
//       );
//       setUploadError(msg);
//       showSnackbar({
//         title: t('uploadFailed', 'Upload failed'),
//         subtitle: msg,
//         kind: 'error',
//         isLowContrast: false,
//       });
//     } finally {
//       setIsUploading(false);
//     }
//   };

//   // ── Render ────────────────────────────────────────────────────────────────

//   return (
//     <>
//       <ModalHeader
//         closeModal={closeModal}
//         title={t('uploadToAttachments', 'Upload to Attachments')}
//       />

//       <ModalBody>
//         <Stack gap={5}>
//           {/* Context info */}
//           <p style={{ margin: 0, color: 'var(--cds-text-secondary)' }}>
//             {t(
//               'uploadModalDescription',
//               'Upload "{{reportType}}" as a PDF to this patient\'s attachment records.',
//               { reportType },
//             )}
//           </p>

//           <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--cds-text-secondary)' }}>
//             <strong>{t('filename', 'Filename')}:</strong> {filename}
//           </p>

//           {/* Metadata form */}
//           <Form aria-label={t('uploadAttachmentForm', 'Upload attachment form')}>
//             <FormGroup legendText="">
//               <TextArea
//                 id="file-caption"
//                 labelText={t('fileCaption', 'Description (optional)')}
//                 placeholder={t(
//                   'fileCaptionPlaceholder',
//                   'Add a short description for this attachment…',
//                 )}
//                 value={fileCaption}
//                 onChange={(e) => setFileCaption(e.currentTarget.value)}
//                 rows={3}
//                 disabled={isUploading}
//                 maxCount={255}
//                 enableCounter
//               />
//             </FormGroup>
//           </Form>

//           {/* Upload progress */}
//           {isUploading && (
//             <div>
//               <InlineLoading
//                 description={t('uploading', 'Uploading…')}
//                 status="active"
//               />
//               <ProgressBar
//                 label={t('uploadProgress', 'Upload progress')}
//                 hideLabel
//                 size="small"
//                 // Indeterminate — we don't get byte-level progress from openmrsFetch
//               />
//             </div>
//           )}

//           {/* Error state */}
//           {uploadError && !isUploading && (
//             <InlineNotification
//               kind="error"
//               title={t('uploadFailed', 'Upload failed')}
//               subtitle={uploadError}
//               lowContrast
//               onClose={() => setUploadError(null)}
//             />
//           )}
//         </Stack>
//       </ModalBody>

//       <ModalFooter>
//         <Button kind="secondary" onClick={closeModal} disabled={isUploading}>
//           {t('cancel', 'Cancel')}
//         </Button>
//         <Button kind="primary" onClick={handleUpload} disabled={isUploading}>
//           {isUploading
//             ? t('uploading', 'Uploading…')
//             : t('upload', 'Upload')}
//         </Button>
//       </ModalFooter>
//     </>
//   );
// };

// export default UploadAttachmentModal;
