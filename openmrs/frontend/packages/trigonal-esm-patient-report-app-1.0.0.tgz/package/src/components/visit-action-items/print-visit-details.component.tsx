import React, { useCallback } from 'react';
import { IconButton } from '@carbon/react';
import { DocumentPdf } from '@carbon/react/icons';
import { useTranslation } from 'react-i18next';
import {
  UserHasAccess,
  type Visit,
  getCoreTranslation,
  showModal,
  useLayoutType,
} from '@openmrs/esm-framework';

interface PrintVisitSummaryProps {
  visit: Visit;
  patient: fhir.Patient;

  /**
   * If true, renders as IconButton instead
   */
  compact?: boolean;
}

/**
 * Renders a print button in the visit action items slot.
 * Clicking opens the patient summary modal pre-scoped to the given visit.
 */
const PrintVisitSummary: React.FC<PrintVisitSummaryProps> = ({ visit, patient }) => {
  const { t } = useTranslation();

  const isTablet = useLayoutType() === 'tablet';
  const responsiveSize = isTablet ? 'lg' : 'sm';
  const patientUuid = patient.id;

  const handleClick = useCallback(() => {
    const dispose = showModal('print-visit-summary-dialog', {
      closeModal: () => dispose(),
      patientUuid,
      visit,
    });
  }, [patientUuid, visit]);

  return (
    <UserHasAccess privilege="Get Encounter">
      <IconButton
        label={getCoreTranslation('print')}
        size={responsiveSize}
        kind="ghost"
        align="top-end"
        onClick={handleClick}
      >
        <DocumentPdf size={16} />
      </IconButton>
    </UserHasAccess>
  );
};

export default PrintVisitSummary;
