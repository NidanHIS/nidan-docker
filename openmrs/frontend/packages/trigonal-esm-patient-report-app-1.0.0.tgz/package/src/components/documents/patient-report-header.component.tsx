import React from 'react';
import { useTranslation } from 'react-i18next';
import type { PatientInfo, VisitDetails } from '../../types';
import { safeFormatDate } from '../../utils';
import styles from './patient-report-header.module.scss';

interface ReportHeaderProps {
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
}

export const ReportHeader: React.FC<ReportHeaderProps> = ({ patientInfo, visitDetails }) => {
  const { t } = useTranslation();
  return (
    <div className={styles.printHeader}>
      <div className={styles.printHeaderLeft}>
        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('patientName', 'Name')}:</span>
          <span className={styles.printValue}>{patientInfo.name}</span>
        </div>

        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('patientDob', 'DOB')}:</span>
          <span className={styles.printValue}>{safeFormatDate(patientInfo.birthDate)}</span>
          <span className={styles.printSpacing}>
            <span className={styles.printLabel}>{t('patientAgeSex', 'Age/Sex')}:</span>
            <span className={styles.printValue}>{patientInfo.age}Y / {patientInfo.gender}</span>
          </span>
        </div>

        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('patientAddress', 'Address')}:</span>
          <span className={styles.printValue}>{patientInfo.address}</span>
        </div>

        {/* {(patientInfo.nhisNumber || patientInfo.ssfId) && ( */}
          <div className={styles.printRow}>
                <span className={styles.printLabel}>{t('nhisNumber', 'NHIS')}:</span>
                <span className={styles.printValue}>{patientInfo.nhisNumber || ''}</span>
              <span className={styles.printSpacing}>
                <span className={styles.printLabel}>{t('ssfId', 'SSF ID')}:</span>
                <span className={styles.printValue}>{patientInfo.ssfId || ''}</span>
              </span>
          </div>
        {/* )} */}
      </div>

      <div className={styles.printHeaderRight}>
        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('visitType', 'Visit Type')}:</span>
          <span className={styles.printValue}>{visitDetails.visitType}</span>
        </div>

        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('visitLocation', 'Location')}:</span>
          <span className={styles.printValue}>{visitDetails.location}</span>
        </div>

        <div className={styles.printRow}>
          <span className={styles.printLabel}>{t('visitDate', 'Visit Date')}:</span>
          <span className={styles.printValue}>{safeFormatDate(visitDetails.startDatetime)}</span>
        </div>
      </div>
    </div>
  );
};
