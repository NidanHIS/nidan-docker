import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession } from '@openmrs/esm-framework';
import type { PatientInfo, VisitDetails, Orders, VitalsData, BiometricsData, ConditionsData, DiagnosisData } from '../../types';
import type { ConfigObject } from '../../config-schema';
import { getObsValue, safeFormatDate, getEncounterProviderDisplay } from '../../utils';
import { useObsConceptsConfig, useProviderConfig } from '../../config-helpers';
import styles from './patient-summary-document.module.scss';
import EncounterPrintLetterhead from '../print/encounter-print-letterhead.component';
import { ReportHeader as ReportHeaderComponent } from '../documents/patient-report-header.component';
import { VitalsBioData as VitalsBioDataComponent } from '../documents/patient-vitals-bio.component';
import { ConditionsData as ConditionsDataComponent } from '../documents/patient-conditions-history.component';
import { DiagnosisAndClinicalNotes as DiagnosisAndClinicalNotesComponent } from '../documents/patient-encounters.components';
import { OrdersData as OrdersDataComponent } from '../documents/patient-orders.component';
import { LabResults as LabResultsComponent } from '../documents/lab-results.component';
import type { EncounterFull, ObsRaw } from '../../types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface PatientSummaryDocumentProps {
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
  orders: Orders[];
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
  conditionsData: ConditionsData[];
  diagnosisData: DiagnosisData[];
  providerName?: string;
  encounters?: EncounterFull[];
  chiefComplaint?: string | null;
}

interface HpiEntry {
  value: string;
  obsDatetime: string;
}

interface EncounterForObsTable {
  encounterId: string;
  encounterType: string;
  encounterDatetime: string;
  providerName: string;
  observations: ObsRaw[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Recursively searches an obs list (including groupMembers) for entries
 * matching the History of Present Illness concept UUID.
 * The UUID is passed as a parameter so it is read from config at runtime.
 */
function findHpiObs(obsList: ObsRaw[], hpiConceptUuid: string): HpiEntry[] {
  const found: HpiEntry[] = [];
  for (const obs of obsList) {
    if (obs.concept?.uuid === hpiConceptUuid && obs.value != null && obs.value !== '') {
      const val =
        typeof obs.value === 'object'
          ? obs.value.display ?? JSON.stringify(obs.value)
          : String(obs.value);
      found.push({ value: val, obsDatetime: obs.obsDatetime });
    }
    if (obs.groupMembers?.length) {
      found.push(...findHpiObs(obs.groupMembers, hpiConceptUuid));
    }
  }
  return found;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const PatientSummaryDocument: React.FC<PatientSummaryDocumentProps> = ({
  patientInfo,
  visitDetails,
  orders,
  vitalsData,
  biometricsData,
  conditionsData,
  diagnosisData,
  providerName,
  encounters = [],
  chiefComplaint,
}) => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();
  const obsConcepts = useObsConceptsConfig();
  const { medicalCouncilNumberAttributeTypeUuid } = useProviderConfig();
  const session = useSession();

  const printedBy =
    session?.user?.person?.display ??
    session?.user?.username ??
    session?.user?.display ??
    t('unknownUser', 'Unknown User');
  const printedAt = new Date().toLocaleString();

  const excludeObsForms = config.patientSummaryDocument?.excludeObsForms ?? [];

  // Encounters with observations, filtered to Consultation type and non-excluded forms
  const encountersWithObs = React.useMemo((): EncounterForObsTable[] => {
    return encounters
      .filter((enc) => enc.encounterType?.display === 'Consultation')
      .filter((enc) => enc.form != null)
      .filter((enc) => !excludeObsForms.includes(enc.form!.uuid))
      .map((enc) => ({
        encounterId: enc.uuid,
        encounterType: enc.form?.name ?? 'Encounter',
        encounterDatetime: enc.encounterDatetime,
        providerName: getEncounterProviderDisplay(enc.encounterProviders, medicalCouncilNumberAttributeTypeUuid) ?? '',
        observations: enc.obs ?? [],
      }))
      .filter((enc) => enc.observations.length > 0);
  }, [encounters, excludeObsForms, medicalCouncilNumberAttributeTypeUuid]);

  // History of Present Illness entries from all consultation encounters
  const hpiEntries = React.useMemo((): HpiEntry[] => {
    return encounters
      .filter((enc) => enc.encounterType?.display === 'Consultation')
      .flatMap((enc) => findHpiObs(enc.obs ?? [], obsConcepts.historyOfPresentIllnessUuid));
  }, [encounters, obsConcepts.historyOfPresentIllnessUuid]);

  // ── Render helpers ──────────────────────────────────────────────────────────

  const footer = (
    <div className={styles.repeatingFooter}>
      <span>
        {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')}{' '}
        <strong>{printedBy}</strong>
      </span>
    </div>
  );

  const signatureSection = (
    <div className={styles.printFooter}>
      <div className={styles.signatureSection}>
        <div className={styles.signatureBox}>
          <div className={styles.signatureLine}>
            {t('medicalOfficerSignature', 'Medical Officer Signature')}
          </div>
          <div className={styles.signatureDetails}>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('doctorName', 'Name')}:</span>
              <span className={styles.signatureValue}>
                {providerName ?? '________________________'}
              </span>
            </div>
            <div className={styles.signatureRow}>
              <span className={styles.signatureLabel}>{t('registrationNo', 'Reg No')}:</span>
              <span className={styles.signatureValue}>________________________</span>
            </div>
          </div>
        </div>
        <div className={styles.stampBox}>
          <div className={styles.officialStamp}>{t('officialStamp', 'Official Stamp')}</div>
        </div>
      </div>
    </div>
  );

  const mainContent = (
    <div className={styles.printMainContent}>
      <h1 className={styles.printTitle}>{t('patientReportTitle', 'Patient Report')}</h1>

      <ReportHeaderComponent patientInfo={patientInfo} visitDetails={visitDetails} />

      <hr className={styles.printHr} />

      {/* Chief Complaint */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>{t('chiefComplaint', 'Chief Complaint')}</div>
        <div className={styles.printSectionContent}>
          {chiefComplaint ? (
            <div className={styles.chiefComplaintValue}>{chiefComplaint}</div>
          ) : (
            <span className={styles.noData}>{t('noChiefComplaintRecorded', 'No chief complaint recorded')}</span>
          )}
        </div>
      </div>

      {/* History of Present Illness */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>
          {t('historyOfPresentIllness', 'History of Present Illness')}
        </div>
        <div className={styles.printSectionContent}>
          {hpiEntries.length > 0 ? (
            hpiEntries.map((entry, idx) => (
              <div key={idx} className={styles.hpiEntry}>
                <span className={styles.hpiValue}>{entry.value}</span>
                {entry.obsDatetime && (
                  <span className={styles.hpiDate}> — {safeFormatDate(entry.obsDatetime)}</span>
                )}
              </div>
            ))
          ) : (
            <span className={styles.noData}>
              {t('noHpiRecorded', 'No history of present illness recorded')}
            </span>
          )}
        </div>
      </div>

      <VitalsBioDataComponent vitalsData={vitalsData} biometricsData={biometricsData} />
      <ConditionsDataComponent conditionsData={conditionsData} />
      <DiagnosisAndClinicalNotesComponent diagnosisData={diagnosisData} />
      <OrdersDataComponent orders={orders} />
      <LabResultsComponent orders={orders} />

      {/* Observations (Form Data) */}
      <div className={styles.printSection}>
        <div className={styles.printSectionTitle}>
          {t('observationsFormData', 'Observations (Form Data)')}
        </div>
        <div className={styles.printSectionContent}>
          {encountersWithObs.length > 0 ? (
            <table className={styles.printObsTable}>
              <thead>
                <tr>
                  <th style={{ width: '40%' }}>{t('field', 'Field / Question')}</th>
                  <th style={{ width: '40%' }}>{t('value', 'Value / Answer')}</th>
                  <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
                </tr>
              </thead>
              <tbody>
                {encountersWithObs.map((enc) => (
                  <React.Fragment key={enc.encounterId}>
                    <tr className={styles.formNameRow}>
                      <td colSpan={3}>
                        <strong>{enc.encounterType}</strong>
                        {enc.providerName && ` (Filled by: ${enc.providerName})`}
                      </td>
                    </tr>
                    {enc.observations.map((obs, obsIndex) => {
                      if (obs.groupMembers?.length) {
                        return (
                          <React.Fragment key={obs.uuid ?? obsIndex}>
                            <tr>
                              <td colSpan={3} style={{ paddingLeft: '20px', fontWeight: 'bold' }}>
                                {obs.concept?.display}
                              </td>
                            </tr>
                            {obs.groupMembers.map((member) => (
                              <tr key={member.uuid}>
                                <td style={{ paddingLeft: '40px' }}>{member.concept?.display}</td>
                                <td>
                                  <strong>{getObsValue(member)}</strong>
                                </td>
                                <td>{safeFormatDate(member.obsDatetime)}</td>
                              </tr>
                            ))}
                          </React.Fragment>
                        );
                      }
                      return (
                        <tr key={obs.uuid ?? obsIndex}>
                          <td style={{ paddingLeft: '20px' }}>{obs.concept?.display}</td>
                          <td>
                            <strong>{getObsValue(obs)}</strong>
                          </td>
                          <td>{safeFormatDate(obs.obsDatetime)}</td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          ) : (
            <span className={styles.noData}>
              {t('noObservationsRecorded', 'No form observations recorded for this visit.')}
            </span>
          )}
        </div>
      </div>

      {signatureSection}
    </div>
  );

  return (
    <div className={styles.printableDocument}>
      <table className={styles.printTable}>
        <thead>
          <tr>
            <td>
              <div className={styles.headerSpacer}>
                {config.printLetterhead && <EncounterPrintLetterhead />}
              </div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{mainContent}</td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className={styles.footerSpacer}>{footer}</div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default PatientSummaryDocument;
