import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession } from '@openmrs/esm-framework';
import { ConfigObject } from '../../config-schema';
import styles from './discharge-summary-document.module.scss';
import EncounterPrintLetterhead from '../print/encounter-print-letterhead.component';
import { formatDisplayDate } from '../../utils';
import { DischargeSummaryData } from '../../hooks/reports/useDischargeSummaryData';

interface DischargeSummaryDocumentProps {
    data: DischargeSummaryData;
}

export const DischargeSummaryDocument: React.FC<DischargeSummaryDocumentProps> = ({ data }) => {
    const { t } = useTranslation();
    const config = useConfig<ConfigObject>();
    const logoSrc = config?.hospitalLogoUrl || '/openmrs/frontend/hospital-logo.png';

    const session = useSession();
    const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
    const printedAt = new Date().toLocaleString();

    const letterhead = <EncounterPrintLetterhead />;

    const footer = (
        <div className={styles.repeatingFooter}>
            <span>
                {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
            </span>
        </div>
    );

    const signatureSection = (
        <div className={styles.footer}>
            <div className={styles.signatureBox}>
                <div className={styles.officialStamp}>{t('officialStamp', 'Official Stamp')}</div>
            </div>
            <div className={styles.signatureBox}>
                <div className={styles.signatureLine}>
                    {t('physicianSignature', 'Physician Signature')}
                </div>
                <div className={styles.signatureDetails}>
                    <div className={styles.signatureDetailItem}>
                        <span className={styles.signatureLabel}>{t('name', 'Name')}:</span>
                        <span className={styles.signatureValue}>{data.providerName}</span>
                    </div>
                    <div className={styles.signatureDetailItem}>
                        <span className={styles.signatureLabel}>{t('date', 'Date')}:</span>
                        <span className={styles.signatureValue}>{formatDisplayDate(new Date().toISOString())}</span>
                    </div>
                </div>
            </div>
        </div>
    );

    const mainContent = (
        <div className={styles.mainContent}>
            <div className={styles.reportHeader}>
                <div className={styles.reportTitle}>
                    {t('dischargeSummaryTitle', 'Discharge Summary')}
                </div>
            </div>

            {/* Patient Information */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('patientInformation', 'I. Patient Information')}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('fullName', 'Full Name')}</span>
                        <span className={styles.value}>{data.patientName}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('gender', 'Gender')}</span>
                        <span className={styles.value}>{data.patientGender}</span>
                    </div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('patientId', 'Patient ID')}</span>
                        <span className={styles.value}>{data.patientId}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('age', 'Age')}</span>
                        <span className={styles.value}>{data.patientAge}</span>
                    </div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('hospitalNumber', 'Hospital Number')}</span>
                        <span className={styles.value}>{data.hospitalNumber}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('admissionDate', 'Admission Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.dateOfAdmission)}</span>
                    </div>
                </div>
                <div className={`${styles.row} ${styles.rowLast}`}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('dischargeDate', 'Discharge Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.dischargeDate)}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('inpatientOutcome', 'Outcome')}</span>
                        <span className={styles.value}>{data.inpatientOutcome || t('notSpecified', 'Not Specified')}</span>
                    </div>
                </div>
            </div>

            {/* Clinical Details */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('clinicalDetails', 'II. Clinical Details')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('diagnosis', 'Final Diagnosis')}</span>
                    <div className={styles.longText}>{data.diagnosis || t('notSpecified', 'Not Specified')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('briefHospitalCourse', 'Brief Hospital Course')}</span>
                    <div className={styles.longText}>{data.briefHospitalCourse}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('majorSurgery', 'Major Surgery')}</span>
                        <span className={styles.value}>{data.majorSurgery || t('none', 'None')}</span>
                    </div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('postOpComplications', 'Post Operative Complications')}</span>
                    <div className={styles.longText}>{data.postOpComplications || t('none', 'None')}</div>
                </div>
            </div>

            {/* Discharge Instructions */}
            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.sectionTitle}>{t('dischargeInstructions', 'III. Discharge Instructions')}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('medicationOnDischarge', 'Medications on Discharge')}</span>
                    <div className={styles.longText}>{data.medicationOnDischarge}</div>
                </div>
                <div className={styles.longTextContainer}>
                    <span className={styles.label}>{t('followUpInstructions', 'Follow-up Instructions')}</span>
                    <div className={styles.longText}>{data.followUpInstructions}</div>
                </div>
                <div className={styles.row}>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('followUpDate', 'Follow-up Date')}</span>
                        <span className={styles.value}>{formatDisplayDate(data.followUpDate)}</span>
                    </div>
                    <div className={styles.col}>
                        <span className={styles.label}>{t('dischargedTo', 'Discharged To')}</span>
                        <span className={styles.value}>{data.dischargedTo}</span>
                    </div>
                </div>
            </div>
            {signatureSection}
        </div>
    );

    return (
        <div className={styles.dischargeSummary}>
            <div className={styles.watermark}>
                <img src={logoSrc} alt="watermark" />
            </div>

            <table className={styles.printTable}>
                <thead>
                    <tr>
                        <td>
                            <div className={styles.headerSpacer}>
                                {letterhead}
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {mainContent}
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>
                            <div className={styles.footerSpacer}>
                                {footer}
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default DischargeSummaryDocument;
