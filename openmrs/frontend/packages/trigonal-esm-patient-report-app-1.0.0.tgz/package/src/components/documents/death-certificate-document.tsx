import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession } from '@openmrs/esm-framework';
import { ConfigObject } from '../../config-schema';
import styles from './death-certificate-document.module.scss';
import EncounterPrintLetterhead from '../print/encounter-print-letterhead.component';
import { formatDisplayDateTime } from '../../utils';
import { DeathNoteData } from '../../hooks/reports/useDeathNoteData';

const hospitalLogoPath = require('../../images/hospital-logo.png');

interface DeathCertificateDocumentProps {
    data: DeathNoteData;
}

export const DeathCertificateDocument: React.FC<DeathCertificateDocumentProps> = ({
    data,
}) => {
    const { t } = useTranslation();
    const config = useConfig<ConfigObject>();
    const printLetterhead = config?.printLetterhead;

    const session = useSession();
    const printedBy = session?.user?.person?.display || session?.user?.username || session?.user?.display || t('unknownUser', 'Unknown User');
    const printedAt = new Date().toLocaleString();

    const letterhead = <EncounterPrintLetterhead />;

    const footer = (
        <div className={styles.repeatingFooter}>
            <span>
                {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')} <strong>{printedBy}</strong>
            </span>
        </div>
    );

    const signatureSection = (
        <div className={styles.deathCertFooter}>
            <div className={styles.deathCertSignatureBox}>
                <div className={styles.officialStamp}>{t('officialStamp', 'Official Stamp')}</div>
            </div>
            <div className={styles.deathCertSignatureBox}>
                <div className={styles.deathCertSignatureLine}>
                    {t('medicalOfficerSignature', 'Medical Officer Signature')}
                </div>
                <div className={styles.deathCertSignatureText}>
                    <span className={styles.deathCertSignatureLabel}>{t('doctorName', 'Name')}:</span>
                    <span className={styles.deathCertSignatureValue}>{data.providerName}</span>
                </div>
                <div className={styles.deathCertSignatureText}>
                    <span className={styles.deathCertSignatureLabel}>{t('qualification', 'Qualification')}:</span>
                    <span className={styles.deathCertSignatureValue}>{data.providerQualification}</span>
                </div>
                <div className={styles.deathCertSignatureText}>
                    <span className={styles.deathCertSignatureLabel}>{t('registrationNo', 'Registration No')}:</span>
                    <span className={styles.deathCertSignatureValue}>{data.providerRegistrationNumber}</span>
                </div>
                <div className={styles.deathCertSignatureText}>
                    <span className={styles.deathCertSignatureLabel}>{t('dateLabel', 'Date')}:</span>
                    <span className={styles.deathCertSignatureValue}>{formatDisplayDateTime(data.dateSigned)}</span>
                </div>
            </div>
        </div>
    );

    const mainContent = (
        <div className={styles.deathCertMainContent}>
            <div className={styles.deathCertHeader}>
                <div className={styles.deathCertDocTitle}>{t('deathCertificateTitle', 'DEATH CERTIFICATE')}</div>
            </div>

            {/* Patient Identification */}
            <div className={styles.deathCertSection}>
                <div className={styles.deathCertSectionHeader}>
                    <div className={styles.deathCertSectionTitle}>{t('patientInformation', 'I. PATIENT INFORMATION')}</div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('fullName', 'Full Name')}</span>
                        <span className={styles.deathCertValue}>{data.patientName}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('gender', 'Gender')}</span>
                        <span className={styles.deathCertValue}>{data.patientGender}</span>
                    </div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('patientId', 'Patient ID')}</span>
                        <span className={styles.deathCertValue}>{data.patientId}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('age', 'Age')}</span>
                        <span className={styles.deathCertValue}>{data.patientAge}</span>
                    </div>
                </div>
                <div className={`${styles.deathCertRow} ${styles.deathCertRowLast}`}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('placeOfDeath', 'Place of Death')}</span>
                        <span className={styles.deathCertValue}>{data.placeOfDeath}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('wardUnit', 'Ward/Unit')}</span>
                        <span className={styles.deathCertValue}>{data.wardOrUnit}</span>
                    </div>
                </div>
            </div>

            {/* Details of Death */}
            <div className={styles.deathCertSection}>
                <div className={styles.deathCertSectionHeader}>
                    <div className={styles.deathCertSectionTitle}>{t('detailsOfDeath', 'II. DETAILS OF DEATH')}</div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('dateTimeOfDeath', 'Date & Time of Death')}</span>
                        <span className={styles.deathCertValue}>{formatDisplayDateTime(data.dateAndTimeOfDeath)}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('mannerOfDeath', 'Manner of Death')}</span>
                        <span className={styles.deathCertValue}>{data.mannerOfDeath}</span>
                    </div>
                </div>
                <div className={`${styles.deathCertRow} ${styles.deathCertRowLast}`}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('broughtDead', 'Brought Dead')}</span>
                        <span className={styles.deathCertValue}>{data.broughtDead}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('deathType', 'Death Type')}</span>
                        <span className={styles.deathCertValue}>{data.deathType}</span>
                    </div>
                </div>
            </div>


            {/* III. Cause of Death */}
            <div className={styles.deathCertSection}>
                <div className={styles.deathCertSectionHeader}>
                    <div className={styles.deathCertSectionTitle}>{t('causeOfDeathLabel', 'III. CAUSE OF DEATH')}</div>
                </div>

                <div className={styles.deathCertCauseTable}>
                    <div className={styles.deathCertPartHeader}>
                        {t('causeOfDeathPart1', 'Part I: Chain of Events Leading Directly to Death')}
                    </div>

                    {/* Immediate Cause */}
                    <div className={styles.deathCertCauseRow}>
                        <div className={styles.deathCertCauseLabel}>a)</div>
                        <div className={styles.deathCertCauseContent}>
                            <span className={styles.deathCertLabel}>{t('immediateCause', 'Immediate Cause')}</span>
                            <div className={styles.deathCertCauseValue}>{data.immediateCause}</div>
                        </div>
                    </div>

                    {/* Antecedent Cause */}
                    <div className={styles.deathCertCauseRow}>
                        <div className={styles.deathCertCauseLabel}>b)</div>
                        <div className={styles.deathCertCauseContent}>
                            <span className={styles.deathCertLabel}>{t('antecedentCause', 'Due to (Antecedent Cause)')}</span>
                            <div className={styles.deathCertCauseValue}>{data.antecedentCause}</div>
                        </div>
                    </div>

                    {/* Underlying Cause */}
                    <div className={`${styles.deathCertCauseRow} ${styles.deathCertCauseRowLast}`}>
                        <div className={styles.deathCertCauseLabel}>c)</div>
                        <div className={styles.deathCertCauseContent}>
                            <span className={styles.deathCertLabel}>{t('underlyingCause', 'Due to (Underlying Cause)')}</span>
                            <div className={styles.deathCertCauseValue}>{data.underlyingCause}</div>
                        </div>
                    </div>

                    <div className={`${styles.deathCertPartHeader} ${styles.deathCertPartHeaderTop}`}>
                        {t('causeOfDeathPart2', 'Part II: Other Significant Conditions Contributing to Death')}
                    </div>
                    <div className={styles.deathCertOtherConditions}>
                        {data.otherSignificantConditions || t('noOtherConditions', 'None')}
                    </div>
                </div>
            </div>

            {/* IV. Administrative & Legal */}
            <div className={styles.deathCertSection}>
                <div className={styles.deathCertSectionHeader}>
                    <div className={styles.deathCertSectionTitle}>{t('administrativeLegal', 'IV. ADMINISTRATIVE & LEGAL')}</div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('medicoLegalCase', 'Medico-Legal Case')}</span>
                        <span className={styles.deathCertValue}>{data.medicoLegalCase}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('postMortemDone', 'Post-mortem Done')}</span>
                        <span className={styles.deathCertValue}>{data.postMortemDone}</span>
                    </div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('maternalDeath', 'Maternal Death')}</span>
                        <span className={styles.deathCertValue}>{data.maternalDeathStatus}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('postOperative', 'Post-Operative')}</span>
                        <span className={styles.deathCertValue}>{data.postOperativeDeath}</span>
                    </div>
                </div>
                <div className={styles.deathCertRow}>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('familyInformed', 'Family Informed')}</span>
                        <span className={styles.deathCertValue}>{data.familyInformed}</span>
                    </div>
                    <div className={styles.deathCertCol}>
                        <span className={styles.deathCertLabel}>{t('mdgpNotifiedAt', 'MDGP Notified At')}</span>
                        <span className={styles.deathCertValue}>{data.mdgpNotifiedAt}</span>
                    </div>
                </div>
                <div className={`${styles.deathCertRow} ${styles.deathCertRowLast}`}>
                    <div className={styles.deathCertCol} style={{ flexDirection: 'column' }}>
                        <span className={styles.deathCertLabel}>{t('briefHospitalCourse', 'Brief Hospital Course')}</span>
                        <div className={styles.hospitalCourse}>{data.briefHospitalCourse}</div>
                    </div>
                </div>
            </div>
            {signatureSection}
        </div>
    );

    return (
        <div className={styles.deathCertDocument}>
            <table className={styles.printTable}>
                <thead>
                    <tr>
                        <td>
                            <div className={styles.headerSpacer}>
                                {letterhead}
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {mainContent}
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>
                            <div className={styles.footerSpacer}>
                                {footer}
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default DeathCertificateDocument;

