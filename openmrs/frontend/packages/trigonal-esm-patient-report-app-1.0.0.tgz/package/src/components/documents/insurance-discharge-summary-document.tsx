import React from 'react';
import { useTranslation } from 'react-i18next';
import useSWR from 'swr';
import { useConfig, useSession, restBaseUrl, formatDate, parseDate } from '@openmrs/esm-framework';
import type { ConfigObject } from '../../config-schema';
import {
  openmrsFetcher,
  getObsValue,
  getObservationDisplayValue,
  getEncounterProviderDisplay,
  renderDateTime,
  renderDateOnly,
  nepaliDateOnly,
} from '../../utils';
import type { InsuranceDischargeSummaryData } from '../../hooks/reports/useInsuranceDischargeSummaryData';
import type { EncounterFull, ObsRaw, DiagnosisWithMeta } from '../../types';
import { LabResults as LabResultsComponent } from '../documents/lab-results.component';
import { ConditionsData as ConditionsDataComponent } from '../documents/patient-conditions-history.component';
import EncounterPrintLetterhead from '../print/encounter-print-letterhead.component';
import { useProviderConfig } from '../../config-helpers';
import styles from './insurance-discharge-summary-document.module.scss';

// ─── Sub-components ───────────────────────────────────────────────────────────

interface ProcedureOrderRowProps {
  order: {
    uuid?: string;
    display?: string;
    dateActivated?: string;
    conceptUuid?: string | null;
    orderer?: { display?: string };
  };
  index: number;
}

/**
 * Renders a single procedure order row, lazily fetching the HIB item code via
 * the concept mappings endpoint so the main document data fetch stays lean.
 */
const ProcedureOrderRow: React.FC<ProcedureOrderRowProps> = ({ order, index }) => {
  const { data: conceptData } = useSWR<{ mappings: { display: string }[] }, Error>(
    order.conceptUuid
      ? `${restBaseUrl}/concept/${order.conceptUuid}?v=custom:(mappings:(display))`
      : null,
    openmrsFetcher,
  );

  const code = React.useMemo(() => {
    if (!conceptData?.mappings?.length) return null;
    for (const m of conceptData.mappings) {
      const parts = m.display?.split(':');
      if (parts && parts.length >= 2) {
        const trimmed = parts[parts.length - 1].trim();
        if (trimmed) return trimmed;
      }
    }
    return null;
  }, [conceptData]);

  return (
    <tr key={order.uuid ?? index}>
      <td>{order.dateActivated ? renderDateOnly(order.dateActivated) : '--'}</td>
      <td>
        <strong>{order.display ?? '--'}</strong>
      </td>
      <td>{code ?? '--'}</td>
      <td>{order.orderer?.display ?? '--'}</td>
    </tr>
  );
};

// ─── Types ────────────────────────────────────────────────────────────────────

interface InsuranceDischargeSummaryDocumentProps {
  data: InsuranceDischargeSummaryData;
}

interface EncounterForObsTable {
  encounterId: string;
  encounterType: string;
  encounterDatetime: string;
  providerName: string;
  observations: ObsRaw[];
}

// ─── Component ────────────────────────────────────────────────────────────────

export const InsuranceDischargeSummaryDocument: React.FC<InsuranceDischargeSummaryDocumentProps> = ({
  data,
}) => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();
  const session = useSession();
  const { medicalCouncilNumberAttributeTypeUuid } = useProviderConfig();

  const printedBy =
    session?.user?.person?.display ??
    session?.user?.username ??
    session?.user?.display ??
    t('unknownUser', 'Unknown User');
  const printedAt = new Date().toLocaleString();

  const encounters: EncounterFull[] = (data.encounters ?? []) as EncounterFull[];
  const excludeObsForms = config.dischargeNote?.excludeObsForms ?? [];

  // ── Diagnoses ───────────────────────────────────────────────────────────────

  const allDiagnoses: DiagnosisWithMeta[] = encounters.flatMap((enc) => {
    const providerName = getEncounterProviderDisplay(enc.encounterProviders, medicalCouncilNumberAttributeTypeUuid) ?? 'N/A';
    return (enc.diagnoses ?? [])
      .filter((d) => !d.voided)
      .map((d) => ({
        diagnosisName: d.diagnosis?.display ?? d.display ?? '',
        rank: d.rank,
        certainty: d.certainty,
        encounterDatetime: enc.encounterDatetime,
        providerName,
      }));
  });

  // Deduplicate by diagnosis UUID, falling back to display text
  const uniqueDiagnoses = allDiagnoses.filter((diag, index, self) =>
    self.findIndex(
      (d) =>
        (diag.diagnosisName && d.diagnosisName === diag.diagnosisName),
    ) === index,
  );

  const provisionalDiagnoses = uniqueDiagnoses.filter((d) => d.certainty === 'PROVISIONAL');
  const finalDiagnoses = uniqueDiagnoses.filter((d) => d.certainty !== 'PROVISIONAL');

  // ── Encounters with observations ────────────────────────────────────────────

  const encountersWithObs = React.useMemo((): EncounterForObsTable[] => {
    return encounters
      .filter((enc) => enc.form != null)
      .filter((enc) => !excludeObsForms.includes(enc.form!.uuid))
      .map((enc) => ({
        encounterId: enc.uuid,
        encounterType: enc.form?.name ?? 'Encounter',
        encounterDatetime: enc.encounterDatetime,
        providerName: getEncounterProviderDisplay(enc.encounterProviders, medicalCouncilNumberAttributeTypeUuid) ?? '',
        observations: enc.obs ?? [],
      }))
      .filter((enc) => enc.observations.length > 0);
  }, [encounters, excludeObsForms, medicalCouncilNumberAttributeTypeUuid]);

  // ── Orders ──────────────────────────────────────────────────────────────────

  const drugOrders = (data.orders ?? []).filter((o) => o.orderType?.name === 'Drug Order');
  const radiologyOrders = (data.orders ?? []).filter((o) => o.orderType?.name === 'Radiology Order');
  const procedureOrders = (data.orders ?? []).filter((o) => o.orderType?.name === 'Procedure Order');

  // ── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Searches all encounter obs (including group members) for an obs linked to
   * the given order UUID and returns the formatted display value.
   */
  const findOrderResult = (orderUuid?: string): string | null => {
    if (!orderUuid) return null;
    for (const encounter of encounters) {
      const results: string[] = [];
      const searchObs = (obs: ObsRaw) => {
        if (obs.order?.uuid === orderUuid) {
          const val = getObservationDisplayValue(obs.value as any);
          if (val && val !== '--') results.push(val);
        }
        obs.groupMembers?.forEach(searchObs);
      };
      encounter.obs?.forEach(searchObs);
      if (results.length > 0) return results.join(', ');
    }
    return null;
  };

  const renderDiagnosisTable = (list: DiagnosisWithMeta[]) => (
    <table className={styles.dataTable}>
      <thead>
        <tr>
          <th>{t('diagnosis', 'Diagnosis')}</th>
          <th style={{ width: '12%' }}>{t('rank', 'Type')}</th>
          <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
          <th style={{ width: '20%' }}>{t('recordedBy', 'Recorded By')}</th>
        </tr>
      </thead>
      <tbody>
        {list.map((diag, index) => (
          <tr key={`${diag.diagnosisName}-${index}`}>
            <td>
              <strong>{diag.diagnosisName}</strong>
            </td>
            <td>
              {diag.rank === 1 || diag.rank === '1'
                ? t('primary', 'Primary')
                : diag.rank === 2 || diag.rank === '2'
                  ? t('secondary', 'Secondary')
                  : diag.rank ?? 'N/A'}
            </td>
            <td>{renderDateTime(diag.encounterDatetime)}</td>
            <td>{diag.providerName}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  // ── Layout ──────────────────────────────────────────────────────────────────

  const footer = (
    <div className={styles.repeatingFooter}>
      <span>
        {t('printedOn', 'Printed on')} <strong>{printedAt}</strong> {t('by', 'by')}{' '}
        <strong>{printedBy}</strong>
      </span>
    </div>
  );

  const mainContent = (
    <div className={styles.mainContent}>
      <div className={styles.reportHeader}>
        <div className={styles.reportTitle}>
          {t('dischargeSummaryInsuranceTitle', 'Discharge Summary')}
        </div>
      </div>

      {/* Patient header block */}
      <div className={styles.patientHeaderBlock}>
        <div className={styles.patientHeaderLine}>
          <span className={styles.patientName}>{data.patientName}</span>
          <span className={styles.patientId}>[{data.hospitalNumber ?? data.patientId}]</span>
          <span className={styles.patientAddress}> - {data.address}</span>
        </div>

        <div className={styles.infoGrid}>
          <div className={styles.infoCol}>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('dateOfBirth', 'Date of Birth')}:</span>
              <span className={styles.value}>{data.dateOfBirth}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('age', 'Age')}:</span>
              <span className={styles.value}>{data.patientAge}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('bloodGroup', 'Blood Group')}:</span>
              <span className={styles.value}>{data.bloodGroup ?? 'N/A'}</span>
            </div>
          </div>

          <div className={styles.infoCol}>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('nhisNumber', 'NHIS Number')}:</span>
              <span className={styles.value}>{data.nhisNumber ?? 'N/A'}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('ssf', 'SSF ID')}:</span>
              <span className={styles.value}>{data.ssfId ?? 'N/A'}</span>
            </div>
          </div>

          <div className={styles.infoCol}>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('bedNo', 'Bed No')}:</span>
              <span className={styles.value}>{data.admissionBedNo ?? 'N/A'}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('ward', 'Ward')}:</span>
              <span className={styles.value}>{data.ward ?? 'N/A'}</span>
            </div>
          </div>

          <div className={styles.infoCol}>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('dateOfAdmission', 'Date of Admission')}:</span>
              <span className={styles.value}>{nepaliDateOnly(data.dateOfAdmission)}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('dateOfDischarge', 'Date of Discharge')}:</span>
              <span className={styles.value}>{nepaliDateOnly(data.dischargeDate)}</span>
            </div>
            <div className={styles.infoItem}>
              <span className={styles.label}>{t('totalStay', 'Total Stay')}:</span>
              <span className={styles.value}>{data.totalStay ?? 'N/A'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Diagnoses */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <div className={styles.sectionTitle}>{t('diagnoses', 'Diagnoses')}</div>
        </div>

        <div className={styles.diagnosisSubSection}>
          <div className={styles.diagnosisSubTitle}>
            {t('provisionalDiagnosis', 'Provisional Diagnosis')}
          </div>
          {provisionalDiagnoses.length > 0 ? (
            renderDiagnosisTable(provisionalDiagnoses)
          ) : (
            <div className={styles.noDataText}>
              {t('noProvisionalDiagnosis', 'No provisional diagnoses recorded.')}
            </div>
          )}
        </div>

        <div className={styles.diagnosisSubSection}>
          <div className={styles.diagnosisSubTitle}>
            {t('finalDiagnosis', 'Final Diagnosis')}
          </div>
          {finalDiagnoses.length > 0 ? (
            renderDiagnosisTable(finalDiagnoses)
          ) : (
            <div className={styles.noDataText}>
              {t('noFinalDiagnosis', 'No final diagnoses recorded.')}
            </div>
          )}
        </div>
      </div>

      {/* Conditions */}
      <div className={styles.section}>
        <ConditionsDataComponent conditionsData={data.conditionsData ?? []} />
      </div>

      {/* Medications */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <div className={styles.sectionTitle}>{t('medications', 'Medications')}</div>
        </div>
        {drugOrders.length > 0 ? (
          <table className={styles.dataTable}>
            <thead>
              <tr>
                <th style={{ width: '15%' }}>{t('startDate', 'Start Date')}</th>
                <th style={{ width: '30%' }}>{t('medication', 'Medication')}</th>
                <th style={{ width: '20%' }}>{t('doseFreq', 'Dose / Freq')}</th>
                <th style={{ width: '20%' }}>{t('instructions', 'Instructions')}</th>
                <th style={{ width: '15%' }}>{t('orderedBy', 'Ordered By')}</th>
              </tr>
            </thead>
            <tbody>
              {drugOrders.map((order, index) => (
                <tr key={order.uuid ?? index}>
                  <td>{order.auditInfo?.dateCreated ? renderDateOnly(order.auditInfo.dateCreated) : '--'}</td>
                  <td>
                    <strong>{order.drug?.display ?? order.display}</strong>
                  </td>
                  <td>
                    {order.dose} {order.doseUnits?.display}
                    {order.frequency?.display ? ` / ${order.frequency.display}` : ''}
                    {order.duration && (
                      <div className={styles.durationText}>
                        {order.duration} {order.durationUnits?.display}
                      </div>
                    )}
                  </td>
                  <td>
                    {order.dosingInstructions ?? t('takeAsDirected', 'Take as Directed')}
                    {order.route?.display && (
                      <div className={styles.routeText}>({order.route.display})</div>
                    )}
                  </td>
                  <td>{order.orderer?.display ?? '--'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className={styles.noDataText}>
            {t('noMedicationsOrdered', 'No active medications ordered.')}
          </div>
        )}
      </div>

      {/* Lab Results */}
      <div className={styles.section}>
        <LabResultsComponent orders={data.orders ?? []} />
      </div>

      {/* Radiology Orders */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <div className={styles.sectionTitle}>{t('radiologyOrders', 'Radiology Orders')}</div>
        </div>
        {radiologyOrders.length > 0 ? (
          <table className={styles.dataTable}>
            <thead>
              <tr>
                <th style={{ width: '15%' }}>{t('date', 'Date')}</th>
                <th style={{ width: '30%' }}>{t('testName', 'Radiology Test')}</th>
                <th style={{ width: '15%' }}>{t('urgency', 'Urgency')}</th>
                <th style={{ width: '15%' }}>{t('orderedBy', 'Ordered By')}</th>
              </tr>
            </thead>
            <tbody>
              {radiologyOrders.map((order, index) => (
                <tr key={order.uuid ?? index}>
                  <td>
                    {order.dateActivated
                      ? renderDateOnly(String(order.dateActivated))
                      : '--'}
                  </td>
                  <td>
                    <strong>{order.display ?? '--'}</strong>
                  </td>
                  <td>{order.urgency ?? 'ROUTINE'}</td>
                  <td>{order.orderer?.display ?? '--'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className={styles.noDataText}>
            {t('noRadiologyOrdersPlaced', 'No radiology orders placed.')}
          </div>
        )}
      </div>

      {/* Procedure / Package Orders */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <div className={styles.sectionTitle}>{t('procedureOrders', 'Package')}</div>
        </div>
        {procedureOrders.length > 0 ? (
          <table className={styles.dataTable}>
            <thead>
              <tr>
                <th style={{ width: '12%' }}>{t('date', 'Date')}</th>
                <th style={{ width: '35%' }}>{t('procedure', 'Package')}</th>
                <th style={{ width: '13%' }}>{t('code', 'Code')}</th>
                <th style={{ width: '14%' }}>{t('orderedBy', 'Ordered By')}</th>
              </tr>
            </thead>
            <tbody>
              {procedureOrders.map((order, index) => (
                <ProcedureOrderRow key={order.uuid ?? index} order={order as any} index={index} />
              ))}
            </tbody>
          </table>
        ) : (
          <div className={styles.noDataText}>
            {t('noProcedureOrdersPlaced', 'No procedure orders placed.')}
          </div>
        )}
      </div>

      {/* Observations (Form Data) */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <div className={styles.sectionTitle}>
            {t('observationsFormData', 'Observations (Form Data)')}
          </div>
        </div>
        {encountersWithObs.length > 0 ? (
          <table className={styles.dataTable}>
            <thead>
              <tr>
                <th style={{ width: '40%' }}>{t('field', 'Field / Question')}</th>
                <th style={{ width: '40%' }}>{t('value', 'Value / Answer')}</th>
                <th style={{ width: '20%' }}>{t('dateRecorded', 'Date Recorded')}</th>
              </tr>
            </thead>
            <tbody>
              {encountersWithObs.map((enc) => (
                <React.Fragment key={enc.encounterId}>
                  <tr className={styles.formNameRow}>
                    <td colSpan={3}>
                      <strong>{enc.encounterType}</strong>
                      {enc.providerName && ` (Filled by: ${enc.providerName})`}
                    </td>
                  </tr>
                  {enc.observations.map((obs, obsIndex) => {
                    if (obs.groupMembers?.length) {
                      return (
                        <React.Fragment key={obs.uuid ?? obsIndex}>
                          <tr>
                            <td colSpan={3} style={{ paddingLeft: '20px', fontWeight: 'bold' }}>
                              {obs.concept?.display}
                            </td>
                          </tr>
                          {obs.groupMembers.map((member) => (
                            <tr key={member.uuid}>
                              <td style={{ paddingLeft: '40px' }}>{member.concept?.display}</td>
                              <td>
                                <strong>{getObsValue(member)}</strong>
                              </td>
                              <td>{renderDateTime(member.obsDatetime)}</td>
                            </tr>
                          ))}
                        </React.Fragment>
                      );
                    }
                    return (
                      <tr key={obs.uuid ?? obsIndex}>
                        <td style={{ paddingLeft: '20px' }}>{obs.concept?.display}</td>
                        <td>
                          <strong>{getObsValue(obs)}</strong>
                        </td>
                        <td>{renderDateTime(obs.obsDatetime)}</td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        ) : (
          <div className={styles.noDataText}>
            {t('noObservationsRecorded', 'No form observations recorded for this visit.')}
          </div>
        )}
      </div>

      {/* Signatures */}
      <div className={styles.signaturesContainer}>
        <div className={styles.signatureCol}>
          <div className={styles.sigTitle}>{t('preparedBy', 'PREPARED BY:')}</div>
          <div className={styles.sigLine}>{t('drNameLabel', 'Dr. Name:')}</div>
          <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC NO:')}</div>
          <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
        </div>
        <div className={styles.signatureCol}>
          <div className={styles.sigTitle}>{t('checkedBy', 'CHECKED BY:')}</div>
          <div className={styles.sigLine}>{t('drNameLabel', 'Dr. Name:')}</div>
          <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC NO:')}</div>
          <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
        </div>
        <div className={styles.signatureCol}>
          <div className={styles.sigTitle}>{t('consultant', 'CONSULTANT:')}</div>
          <div className={styles.sigLine}>
            {t('drNameLabel', 'Dr. Name:')} {data.admissionConsultant ?? ''}
          </div>
          <div className={styles.sigLine}>{t('nmcNoLabel', 'NMC No:')}</div>
          <div className={styles.sigLine}>{t('signatureLabel', 'Signature:')}</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className={styles.dischargeSummary}>
      <div className={styles.watermark}>
        <img src="/openmrs/frontend/hospital-logo.png" alt="watermark" />
      </div>
      <table className={styles.printTable}>
        <thead>
          <tr>
            <td>
              <div className={styles.headerSpacer}>
                <EncounterPrintLetterhead />
              </div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{mainContent}</td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className={styles.footerSpacer}>{footer}</div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default InsuranceDischargeSummaryDocument;
