import React from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, } from '@carbon/react';
import { usePatientSummaryData } from '../hooks/usePatientSummary';
import PDFActions from './pdfActions';

interface PrintPatientSummaryProps {
  patientUuid: string;
  closeModal: () => void;
}

const PrintSummaryDialog: React.FC<PrintPatientSummaryProps> = ({ patientUuid, closeModal }) => {
  const { t } = useTranslation();
  
  const { 
    patientInfo, 
    visitDetails, 
    orders,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    isLoading, 
    error 
  } = usePatientSummaryData(patientUuid);

  if (isLoading) {
    return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
  }

  if (error) return <div>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</div>;

  return (
    <>
      <ModalHeader
        closeModal={closeModal} 
        title={t('printSummaryConfirmation', 'Do you want to print the patient report?')}
      />
      <ModalBody>
        <p>{t('printSummaryExplainerMessage', 'You can either preview or print the patient summary. This will include the details of the current visit and patient information.')}</p>
      </ModalBody>
      <ModalFooter>
        <PDFActions
          patientInfo={patientInfo}
          visitDetails={visitDetails}
          orders={orders}
          vitalsData={vitalsData}
          biometricsData={biometricsData}
          conditionsData={conditionsData}
          diagnosisData={diagnosisData}
          clinicalNotes={clinicalNotes}
        />
      </ModalFooter>
    </>
  );
};

export default PrintSummaryDialog;