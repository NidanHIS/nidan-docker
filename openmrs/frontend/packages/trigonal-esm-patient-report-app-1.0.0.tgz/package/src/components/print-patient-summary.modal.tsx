import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { usePatientSummaryData } from '../hooks/usePatientSummary';
import { PatientSummaryDocument } from './patient-report-document/patient-summary-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface PrintPatientSummaryProps {
  patientUuid: string;
  closeModal: () => void;
}

const PrintSummaryDialog: React.FC<PrintPatientSummaryProps> = ({ patientUuid, closeModal }) => {
  const { t } = useTranslation();
  const contentRef = useRef<HTMLDivElement>(null);

  const {
    patientInfo,
    visitDetails,
    orders,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    isLoading,
    error
  } = usePatientSummaryData(patientUuid);

  const handlePrint = useReactToPrint({
    contentRef,
    documentTitle: `${t('reportName', 'patient_report')}_${patientInfo?.name?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
  });

  if (isLoading) {
    return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
  }

  if (error) return <div>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</div>;

  return (
    <>
      <ModalHeader
        closeModal={closeModal}
        title={t('patientReportTitle', 'Patient Report')}
      />
      <ModalBody>
        <div className={sharedStyles.printPreviewContainer}>
          <div className={sharedStyles.printPreviewScaleWrapper}>
            <div ref={contentRef}>
              <PatientSummaryDocument
                patientInfo={patientInfo}
                visitDetails={visitDetails}
                orders={orders}
                vitalsData={vitalsData}
                biometricsData={biometricsData}
                conditionsData={conditionsData}
                diagnosisData={diagnosisData}
                clinicalNotes={clinicalNotes}
              />
            </div>
          </div>
        </div>
      </ModalBody>
      <ModalFooter>
        <Button kind="secondary" onClick={closeModal}>
          {t('close', 'Close')}
        </Button>
        <Button kind="primary" onClick={handlePrint}>
          {t('print', 'Print')}
        </Button>
      </ModalFooter>
    </>
  );
};

export default PrintSummaryDialog;