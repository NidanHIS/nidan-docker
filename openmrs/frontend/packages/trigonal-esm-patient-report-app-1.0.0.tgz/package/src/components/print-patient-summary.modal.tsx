import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { usePatientSummaryData } from '../hooks/usePatientSummary';
import { PatientSummaryDocument } from './patient-report-document/patient-summary-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface PrintPatientSummaryProps {
  patientUuid: string;
  closeModal: () => void;
}

const PrintSummaryDialog: React.FC<PrintPatientSummaryProps> = ({ patientUuid, closeModal }) => {
  const { t } = useTranslation();
  const contentRef = useRef<HTMLDivElement>(null);

  const {
    patientInfo,
    visitDetails,
    orders,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    encounters,
    chiefComplaint,
    isLoading,
    error,
  } = usePatientSummaryData(patientUuid);

  useEffect(() => {
    if (error) {
      showSnackbar({
        title: t('errorLoadingData', 'Error loading patient data'),
        subtitle: error?.message,
        kind: 'error',
        isLowContrast: false,
      });
    }
  }, [error, t]);

  const handlePrint = useReactToPrint({
    contentRef,
    documentTitle: `${t('reportName', 'patient_report')}_${patientInfo?.name?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
  });

  return (
    <>
      <ModalHeader closeModal={closeModal} title={t('patientReportTitle', 'Patient Report')} />
      <ModalBody>
        {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
        {!isLoading && !patientInfo && !error && (
          <InlineNotification
            kind="info"
            title={t('noDataFound', 'No patient data found.')}
            lowContrast
          />
        )}
        {!isLoading && patientInfo && (
          <div className={sharedStyles.printPreviewContainer}>
            <div className={sharedStyles.printPreviewScaleWrapper}>
              <div ref={contentRef}>
                <PatientSummaryDocument
                  patientInfo={patientInfo}
                  visitDetails={visitDetails}
                  orders={orders}
                  vitalsData={vitalsData}
                  biometricsData={biometricsData}
                  conditionsData={conditionsData}
                  diagnosisData={diagnosisData}
                  encounters={encounters}
                  chiefComplaint={chiefComplaint}
                />
              </div>
            </div>
          </div>
        )}
      </ModalBody>
      <ModalFooter>
        <Button kind="secondary" onClick={closeModal}>
          {t('close', 'Close')}
        </Button>
        <Button kind="primary" onClick={handlePrint} disabled={isLoading || !patientInfo}>
          {t('print', 'Print')}
        </Button>
      </ModalFooter>
    </>
  );
};

export default PrintSummaryDialog;