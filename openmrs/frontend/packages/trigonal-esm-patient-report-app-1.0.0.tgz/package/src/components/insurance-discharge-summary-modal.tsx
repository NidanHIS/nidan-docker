import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useInsuranceDischargeSummaryData } from '../hooks/useInsuranceDischargeSummaryData';
import { InsuranceDischargeSummaryDocument } from './patient-report-document/insurance-discharge-summary-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface InsuranceDischargeSummaryModalProps {
    patientUuid: string;
    visitUuid?: string;
    closeModal: () => void;
}

const InsuranceDischargeSummaryModal: React.FC<InsuranceDischargeSummaryModalProps> = ({ patientUuid, visitUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { data, isLoading, error } = useInsuranceDischargeSummaryData(patientUuid, visitUuid);

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading insurance discharge summary data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `insurance_discharge_summary_${data?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'report'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('dischargeSummaryInsurance', 'Discharge Summary')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !data && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noInsuranceDischargeSummaryData', 'No data found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && data && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <InsuranceDischargeSummaryDocument data={data} />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !data}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default InsuranceDischargeSummaryModal;
