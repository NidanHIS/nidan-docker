import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, InlineNotification, Button } from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { useNewbornAdmissionData } from '../hooks/useNewbornAdmissionData';
import { usePatientInfo } from '../hooks/usePatientInfo';
import { BirthCertificateDocument } from './patient-report-document/birth-certificate-document';
import { useReactToPrint } from 'react-to-print';
import sharedStyles from '../styles/print-styles.module.scss';

interface BirthCertificateModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const BirthCertificateModal: React.FC<BirthCertificateModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const contentRef = useRef<HTMLDivElement>(null);
    const { newbornData, isLoading: isNewbornLoading, error: newbornError } = useNewbornAdmissionData(patientUuid);
    const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);

    const isLoading = isNewbornLoading || isPatientLoading;
    const error = newbornError || patientError;

    useEffect(() => {
        if (error) {
            showSnackbar({
                title: t('errorLoadingData', 'Error loading birth certificate data'),
                subtitle: error?.message,
                kind: 'error',
                isLowContrast: false,
            });
        }
    }, [error, t]);

    const handlePrint = useReactToPrint({
        contentRef,
        documentTitle: `birth_certificate_${newbornData?.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'certificate'}_${new Date().toISOString().split('T')[0]}`,
    });

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('birthCertificate', 'Birth Certificate')} />
            <ModalBody>
                {isLoading && <InlineLoading description={`${t('loading', 'Loading')} ...`} />}
                {!isLoading && !newbornData && !error && (
                    <InlineNotification
                        kind="info"
                        title={t('noNewbornAdmissionNote', 'No Newborn admission note found for this patient.')}
                        lowContrast
                    />
                )}
                {!isLoading && newbornData && (
                    <div className={sharedStyles.printPreviewContainer}>
                        <div className={sharedStyles.printPreviewScaleWrapper}>
                            <div ref={contentRef}>
                                <BirthCertificateDocument
                                    newbornData={newbornData}
                                    patientGender={patientInfo?.gender}
                                    patientNumber={patientInfo?.patientId}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button kind="secondary" onClick={closeModal}>
                    {t('close', 'Close')}
                </Button>
                <Button kind="primary" onClick={handlePrint} disabled={isLoading || !newbornData}>
                    {t('print', 'Print')}
                </Button>
            </ModalFooter>
        </>
    );
};

export default BirthCertificateModal;
