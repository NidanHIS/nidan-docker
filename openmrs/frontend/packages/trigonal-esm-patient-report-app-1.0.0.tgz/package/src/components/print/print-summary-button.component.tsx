import React, { useCallback } from 'react';
import { MenuButton, MenuItem } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { showModal, usePatient } from '@openmrs/esm-framework';
import { useLatestVisit } from '../../hooks/visit/useLatestVisit';
import styles from './print-summary-button.scss';

const PrintSummaryButtonInner = ({ patientUuid }: { patientUuid: string }) => {
  const { t } = useTranslation();
  const { visit, isLoading } = useLatestVisit(patientUuid);

  const openModal = useCallback(
    (modalName: string) => {
      const dispose = showModal(modalName, {
        closeModal: () => dispose(),
        patientUuid,
        visitUuid: visit?.uuid,
      });
    },
    [patientUuid, visit],
  );

  if (isLoading || !visit) return null;

  const menuItems = [
    { modal: 'print-summary-dialog',              label: t('patientSummary', 'Patient Summary') },
    { modal: 'birth-certificate-modal',           label: t('birthCertificate', 'Birth Certificate') },
    { modal: 'death-certificate-modal',           label: t('deathCertificate', 'Death Certificate') },
    { modal: 'insurance-referral-report-modal',   label: t('referralReport', 'Referral Report') },
    { modal: 'insurance-referral-report-modal',   label: t('referralReportInsurance', 'Referral Report (Insurance)') },
    { modal: 'insurance-discharge-summary-modal', label: t('dischargeSummary', 'Discharge Summary') },
    { modal: 'insurance-discharge-summary-modal', label: t('dischargeSummaryInsurance', 'Discharge Summary (Insurance)') },
  ];

  return (
    <MenuButton label={t('print', 'Print')} kind="primary" className={styles.printSummaryButton}>
      {menuItems.map(({ modal, label }) => (
        <MenuItem key={modal} onClick={() => openModal(modal)} label={label} />
      ))}
    </MenuButton>
  );
};

export const PrintSummaryButton = () => {
  const { patient, isLoading } = usePatient();
  const patientUuid = patient?.id;

  if (isLoading || !patientUuid) return null;

  return <PrintSummaryButtonInner patientUuid={patientUuid} />;
};
