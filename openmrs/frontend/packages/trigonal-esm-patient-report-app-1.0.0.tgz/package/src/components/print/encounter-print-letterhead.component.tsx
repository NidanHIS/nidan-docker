import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@openmrs/esm-framework';
import type { ConfigObject } from '../../config-schema';
import styles from './encounter-print-letterhead.module.scss';

const bundledLogoPath = require('../../images/hospital-logo.png');

export const EncounterPrintLetterhead: React.FC = () => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();

  const {
    hospitalName,
    hospitalAddress,
    hospitalContactInfo,
    hospitalLetterheadTopLines,
    hospitalLetterheadBottomLines,
    printLetterhead,
    hospitalLogoUrl,
  } = config || {};

  if (printLetterhead === false) {
    return null;
  }

  // Use the config URL when set; fall back to the bundled asset
  const logoSrc = hospitalLogoUrl || bundledLogoPath;

  return (
    <div className={styles.letterhead}>
      <div className={styles.logoContainer}>
        <img src={logoSrc} alt="Hospital Logo" className={styles.logo} />
      </div>
      <div className={styles.hospitalDetails}>
        {hospitalLetterheadTopLines?.map((line: string, i: number) => (
          <p key={i} className={styles.topLine}>
            {line}
          </p>
        ))}
        <h2 className={styles.hospitalName}>{hospitalName || t('hospitalName', 'Hospital Name')}</h2>
        {hospitalLetterheadBottomLines?.map((line: string, i: number) => (
          <p key={i} className={styles.bottomLine}>
            {line}
          </p>
        ))}
        <p className={styles.address}>{hospitalAddress}</p>
        <p className={styles.contact}>{hospitalContactInfo}</p>
      </div>
      <div className={styles.spacer} />
    </div>
  );
};

export default EncounterPrintLetterhead;
