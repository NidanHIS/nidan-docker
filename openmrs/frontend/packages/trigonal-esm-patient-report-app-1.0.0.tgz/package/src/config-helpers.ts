import { useConfig } from '@openmrs/esm-framework';
import type { ConfigObject } from './config-schema';

/**
 * Returns the `forms` section of the module config — form UUIDs used when
 * filtering encounter queries by a specific clinical form.
 *
 * Using this hook instead of importing from `constants.ts` means that
 * administrators can override the UUIDs in their deployment config without
 * needing a code rebuild.
 *
 * @example
 * const { dischargeSummaryFormUuid } = useFormConfig();
 * const url = `${restBaseUrl}/nidan/encounter?form=${dischargeSummaryFormUuid}`;
 */
export function useFormConfig() {
  const { forms } = useConfig<ConfigObject>();
  return forms;
}

/**
 * Returns the `obsConcepts` section of the module config — concept UUIDs used
 * when extracting specific clinical values from encounter obs arrays.
 *
 * @example
 * const { reasonForReferralUuid } = useObsConceptsConfig();
 * const value = extractObsValue(obs, reasonForReferralUuid);
 */
export function useObsConceptsConfig() {
  const { obsConcepts } = useConfig<ConfigObject>();
  return obsConcepts;
}

/**
 * Returns the `concepts` section of the module config — vitals and biometric
 * concept UUIDs used in FHIR Observation queries.
 *
 * @example
 * const { systolicBloodPressureUuid, weightUuid } = useVitalsConceptsConfig();
 */
export function useVitalsConceptsConfig() {
  const { concepts } = useConfig<ConfigObject>();
  return concepts;
}

/**
 * Builds a comma-separated string of all vitals concept UUIDs suitable for
 * use as the `concept` query parameter in the REST /obs endpoint.
 *
 * Replaces the static `VITALS_CONCEPTS_QUERY` constant so the list stays in
 * sync with whatever UUIDs are configured at runtime.
 *
 * @example
 * const vitalsConceptsQuery = useVitalsConceptsQuery();
 * const url = `${restBaseUrl}/obs?patient=${uuid}&concept=${vitalsConceptsQuery}`;
 */
export function useVitalsConceptsQuery(): string {
  const concepts = useVitalsConceptsConfig();
  return [
    concepts.systolicBloodPressureUuid,
    concepts.diastolicBloodPressureUuid,
    concepts.pulseUuid,
    concepts.temperatureUuid,
    concepts.oxygenSaturationUuid,
    concepts.heightUuid,
    concepts.weightUuid,
    concepts.respiratoryRateUuid,
  ].join(',');
}

/**
 * Returns the `providers` section of the module config — provider attribute
 * type UUIDs used to extract typed values (e.g. NMC number) from provider records.
 *
 * @example
 * const { medicalCouncilNumberAttributeTypeUuid } = useProviderConfig();
 */
export function useProviderConfig() {
  const { providers } = useConfig<ConfigObject>();
  return providers;
}
