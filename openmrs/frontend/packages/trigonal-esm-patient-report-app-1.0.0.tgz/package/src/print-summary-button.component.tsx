import React, { useCallback } from 'react';
import { Button } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { showModal } from '@openmrs/esm-framework';
import { useVisit } from '@openmrs/esm-framework';
import styles from './print-summary-button.scss';

export interface PatientInfoProps {
  patient: fhir.Patient;
}

export const PrintSummaryButton = () => {
  const { t } = useTranslation();

  const getPatientUuid = () => {
    const pathArray = window.location.pathname.split('/');
    const patientIndex = pathArray.indexOf('patient');
    return patientIndex !== -1 ? pathArray[patientIndex + 1] : null;
  };

  const patientUuid = getPatientUuid();

  if (!patientUuid) {
    return null;
  }

  const { activeVisit, isLoading, error } = useVisit(patientUuid);

  const openSummaryPdfModal = useCallback((uuid: string) => {
    const dispose = showModal('print-summary-dialog', {
      closeModal: () => dispose(),
      patientUuid: uuid,
    });
  }, []);

  if (isLoading || !activeVisit) {
    return null;
  }

  return (
    <div>
    <Button
      kind="primary"
      onClick={() => openSummaryPdfModal(patientUuid)}
      className={styles.printSummaryButton}
    >
      {t('printSummary', 'Print Summary')}
    </Button>
    </div>
  );
};

