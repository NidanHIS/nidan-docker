import React, { useCallback } from 'react';
import { MenuButton, MenuItem } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { showModal, useVisit, usePatient } from '@openmrs/esm-framework';
import styles from './print-summary-button.scss';

const PrintSummaryButtonInner = ({ patientUuid }: { patientUuid: string }) => {
  const { t } = useTranslation();
  const { activeVisit, isLoading } = useVisit(patientUuid); // safe: uuid is guaranteed here

  const openModal = useCallback(
    (modalName: string) => {
      const dispose = showModal(modalName, {
        closeModal: () => dispose(),
        patientUuid,
        visitUuid: activeVisit?.uuid,
      });
    },
    [patientUuid, activeVisit],
  );

  if (isLoading || !activeVisit) return null;

  const menuItems = [
    { modal: 'print-summary-dialog',    label: t('patientSummary', 'Patient Summary') },
    { modal: 'birth-certificate-modal', label: t('birthCertificate', 'Birth Certificate') },
    { modal: 'death-certificate-modal', label: t('deathCertificate', 'Death Certificate') },
    { modal: 'referral-report-modal',   label: t('referralReport', 'Referral Report') },
    { modal: 'discharge-summary-modal', label: t('dischargeSummary', 'Discharge Summary') },
    { modal: 'insurance-discharge-summary-modal', label: t('dischargeSummaryInsurance', 'Discharge Summary (Insurance)') },
  ];

  return (
    <MenuButton label={t('print', 'Print')} kind="primary" className={styles.printSummaryButton}>
      {menuItems.map(({ modal, label }) => (
        <MenuItem key={modal} onClick={() => openModal(modal)} label={label} />
      ))}
    </MenuButton>
  );
};

export const PrintSummaryButton = () => {
  const { patient, isLoading } = usePatient();
  const patientUuid = patient?.id;

  // Don't render the inner component (and thus don't call useVisit)
  // until we know we actually have a patient uuid
  if (isLoading || !patientUuid) return null;

  return <PrintSummaryButtonInner patientUuid={patientUuid} />;
};