import React, { useCallback } from 'react';
import { MenuButton, MenuItem } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { showModal } from '@openmrs/esm-framework';
import { useVisit } from '@openmrs/esm-framework';
import styles from './print-summary-button.scss';

export interface PatientInfoProps {
  patient: fhir.Patient;
}

export const PrintSummaryButton = () => {
  const { t } = useTranslation();

  const getPatientUuid = () => {
    const pathArray = window.location.pathname.split('/');
    const patientIndex = pathArray.indexOf('patient');
    return patientIndex !== -1 ? pathArray[patientIndex + 1] : null;
  };

  const patientUuid = getPatientUuid();

  const { activeVisit, isLoading, error } = useVisit(patientUuid);

  const openSummaryPdfModal = useCallback((uuid: string) => {
    const dispose = showModal('print-summary-dialog', {
      closeModal: () => dispose(),
      patientUuid: uuid,
    });
  }, []);

  const openBirthCertificateModal = useCallback((uuid: string) => {
    const dispose = showModal('birth-certificate-modal', {
      closeModal: () => dispose(),
      patientUuid: uuid,
    });
  }, []);

  const openDeathCertificateModal = useCallback((uuid: string) => {
    const dispose = showModal('death-certificate-modal', {
      closeModal: () => dispose(),
      patientUuid: uuid,
    });
  }, []);

  if (!patientUuid || isLoading || !activeVisit) {
    return null;
  }


  return (
    <div>
      <MenuButton label={t('print', 'Print')} kind="primary" className={styles.printSummaryButton}>
        <MenuItem onClick={() => openSummaryPdfModal(patientUuid)} label={t('patientSummary', 'Patient Summary')} />
        <MenuItem onClick={() => openBirthCertificateModal(patientUuid)} label={t('birthCertificate', 'Birth Certificate')} />
        <MenuItem onClick={() => openDeathCertificateModal(patientUuid)} label={t('deathCertificate', 'Death Certificate')} />
      </MenuButton>
    </div>
  );
};

