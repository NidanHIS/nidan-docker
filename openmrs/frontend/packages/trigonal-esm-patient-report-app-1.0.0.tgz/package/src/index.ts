import { defineConfigSchema, getAsyncLifecycle, getSyncLifecycle } from '@openmrs/esm-framework';
import { configSchema } from './config-schema';
import { PrintSummaryButton } from './print-summary-button.component';
import PrintVisitSummary from './components/visit-action-items/print-visit-details.component';

const moduleName = '@trigonal/esm-patient-report-app';

const options = {
  featureName: 'patient-report',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

export const printSummaryButton = getSyncLifecycle(PrintSummaryButton, {
  featureName: 'patient-actions-slot',
  moduleName,
});

export const printSummaryModal = getAsyncLifecycle(() => import('./components/print-patient-summary.modal'), {
  featureName: 'print patient summary',
  moduleName,
});

export const birthCertificateModal = getAsyncLifecycle(() => import('./components/birth-certificate-modal'), {
  featureName: 'birth certificate',
  moduleName,
});

export const deathCertificateModal = getAsyncLifecycle(() => import('./components/death-certificate-modal'), {
  featureName: 'death certificate',
  moduleName,
});

export const referralReportModal = getAsyncLifecycle(() => import('./components/referral-report-modal'), {
  featureName: 'referral report',
  moduleName,
});

export const dischargeSummaryModal = getAsyncLifecycle(() => import('./components/discharge-summary-modal'), {
  featureName: 'discharge summary',
  moduleName,
});

export const insuranceDischargeSummaryModal = getAsyncLifecycle(() => import('./components/insurance-discharge-summary-modal'), {
  featureName: 'discharge summary insurance',
  moduleName,
});

export const insuranceReferralReportModal = getAsyncLifecycle(() => import('./components/insurance-referral-report-modal'), {
  featureName: 'referral report insurance',
  moduleName,
});

export const visitPrintSummary = getAsyncLifecycle(() => import('./components/visit-action-items/print-visit-details.component'), {
  featureName: 'print visit details',
  moduleName,
});

export const printVisitSummaryModal = getAsyncLifecycle(() => import('./components/print-visit-summary.modal'), {
  featureName: 'print visit summary',
  moduleName,
});

