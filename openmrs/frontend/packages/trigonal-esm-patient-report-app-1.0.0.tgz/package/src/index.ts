import { PrintSummaryButton } from './print-summary-button.component';
import { configSchema } from './config-schema';
import { getSyncLifecycle, getAsyncLifecycle, defineConfigSchema } from '@openmrs/esm-framework';

const moduleName = '@trigonal/esm-patient-report-app';

const options = {
  featureName: 'patient-report',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

export const printSummaryButton = getSyncLifecycle(PrintSummaryButton, {
  featureName: 'patient-actions-slot',
  moduleName,
});

export const printSummaryModal = getAsyncLifecycle(() => import('./components/print-patient-summary.modal'), {
  featureName: 'print patient summary',
  moduleName,
});
