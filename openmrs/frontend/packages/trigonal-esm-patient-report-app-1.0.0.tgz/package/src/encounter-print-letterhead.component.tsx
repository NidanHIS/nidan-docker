import React from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@openmrs/esm-framework';
import { ConfigObject } from './config-schema';
import styles from './encounter-print-letterhead.module.scss';

const hospitalLogoPath = require('./images/hospital-logo.png');

const EncounterPrintLetterhead: React.FC = () => {
  const { t } = useTranslation();
  const config = useConfig<ConfigObject>();

  const {
    hospitalName,
    hospitalAddress,
    hospitalContactInfo,
    hospitalLetterheadTopLines,
    hospitalLetterheadBottomLines,
    printLetterhead,
  } = config || {};

  if (printLetterhead === false) {
    return null;
  }

  return (
    <div className={styles.letterhead}>
      <div className={styles.logoContainer}>
        <img src={hospitalLogoPath} alt="Hospital Logo" className={styles.logo} />
      </div>
      <div className={styles.hospitalDetails}>
        {hospitalLetterheadTopLines?.map((line: string, i: number) => (
          <p key={i} className={styles.topLine}>
            {line}
          </p>
        ))}
        <h2 className={styles.hospitalName}>{hospitalName || t('hospitalName', 'Hospital Name')}</h2>
        {hospitalLetterheadBottomLines?.map((line: string, i: number) => (
          <p key={i} className={styles.bottomLine}>
            {line}
          </p>
        ))}
        <p className={styles.address}>{hospitalAddress || t('hospitalAddress', 'Hospital Address')}</p>
        <p className={styles.contact}>{hospitalContactInfo || t('hospitalContactInfo', 'Contact: +000-0000000')}</p>
      </div>
      <div className={styles.spacer} />
    </div>
  );
};

export default EncounterPrintLetterhead;
