// import React from 'react';
// import { render, screen } from '@testing-library/react';
// import { userEvent } from '@testing-library/user-event';
// import { PrintSummaryButton } from './print-summary-button.component';
// import { useVisit, showModal } from '@openmrs/esm-framework';
// import { useTranslation } from 'react-i18next';

// jest.mock('react-i18next', () => ({
//   useTranslation: jest.fn().mockReturnValue({
//     t: jest.fn().mockImplementation((key, defaultValue) => defaultValue)
//   })
// }));

// jest.mock('@openmrs/esm-framework', () => ({
//   useVisit: jest.fn(),
//   showModal: jest.fn()
// }));

// describe('PrintSummaryButton', () => {
//   beforeEach(() => {
//     jest.clearAllMocks();
//   });

//   test('renders nothing when there is no current visit', () => {
//     (useVisit as jest.Mock).mockReturnValue({
//       activeVisit: null,
//       isLoading: false
//     });

//     const { container } = render(<PrintSummaryButton patient={{} as fhir.Patient} />);

//     expect(container.firstChild).toBeNull();
//   });

//   test('renders the button when there is a current visit', () => {
//     (useVisit as jest.Mock).mockReturnValue({
//       activeVisit: { uuid: 'visit-uuid' },
//       isLoading: false
//     });
//     render(<PrintSummaryButton patient={{} as fhir.Patient} />);
//     expect(screen.getByText('Print Summary')).toBeInTheDocument();
//   });

  // test('calls showModal with correct parameters when button is clicked', () => {
  //   const mockDispose = jest.fn();
  //   (showModal as jest.Mock).mockReturnValue(mockDispose);
    
  //   (useVisit as jest.Mock).mockReturnValue({
  //     activeVisit: { uuid: 'visit-uuid' },
  //     isLoading: false
  //   });
  //   render(<PrintSummaryButton patient={{} as fhir.Patient} />);

  //   userEvent.click(screen.getByRole('button'));
  //   expect(showModal).toHaveBeenCalledWith('print-summary-dialog', {
  //     closeModal: expect.any(Function),
  //     patientUuid: 'test-uuid'
  //   });
  // });
});