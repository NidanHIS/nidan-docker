/**
 * @file constants.ts
 *
 * Code-level constants that are NOT user-configurable.
 *
 * UUID-based configuration (form UUIDs, concept UUIDs) has been moved to
 * config-schema.ts so that different OpenMRS deployments can override them
 * without a code rebuild. Access those values via:
 *
 *   const { forms, obsConcepts, concepts } = useConfig<ConfigObject>();
 *
 * What lives here: OpenMRS REST API "custom representation" strings.
 * These are tightly coupled to the code — a change to a custom rep requires
 * updating the hook that consumes it, so they are not deployment-configurable.
 */

// ─── Custom Representation Strings ───────────────────────────────────────────

/**
 * OpenMRS REST API `v=custom:(...)` representation strings.
 *
 * Each entry specifies exactly which fields the server should return,
 * keeping response payloads small. Centralised here so a field-level change
 * only needs to happen in one place.
 */
export const CUSTOM_REPS = {
  /**
   * Full encounter representation: diagnoses, obs (with group members), form,
   * encounter type, visit, patient, and provider info including attributes.
   *
   * Used by: useEncounters → usePatientSummaryData, useInsuranceDischargeSummaryData,
   * useVisitSummaryData
   */
  ENCOUNTER_FULL:
    'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient,obs:(uuid,order:(uuid),concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person,attributes:(attributeType:(uuid),value,voided))))',

  /**
   * Lightweight encounter representation: diagnoses and provider only (no obs).
   *
   * Used by: useEncountersWithDiagnoses → useInsuranceReferralReportData
   */
  ENCOUNTER_DIAGNOSIS_ONLY:
    'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis:(coded:(uuid,display),nonCoded),certainty,voided),encounterDatetime,encounterProviders:(provider:(person:(display))))',

  /**
   * Visit representation with nested encounters, diagnoses, and obs.
   * A single request that avoids a separate encounter-list fetch.
   *
   * Used by: useVisitSummaryData (visit/${uuid} endpoint)
   */
  VISIT_WITH_ENCOUNTERS:
    'custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,rank,certainty,voided,diagnosis),obs:(uuid,concept:(uuid,display),value,obsDatetime),encounterType:(uuid,display)),startDatetime,stopDatetime)',

  /**
   * Encounter with full patient identifiers, obs (3-level group nesting), and providers.
   * Used with the custom /nidan/encounter endpoint.
   *
   * Used by: useDischargeSummaryData, useReferralReportData
   */
  ENCOUNTER_WITH_PATIENT_OBS:
    'custom:(uuid,display,encounterDatetime,diagnoses:(display,diagnosis:(display)),form:(uuid,name,display),visit:(location:(display),startDatetime),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime,groupMembers:(uuid,concept:(uuid,display),value,display,obsDatetime,groupMembers:(uuid,concept:(uuid,display),value,display,obsDatetime))),encounterProviders:(provider:(person:(display))))',

  /**
   * Referral encounter with visit window dates, full obs, and patient identifiers.
   * Used with the custom /nidan/encounter endpoint.
   *
   * Used by: useInsuranceReferralReportData
   */
  ENCOUNTER_REFERRAL:
    'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(uuid,startDatetime,stopDatetime,location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value,display,obsDatetime),location:(display),encounterProviders:(provider:(person:(display))))',

  /**
   * Minimal form obs for the Admission Summary Record Note.
   *
   * Used by: useInsuranceDischargeSummaryData
   */
  ADMISSION_SUMMARY_OBS: 'custom:(uuid,obs:(uuid,concept:(uuid,display),value,display))',

  /**
   * Minimal vitals obs: concept UUID, value, and datetime only.
   *
   * Used by: useInsuranceReferralReportData (/obs endpoint)
   */
  VITALS_OBS: 'custom:(uuid,concept:(uuid),value,obsDatetime)',
} as const;
