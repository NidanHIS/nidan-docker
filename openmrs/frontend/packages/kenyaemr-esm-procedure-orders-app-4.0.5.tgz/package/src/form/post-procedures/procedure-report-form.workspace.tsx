import React, { useCallback } from 'react';
import { mutate } from 'swr';
import {
  ExtensionSlot,
  openmrsFetch,
  restBaseUrl,
  showSnackbar,
  useConfig,
  Workspace2,
  closeWorkspaceGroup2
} from '@openmrs/esm-framework';
import { type ConfigObject } from '../../config-schema';
import { type Result } from '../../types';

interface ProcedureReportFormProps {
  groupProps: { patientUuid: string, order: Result, visit: any }
  closeWorkspace: () => void;
}

const ProcedureReportForm: React.FC<ProcedureReportFormProps> = ({
  groupProps: { patientUuid, order, visit },
  closeWorkspace,
}) => {
  const { procedureReportFormUuid } = useConfig<ConfigObject>();

  const handlePostResponse = useCallback(() => {
    return openmrsFetch(`${restBaseUrl}/order/${order.uuid}/fulfillerdetails`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: {
        fulfillerStatus: 'COMPLETED',
        fulfillerComment: '',
      },
    })
      .then(() => {
        mutate((key) => typeof key === 'string' && key.includes('/order'));
        closeWorkspace();
        closeWorkspaceGroup2();
      })
      .catch((error) => {
        console.error('Error updating fulfiller details:', error);
        showSnackbar({
          title: 'Error',
          kind: 'error',
          subtitle: error?.message,
          isLowContrast: false,
        });
        closeWorkspace();
        closeWorkspaceGroup2();
      });
  }, [order.uuid]);

  return (
    <Workspace2 title="Procedure Report Form">
      <ExtensionSlot
        name="form-widget-slot"
        state={{
          view: 'form',
          formUuid: procedureReportFormUuid,
          patientUuid,
          patient: {
            ...order.patient,
            id: order.patient?.uuid,
          },
          encounterUuid: '',
          visitUuid: null,
          additionalProps: {
            mode: 'enter',
          },
          showDiscardSubmitButtons: true,
          closeWorkspaceWithSavedChanges: handlePostResponse,
          promptBeforeClosing: () => { },
          setHasUnsavedChanges: () => { },
        }}
      />
    </Workspace2>
  );
};

export default ProcedureReportForm;
