import { getAsyncLifecycle, defineConfigSchema, getSyncLifecycle } from '@openmrs/esm-framework';

import { configSchema } from './config-schema';
import { createLeftPanelLink } from './left-panel-link';
import workListProcedures from './procedure-tabs/work-list-tab.component';
import referredProcedures from './procedure-tabs/referred-tab.component';
import completedProcedures from './procedure-tabs/completed-tab.component';
import notDoneProcedures from './procedure-tabs/not-done-tab.component';
import addProcedureToWorklistDialog from './procedures-ordered/pick-procedure-order/add-to-worklist-dialog.component';
import procedureInstructionsModal from './procedures-ordered/procedure-instructions/procedure-instructions.component';
import ProceduresOrderBasketPanelExtension from './form/procedures-orders/procedures-order-basket-panel/procedures-order-basket-panel.extension';
import rejectProcedureOrderDialog from './procedures-ordered/reject-order-dialog/reject-procedure-order-dialog.component';
import procedureRejectReasonModal from './procedures-ordered/reject-reason/procedure-reject-reason.component';
import PostProcedureForm from './form/post-procedures/post-procedure-form.component';
import PrintPreviewModal from './print/print-procedure-results.component';
import Procedure from './procedure.component';
import SearchPatientWorkspace from './form/search-patient-workspace/search-patient.workspace';
import { procedureordersDashboardMeta } from './dashboard-meta';
import { createDashboardLink } from '@openmrs/esm-patient-common-lib';
import ProceduresOrdersSummary from './shared/ui/common/procedures-orders-summary.component';
import ProcedureReportForm from './form/post-procedures/procedure-report-form.workspace';

const moduleName = '@kenyaemr/esm-procedure-orders-app';

const options = {
  featureName: 'esm-procedure-orders-app',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

export const root = getAsyncLifecycle(() => import('./root.component'), options);
export const expressProceduresDashboard = getSyncLifecycle(Procedure, options);

// t('Procedures', 'Procedures')
export const procedureDashboardLink = getSyncLifecycle(
  createLeftPanelLink({
    name: 'procedure',
    title: 'Procedures',
  }),
  options,
);

export const procedureOrderDashboardLink =
  getSyncLifecycle(
    createDashboardLink({
      ...procedureordersDashboardMeta,
    }),
    options,
  );

// Modals
export const rejectProcedureOrderDialogComponent = getSyncLifecycle(rejectProcedureOrderDialog, options);

export const worklistProceduresTabComponent = getSyncLifecycle(workListProcedures, options);

export const referredProceduresTabComponent = getSyncLifecycle(referredProcedures, options);
export const completedProceduresTabComponent = getSyncLifecycle(completedProcedures, options);
export const notDoneProceduresTabComponent = getSyncLifecycle(notDoneProcedures, options);
export const procedureInstructionsModalComponent = getSyncLifecycle(procedureInstructionsModal, options);
export const procedureRejectModalComponent = getSyncLifecycle(procedureRejectReasonModal, options);
export const addProcedureToWorklistDialogComponent = getSyncLifecycle(addProcedureToWorklistDialog, options);

export const proceduresOrderPanel = getSyncLifecycle(ProceduresOrderBasketPanelExtension, options);
export const postProcedureResults = getSyncLifecycle(PostProcedureForm, options);
export const printProcedureReportModal = getSyncLifecycle(PrintPreviewModal, options);

// t('addProcedureOrderWorkspaceTitle', 'Add procedure order')
export const addProceduresOrderWorkspace = getAsyncLifecycle(
  () => import('./form/procedures-orders/add-procedures-order/add-procedures-order.workspace'),
  options,
);
export const procedureResultsComponent = getAsyncLifecycle(
  () => import('./procedure-results/procedure-results.component'),
  options,
);
export const procedureOrderSearchPatientWorkspace = getSyncLifecycle(SearchPatientWorkspace, options);
export const procedureOrdersSummary = getSyncLifecycle(ProceduresOrdersSummary, options);

export const procedureReportFormWorkspace = getSyncLifecycle(ProcedureReportForm, options);
