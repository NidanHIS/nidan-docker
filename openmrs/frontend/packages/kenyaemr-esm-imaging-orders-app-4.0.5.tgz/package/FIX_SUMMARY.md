# Summary: Imaging Order Registration Fix

## Problem Overview
The application was failing to launch the imaging order form with the error:
`"No workspace named 'add-imaging-order' has been registered"`

This occurred when clicking the "Add" button in the Imaging Order Basket panel.

## Root Cause Analysis
- **Naming Mismatch**: The workspace name used in the `launchWorkspace` call did not consistently match the registration in `routes.json`.
- **API Choice**: The `esm-imaging-orders-app` uses the newer `workspaces2` definition in `routes.json`. The standard `launchWorkspace` API is for older workspace definitions. 
- **Context Constraints**: Attempting to use `useWorkspace2Context` to get `launchChildWorkspace` failed because React Context does not reliably propagate across separate microfrontend boundaries in the OpenMRS ESM architecture.

## Implementation Journey

1.  **Workspace Renaming**: Standardized the workspace name to `add-imaging-order-workspace` across `routes.json` and call sites to avoid caching or collision issues.
2.  **API Refinement**: Switched from `launchWorkspace` to `launchWorkspace2`.
3.  **Local Implementation**: Implemented the launch logic directly within the `esm-imaging-orders-app` to avoid making breaking changes to the shared `esm-patient-common-lib` or the parent `esm-patient-orders-app`.

## Final Solution
The fix was implemented in [imaging-order-basket-panel.extension.tsx](file:///d:/order-add/esm-imaging-orders-app/src/form/imaging-orders/imaging-order-basket-panel/imaging-order-basket-panel.extension.tsx):

```typescript
// 1. Import launchWorkspace2
import { launchWorkspace2 } from '@openmrs/esm-framework';

// 2. Implementation using launchWorkspace2
const launchImagingOrderForm = useCallback((orderTypeUuid: string, order?: ImagingOrderBasketItem) => {
  launchWorkspace2('add-imaging-order-workspace', { orderTypeUuid, order }, null, null);
}, []);
```

## Key Files Modified
- [routes.json](file:///d:/order-add/esm-imaging-orders-app/src/routes.json): Registered the workspace as `add-imaging-order-workspace`.
- [index.ts](file:///d:/order-add/esm-imaging-orders-app/src/index.ts): Exported the `addImagingOrderWorkspace` component.
- [imaging-order-basket-panel.extension.tsx](file:///d:/order-add/esm-imaging-orders-app/src/form/imaging-orders/imaging-order-basket-panel/imaging-order-basket-panel.extension.tsx): Updated to use the correct name and launch API.

## Outcome
The "Add" button now successfully launches the Imaging Order form within the patient chart workspace, matching the behavior of the Lab Order functionality.
