import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button, IconButton } from '@carbon/react';
import { showModal, launchWorkspace2, ViewIcon } from '@openmrs/esm-framework';
import { type Order } from '@openmrs/esm-patient-common-lib';
import OrderActionExtension from './order-action-extension.component';
import { type Result } from '../../../../imaging-tabs/work-list/work-list.resource';
import styles from './action-button.scss';
import { useLaunchWorkspaceRequiringVisit } from '@openmrs/esm-patient-common-lib';

type ActionButtonProps = {
  action: {
    actionName: string;
    order: number;
  };
  order: Result;
  patientUuid: string;
  size?: 'sm' | 'md' | 'lg';
};

const ActionButton: React.FC<ActionButtonProps> = ({ action, order, patientUuid, size = 'md' }) => {
  const { t } = useTranslation();

  const launchFormWorkspace = useLaunchWorkspaceRequiringVisit(
    patientUuid,
    'patient-form-entry-workspace'
  );

  const openForm = () => {
    launchFormWorkspace({
      workspaceTitle: 'Test Form 1',
      form: { uuid: '2ddde996-b1c3-37f1-a53e-378dd1a4f6b5' },
      encounterUuid: '',
    });
  };

  const handleOpenImagingReportForm = () => {
    launchWorkspace2('imaging-report-form', {
      patientUuid,
      order,
    });
  };

  const handleOpeningReviewWorkspace = () => {
    launchWorkspace2('imaging-review-form', {
      order,
    });
  };

  const renderActionButton = () => {
    switch (action.actionName) {
      case 'add-imaging-to-work-list-modal':
        return (
        <Button
          kind='primary'
          size={size}
          onClick={() => {
            const dispose = showModal(action.actionName, {
              closeModal: () => dispose(),
              order: order,
            });
          }}>
          {t('pickOrder', 'Pick Order')}
        </Button>
      );
      
      case 'view-radiology-report':
        return (
          <IconButton
          label="View Image"
          align="left"
          kind="ghost"
            onClick={() => { }
          }
          >
            <ViewIcon />
          </IconButton>
        );

      case 'imaging-report-form':
        return (
          <Button kind="primary" size={size} onClick={openForm} className={styles.actionButtons}>
            {t('imagingReportForm', 'Imaging Report Form')}
          </Button>
        );

      case 'imaging-review-form':
        return (
          <Button kind="primary" size={size} className={styles.actionButtons} onClick={handleOpeningReviewWorkspace}>
            {t('reviewImagingReport', 'Review Imaging Report')}
          </Button>
        );

      case 'amend-imaging-order-modal':
        return (
          <Button
            kind="secondary"
            size={size}
            className={styles.actionButtons}
            onClick={() => {
              const dispose = showModal('amend-imaging-order-modal', {
                closeModal: () => dispose(),
                order: order,
              });
            }}>
            {t('amendRequest', 'Amend request')}
          </Button>
        );

      case 'reject-imaging-order-modal':
        return (
          <Button
            kind="danger"
            size={size}
            className={styles.actionButtons}
            onClick={() => {
              const dispose = showModal('reject-imaging-order-modal', {
                closeModal: () => dispose(),
                order: order,
              });
            }}>
            {t(
              action.actionName.replace(/-/g, ''),
              action.actionName
                .split('-')
                .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ')
                .replace('Modal', ''),
            )}
          </Button>
        );

      default:
        return null;
    }
  };

  return <div className={styles.actionButtonContainer}>{renderActionButton()}</div>;
};

export default ActionButton;
