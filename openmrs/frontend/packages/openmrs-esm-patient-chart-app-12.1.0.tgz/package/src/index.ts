import { defineConfigSchema, getAsyncLifecycle, getSyncLifecycle } from '@openmrs/esm-framework';
import * as Framework from '@openmrs/esm-framework';
import { createDashboardLink } from '@openmrs/esm-patient-common-lib';
import { esmPatientChartSchema } from './config-schema';
import { moduleName } from './constants';
import { setupCacheableRoutes, setupOfflineVisitsSync } from './offline';
import { summaryDashboardMeta, encountersDashboardMeta } from './dashboard.meta';
import deleteVisitActionButtonComponent from './actions-buttons/delete-visit.component';
import currentVisitSummaryComponent from './visit/visits-widget/current-visit-summary.extension';
import markPatientAliveActionButtonComponent from './actions-buttons/mark-patient-alive.component';
import markPatientDeceasedActionButtonComponent from './actions-buttons/mark-patient-deceased.component';
import pastVisitsOverviewComponent from './visit/visits-widget/visit-detail-overview.component';
import patientChartPageComponent from './root.component';
import patientDetailsTileComponent from './patient-details-tile/patient-details-tile.component';
import startVisitActionButtonComponent from './actions-buttons/start-visit.component';
import startVisitActionButtonOnPatientSearch from './visit/start-visit-button.component';
import stopVisitActionButtonComponent from './actions-buttons/stop-visit.component';
import visitAttributeTagsComponent from './patient-banner-tags/visit-attribute-tags.extension';
import allergiesTagsComponent from './patient-banner-tags/allergies-tags.extension';
import conditionsTagsComponent from './patient-banner-tags/conditions-tags.extension';
import EncounterOverview from './visit/visits-widget/past-visits-components/encounters-table/all-encounters-overview.component';
import VisitHistoryOverview from './visit/visit-history-table/visit-overview.component';
import DiagnosisOverview from './diagnosis/diagnosis-overview.component';
import ActiveFormsOverview from './forms/active-forms-overview.component';


// This allows @openmrs/esm-framework to be accessed by modules that are not
// using webpack. This is used for ngx-formentry.
window['_openmrs_esm_framework'] = Framework;

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  setupOfflineVisitsSync();
  setupCacheableRoutes();

  defineConfigSchema(moduleName, esmPatientChartSchema);
}

export const root = getSyncLifecycle(patientChartPageComponent, { featureName: 'patient-chart', moduleName });

export const patientSummaryDashboardLink =
  // t('Patient Summary', 'Patient Summary')
  getSyncLifecycle(
    createDashboardLink({
      ...summaryDashboardMeta,
    }),
    {
      featureName: 'summary-dashboard',
      moduleName,
    },
  );

export const markPatientAliveActionButton = getSyncLifecycle(markPatientAliveActionButtonComponent, {
  featureName: 'patient-action-mark-alive',
  moduleName,
});

export const markPatientDeceasedActionButton = getSyncLifecycle(markPatientDeceasedActionButtonComponent, {
  featureName: 'patient-action-mark-deceased',
  moduleName,
});

export const startVisitActionButton = getSyncLifecycle(startVisitActionButtonComponent, {
  featureName: 'patient-action-start-visit',
  moduleName,
});

export const stopVisitActionButton = getSyncLifecycle(stopVisitActionButtonComponent, {
  featureName: 'patient-action-stop-visit',
  moduleName,
});

export const deleteVisitActionMenuButton = getSyncLifecycle(deleteVisitActionButtonComponent, {
  featureName: 'patient-action-delete-visit',
  moduleName,
});

export const startVisitPatientSearchActionButton = getSyncLifecycle(startVisitActionButtonOnPatientSearch, {
  featureName: 'patient-search-action-start-visit',
  moduleName,
});

export const stopVisitPatientSearchActionButton = getSyncLifecycle(stopVisitActionButtonComponent, {
  featureName: 'patient-search-action-stop-visit',
  moduleName,
});

export const clinicalViewsSummary = getAsyncLifecycle(
  () => import('./clinical-views/encounter-tile/clinical-views-summary.component'),
  { featureName: 'clinical-views-summary', moduleName },
);

export const encountersSummaryDashboardLink =
  // t('Visits', 'Visits')
  getSyncLifecycle(
    createDashboardLink({
      ...encountersDashboardMeta,
    }),
    { featureName: 'encounter', moduleName },
  );

export const currentVisitSummary = getSyncLifecycle(currentVisitSummaryComponent, {
  featureName: 'current-visit-summary',
  moduleName,
});

export const pastVisitsDetailOverview = getSyncLifecycle(pastVisitsOverviewComponent, {
  featureName: 'visits-detail-overview',
  moduleName,
});

export const patientDetailsTile = getSyncLifecycle(patientDetailsTileComponent, {
  featureName: 'patient-details-tile',
  moduleName,
});

export const visitAttributeTags = getSyncLifecycle(visitAttributeTagsComponent, {
  featureName: 'visit-attribute-tags',
  moduleName,
});

export const allergiesTags = getSyncLifecycle(allergiesTagsComponent, {
  featureName: 'allergies-tags',
  moduleName,
});

export const conditionsTags = getSyncLifecycle(conditionsTagsComponent, {
  featureName: 'conditions-tags',
  moduleName,
});

export const encounterOverviewComponent = getSyncLifecycle(EncounterOverview, {
  featureName: 'encounter-overview-widget',
  moduleName,
});

export const visitOverviewComponent = getSyncLifecycle(VisitHistoryOverview, {
  featureName: 'visit-overview-widget',
  moduleName,
});

export const diagnosisOverview = getSyncLifecycle(DiagnosisOverview, {
  featureName: 'diagnosis-overview-widget',
  moduleName,
});

export const activeFormsOverview = getSyncLifecycle(ActiveFormsOverview, {
  featureName: 'active-forms-overview-widget',
  moduleName,
});


export const startVisitWorkspace = getAsyncLifecycle(() => import('./visit/visit-form/visit-form.workspace'), {
  featureName: 'start-visit-form',
  moduleName,
});

export const exportedVisitForm = getAsyncLifecycle(() => import('./visit/visit-form/exported-visit-form.workspace'), {
  featureName: 'exported-visit-form',
  moduleName,
});

// t('markPatientDeceased', 'Mark patient deceased')
export const markPatientDeceasedForm = getAsyncLifecycle(
  () => import('./mark-patient-deceased/mark-patient-deceased-form.workspace'),
  {
    featureName: 'mark-patient-deceased-form',
    moduleName,
  },
);

export const startVisitModal = getAsyncLifecycle(() => import('./visit/visit-prompt/start-visit-dialog.modal'), {
  featureName: 'start visit',
  moduleName,
});

export const deleteVisitModal = getAsyncLifecycle(() => import('./visit/visit-prompt/delete-visit-dialog.modal'), {
  featureName: 'delete visit',
  moduleName,
});

export const modifyVisitDateModal = getAsyncLifecycle(() => import('./visit/visit-prompt/modify-visit-date.modal'), {
  featureName: 'modify visit date',
  moduleName,
});

export const endVisitModal = getAsyncLifecycle(() => import('./visit/visit-prompt/end-visit-dialog.modal'), {
  featureName: 'end visit',
  moduleName,
});

export const markPatientAliveModal = getAsyncLifecycle(() => import('./mark-patient-alive/mark-patient-alive.modal'), {
  featureName: 'mark patient alive',
  moduleName,
});

export const deleteEncounterModal = getAsyncLifecycle(
  () => import('./visit/visits-widget/past-visits-components/delete-encounter.modal'),
  {
    featureName: 'delete-encounter-modal',
    moduleName,
  },
);

export const editVisitDetailsActionButton = getAsyncLifecycle(
  () => import('./visit/visit-action-items/edit-visit-details.component'),
  { featureName: 'edit-visit-details', moduleName },
);

export const deleteVisitActionButton = getAsyncLifecycle(
  () => import('./visit/visit-action-items/delete-visit-action-item.component'),
  { featureName: 'delete-visit', moduleName },
);

export const activeVisitActionsComponent = getAsyncLifecycle(
  () => import('./visit/visits-widget/active-visit-buttons/active-visit-buttons'),
  { featureName: 'active-visit-actions', moduleName },
);

export const encounterListTableTabs = getAsyncLifecycle(
  () => import('./clinical-views/encounter-list/encounter-list-tabs.extension'),
  { featureName: 'encounter-list-table-tabs', moduleName },
);

export const visitContextSwitcherModal = getAsyncLifecycle(
  () => import('./visit/visits-widget/visit-context/visit-context-switcher.modal'),
  { featureName: 'visit-context-switcher', moduleName },
);

export const visitContextHeader = getAsyncLifecycle(
  () => import('./visit/visits-widget/visit-context/visit-context-header.extension'),
  { featureName: 'visit-context-header', moduleName },
);

export const retrospectiveDateTimePicker = getAsyncLifecycle(
  () =>
    import(
      './visit/visits-widget/visit-context/retrospective-data-date-time-picker/retrospective-date-time-picker.component'
    ),
  { featureName: 'retrospective-date-time-picker', moduleName },
);
