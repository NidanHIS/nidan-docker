import React, { type ComponentProps } from 'react';
import { useTranslation } from 'react-i18next';
import { IncidentReporter } from '@carbon/react/icons';
import { ActionMenuButton2 } from '@openmrs/esm-framework';
import { useStartVisitIfNeeded, type PatientChartWorkspaceActionButtonProps } from '@openmrs/esm-patient-common-lib';

/**
 * This button uses the patient chart store and MUST only be used
 * within the patient chart
 */
const ConditionActionButton: React.FC<PatientChartWorkspaceActionButtonProps> = ({ groupProps: { patientUuid } }) => {
  const { t } = useTranslation();

  const startVisitIfNeeded = useStartVisitIfNeeded(patientUuid);

  return (
    <ActionMenuButton2
      icon={(props: ComponentProps<typeof IncidentReporter>) => <IncidentReporter {...props} />}
      label={t('condition', 'Condition')}
      workspaceToLaunch={{
        workspaceName: 'conditions-form-workspace',
        workspaceProps: {},
      }}
      onBeforeWorkspaceLaunch={startVisitIfNeeded}
    />
  );
};

export default ConditionActionButton;
