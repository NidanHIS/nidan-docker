import React from 'react';
import { vi, describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useSystemVisitSetting } from '@openmrs/esm-patient-common-lib';
import { mockCurrentVisit, mockVisit2, mockVisit3 } from '__mocks__';
import { useInfiniteVisits } from '../visit.resource';
import VisitContextSwitcherModal from './visit-context-switcher.modal';

const mockUseSystemVisitSetting = vi.fn(useSystemVisitSetting).mockReturnValue({
  errorFetchingSystemVisitSetting: null,
  isLoadingSystemVisitSetting: false,
  systemVisitEnabled: true,
});

const mockUseInfiniteVisits = vi.fn(useInfiniteVisits).mockReturnValue({
  visits: [mockCurrentVisit, mockVisit2, mockVisit3],
  error: null,
  mutate: vi.fn(),
  isValidating: false,
  isLoading: false,
  totalCount: 3,
  hasMore: false,
  loadMore: vi.fn(),
  nextUri: '',
});

vi.mock('@openmrs/esm-patient-common-lib/src/useSystemVisitSetting', () => ({
  useSystemVisitSetting: () => mockUseSystemVisitSetting(),
}));

vi.mock('../visit.resource', () => ({
  useInfiniteVisits: () => mockUseInfiniteVisits('some-uuid'),
}));

const mockSetVisitContext = vi.fn();
vi.mock('@openmrs/esm-patient-common-lib', async () => ({
  ...((await vi.importActual('@openmrs/esm-patient-common-lib')) as object),
  usePatientChartStore: vi.fn(() => ({
    visitContext: null,
    setVisitContext: mockSetVisitContext,
  })),
}));

describe('VisitContextSwitcherModal', () => {
  it('should display a list of past visits', () => {
    mockUseSystemVisitSetting.mockReturnValueOnce({
      systemVisitEnabled: false,
      errorFetchingSystemVisitSetting: null,
      isLoadingSystemVisitSetting: false,
    });
    renderVisitContextSwitcherModal();
    // location
    expect(screen.getAllByText('Registration Desk')).toHaveLength(3);
    // visit type - only check the visitType div elements
    expect(screen.getAllByText('Facility Visit', { selector: '.visitType' })).toHaveLength(3);
  });

  it('should call setVisitContext when continue button is clicked with selected visit', async () => {
    const user = userEvent.setup();

    renderVisitContextSwitcherModal();

    // Select a visit by clicking on the first visit card
    const firstVisitRadio = screen.getAllByRole('radio', { name: /Facility Visit/ })[0];
    await user.click(firstVisitRadio);

    // Click the continue button
    const continueButton = screen.getByRole('button', { name: /continue/i });
    await user.click(continueButton);

    // Verify setVisitContext was called with the selected visit
    expect(mockSetVisitContext).toHaveBeenCalledWith(mockCurrentVisit, expect.any(Function));
  });
});

function renderVisitContextSwitcherModal() {
  render(<VisitContextSwitcherModal patientUuid="some-uuid" closeModal={vi.fn()} />);
}
