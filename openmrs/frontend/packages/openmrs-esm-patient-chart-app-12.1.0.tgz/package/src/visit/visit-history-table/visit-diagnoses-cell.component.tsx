import { DiagnosisTags, type Visit } from '@openmrs/esm-framework';
import React from 'react';

interface Props {
  visit: Visit;
  patient: fhir.Patient;
}

const VisitDiagnosisCell: React.FC<Props> = ({ visit }) => {
  const diagnoses = visit.encounters
    .flatMap((encounter) => encounter.diagnoses)
    .filter((diagnosis) => !diagnosis.voided)
    .sort((a, b) => a.rank - b.rank);

  return <DiagnosisTags diagnoses={diagnoses} />;
};

export default VisitDiagnosisCell;
