import React, { useCallback, useMemo, useState } from 'react';
import type { ComponentProps } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  DataTable,
  DataTableSkeleton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tile,
  type DataTableHeader,
  type DataTableSortState,
} from '@carbon/react';
import {
  AddIcon,
  EditIcon,
  formatDate,
  isDesktop as isDesktopLayout,
  launchWorkspace2,
  parseDate,
  useConfig,
  useLayoutType,
  usePagination,
  userHasAccess,
  useSession,
} from '@openmrs/esm-framework';
import {
  CardHeader,
  EmptyState,
  ErrorState,
  PatientChartPagination,
  useLaunchWorkspaceRequiringVisit,
  usePatientChartStore,
  type Form,
} from '@openmrs/esm-patient-common-lib';
import type { ChartConfig } from '../config-schema';
import {
  encounterHasJsonSchemaForm,
  mapEncounter,
  type MappedEncounter,
  useEncountersByVisitUuid,
} from '../visit/visits-widget/past-visits-components/encounters-table/encounters-table.resource';
import styles from './active-forms-overview.scss';

interface ActiveFormTableRow {
  id: string;
  formName: string;
  date: string;
  dateRender: string;
  form: Form;
  editPrivilege: string;
  rawDatetime: string;
}

interface ActiveFormTableHeader {
  key: keyof ActiveFormTableRow;
  header: string;
  isSortable?: boolean;
  sortFunc?: (valueA: ActiveFormTableRow, valueB: ActiveFormTableRow) => number;
}

interface ActiveFormsOverviewProps {
  patientUuid: string;
}

function useActiveFormsSorting(tableHeaders: Array<ActiveFormTableHeader>, tableRows: Array<ActiveFormTableRow>) {
  const [sortParams, setSortParams] = useState<{
    key: string;
    sortDirection: DataTableSortState;
  }>({ key: '', sortDirection: 'NONE' });

  const sortRow = (
    _cellA: unknown,
    _cellB: unknown,
    { key, sortDirection }: { key: string; sortDirection: DataTableSortState },
  ) => {
    setSortParams({ key, sortDirection });
    return 0;
  };

  const sortedRows = useMemo(() => {
    if (sortParams.sortDirection === 'NONE') {
      return tableRows;
    }

    const { key, sortDirection } = sortParams;
    const tableHeader = tableHeaders.find((h) => h.key === key);

    if (!tableHeader?.sortFunc) {
      return tableRows;
    }

    return tableRows.slice().sort((a, b) => {
      const sortingNum = tableHeader.sortFunc!(a, b);
      return sortDirection === 'DESC' ? sortingNum : -sortingNum;
    });
  }, [sortParams, tableRows, tableHeaders]);

  return { sortedRows, sortRow };
}

function canEditEncounter(
  encounter: MappedEncounter,
  session: ReturnType<typeof useSession>['user'],
  config: ChartConfig,
): boolean {
  const encounterAgeInMinutes = (Date.now() - new Date(encounter.rawDatetime).getTime()) / (1000 * 60);

  const hasEditEncounterAccess =
    userHasAccess(encounter.editPrivilege, session) &&
    (config.encounterEditableDuration === -1 ||
      (config.encounterEditableDuration > 0 && encounterAgeInMinutes <= config.encounterEditableDuration) ||
      config.encounterEditableDurationOverridePrivileges.some((privilege) => userHasAccess(privilege, session)));

  return hasEditEncounterAccess && Boolean(encounter.form?.uuid);
}

const ActiveFormsOverview: React.FC<ActiveFormsOverviewProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const headerTitle = t('activeForms', 'Active visit forms');
  const layout = useLayoutType();
  const isDesktop = isDesktopLayout(layout);
  const isTablet = !isDesktop;
  const session = useSession();
  const config = useConfig<ChartConfig>();
  const { visitContext } = usePatientChartStore(patientUuid);
  const activeVisitUuid = visitContext?.uuid ?? null;

  const launchClinicalFormsWorkspace = useLaunchWorkspaceRequiringVisit(patientUuid, 'clinical-forms-workspace');
  const launchStartVisit = useCallback(
    () =>
      launchWorkspace2('start-visit-workspace-form', {
        openedFrom: 'patient-chart-active-forms-overview',
      }),
    [],
  );

  const { data: visitEncounters, isLoading, error } = useEncountersByVisitUuid(patientUuid, activeVisitUuid);

  const encountersByUuid = useMemo(() => {
    const map = new Map<string, MappedEncounter>();
    visitEncounters?.filter(encounterHasJsonSchemaForm).forEach((encounter) => {
      map.set(encounter.uuid, mapEncounter(encounter));
    });
    return map;
  }, [visitEncounters]);

  const headers: Array<ActiveFormTableHeader> = useMemo(
    () => [
      {
        key: 'formName',
        header: t('form', 'Form name'),
        isSortable: true,
        sortFunc: (valueA, valueB) => valueA.formName.localeCompare(valueB.formName),
      },
      {
        key: 'dateRender',
        header: t('date', 'Date'),
        isSortable: true,
        sortFunc: (valueA, valueB) => new Date(valueA.date).getTime() - new Date(valueB.date).getTime(),
      },
    ],
    [t],
  );

  const tableRows = useMemo(() => {
    if (!visitEncounters) {
      return [];
    }

    return visitEncounters
      .filter(encounterHasJsonSchemaForm)
      .map((encounter) => {
        const mapped = mapEncounter(encounter);
        return {
          id: mapped.id,
          formName: mapped.formName,
          date: mapped.rawDatetime,
          dateRender: mapped.rawDatetime
            ? formatDate(parseDate(mapped.rawDatetime), { mode: 'wide', time: 'for today' })
            : '--',
          form: mapped.form,
          editPrivilege: mapped.editPrivilege,
          rawDatetime: mapped.rawDatetime,
        };
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [visitEncounters]);

  const { sortedRows, sortRow } = useActiveFormsSorting(headers, tableRows);
  const pageSize = 10;
  const { results: paginatedForms, goTo, currentPage } = usePagination(sortedRows, pageSize);

  const handleEditForm = useCallback((encounter: MappedEncounter) => {
    launchWorkspace2('patient-form-entry-workspace', {
      form: encounter.form,
      encounterUuid: encounter.id,
    });
  }, []);

  if (!activeVisitUuid) {
    return (
      <EmptyState
        displayText={t('activeForms_lower', 'forms for this visit')}
        headerTitle={headerTitle}
        launchForm={launchStartVisit}
      />
    );
  }

  if (isLoading) {
    return <DataTableSkeleton role="progressbar" zebra />;
  }

  if (error) {
    return <ErrorState error={error} headerTitle={headerTitle} />;
  }

  if (tableRows.length === 0) {
    return (
      <EmptyState
        displayText={t('activeForms_lower', 'forms for this visit')}
        headerTitle={headerTitle}
        launchForm={launchClinicalFormsWorkspace}
      />
    );
  }

  return (
    <div className={styles.widgetCard}>
      <CardHeader title={headerTitle}>
        <Button
          kind="ghost"
          renderIcon={(props: ComponentProps<typeof AddIcon>) => <AddIcon size={16} {...props} />}
          iconDescription={t('addForm', 'Add form')}
          onClick={launchClinicalFormsWorkspace}
        >
          {t('add', 'Add')}
        </Button>
      </CardHeader>
      <DataTable
        aria-label="active visit forms overview"
        headers={headers}
        isSortable
        overflowMenuOnHover={isDesktop}
        rows={paginatedForms}
        size={isTablet ? 'lg' : 'sm'}
        sortRow={sortRow}
        useZebraStyles
      >
        {({ rows, headers: renderedHeaders, getHeaderProps, getTableProps }) => (
          <>
            <TableContainer className={styles.tableContainer}>
              <Table {...getTableProps()} className={styles.table}>
                <TableHead>
                  <TableRow>
                    {(renderedHeaders as Array<DataTableHeader & ActiveFormTableHeader>).map((header) => (
                      <TableHeader
                        key={header.key}
                        className={styles.productiveHeading01}
                        {...getHeaderProps({
                          header,
                          isSortable: header.isSortable,
                        })}
                      >
                        {header.header}
                      </TableHeader>
                    ))}
                    <TableHeader className={styles.productiveHeading01}>{t('actions', 'Actions')}</TableHeader>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => {
                    const encounter = encountersByUuid.get(row.id);
                    const isEditable = encounter ? canEditEncounter(encounter, session?.user, config) : false;

                    return (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                        <TableCell className={styles.actionsCell}>
                          {isEditable && encounter && (
                            <Button
                              kind="ghost"
                              size="sm"
                              renderIcon={(props: ComponentProps<typeof EditIcon>) => <EditIcon size={16} {...props} />}
                              iconDescription={t('editForm', 'Edit form')}
                              onClick={() => handleEditForm(encounter)}
                            >
                              {t('editEncounter', 'Edit')}
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>

            {rows.length === 0 ? (
              <div className={styles.tileContainer}>
                <Tile className={styles.tile}>
                  <div className={styles.tileContent}>
                    <p className={styles.content}>{t('noActiveFormsToDisplay', 'No forms to display for this visit')}</p>
                  </div>
                </Tile>
              </div>
            ) : null}
          </>
        )}
      </DataTable>
      <PatientChartPagination
        currentItems={paginatedForms.length}
        onPageNumberChange={({ page }) => goTo(page)}
        pageNumber={currentPage}
        pageSize={pageSize}
        totalItems={sortedRows.length}
      />
    </div>
  );
};

export default ActiveFormsOverview;
