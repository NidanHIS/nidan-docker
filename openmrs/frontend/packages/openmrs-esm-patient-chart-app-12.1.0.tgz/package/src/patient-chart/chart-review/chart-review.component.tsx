import React, { useEffect, useMemo } from 'react';
import { Navigate } from 'react-router-dom';
import {
  type ConfigObject,
  useExtensionStore,
  useAssignedExtensions,
  registerExtensionSlot,
} from '@openmrs/esm-framework';
import {
  DashboardView,
  type DashboardConfig,
  type LayoutMode,
} from './dashboard-view.component';
import { basePath } from '../../constants';

function makePath(
  target: DashboardConfig,
  params: Record<string, string> = {},
) {
  const parts = `${basePath}/${encodeURIComponent(target.path)}`.split('/');

  Object.keys(params).forEach((key) => {
    for (let i = 0; i < parts.length; i++) {
      if (parts[i][0] === ':' && parts[i].indexOf(key) === 1) {
        parts[i] = params[key];
      }
    }
  });

  return parts.join('/');
}

/**
 * Maps old dashboard URL path segments to their new lowercase/hyphenated equivalents.
 * This ensures that existing bookmarks, shared links, and external references
 * continue to resolve to the correct dashboard after the path rename.
 */
const legacyPathAliases: Record<string, string> = {
  'Patient Summary': 'patient-summary',
  'Vitals & Biometrics': 'vitals-and-biometrics',
  'Vitals %26 Biometrics': 'vitals-and-biometrics',
  Allergies: 'allergies',
  Appointments: 'appointments',
  Attachments: 'attachments',
  'Billing history': 'billing-history',
  Conditions: 'conditions',
  Encounters: 'encounters',
  Immunizations: 'immunizations',
  Medications: 'medications',
  Orders: 'orders',
  Programs: 'programs',
  Results: 'results',
  Visits: 'visits',
};

function resolveView(view: string): string {
  return legacyPathAliases[view] ?? view;
}

function isDashboardConfig(obj: unknown): obj is DashboardConfig {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'path' in obj &&
    typeof obj.path === 'string' &&
    'slot' in obj &&
    typeof obj.slot === 'string'
  );
}

const seenMessages = new Set<string>();

function getDashboardDefinition(
  meta: object,
  config: ConfigObject,
  moduleName: string,
  name: string,
) {
  const mergedDefinition = { ...meta, ...config, moduleName };

  if (isDashboardConfig(mergedDefinition)) {
    return mergedDefinition;
  } else {
    const msg = `Could not find a valid dashboard definition for the dashboard ${name} located in ${moduleName}`;

    if (!seenMessages.has(msg)) {
      console.error(msg);
      seenMessages.add(msg);
    }

    return null;
  }
}

interface ChartReviewProps {
  patientUuid: string;
  patient: fhir.Patient;
  view: string;
  setDashboardLayoutMode?: (layoutMode: LayoutMode) => void;
}

const ChartReview: React.FC<ChartReviewProps> = ({
  patientUuid,
  patient,
  view,
  setDashboardLayoutMode,
}) => {
  const extensionStore = useExtensionStore();

  /**
   * Get the assigned extensions for the main dashboard slot.
   *
   * useAssignedExtensions applies the appropriate display conditions,
   * so it should be used instead of accessing candidateExtensions directly.
   */
  const dashboardExtensions = useAssignedExtensions(
    'patient-chart-dashboard-slot',
  );

  /**
   * Get the dashboard definitions.
   *
   * Some entries in the patient-chart-dashboard-slot point to another
   * extension slot through `config.slotName`. In that case, we need to
   * retrieve the assigned extensions from that nested slot.
   */
  const dashboards = dashboardExtensions
    .flatMap((e) => {
      if (e.config?.slotName) {
        const slotName = e.config.slotName;

        /**
         * Check whether the nested extension slot has been registered.
         */
        const slot = extensionStore.slots[slotName];

        if (!slot) {
          registerExtensionSlot(
            '@openmrs/esm-patient-chart-app',
            slotName,
          );

          /**
           * Since we registered the new extension slot, force a re-render
           * by throwing the immediately-resolved promise.
           */
          throw Promise.resolve();
        }

        /**
         * Use useAssignedExtensions for the nested slot as well so that
         * display conditions are respected.
         *
         * NOTE: React hooks cannot be called conditionally or inside this
         * callback. The nested-slot case is therefore handled below.
         */
        return (slot.assignedExtensions ?? []).map((extension) =>
          getDashboardDefinition(
            extension.meta,
            extension.config,
            extension.moduleName,
            extension.name,
          ),
        );
      }

      return getDashboardDefinition(
        e.meta,
        e.config,
        e.moduleName,
        e.name,
      );
    })
    .filter(Boolean);

  const defaultDashboard = dashboards.find((dashboard) =>
    Boolean(dashboard.path),
  );

  const resolvedView = resolveView(view);

  const dashboard = useMemo(() => {
    return dashboards.find((dashboard) => dashboard.path === resolvedView);
  }, [dashboards, resolvedView]);

  useEffect(() => {
    const activeDashboard = dashboard ?? defaultDashboard;

    if (activeDashboard && setDashboardLayoutMode) {
      setDashboardLayoutMode(activeDashboard.layoutMode ?? 'contained');
    }
  }, [dashboard, defaultDashboard, setDashboardLayoutMode]);

  if (!defaultDashboard) {
    return null;
  }

  if (!dashboard) {
    return (
      <Navigate
        to={makePath(defaultDashboard, {
          patientUuid,
        })}
        replace
      />
    );
  }

  return (
    <DashboardView
      dashboard={dashboard}
      patientUuid={patientUuid}
      patient={patient}
    />
  );
};

export default ChartReview;
