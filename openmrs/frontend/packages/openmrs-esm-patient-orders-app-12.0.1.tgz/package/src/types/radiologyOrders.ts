export interface RadiologyOrder {
  uuid: string;
  dateActivated: string;
}
