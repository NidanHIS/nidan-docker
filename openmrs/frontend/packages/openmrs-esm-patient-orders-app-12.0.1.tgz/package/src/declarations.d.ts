declare module '*.scss' {
  const content: { [className: string]: string };
  export default content;
}

declare module 'chart.js';
declare module 'react-chartjs-2';
declare module 'cornerstone-core';
declare module 'cornerstone-wado-image-loader';
