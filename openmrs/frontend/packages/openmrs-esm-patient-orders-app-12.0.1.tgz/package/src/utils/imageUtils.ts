/** Placeholder base64 PNG used until a study image is selected. */
const PLACEHOLDER_IMAGE =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

let currentImage = PLACEHOLDER_IMAGE;

export function setRandomImage(): void {
  currentImage = PLACEHOLDER_IMAGE;
}

export function getImage(): string {
  return currentImage;
}
