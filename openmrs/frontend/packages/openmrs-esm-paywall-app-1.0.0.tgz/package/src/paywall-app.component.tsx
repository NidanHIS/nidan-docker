import React from 'react';
import { useTranslation } from 'react-i18next';
import { Layer, Tile } from '@carbon/react';
import styles from './paywall-app.scss';

const PaywallApp: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className={styles.container}>
      <Layer>
        <Tile className={styles.tile}>
          <h1 className={styles.heading}>{t('paywall-appHeading', 'PaywallApp')}</h1>
          <p className={styles.content}>{t('paywall-appDescription', 'Welcome to the PaywallApp page.')}</p>
        </Tile>
      </Layer>
    </div>
  );
};

export default PaywallApp;
