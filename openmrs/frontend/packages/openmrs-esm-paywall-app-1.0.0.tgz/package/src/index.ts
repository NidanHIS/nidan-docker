import { getAsyncLifecycle, getSyncLifecycle, defineConfigSchema } from '@openmrs/esm-framework';
import { paywallGatekeeperConfigSchema } from './config-schema';
import { moduleName } from './constants';
import patientPaymentStatusButtonComponent from './check-status-modal/patient-payment-status.component';
import { initializeWorkspaceGatekeeper } from './paywall-gatekeeper';

const options = {
  featureName: 'paywall-app',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, paywallGatekeeperConfigSchema);
  initializeWorkspaceGatekeeper();
}

// Root component
export const root = getAsyncLifecycle(() => import('./root.component'), options);
export const paymentStatusTag = getAsyncLifecycle(() => import('./banner-tags/payment-status-tag.extension'), options);

export const patientPaymentStatusButton = getSyncLifecycle(patientPaymentStatusButtonComponent, {
  featureName: 'patient-action-payment-status',
  moduleName,
});

export const patientPaymentStatusModal = getAsyncLifecycle(
  () => import('./check-status-modal/patient-payment-status-modal.component'),
  {
    featureName: 'patient-payment-status-modal',
    moduleName,
  },
);

// Extensions

// Modals
export const paywallBlockModal = getAsyncLifecycle(() => import('./paywall-block-modal.component'), options);

// Workspaces
