import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Tag } from '@carbon/react';
import { Receipt } from '@carbon/icons-react';
import { useConfig, useVisit } from '@openmrs/esm-framework';
import { checkPaymentStatus, getPaywallConfig } from '../paywall.resource';
import type { PaywallGatekeeperConfig } from '../config-schema';
import styles from './payment-status-tag.scss';

interface PaymentStatusTagProps {
  /** The patient UUID to check payment status for */
  patientUuid: string;
  /** Optional visit UUID if needed for the check */
  visitUuid?: string;
}

/**
 * Displays a badge indicating whether the patient has any outstanding payment.
 * Uses the paywall `/check` endpoint via `checkPaymentStatus`. Shows "Paid" when
 * `paymentStatus` is "paid" (or decision === 'allow' with zero outstanding),
 * otherwise shows "Unpaid" with the outstanding amount.
 */
const PaymentStatusTag: React.FC<PaymentStatusTagProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const { activeVisit } = useVisit(patientUuid);
  const visitUuid = activeVisit?.uuid;
  const [loading, setLoading] = useState(true);
  const [paid, setPaid] = useState<boolean | null>(null);
  const [outstanding, setOutstanding] = useState<number>(0);
  const [currency, setCurrency] = useState<string>('NPR');
  const { pollingIntervalMs, cacheTtlMs } = useConfig<PaywallGatekeeperConfig>();
  const checkTicket = false;

  useEffect(() => {
    let cancelled = false;
    let interval: ReturnType<typeof setInterval> | undefined;

    const run = async () => {
      try {
        // effectiveEnforcing = enabled AND NOT canSkip.
        // When false, payment is never blocked for this user — skip everything.
        const paywallConfig = await getPaywallConfig();
        if (!paywallConfig.effectiveEnforcing) {
          if (!cancelled) setLoading(false);
          return; // No /check call, no poll interval created.
        }

        const result = await checkPaymentStatus(patientUuid, visitUuid, '', checkTicket, cacheTtlMs);
        if (!cancelled) {
          const isPaid = result.decision === 'allow' && (result.outstandingAmount ?? 0) === 0;
          setPaid(isPaid);
          setOutstanding(result.outstandingAmount ?? 0);
          setCurrency(result.currency ?? 'NPR');
        }
      } catch (e) {
        if (!cancelled) setPaid(null);
        console.error('Failed to fetch payment status for patient', patientUuid, e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    // Initial fetch — only start polling if enforcing
    run().then(() => {
      if (!cancelled) {
        interval = setInterval(run, pollingIntervalMs);
      }
    });

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [patientUuid, visitUuid]);

  if (loading) {
    return null; // Do not render until we know the status.
  }

  if (paid === null) {
    // Unknown status – optionally show nothing or a neutral badge.
    return null;
  }

  const label = paid ? t('paid', 'Paid') : t('unpaid', 'Unpaid');
  const color = paid ? 'green' : 'red';

  return (
    <Tag className={styles.badgeClass} type={color} title={paid ? '' : `${t('outstanding', 'Outstanding')}: ${new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(outstanding)}`}>
      <Receipt size={12} className={styles.receiptIcon} /> {label}
    </Tag>
  );
};
export { PaymentStatusTagProps };
export default PaymentStatusTag;