import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button, ModalBody, ModalHeader, Tabs, Tab, TabList, TabPanels, TabPanel, Tag, InlineLoading } from '@carbon/react';
import { useVisit } from '@openmrs/esm-framework';
import { checkPaymentStatus } from '../paywall.resource';
import type { PaywallCheckResponse } from 'src/paywall.resource';
import styles from './patient-payment-status-modal.scss';

interface PatientPaymentStatusModalProps {
  closeModal: () => void;
  patientUuid: string;
}

interface TabContentProps {
  patientUuid: string;
  visitUuid?: string;
  isCurrentVisit: boolean;
}

const PaymentStatusTabContent: React.FC<TabContentProps> = ({ patientUuid, visitUuid, isCurrentVisit }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<PaywallCheckResponse | null>(null);

  const fetchStatus = useCallback(async () => {
    if (isCurrentVisit && !visitUuid) {
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await checkPaymentStatus(patientUuid, visitUuid);
      setData(result);
    } catch (err: any) {
      setError(err?.message || t('failedToFetchPaymentStatus', 'Failed to fetch payment status.'));
    } finally {
      setLoading(false);
    }
  }, [patientUuid, visitUuid, isCurrentVisit, t]);

  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  if (isCurrentVisit && !visitUuid) {
    return (
      <div className={styles.noVisitMessage}>
        <p>{t('noActiveVisitMessage', 'No active visit found for this patient.')}</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className={styles.paymentStatusContainer}>
        <InlineLoading description={t('checkingPaymentStatus', 'Checking payment status...')} />
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.paymentStatusContainer}>
        <div className={`${styles.statusCard} ${styles.block}`}>
          <div className={styles.statusHeader}>
            <span className={styles.statusTitle}>{t('error', 'Error')}</span>
            <Tag type="red">{t('failed', 'FAILED')}</Tag>
          </div>
          <p className={styles.statusReason}>{error}</p>
          <div className={styles.refreshButtonContainer}>
            <Button kind="ghost" size="sm" onClick={fetchStatus}>
              {t('retry', 'Retry')}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return null;
  }

  const { decision, reason, outstandingAmount, dueAmount, cartAmount, currency, paymentStatus, mode } = data;

  const cardClass = decision === 'block' ? styles.block : decision === 'warn' ? styles.warn : styles.allow;
  const tagType = decision === 'block' ? 'red' : decision === 'warn' ? 'warm-gray' : 'green';

  return (
    <div className={styles.paymentStatusContainer}>
      <div className={styles.refreshButtonContainer}>
        <Button kind="ghost" size="sm" onClick={fetchStatus}>
          {t('refresh', 'Refresh')}
        </Button>
      </div>
      <div className={`${styles.statusCard} ${cardClass}`}>
        <div className={styles.statusHeader}>
          <span className={styles.statusTitle}>
            {decision === 'block'
              ? t('paymentStatusBlocked', 'Payment Blocked')
              : decision === 'warn'
                ? t('paymentStatusWarning', 'Payment Warning')
                : t('paymentStatusClear', 'Payment Clear')}
          </span>
          <Tag type={tagType}>{decision.toUpperCase()}</Tag>
        </div>

        <p className={styles.statusReason}>
          {reason || (decision === 'allow' ? t('noOutstandingAmount', 'No outstanding amount due.') : '')}
        </p>

        <div className={styles.gridDetails}>
          <div className={styles.detailItem}>
            <span className={styles.label}>{t('outstandingAmount', 'Outstanding Amount')}</span>
            <span className={decision === 'allow' ? styles.outstandingAllow : styles.outstanding}>
              {outstandingAmount} {currency}
            </span>
          </div>
          <div className={styles.detailItem}>
            <span className={styles.label}>{t('paymentStatusLabel', 'Payment Status')}</span>
            <span className={styles.value}>{paymentStatus}</span>
          </div>
          <div className={styles.detailItem}>
            <span className={styles.label}>{t('dueAmount', 'Due Amount (Invoiced)')}</span>
            <span className={styles.value}>
              {dueAmount} {currency}
            </span>
          </div>
          <div className={styles.detailItem}>
            <span className={styles.label}>{t('cartAmount', 'Cart Amount (Pending)')}</span>
            <span className={styles.value}>
              {cartAmount} {currency}
            </span>
          </div>
          <div className={styles.detailItem}>
            <span className={styles.label}>{t('checkMode', 'Mode')}</span>
            <span className={styles.value}>{mode}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const PatientPaymentStatusModal: React.FC<PatientPaymentStatusModalProps> = ({ closeModal, patientUuid }) => {
  const { t } = useTranslation();
  const { activeVisit } = useVisit(patientUuid);

  return (
    <>
      <ModalHeader closeModal={closeModal} title={t('checkPatientPaymentStatus', 'Check Patient Payment Status')} />
      <ModalBody>
        <Tabs>
          <TabList contained>
            <Tab>{t('currentVisitPaymentStatusTab', 'Current Visit Payment')}</Tab>
            <Tab>{t('overallPaymentStatusTab', 'Overall Payment')}</Tab>
          </TabList>
          <TabPanels>
            <TabPanel>
              <PaymentStatusTabContent
                patientUuid={patientUuid}
                visitUuid={activeVisit?.uuid}
                isCurrentVisit={true}
              />
            </TabPanel>
            <TabPanel>
              <PaymentStatusTabContent
                patientUuid={patientUuid}
                isCurrentVisit={false}
              />
            </TabPanel>
          </TabPanels>
        </Tabs>
      </ModalBody>
    </>
  );
};

export default PatientPaymentStatusModal;
