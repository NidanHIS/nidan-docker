import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@carbon/react';
import { Receipt } from '@carbon/icons-react';
import { showModal } from '@openmrs/esm-framework';
import styles from './action-button.scss';

interface PatientPaymentStatusButtonProps {
  patientUuid: string;
  closeMenu?: () => void;
}

const PatientPaymentStatusButton: React.FC<PatientPaymentStatusButtonProps> = ({
  patientUuid,
  closeMenu,
}) => {
  const { t } = useTranslation();

  const handleLaunchModal = useCallback(() => {
    closeMenu?.();
    const dispose = showModal('patient-payment-status-dialog', {
      closeModal: () => dispose(),
      patientUuid,
    });
  }, [patientUuid, closeMenu]);

  return (
    <div className={styles.checkButton}>
      <Button
        renderIcon= {Receipt}
        onClick={handleLaunchModal}
        kind= 'ghost'
      >
        { t('checkPaymentStatus', 'Check payment status') }
      </Button>
    </div>
  );
};

export default PatientPaymentStatusButton;
