import { describe, it, expect, vi, beforeEach } from 'vitest';
import { workspace2Store, workspace2StoreActions } from '@openmrs/esm-framework/src/internal';
import { showModal, showSnackbar } from '@openmrs/esm-framework';
import { initializeWorkspaceGatekeeper } from './paywall-gatekeeper';
import * as paywallResource from './paywall.resource';

// Mock the paywall resource module
vi.mock('./paywall.resource', () => ({
  getPaywallConfig: vi.fn(),
  checkPaymentStatus: vi.fn(),
}));

// Mock esm-framework functions
vi.mock('@openmrs/esm-framework', async () => {
  const actual = await vi.importActual<any>('@openmrs/esm-framework');
  return {
    ...actual,
    showModal: vi.fn(),
    showSnackbar: vi.fn(),
  };
});

describe('Paywall Gatekeeper', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Reset store state
    workspace2Store.setState({
      registeredGroupsByName: {},
      registeredWindowsByName: {},
      registeredWorkspacesByName: {
        'patient-form-entry-workspace': { window: 'chart-window', moduleName: 'test' } as any,
        'other-workspace': { window: 'chart-window', moduleName: 'test' } as any,
      },
      openedGroup: {
        groupName: 'patient-chart',
        props: { patientUuid: 'patient-123' },
      },
      openedWindows: [],
      workspaceTitleByWorkspaceName: {},
      isMostRecentlyOpenedWindowHidden: false,
    });
  });

  it('does not check payment when a non-gated workspace is opened', async () => {
    initializeWorkspaceGatekeeper();

    // Trigger workspace open event
    workspace2Store.setState({
      openedWindows: [
        {
          windowName: 'chart-window',
          maximized: false,
          props: {},
          openedWorkspaces: [
            {
              workspaceName: 'other-workspace',
              props: {},
              hasUnsavedChanges: false,
              uuid: '1',
            },
          ],
        },
      ],
    });

    // Wait for microtasks
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(paywallResource.getPaywallConfig).not.toHaveBeenCalled();
    expect(paywallResource.checkPaymentStatus).not.toHaveBeenCalled();
  });

  it('bypasses checks when effectiveEnforcing is false', async () => {
    vi.mocked(paywallResource.getPaywallConfig).mockResolvedValue({
      effectiveEnforcing: false,
    } as any);

    initializeWorkspaceGatekeeper();

    workspace2Store.setState({
      openedWindows: [
        {
          windowName: 'chart-window',
          maximized: false,
          props: {},
          openedWorkspaces: [
            {
              workspaceName: 'patient-form-entry-workspace',
              props: {},
              hasUnsavedChanges: false,
              uuid: '2',
            },
          ],
        },
      ],
    });

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(paywallResource.getPaywallConfig).toHaveBeenCalled();
    expect(paywallResource.checkPaymentStatus).not.toHaveBeenCalled();
  });

  it('blocks workspace and shows modal when check decision is block', async () => {
    vi.mocked(paywallResource.getPaywallConfig).mockResolvedValue({
      effectiveEnforcing: true,
    } as any);
    vi.mocked(paywallResource.checkPaymentStatus).mockResolvedValue({
      decision: 'block',
      blocked: true,
      reason: 'Outstanding payment due',
      outstandingAmount: 1500.0,
      currency: 'NPR',
      patientUuid: 'patient-123',
    } as any);

    const closeWorkspaceSpy = vi.spyOn(workspace2StoreActions, 'closeWorkspace');

    initializeWorkspaceGatekeeper();

    workspace2Store.setState({
      openedWindows: [
        {
          windowName: 'chart-window',
          maximized: false,
          props: {},
          openedWorkspaces: [
            {
              workspaceName: 'patient-form-entry-workspace',
              props: { patientUuid: 'patient-123' },
              hasUnsavedChanges: false,
              uuid: '3',
            },
          ],
        },
      ],
    });

    // Allow async subscriber to run
    await new Promise((resolve) => setTimeout(resolve, 10));

    // Verify payment check was called
    expect(paywallResource.checkPaymentStatus).toHaveBeenCalledWith('patient-123', undefined);

    // Verify workspace was closed
    expect(closeWorkspaceSpy).toHaveBeenCalledWith(expect.any(Object), 'patient-form-entry-workspace');

    // Verify block modal was displayed
    expect(showModal).toHaveBeenCalledWith('paywall-block-modal', {
      patientUuid: 'patient-123',
      workspaceName: 'patient-form-entry-workspace',
      reason: 'Outstanding payment due',
      outstandingAmount: 1500.0,
      currency: 'NPR',
    });
  });

  it('shows a warning snackbar and allows workspace when check decision is warn', async () => {
    vi.mocked(paywallResource.getPaywallConfig).mockResolvedValue({
      effectiveEnforcing: true,
    } as any);
    vi.mocked(paywallResource.checkPaymentStatus).mockResolvedValue({
      decision: 'warn',
      blocked: false,
      reason: 'Pending balance notice',
      outstandingAmount: 50.0,
      currency: 'NPR',
      patientUuid: 'patient-123',
    } as any);

    const closeWorkspaceSpy = vi.spyOn(workspace2StoreActions, 'closeWorkspace');

    initializeWorkspaceGatekeeper();

    workspace2Store.setState({
      openedWindows: [
        {
          windowName: 'chart-window',
          maximized: false,
          props: {},
          openedWorkspaces: [
            {
              workspaceName: 'patient-form-entry-workspace',
              props: { patientUuid: 'patient-123' },
              hasUnsavedChanges: false,
              uuid: '4',
            },
          ],
        },
      ],
    });

    await new Promise((resolve) => setTimeout(resolve, 10));

    // Workspace should NOT be closed
    expect(closeWorkspaceSpy).not.toHaveBeenCalled();

    // Warn snackbar should be displayed
    expect(showSnackbar).toHaveBeenCalledWith({
      title: 'Outstanding Dues',
      subtitle: 'Pending balance notice',
      kind: 'warning',
    });
  });

  it('fails open if the paywall status API fails', async () => {
    vi.mocked(paywallResource.getPaywallConfig).mockResolvedValue({
      effectiveEnforcing: true,
    } as any);
    vi.mocked(paywallResource.checkPaymentStatus).mockRejectedValue(new Error('Network error'));

    const closeWorkspaceSpy = vi.spyOn(workspace2StoreActions, 'closeWorkspace');

    initializeWorkspaceGatekeeper();

    workspace2Store.setState({
      openedWindows: [
        {
          windowName: 'chart-window',
          maximized: false,
          props: {},
          openedWorkspaces: [
            {
              workspaceName: 'patient-form-entry-workspace',
              props: { patientUuid: 'patient-123' },
              hasUnsavedChanges: false,
              uuid: '5',
            },
          ],
        },
      ],
    });

    await new Promise((resolve) => setTimeout(resolve, 10));

    // Workspace should NOT be closed (fail-open)
    expect(closeWorkspaceSpy).not.toHaveBeenCalled();
    expect(showModal).not.toHaveBeenCalled();
  });
});
