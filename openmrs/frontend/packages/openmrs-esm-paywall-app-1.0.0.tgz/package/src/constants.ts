export const moduleName = '@openmrs/esm-paywall-app';
