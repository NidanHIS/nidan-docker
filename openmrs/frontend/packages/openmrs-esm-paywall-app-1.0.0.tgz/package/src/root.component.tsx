import React from 'react';
import { initializeWorkspaceGatekeeper } from './paywall-gatekeeper';

const Root: React.FC = () => {
  return null;
};

export default Root;