import React from 'react';
import { useTranslation } from 'react-i18next';
import { Layer, Tile } from '@carbon/react';
import styles from './odontogram.scss';

const Odontogram: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className={styles.container}>
      <Layer>
        <Tile className={styles.tile}>
          <h1 className={styles.heading}>
            {t('odontogramHeading', 'Odontogram')}
          </h1>
          <p className={styles.content}>
            {t('odontogramDescription', 'Welcome to the Odontogram page.')}
          </p>
        </Tile>
      </Layer>
    </div>
  );
};

export default Odontogram;