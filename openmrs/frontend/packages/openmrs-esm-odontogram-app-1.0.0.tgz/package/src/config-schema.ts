import { Type } from '@openmrs/esm-framework';

export const configSchema = {
  /**
   * FDI concept UUID map – permanent teeth (11-48).
   * Each key is a tooth number; the value is the OpenMRS concept UUID for that tooth.
   */
  permanentTeeth: {
    tooth11: { _type: Type.ConceptUuid, _default: 'a0f0ef3c-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 11.' },
    tooth12: { _type: Type.ConceptUuid, _default: 'a0f40dd0-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 12.' },
    tooth13: { _type: Type.ConceptUuid, _default: 'a0f7028f-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 13.' },
    tooth14: { _type: Type.ConceptUuid, _default: 'a0f9e6f3-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 14.' },
    tooth15: { _type: Type.ConceptUuid, _default: 'a0fcd711-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 15.' },
    tooth16: { _type: Type.ConceptUuid, _default: 'a0ffa78d-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 16.' },
    tooth17: { _type: Type.ConceptUuid, _default: 'a1029729-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 17.' },
    tooth18: { _type: Type.ConceptUuid, _default: 'a1055b80-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 18.' },

    tooth21: { _type: Type.ConceptUuid, _default: 'b5f44ced-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 21.' },
    tooth22: { _type: Type.ConceptUuid, _default: 'b5f51f4b-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 22.' },
    tooth23: { _type: Type.ConceptUuid, _default: 'b5f5f772-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 23.' },
    tooth24: { _type: Type.ConceptUuid, _default: 'b5f6d2c3-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 24.' },
    tooth25: { _type: Type.ConceptUuid, _default: 'b5f79c8e-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 25.' },
    tooth26: { _type: Type.ConceptUuid, _default: 'b5f86485-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 26.' },
    tooth27: { _type: Type.ConceptUuid, _default: 'b5f93ef9-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 27.' },
    tooth28: { _type: Type.ConceptUuid, _default: 'b5fa7fa6-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 28.' },

    tooth31: { _type: Type.ConceptUuid, _default: 'b5fb736f-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 31.' },
    tooth32: { _type: Type.ConceptUuid, _default: 'b5fc5f75-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 32.' },
    tooth33: { _type: Type.ConceptUuid, _default: 'b5fd4240-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 33.' },
    tooth34: { _type: Type.ConceptUuid, _default: 'b5fe3a8e-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 34.' },
    tooth35: { _type: Type.ConceptUuid, _default: 'b5ff1f7c-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 35.' },
    tooth36: { _type: Type.ConceptUuid, _default: 'b60004f0-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 36.' },
    tooth37: { _type: Type.ConceptUuid, _default: 'b600e4fd-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 37.' },
    tooth38: { _type: Type.ConceptUuid, _default: 'b601b204-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 38.' },

    tooth41: { _type: Type.ConceptUuid, _default: 'b60294c2-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 41.' },
    tooth42: { _type: Type.ConceptUuid, _default: 'b60384c0-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 42.' },
    tooth43: { _type: Type.ConceptUuid, _default: 'b6046407-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 43.' },
    tooth44: { _type: Type.ConceptUuid, _default: 'b6054e86-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 44.' },
    tooth45: { _type: Type.ConceptUuid, _default: 'b6062daf-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 45.' },
    tooth46: { _type: Type.ConceptUuid, _default: 'b6071496-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 46.' },
    tooth47: { _type: Type.ConceptUuid, _default: 'b6080582-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 47.' },
    tooth48: { _type: Type.ConceptUuid, _default: 'b608e88b-acea-11f1-aa03-0242ac130004', _description: 'Concept UUID for tooth 48.' },
  },

  /**
   * FDI concept UUID map – primary / deciduous teeth (51-85).
   * Replace the placeholder values with real UUIDs once concepts are created.
   */
  primaryTeeth: {
    tooth51: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 51.' },
    tooth52: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 52.' },
    tooth53: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 53.' },
    tooth54: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 54.' },
    tooth55: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 55.' },

    tooth61: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 61.' },
    tooth62: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 62.' },
    tooth63: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 63.' },
    tooth64: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 64.' },
    tooth65: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 65.' },

    tooth71: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 71.' },
    tooth72: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 72.' },
    tooth73: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 73.' },
    tooth74: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 74.' },
    tooth75: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 75.' },

    tooth81: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 81.' },
    tooth82: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 82.' },
    tooth83: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 83.' },
    tooth84: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 84.' },
    tooth85: { _type: Type.ConceptUuid, _default: 'uuid', _description: 'Concept UUID for deciduous tooth 85.' },
  },

  concepts: {
    /**
     * Concept-set UUID whose answers list the available tooth surfaces.
     * GET /ws/rest/v1/concept/{uuid}?v=custom:(uuid,display,answers)
     */
    surfaceConceptSetUuid: {
      _type: Type.ConceptUuid,
      _default: 'd76c2fee-ace9-11f1-aa03-0242ac130004',
      _description: 'UUID of the concept set that holds tooth-surface options.',
    },

    /**
     * Concept-set UUID whose answers list the available dental finding types.
     */
    findingTypeConceptSetUuid: {
      _type: Type.ConceptUuid,
      _default: 'f0508add-ace9-11f1-aa03-0242ac130004',
      _description: 'UUID of the concept set that holds dental finding-type options.',
    },

    /**
     * Concept-set UUID whose answers list the available dental procedures.
     */
    procedureConceptSetUuid: {
      _type: Type.ConceptUuid,
      _default: '5be3a766-3485-48dd-816c-994f2eeb6739',
      _description: 'UUID of the concept set that holds dental procedure options.',
    },

    /**
     * Concept UUID used as the obs concept for the free-text notes
     * observation within a dental finding group.
     */
    notesConceptUuid: {
      _type: Type.ConceptUuid,
      _default: '0430ae64-acea-11f1-aa03-0242ac130004',
      _description: 'UUID of the concept used for free-text clinical notes inside a finding group.',
    },

    /**
     * Concept UUID used as the obs concept for the tooth member
     * within a dental finding group (the "which tooth" obs).
     */
    toothConceptUuid: {
      _type: Type.ConceptUuid,
      _default: 'b37ec4f6-ace9-11f1-aa03-0242ac130004',
      _description: 'UUID of the parent "Tooth" concept used as the obs concept for the tooth obs inside a finding group.',
    },

    /**
     * Concept UUID used as the grouping concept for the whole dental
     * finding obs group.
     */
    findingGroupConceptUuid: {
      _type: Type.ConceptUuid,
      _default: '85a1cd99-ace9-11f1-aa03-0242ac130004',
      _description: 'UUID of the concept used as the obs-group concept for each dental finding group.',
    },
  },

  /**
   * Encounter type UUID for dental-chart encounters.
   */
  encounterTypeUuid: {
    _type: Type.UUID,
    _default: '13cb3a1a-2b2f-405d-b919-330935402029',
    _description: 'UUID of the encounter type created when saving a dental chart.',
  },

  /**
   * When enabled, the dental-note action button is only shown when the
   * clinician's current session location matches `locationUuid`.
   */
  filterByLocation: {
    enabled: {
      _type: Type.Boolean,
      _default: true,
      _description: 'Hide the dental-note action button when the current session location does not match locationUuid.',
    },
    locationUuid: {
      _type: Type.UUID,
      _default: '1ce1b7d4-c865-4178-82b0-5932e51503d6',
      _description: 'UUID of the location at which the dental-note action button should be visible.',
    },
  },

  /**
   * When true the workspace renders an O3 form (via @openmrs/form-engine-lib)
   * identified by `formUuid` instead of the custom odontogram UI.
   */
  useO3Form: {
    _type: Type.Boolean,
    _default: true,
    _description: 'Use the O3 form engine to render the dental workspace instead of the custom odontogram chart.',
  },

  /**
   * UUID of the O3 form to render when `useO3Form` is true.
   */
  formUuid: {
    _type: Type.UUID,
    _default: '2ceb91b8-0f55-3ea8-8e27-088261e9434f',
    _description: 'UUID of the O3 form definition to load in the dental workspace when useO3Form is enabled.',
  },
};

export interface PermanentTeethConfig {
  [key: string]: string;
  tooth11: string; tooth12: string; tooth13: string; tooth14: string;
  tooth15: string; tooth16: string; tooth17: string; tooth18: string;
  tooth21: string; tooth22: string; tooth23: string; tooth24: string;
  tooth25: string; tooth26: string; tooth27: string; tooth28: string;
  tooth31: string; tooth32: string; tooth33: string; tooth34: string;
  tooth35: string; tooth36: string; tooth37: string; tooth38: string;
  tooth41: string; tooth42: string; tooth43: string; tooth44: string;
  tooth45: string; tooth46: string; tooth47: string; tooth48: string;
}

export interface PrimaryTeethConfig {
  [key: string]: string;
  tooth51: string; tooth52: string; tooth53: string; tooth54: string; tooth55: string;
  tooth61: string; tooth62: string; tooth63: string; tooth64: string; tooth65: string;
  tooth71: string; tooth72: string; tooth73: string; tooth74: string; tooth75: string;
  tooth81: string; tooth82: string; tooth83: string; tooth84: string; tooth85: string;
}

export interface ConfigSchema {
  permanentTeeth: PermanentTeethConfig;
  primaryTeeth: PrimaryTeethConfig;
  concepts: {
    surfaceConceptSetUuid: string;
    findingTypeConceptSetUuid: string;
    procedureConceptSetUuid: string;
    notesConceptUuid: string;
    toothConceptUuid: string;
    findingGroupConceptUuid: string;
  };
  encounterTypeUuid: string;
  filterByLocation: {
    enabled: boolean;
    locationUuid: string;
  };
  useO3Form: boolean;
  formUuid: string;
}
