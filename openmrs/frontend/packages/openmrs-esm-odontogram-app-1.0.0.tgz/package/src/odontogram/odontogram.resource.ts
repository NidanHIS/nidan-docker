/**
 * odontogram.resource.ts
 *
 * All OpenMRS API interactions for the odontogram:
 *   - useSurfaces(uuid)        – fetches the surface concept set
 *   - useFindingTypes(uuid)    – fetches the finding-type concept set
 *   - useProcedures(uuid)      – fetches the procedure concept set
 *   - usePatientFindings()     – loads existing obs for a patient/encounter
 *   - saveFindings()           – posts an updated encounter payload
 *   - toEncounterObs()         – pure serialiser: DentalObservationGroup[] → ObsPayload[]
 *
 * Concept UUIDs are no longer imported from constants.ts; callers (components)
 * read them from config via useConfig() and pass them in as arguments.
 *
 * Uses openmrsFetch + useSWR from @openmrs/esm-framework, following the
 * patterns used across all O3 frontend modules.
 */

import useSWR from 'swr';
import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type {
  ConceptSetResponse,
  ConceptSetMember,
  DentalObservationGroup,
  EncounterPayload,
  ObsPayload,
  ObsRestValue,
} from './types';

// ---------------------------------------------------------------------------
// Concept-set fetchers
// ---------------------------------------------------------------------------

const CONCEPT_CUSTOM_REP = 'custom:(uuid,display,answers)';

function useConceptSet(conceptUuid: string): {
  members: ConceptSetMember[];
  isLoading: boolean;
  error: Error | undefined;
} {
  const url = conceptUuid
    ? `${restBaseUrl}/concept/${conceptUuid}?v=${CONCEPT_CUSTOM_REP}`
    : null;
  const { data, error, isLoading } = useSWR<{ data: ConceptSetResponse }>(url, openmrsFetch);
  const members = (data?.data?.answers ?? []).filter((m) => !m.retired);
  return { members, isLoading, error };
}

/**
 * Returns active surface concepts for the given concept-set UUID.
 * Pass `config.concepts.surfaceConceptSetUuid`.
 */
export function useSurfaces(conceptSetUuid: string) {
  return useConceptSet(conceptSetUuid);
}

/**
 * Returns active finding-type concepts for the given concept-set UUID.
 * Pass `config.concepts.findingTypeConceptSetUuid`.
 */
export function useFindingTypes(conceptSetUuid: string) {
  return useConceptSet(conceptSetUuid);
}

/**
 * Returns active dental procedure concepts for the given concept-set UUID.
 * Pass `config.concepts.procedureConceptSetUuid`.
 */
export function useProcedures(conceptSetUuid: string) {
  return useConceptSet(conceptSetUuid);
}

// ---------------------------------------------------------------------------
// Patient findings loader
// ---------------------------------------------------------------------------

export interface FindingConceptUuids {
  surfaceConceptSetUuid: string;
  findingTypeConceptSetUuid: string;
  procedureConceptSetUuid: string;
  notesConceptUuid: string;
  /** FDI number → concept UUID map built from config permanentTeeth + primaryTeeth */
  toothUuidByFdi: Map<number, string>;
}

/**
 * Loads an encounter's obs and maps any dental obs groups back into
 * DentalObservationGroup instances.
 *
 * @param encounterUuid  The encounter to load obs from.
 * @param conceptUuids   Concept UUIDs read from config, used to identify each
 *                       obs member type within a group.
 */
export function usePatientFindings(
  encounterUuid: string | null | undefined,
  conceptUuids: FindingConceptUuids,
): {
  findings: DentalObservationGroup[];
  isLoading: boolean;
  error: Error | undefined;
  mutate: () => void;
} {
  const url = encounterUuid
    ? `${restBaseUrl}/encounter/${encounterUuid}?v=custom:(uuid,obs:(uuid,concept:(uuid,display),value:(uuid,display),groupMembers:(uuid,concept:(uuid,display),value:(uuid,display))))`
    : null;

  const { data, error, isLoading, mutate } = useSWR<{ data: { obs: ObsRestValue[] } }>(
    url,
    openmrsFetch,
  );

  const findings: DentalObservationGroup[] = [];

  if (data?.data?.obs) {
    // Build the inverse UUID → FDI map from the config-provided forward map.
    const uuidToFdi = new Map<string, number>();
    for (const [fdi, uuid] of conceptUuids.toothUuidByFdi) {
      if (uuid && uuid !== 'uuid') uuidToFdi.set(uuid, fdi);
    }

    for (const obs of data.data.obs) {
      if (!obs.groupMembers || obs.groupMembers.length === 0) continue;

      // Find the tooth obs inside the group
      const toothObs = obs.groupMembers.find(
        (m) =>
          typeof m.value === 'object' &&
          m.value !== null &&
          uuidToFdi.has((m.value as { uuid: string }).uuid),
      );
      if (!toothObs || typeof toothObs.value !== 'object' || toothObs.value === null) continue;

      const toothValueUuid = (toothObs.value as { uuid: string; display: string }).uuid;
      const fdi = uuidToFdi.get(toothValueUuid);
      if (fdi === undefined) continue;

      const surfaceObs   = obs.groupMembers.find((m) => m.concept.uuid === conceptUuids.surfaceConceptSetUuid);
      const findingObs   = obs.groupMembers.find((m) => m.concept.uuid === conceptUuids.findingTypeConceptSetUuid);
      const procedureObs = obs.groupMembers.find((m) => m.concept.uuid === conceptUuids.procedureConceptSetUuid);
      const notesObs     = obs.groupMembers.find((m) => m.concept.uuid === conceptUuids.notesConceptUuid);

      if (!findingObs || typeof findingObs.value !== 'object' || findingObs.value === null) continue;

      findings.push({
        id: obs.uuid,
        tooth: {
          fdi,
          uuid: toothValueUuid,
          display: (toothObs.value as { display: string }).display,
        },
        surface:
          surfaceObs && typeof surfaceObs.value === 'object' && surfaceObs.value !== null
            ? {
                uuid: (surfaceObs.value as { uuid: string }).uuid,
                display: (surfaceObs.value as { display: string }).display,
              }
            : undefined,
        procedure:
          procedureObs && typeof procedureObs.value === 'object' && procedureObs.value !== null
            ? {
                uuid: (procedureObs.value as { uuid: string }).uuid,
                display: (procedureObs.value as { display: string }).display,
              }
            : undefined,
        findingType: {
          uuid: (findingObs.value as { uuid: string }).uuid,
          display: (findingObs.value as { display: string }).display,
        },
        notes: typeof notesObs?.value === 'string' ? notesObs.value : undefined,
        obsGroupUuid: obs.uuid,
      });
    }
  }

  return { findings, isLoading, error, mutate };
}

// ---------------------------------------------------------------------------
// Serialiser  (pure function – no side-effects, fully testable)
// ---------------------------------------------------------------------------

export interface ObsConceptUuids {
  surfaceConceptSetUuid: string;
  findingTypeConceptSetUuid: string;
  procedureConceptSetUuid: string;
  notesConceptUuid: string;
  toothConceptUuid: string;
  findingGroupConceptUuid: string;
}

/**
 * Converts an array of DentalObservationGroup into obs payloads suitable for
 * inclusion in a POST /ws/rest/v1/encounter body.
 *
 * Each group becomes one obs with groupMembers:
 *   - tooth obs        (coded value = tooth concept UUID)
 *   - findingType obs  (coded value = finding-type concept UUID)
 *   - surface obs      (coded value = surface concept UUID, omitted if absent)
 *   - procedure obs    (coded value = procedure concept UUID, omitted if absent)
 *   - notes obs        (text value, omitted if absent or empty)
 *
 * @param groups       The findings to serialise.
 * @param conceptUuids All relevant concept UUIDs read from config.
 */
export function toEncounterObs(
  groups: DentalObservationGroup[],
  conceptUuids: ObsConceptUuids,
): ObsPayload[] {
  return groups.map((g) => {
    const members: ObsPayload[] = [
      { concept: conceptUuids.toothConceptUuid, value: g.tooth.uuid },
      { concept: conceptUuids.findingTypeConceptSetUuid, value: g.findingType.uuid },
    ];

    if (g.surface) {
      members.push({ concept: conceptUuids.surfaceConceptSetUuid, value: g.surface.uuid });
    }

    if (g.procedure) {
      members.push({ concept: conceptUuids.procedureConceptSetUuid, value: g.procedure.uuid });
    }

    if (g.notes && g.notes.trim()) {
      members.push({ concept: conceptUuids.notesConceptUuid, value: g.notes.trim() });
    }

    return {
      concept: conceptUuids.findingGroupConceptUuid,
      groupMembers: members,
    };
  });
}

// ---------------------------------------------------------------------------
// Save helpers
// ---------------------------------------------------------------------------

/**
 * Creates a brand-new encounter containing all dental obs groups in one
 * atomic POST to /ws/rest/v1/encounter.
 */
export async function createEncounterWithFindings(
  payload: EncounterPayload,
): Promise<{ uuid: string; [key: string]: unknown }> {
  const response = await openmrsFetch(`${restBaseUrl}/encounter`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return (response as { data: { uuid: string; [key: string]: unknown } }).data;
}

/**
 * Adds obs to an existing encounter without creating a new one.
 */
export async function saveFindings(
  encounterUuid: string,
  obsPayloads: ObsPayload[],
): Promise<void> {
  await openmrsFetch(`${restBaseUrl}/encounter/${encounterUuid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ obs: obsPayloads }),
  });
}

// ---------------------------------------------------------------------------
// Private helpers
// ---------------------------------------------------------------------------

/**
 * Builds a FDI number → concept UUID map from config-schema tooth sections.
 * Pass `config.permanentTeeth` and `config.primaryTeeth`.
 */
export function buildToothUuidByFdiMap(
  permanentTeeth: Readonly<Record<string, string>>,
  primaryTeeth: Readonly<Record<string, string>>,
): Map<number, string> {
  const map = new Map<number, string>();
  for (const [key, uuid] of Object.entries(permanentTeeth)) {
    const fdi = parseInt(key.replace('tooth', ''), 10);
    if (!isNaN(fdi) && uuid && uuid !== 'uuid') map.set(fdi, uuid);
  }
  for (const [key, uuid] of Object.entries(primaryTeeth)) {
    const fdi = parseInt(key.replace('tooth', ''), 10);
    if (!isNaN(fdi) && uuid && uuid !== 'uuid') map.set(fdi, uuid);
  }
  return map;
}

// ---------------------------------------------------------------------------
// Dental encounter history
// ---------------------------------------------------------------------------

/** Minimal shape of a group-member obs as returned by the encounter list query */
export interface EncounterObsMember {
  uuid: string;
  concept: { uuid: string; display: string };
  value: { uuid: string; display: string } | string | null;
  display: string;
}

/** Minimal shape of a top-level obs (obs group) inside an encounter */
export interface EncounterObsGroup {
  uuid: string;
  concept: { uuid: string; display: string };
  display: string;
  groupMembers: EncounterObsMember[] | null;
  value: null;
  obsDatetime: string;
}

/** Minimal shape of a single encounter in the list response */
export interface DentalEncounter {
  uuid: string;
  display: string;
  encounterDatetime: string;
  encounterType: { uuid: string; display: string };
  visit: {
    uuid: string;
    display: string;
    visitType: { uuid: string; display: string };
    location: { uuid: string; display: string };
    startDatetime: string;
    stopDatetime: string | null;
  };
  obs: EncounterObsGroup[];
  encounterProviders: Array<{ provider: { person: { uuid: string; display?: string } } }>;
}

/** Parsed tooth-level finding row (one obs group → one row) */
export interface ParsedDentalFinding {
  obsGroupUuid: string;
  toothDisplay: string;
  findingType: string;
  surface: string;
  procedure: string;
  notes: string;
  obsDatetime: string;
}

/** A single encounter with its findings already parsed */
export interface ParsedDentalEncounter {
  uuid: string;
  encounterDatetime: string;
  visitDisplay: string;
  locationDisplay: string;
  findings: ParsedDentalFinding[];
}

const ENCOUNTER_LIST_CUSTOM_REP =
  'custom:(uuid,display,encounterDatetime,encounterType,visit:(uuid,display,visitType,location,startDatetime,stopDatetime),' +
  'patient,obs:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),display,' +
  'groupMembers:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),value:(uuid,display),display),' +
  'value,obsDatetime),encounterProviders:(provider:(person)))';

/**
 * Fetches dental consultation encounters for a patient and parses obs groups
 * into structured ParsedDentalEncounter rows ready for display.
 *
 * @param patientUuid       Patient UUID
 * @param encounterTypeUuid Encounter type UUID (from config)
 * @param conceptUuids      Concept UUIDs used to identify each obs member type
 * @param limit             Max number of encounters to fetch (default 20)
 */
export function useDentalEncounters(
  patientUuid: string | null | undefined,
  encounterTypeUuid: string,
  conceptUuids: Pick<
    ObsConceptUuids,
    'toothConceptUuid' | 'findingTypeConceptSetUuid' | 'surfaceConceptSetUuid' | 'procedureConceptSetUuid' | 'notesConceptUuid'
  >,
  limit = 20,
): {
  encounters: ParsedDentalEncounter[];
  isLoading: boolean;
  error: Error | undefined;
  mutate: () => void;
} {
  const url = patientUuid
    ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${ENCOUNTER_LIST_CUSTOM_REP}` +
      `&order=desc&encounterType=${encounterTypeUuid}&limit=${limit}&startIndex=0&totalCount=true`
    : null;

  const { data, error, isLoading, mutate } = useSWR<{
    data: { results: DentalEncounter[] };
  }>(url, openmrsFetch);

  const encounters: ParsedDentalEncounter[] = (data?.data?.results ?? []).map((enc) => {
    const findings: ParsedDentalFinding[] = (enc.obs ?? [])
      .filter((o) => Array.isArray(o.groupMembers) && o.groupMembers.length > 0)
      .map((obsGroup) => {
        const members = obsGroup.groupMembers ?? [];

        const get = (conceptUuid: string): string => {
          const m = members.find((mm) => mm.concept.uuid === conceptUuid);
          if (!m) return '';
          if (m.value && typeof m.value === 'object') return m.value.display;
          if (typeof m.value === 'string') return m.value;
          return '';
        };

        return {
          obsGroupUuid:  obsGroup.uuid,
          toothDisplay:  get(conceptUuids.toothConceptUuid),
          findingType:   get(conceptUuids.findingTypeConceptSetUuid),
          surface:       get(conceptUuids.surfaceConceptSetUuid),
          procedure:     get(conceptUuids.procedureConceptSetUuid),
          notes:         get(conceptUuids.notesConceptUuid),
          obsDatetime:   obsGroup.obsDatetime,
        };
      });

    return {
      uuid:               enc.uuid,
      encounterDatetime:  enc.encounterDatetime,
      visitDisplay:       enc.visit?.visitType?.display ?? enc.visit?.display ?? '—',
      locationDisplay:    enc.visit?.location?.display ?? '—',
      findings,
    };
  });

  return { encounters, isLoading, error, mutate };
}
