/**
 * types.ts
 *
 * Shared clinical-data types for the odontogram Phase 2 layer.
 * No React, no SVG imports – pure domain types so they can be reused by
 * API services, serializers, and UI components alike.
 */

// ---------------------------------------------------------------------------
// OpenMRS REST API shapes (minimal subset used here)
// ---------------------------------------------------------------------------

/** A concept reference as returned by the REST API */
export interface ConceptReference {
  uuid: string;
  display: string;
}

/** A single set-member concept within a concept-set API response */
export interface ConceptSetMember {
  uuid: string;
  display: string;
  retired: boolean;
  names: Array<{ display: string }>;
}

/** Shape of GET /ws/rest/v1/concept/{uuid}?v=custom:(...) */
export interface ConceptSetResponse {
  uuid: string;
  display: string;
  names: Array<{ display: string }>;
  answers: ConceptSetMember[];
}

/** Shape of a single obs as returned inside an encounter */
export interface ObsRestValue {
  uuid: string;
  concept: ConceptReference;
  value: ConceptReference | string | number | null;
  groupMembers?: ObsRestValue[];
  obsDatetime?: string;
  voided?: boolean;
}

/** Shape of the encounter REST response for obs loading */
export interface EncounterRestResponse {
  uuid: string;
  obs: ObsRestValue[];
}

// ---------------------------------------------------------------------------
// Domain model
// ---------------------------------------------------------------------------

/**
 * A single dental finding entry.
 * One DentalObservationGroup maps to one obs group in an OpenMRS encounter.
 *
 * Encounter
 * ├── Tooth 16 group
 * │   ├── Obs: tooth       → ConceptReference (the FDI-tooth concept)
 * │   ├── Obs: surface     → ConceptReference (optional)
 * │   ├── Obs: findingType → ConceptReference
 * │   └── Obs: notes       → string (free text, optional)
 * └── ...
 */
export interface DentalObservationGroup {
  /**
   * Stable client-side id used as React key and for edit/delete targeting.
   * Not persisted to OpenMRS; use `obsGroupUuid` for that.
   */
  id: string;

  /** The tooth this finding belongs to (FDI number + concept reference) */
  tooth: ConceptReference & { fdi: number };

  /** Affected surface (optional) */
  surface?: ConceptReference;

  /** procedure */
  procedure?: ConceptReference;

  /** The clinical finding type (required) */
  findingType: ConceptReference;

  /** Free-text notes (optional) */
  notes?: string;

  /**
   * When the group was loaded from an existing encounter, the obs-group UUID
   * is stored here so the serializer can void the old group on save.
   */
  obsGroupUuid?: string;
}

/**
 * Partial form state while the user fills in the finding panel.
 * All fields except `fdi` are optional until the user submits.
 */
export interface FindingDraft {
  fdi: number;
  surfaceUuid: string;
  procedureUuid: string;
  findingTypeUuid: string;
  notes: string;
}

// ---------------------------------------------------------------------------
// Encounter payload types (toEncounterObs output)
// ---------------------------------------------------------------------------

/**
 * An obs object ready to be submitted inside an encounter payload.
 * Uses the minimal fields accepted by POST /ws/rest/v1/encounter.
 */
export interface ObsPayload {
  concept: string; // concept UUID
  value?: string | number; // coded UUID or text
  groupMembers?: ObsPayload[];
  voided?: boolean;
}

/**
 * Full encounter creation payload for POST /ws/rest/v1/encounter.
 */
export interface EncounterPayload {
  patient: string;
  visit: string;
  encounterType: string;
  /** ISO-8601 datetime string, e.g. "2026-09-15T10:00:00.000+0000" */
  encounterDatetime: string;
  obs: ObsPayload[];
}
