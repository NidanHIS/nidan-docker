import React from 'react';
import { Workspace2 } from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import DentalChart from '../dental-chart.component';

export interface DentalChartWorkspaceProps {
  encounterUuid?: string;
}

/**
 * Workspace shell for the dental chart.
 * DentalChart handles the useO3Form / classic-mode branch internally,
 * so this wrapper stays thin.
 */
const DentalChartFormWorkspace: React.FC<PatientWorkspace2DefinitionProps<DentalChartWorkspaceProps, {}>> = ({
  closeWorkspace,
  workspaceProps,
  groupProps,
}) => (
  <Workspace2 title="Dental Chart">
    <DentalChart
      patientUuid={groupProps?.patientUuid}
      visitUuid={groupProps?.visitContext?.uuid}
      encounterUuid={workspaceProps?.encounterUuid}
      closeWorkspace={closeWorkspace}
    />
  </Workspace2>
);

export default DentalChartFormWorkspace;
