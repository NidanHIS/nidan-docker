import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig, useSession, ActionMenuButton, launchWorkspace2, workspace2Store, getWindowByWorkspaceName } from '@openmrs/esm-framework/src/internal';
import { useStartVisitIfNeeded, type PatientChartWorkspaceActionButtonProps } from '@openmrs/esm-patient-common-lib';
import type { ConfigSchema } from '../config-schema';
import ToothIcon from './tooth-icon.component';

const WORKSPACE_NAME = 'dental-chart-workspace';

/**
 * Action-menu button for the patient chart.
 * Launches the dental-chart workspace and immediately maximises its window.
 *
 * When config.filterByLocation.enabled is true the button is only rendered
 * when the current session location matches config.filterByLocation.locationUuid.
 */
const DentalNoteActionButton: React.FC<PatientChartWorkspaceActionButtonProps> = ({
  groupProps: { patientUuid },
}) => {
  const { t } = useTranslation();
  const startVisitIfNeeded = useStartVisitIfNeeded(patientUuid);
  const { filterByLocation } = useConfig<ConfigSchema>();
  const session = useSession();

  // Location guard – return nothing if filtering is on and location doesn't match
  if (filterByLocation.enabled) {
    const currentLocationUuid = session?.sessionLocation?.uuid;
    if (currentLocationUuid !== filterByLocation.locationUuid) {
      return null;
    }
  }

  const handleClick = async () => {
    const canOpen = await startVisitIfNeeded();
    if (!canOpen) return;

    const opened = await launchWorkspace2(WORKSPACE_NAME, {});
    if (!opened) return;

    try {
      const { name: windowName } = getWindowByWorkspaceName(WORKSPACE_NAME);
      workspace2Store.setState((state) => {
        const idx = state.openedWindows.findIndex((w) => w.windowName === windowName);
        if (idx < 0) return state;
        const openedWindows = [...state.openedWindows];
        openedWindows[idx] = { ...openedWindows[idx], maximized: true };
        return { ...state, openedWindows };
      });
    } catch (_) {
      // getWindowByWorkspaceName throws if not found; swallow gracefully
    }
  };

  return (
    <ActionMenuButton
      getIcon={(props) => <ToothIcon {...props} />}
      label={t('dentalNote', 'Dental note')}
      iconDescription={t('dentalNote', 'Dental note')}
      handler={handleClick}
      type="dental-chart"
    />
  );
};

export default DentalNoteActionButton;
