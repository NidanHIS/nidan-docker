/**
 * tooth.component.tsx
 *
 * Renders one tooth using the occlusal-surface path shapes from the
 * IvanBBaev/dental-psychosomatics reference – anatomically correct outlines
 * with fissure/cusp detail lines.
 *
 * Each tooth <g> is:
 *   translate(cx, cy) → rotate(rot) → scale(s)
 *
 * The FDI label is rendered as a SIBLING element (upright, at labelX/labelY)
 * in odontogram.component.tsx, not inside the rotated group.
 *
 * Phase 2: surface polygons can be added inside <g id="tooth-{fdi}">.
 */

import React from 'react';
import type { ToothDatum } from './tooth-data';
import type { ToothPosition } from './arc-layout';
import styles from './odontogram.module.scss';

// ---------------------------------------------------------------------------
// Tooth type (matches reference)
// ---------------------------------------------------------------------------

type ToothType = 'incisor' | 'canine' | 'premolar' | 'molar';

const TYPE_BY_POS: Record<number, ToothType> = {
  1: 'incisor', 2: 'incisor',
  3: 'canine',
  4: 'premolar', 5: 'premolar',
  6: 'molar', 7: 'molar', 8: 'molar',
};

// ---------------------------------------------------------------------------
// Occlusal outlines  (ported verbatim from reference geometry.ts PATHS)
// ---------------------------------------------------------------------------

const PATHS: Record<ToothType, string> = {
  incisor:  'M -8 -3 Q 0 -5 8 -3 Q 9.5 0 8 3 Q 0 4.6 -8 3 Q -9.5 0 -8 -3 Z',
  canine:   'M 0 -8.5 Q 5.5 -6 6 -1 Q 6 5 0 7.5 Q -6 5 -6 -1 Q -5.5 -6 0 -8.5 Z',
  premolar: 'M -8 -6.5 Q 0 -8.5 8 -6.5 Q 10 0 8 6.5 Q 0 8.5 -8 6.5 Q -10 0 -8 -6.5 Z',
  molar:    'M -8 -10 Q -4 -11 0 -10.5 Q 4 -11 8 -10 Q 11 -9 10.5 -5 Q 11 0 10.5 5 Q 11 9 8 10 Q 4 11 0 10.5 Q -4 11 -8 10 Q -11 9 -10.5 5 Q -11 0 -10.5 -5 Q -11 -9 -8 -10 Z',
};

// ---------------------------------------------------------------------------
// Occlusal detail lines  (ported from reference geometry.ts DETAILS)
// ---------------------------------------------------------------------------

const DETAILS: Record<ToothType, string> = {
  incisor:  'M -6 0 H 6',
  canine:   'M 0 -6 L 0 5',
  premolar: 'M -5 0 H 5',
  molar:    'M 0 -8 V 8 M -8 0 H 8',
};

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export interface ToothProps {
  tooth: ToothDatum;
  position: ToothPosition;
  isSelected: boolean;
  /** True when rendered in mixed mode — primary teeth get a blue tint */
  mixedPrimary?: boolean;
  /** True when at least one finding has been recorded for this tooth */
  hasFinding?: boolean;
  onSelect: (fdi: number) => void;
}

const Tooth: React.FC<ToothProps> = ({ tooth, position, isSelected, mixedPrimary = false, hasFinding = false, onSelect }) => {
  const { cx, cy, rotationDeg, scale } = position;
  const type = TYPE_BY_POS[tooth.positionInQuadrant] ?? 'molar';
  const isPrimaryInMixed = tooth.dentition === 'primary' && mixedPrimary;

  const handleClick = () => onSelect(tooth.fdi);
  const handleKeyDown = (e: React.KeyboardEvent<SVGGElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onSelect(tooth.fdi);
    }
  };

  // Build body class: base + optional primary-in-mixed tint + optional selected
  const bodyClass = [
    styles.toothBody,
    isPrimaryInMixed ? styles.toothBodyPrimary : '',
    isSelected ? styles.toothBodySel : '',
  ].filter(Boolean).join(' ');

  return (
    <g
      id={`tooth-${tooth.fdi}`}
      data-fdi={tooth.fdi}
      data-dentition={tooth.dentition}
      data-arch={tooth.arch}
      transform={`translate(${cx.toFixed(2)} ${cy.toFixed(2)}) rotate(${rotationDeg.toFixed(2)}) scale(${scale.toFixed(3)})`}
      className={`${styles.toothG}${isSelected ? ` ${styles.toothGSel}` : ''}`}
      role="button"
      tabIndex={0}
      aria-pressed={isSelected}
      aria-label={tooth.name}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      {/* Transparent hit-area for easier clicking */}
      <circle className={styles.hit} cx={0} cy={0} r={15} />
      {/* Tooth crown outline */}
      <path className={bodyClass} d={PATHS[type]} />
      {/* Occlusal detail */}
      <path className={styles.anat} d={DETAILS[type]} aria-hidden="true" />
      {/* Finding indicator dot – small teal circle in the top-right of the tooth */}
      {hasFinding && !isSelected && (
        <circle
          cx={8}
          cy={-8}
          r={3.5}
          className={styles.findingDot}
          aria-hidden="true"
        />
      )}
    </g>
  );
};

export default Tooth;
