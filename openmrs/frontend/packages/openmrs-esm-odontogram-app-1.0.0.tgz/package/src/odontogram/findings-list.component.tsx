/**
 * findings-list.component.tsx
 *
 * Shows all DentalObservationGroups recorded so far in this session / encounter.
 * Each row has Edit and Delete actions.
 *
 * Renders nothing when the findings array is empty.
 */

import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  InlineLoading,
  Tag,
  Tile,
} from '@carbon/react';
import { TrashCan, Edit } from '@carbon/react/icons';
import type { DentalObservationGroup } from './types';
import styles from './findings-list.module.scss';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface FindingsListProps {
  findings: DentalObservationGroup[];
  onEdit: (group: DentalObservationGroup) => void;
  onDelete: (id: string) => void;
  deletingId?: string | null;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

const FindingsList: React.FC<FindingsListProps> = ({
  findings,
  onEdit,
  onDelete,
  deletingId,
}) => {
  const { t } = useTranslation();

  if (findings.length === 0) return null;

  return (
    <Tile className={styles.listTile}>
      <h3 className={styles.listHeading}>
        {t('recordedFindings', 'Recorded findings')}
        <span className={styles.count}>{findings.length}</span>
      </h3>

      <ul className={styles.list} aria-label={t('recordedFindings', 'Recorded findings')}>
        {findings.map((group) => (
          <FindingRow
            key={group.id}
            group={group}
            isDeleting={deletingId === group.id}
            onEdit={onEdit}
            onDelete={onDelete}
          />
        ))}
      </ul>
    </Tile>
  );
};

// ---------------------------------------------------------------------------
// Row sub-component
// ---------------------------------------------------------------------------

interface FindingRowProps {
  group: DentalObservationGroup;
  isDeleting: boolean;
  onEdit: (group: DentalObservationGroup) => void;
  onDelete: (id: string) => void;
}

const FindingRow: React.FC<FindingRowProps> = ({ group, isDeleting, onEdit, onDelete }) => {
  const { t } = useTranslation();
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleDeleteClick = () => {
    if (confirmDelete) {
      onDelete(group.id);
      setConfirmDelete(false);
    } else {
      setConfirmDelete(true);
    }
  };

  return (
    <li className={styles.row}>
      {/* Left: tooth badge + finding info */}
      <div className={styles.rowMain}>
        <span className={styles.toothBadge} aria-label={t('toothFdi', 'Tooth {{fdi}}', { fdi: group.tooth.fdi })}>
          {group.tooth.fdi}
        </span>

        <div className={styles.rowDetails}>
          <span className={styles.toothName}>{group.tooth.display}</span>

          <div className={styles.tags}>
            {group.surface && (
              <Tag type="blue" size="sm">
                {group.surface.display}
              </Tag>
            )}
            <Tag type="teal" size="sm">
              {group.findingType.display}
            </Tag>
          </div>

          {group.notes && (
            <p className={styles.notes}>{group.notes}</p>
          )}
        </div>
      </div>

      {/* Right: actions */}
      <div className={styles.rowActions}>
        {isDeleting ? (
          <InlineLoading description={t('deleting', 'Deleting…')} />
        ) : (
          <>
            <Button
              kind="ghost"
              size="sm"
              renderIcon={Edit}
              iconDescription={t('edit', 'Edit')}
              hasIconOnly
              onClick={() => {
                setConfirmDelete(false);
                onEdit(group);
              }}
              aria-label={t('editFinding', 'Edit finding for tooth {{fdi}}', { fdi: group.tooth.fdi })}
            />

            <Button
              kind={confirmDelete ? 'danger' : 'ghost'}
              size="sm"
              renderIcon={TrashCan}
              iconDescription={confirmDelete ? t('confirmDelete', 'Confirm delete') : t('delete', 'Delete')}
              hasIconOnly={!confirmDelete}
              onClick={handleDeleteClick}
              aria-label={
                confirmDelete
                  ? t('confirmDeleteFinding', 'Confirm delete finding for tooth {{fdi}}', { fdi: group.tooth.fdi })
                  : t('deleteFinding', 'Delete finding for tooth {{fdi}}', { fdi: group.tooth.fdi })
              }
            >
              {confirmDelete ? t('confirmDelete', 'Confirm delete') : undefined}
            </Button>

            {confirmDelete && (
              <Button
                kind="ghost"
                size="sm"
                onClick={() => setConfirmDelete(false)}
              >
                {t('cancelDelete', 'Cancel')}
              </Button>
            )}
          </>
        )}
      </div>
    </li>
  );
};

export default FindingsList;
