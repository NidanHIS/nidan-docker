/**
 * tooth-icon.component.tsx
 *
 * Outline tooth icon for OpenMRS O3 / Carbon UI.
 */

import React from 'react';

interface ToothIconProps {
  size?: number;
  className?: string;
  'aria-hidden'?: boolean | 'true' | 'false';
}

const ToothIcon: React.FC<ToothIconProps> = ({
  size = 16,
  className,
  ...rest
}) => {
  return (
    <svg
      {...rest}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <path
        d="
          M5.1 9.2

          C4.0 8.0 3.5 6.2 3.9 4.7
          C4.3 3.1 5.5 1.9 7.0 1.6

          C8.5 1.3 9.9 1.9 11.0 2.3
          C11.4 2.5 11.7 2.6 12.0 2.6

          C12.3 2.6 12.6 2.5 13.0 2.3
          C14.1 1.9 15.5 1.3 17.0 1.6

          C18.5 1.9 19.7 3.1 20.1 4.7
          C20.5 6.2 20.0 8.0 18.9 9.2

          C18.6 10.0 18.5 10.8 18.4 11.6

          L17.5 17.5

          C17.3 18.9 16.8 20.2 16.1 20.7
          C15.5 21.2 14.9 20.8 14.6 19.9

          C14.1 18.5 14.0 16.6 13.6 15.2
          C13.3 13.9 12.8 13.0 12.0 13.0

          C11.2 13.0 10.7 13.9 10.4 15.2
          C10.0 16.6 9.9 18.5 9.4 19.9

          C9.1 20.8 8.5 21.2 7.9 20.7
          C7.2 20.2 6.7 18.9 6.5 17.5

          L5.6 11.6

          C5.5 10.8 5.4 10.0 5.1 9.2

          Z
        "
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default ToothIcon;