/**
 * finding-panel.component.tsx
 *
 * Inline panel that appears below the odontogram when a tooth is selected.
 * Lets the clinician enter or edit a dental finding for that tooth.
 *
 * Layout:
 *   Tooth: 16
 *   Surface: [Select ▾]
 *   Finding: [Select ▾]
 *   Notes:   [___________________________]
 *   [Cancel]  [Save]
 *
 * Props
 * -----
 *   fdi           – FDI number of the selected tooth
 *   toothName     – human-readable tooth name (for the heading)
 *   surfaces      – list of surface concepts from the API
 *   findingTypes  – list of finding-type concepts from the API
 *   isLoading     – true while concept sets are loading
 *   initialValues – pre-filled when editing an existing finding
 *   isSaving      – true while the save request is in-flight
 *   onSave        – called with the filled FindingDraft on submit
 *   onCancel      – called when the user dismisses the panel
 */

import React, { useState, useEffect, useId } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  ComboBox,
  InlineLoading,
  InlineNotification,
  TextArea,
  Tile,
} from '@carbon/react';
import type { ConceptSetMember, FindingDraft } from './types';
import styles from './finding-panel.module.scss';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface FindingPanelProps {
  fdi: number;
  toothName: string;
  surfaces: ConceptSetMember[];
  findingTypes: ConceptSetMember[];
  procedures: ConceptSetMember[];
  isLoading: boolean;
  conceptError?: Error;
  initialValues?: Partial<FindingDraft>;
  isSaving: boolean;
  saveError?: Error;
  onSave: (draft: FindingDraft) => void;
  onCancel: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

const FindingPanel: React.FC<FindingPanelProps> = ({
  fdi,
  toothName,
  surfaces,
  findingTypes,
  procedures,
  isLoading,
  conceptError,
  initialValues,
  isSaving,
  saveError,
  onSave,
  onCancel,
}) => {
  const { t } = useTranslation();
  const formId = useId();

  const [surfaceUuid,      setSurfaceUuid]      = useState(initialValues?.surfaceUuid      ?? '');
  const [procedureUuid,    setProcedureUuid]    = useState(initialValues?.procedureUuid    ?? '');
  const [findingTypeUuid,  setFindingTypeUuid]  = useState(initialValues?.findingTypeUuid  ?? '');
  const [notes,            setNotes]            = useState(initialValues?.notes            ?? '');
  const [validationError,  setValidationError]  = useState('');

  // Reset form when the selected tooth changes
  useEffect(() => {
    setSurfaceUuid(initialValues?.surfaceUuid ?? '');
    setProcedureUuid(initialValues?.procedureUuid ?? '');
    setFindingTypeUuid(initialValues?.findingTypeUuid ?? '');
    setNotes(initialValues?.notes ?? '');
    setValidationError('');
  }, [fdi, initialValues]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!findingTypeUuid) {
      setValidationError(t('findingRequired', 'Please select a finding type'));
      return;
    }
    setValidationError('');
    onSave({ fdi, surfaceUuid, procedureUuid, findingTypeUuid, notes });
  };

  const surfaceItems   = surfaces.map((s) => ({ id: s.uuid, label: s.display }));
  const findingItems   = findingTypes.map((f) => ({ id: f.uuid, label: f.display }));
  const procedureItems = procedures.map((p) => ({ id: p.uuid, label: p.display }));

  const selectedSurface   = surfaceItems.find((s) => s.id === surfaceUuid) ?? null;
  const selectedFinding   = findingItems.find((f) => f.id === findingTypeUuid) ?? null;
  const selectedProcedure = procedureItems.find((p) => p.id === procedureUuid) ?? null;

  return (
    <Tile className={styles.panel}>
      <header className={styles.panelHeader}>
        <span className={styles.toothBadge} aria-hidden="true">{fdi}</span>
        <h3 className={styles.panelTitle}>
          {t('findingFor', 'Finding for {{tooth}}', { tooth: toothName })}
        </h3>
      </header>

      {/* Concept-set loading / error */}
      {isLoading && (
        <InlineLoading description={t('loadingOptions', 'Loading options…')} />
      )}
      {conceptError && (
        <InlineNotification
          kind="error"
          title={t('conceptLoadError', 'Could not load options')}
          subtitle={conceptError.message}
          lowContrast
          hideCloseButton
        />
      )}
      {saveError && (
        <InlineNotification
          kind="error"
          title={t('saveError', 'Save failed')}
          subtitle={saveError.message}
          lowContrast
          hideCloseButton
        />
      )}

      <form id={formId} onSubmit={handleSubmit} noValidate>
        {/* Surface (optional) */}
        <div className={styles.field}>
          <ComboBox
            id={`${formId}-surface`}
            titleText={t('surface', 'Surface')}
            placeholder={t('selectSurface', 'Select surface (optional)')}
            items={surfaceItems}
            itemToString={(item) => item?.label ?? ''}
            selectedItem={selectedSurface}
            onChange={({ selectedItem }) => setSurfaceUuid(selectedItem?.id ?? '')}
            disabled={isLoading || isSaving}
          />
        </div>

        {/* Procedure (optional) */}
        <div className={styles.field}>
          <ComboBox
            id={`${formId}-procedure`}
            titleText={t('procedure', 'Procedure')}
            placeholder={t('selectProcedure', 'Select procedure (optional)')}
            items={procedureItems}
            itemToString={(item) => item?.label ?? ''}
            selectedItem={selectedProcedure}
            onChange={({ selectedItem }) => setProcedureUuid(selectedItem?.id ?? '')}
            disabled={isLoading || isSaving}
          />
        </div>

        {/* Finding type (required) */}
        <div className={styles.field}>
          <ComboBox
            id={`${formId}-finding`}
            titleText={t('findingType', 'Finding')}
            placeholder={t('selectFinding', 'Select finding type')}
            items={findingItems}
            itemToString={(item) => item?.label ?? ''}
            selectedItem={selectedFinding}
            onChange={({ selectedItem }) => {
              setFindingTypeUuid(selectedItem?.id ?? '');
              if (selectedItem) setValidationError('');
            }}
            disabled={isLoading || isSaving}
            invalid={!!validationError}
            invalidText={validationError}
          />
        </div>

        {/* Notes */}
        <div className={styles.field}>
          <TextArea
            id={`${formId}-notes`}
            labelText={t('notes', 'Notes')}
            placeholder={t('notesPlaceholder', 'Optional clinical notes…')}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            disabled={isSaving}
          />
        </div>

        {/* Actions */}
        <div className={styles.actions}>
          <Button
            kind="ghost"
            type="button"
            onClick={onCancel}
            disabled={isSaving}
            size="sm"
          >
            {t('cancel', 'Cancel')}
          </Button>
          <Button
            kind="primary"
            type="submit"
            disabled={isLoading || isSaving}
            size="sm"
          >
            {isSaving
              ? <InlineLoading description={t('saving', 'Saving…')} />
              : t('save', 'Save')}
          </Button>
        </div>
      </form>
    </Tile>
  );
};

export default FindingPanel;
