// ---------------------------------------------------------------------------
// Tooth concept UUID maps have been moved to config-schema.ts so they can be
// overridden per deployment without a code change.
//
// Use `config.permanentTeeth` and `config.primaryTeeth` (from useConfig()) and
// build a runtime FDI → UUID map with `buildToothUuidByFdiMap()` from
// odontogram.resource.ts.
// ---------------------------------------------------------------------------
