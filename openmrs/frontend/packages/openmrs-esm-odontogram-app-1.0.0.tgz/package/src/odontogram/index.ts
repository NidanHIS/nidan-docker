/**
 * Public surface of the odontogram package.
 * Always import from here, never from individual files.
 */

// SVG chart + dentition selector
export { default as Odontogram } from './odontogram.component';
export { default as DentitionSelector } from './dentition-selector.component';
export type { OdontogramProps } from './odontogram.component';

// Tooth data
export type { DentitionType, ToothDatum, Arch, Quadrant } from './tooth-data';
export { PERMANENT_TEETH, PRIMARY_TEETH, ALL_TEETH_BY_FDI } from './tooth-data';

// Arc geometry
export type { ToothPosition } from './arc-layout';
export { computeToothPositions } from './arc-layout';

// Clinical types (Phase 2)
export type {
  ConceptReference,
  ConceptSetMember,
  ConceptSetResponse,
  DentalObservationGroup,
  EncounterPayload,
  FindingDraft,
  ObsPayload,
} from './types';

// Concept constants — tooth UUIDs are now in config-schema.ts (permanentTeeth / primaryTeeth).
// Use buildToothUuidByFdiMap() from odontogram.resource to build a runtime FDI → UUID map.

// Resource layer (Phase 2)
export { useSurfaces, useFindingTypes, useProcedures, usePatientFindings, useDentalEncounters, toEncounterObs, saveFindings, createEncounterWithFindings, buildToothUuidByFdiMap } from './odontogram.resource';
export type { FindingConceptUuids, ObsConceptUuids, ParsedDentalEncounter, ParsedDentalFinding } from './odontogram.resource';

// Finding UI components (Phase 2)
export { default as FindingPanel } from './finding-panel.component';
export type { FindingPanelProps } from './finding-panel.component';
export { default as FindingsList } from './findings-list.component';
export type { FindingsListProps } from './findings-list.component';
