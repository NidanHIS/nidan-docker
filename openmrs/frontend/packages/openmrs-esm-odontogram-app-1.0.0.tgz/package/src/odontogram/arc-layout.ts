/**
 * arc-layout.ts
 *
 * Geometry adapted from the IvanBBaev/dental-psychosomatics reference.
 * Two completely separate horseshoe jaws stacked vertically:
 *   - Upper arch: centred at (CX, UPPER_CY), opens downward, incisors at top
 *   - Lower arch: centred at (CX, LOWER_CY), opens upward,  incisors at bottom
 *
 * Mixed dentition layout:
 *   - Permanent teeth sit on the OUTER ellipse (ARCH_RX / ARCH_RY)
 *   - Primary teeth sit on a SMALLER INNER ellipse (PRIM_RX / PRIM_RY)
 *     so they appear as a second ring just inside the permanent ring.
 *   - Labels for permanent teeth are pushed OUTWARD (away from palate).
 *   - Labels for primary teeth are pushed INWARD (toward palate centre)
 *     so they sit in the gap between the two rings and never overlap.
 *
 * viewBox: "0 0 680 780"
 * Phase 2: import computeToothPositions, gumPalatePath, palateRugae.
 */

import type { ToothDatum } from './tooth-data';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

// export const VB_W = 680;
// export const VB_H = 780;
// export const CX   = 340;

// export const UPPER_CY = 230;
// export const LOWER_CY = 556;

// /** Permanent-tooth arch ellipse radii */
// export const ARCH_RX = 212;
// export const ARCH_RY = 158;

export const VB_W = 680;
export const VB_H = 650;
export const CX   = 340;

export const UPPER_CY = 200;
export const LOWER_CY = 452;

/** Permanent-tooth arch ellipse radii */
export const ARCH_RX = 165;
export const ARCH_RY = 118;

/**
 * Primary-tooth arch ellipse radii.
 * Chosen so the primary ring sits clearly inward of the permanent ring,
 * with enough room for both tooth bodies and their labels to be legible.
 * Primary teeth are scaled ~0.72× so their occlusal footprint is smaller.
 * The arch radius is reduced to ~62% of the permanent radius so bodies
 * don't collide.
 */
const PRIM_RX = 122; // inner ring in mixed mode
const PRIM_RY = 88;

/**
 * How far (in SVG units) to push the FDI label away from the tooth centre.
 * Positive = outward (away from palate), negative = inward (toward palate).
 */
const PERM_LABEL_OFFSET   =  34; // outside the permanent ring
const PRIM_LABEL_OFFSET   = -26; // inside the primary ring, toward the dome

// Each jaw sweeps ~240° of its ellipse.
const ARC = {
  upper: { cy: UPPER_CY, start: 150, end: 390 },
  lower: { cy: LOWER_CY, start: 210, end: -30 },
} as const;

const DEG = Math.PI / 180;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ToothPosition {
  cx: number;
  cy: number;
  /** Rotation so the occlusal surface faces the palate centre */
  rotationDeg: number;
  /** Uniform scale factor – larger for molars, smaller for primaries */
  scale: number;
  /** FDI label x (may be inward of the tooth for primary in mixed mode) */
  labelX: number;
  /** FDI label y */
  labelY: number;
  /** Whether the label is placed inward (primary in mixed) */
  labelInward: boolean;
}

// ---------------------------------------------------------------------------
// Geometry helpers
// ---------------------------------------------------------------------------

interface Pt { x: number; y: number }

function ellipsePtCustom(cy: number, aDeg: number, rx: number, ry: number): Pt {
  const a = aDeg * DEG;
  return { x: CX + rx * Math.cos(a), y: cy + ry * Math.sin(a) };
}

/**
 * Arc-length-equalised distribution of n points along an elliptical arc.
 * (Ported verbatim from IvanBBaev/dental-psychosomatics geometry.ts)
 */
function archPositions(cy: number, startDeg: number, endDeg: number, n: number, rx: number, ry: number): Pt[] {
  const N = 720;
  const pts: Pt[] = [];
  for (let k = 0; k <= N; k++) {
    pts.push(ellipsePtCustom(cy, startDeg + ((endDeg - startDeg) * k) / N, rx, ry));
  }
  const cum: number[] = [0];
  for (let k = 1; k <= N; k++) {
    cum.push(cum[k - 1] + Math.hypot(pts[k].x - pts[k - 1].x, pts[k].y - pts[k - 1].y));
  }
  const total = cum[N];

  const res: Pt[] = [];
  for (let i = 0; i < n; i++) {
    const target = (total * (i + 0.5)) / n;
    let k = 1;
    while (k < N && cum[k] < target) k++;
    res.push(pts[k]);
  }
  return res;
}

/**
 * Push a point radially from the jaw centre by `offset` SVG units.
 * Positive offset → outward (away from palate), negative → inward.
 */
function radialOffset(px: number, py: number, cy: number, offset: number): { x: number; y: number } {
  const dx = px - CX;
  const dy = py - cy;
  const len = Math.hypot(dx, dy) || 1;
  return { x: px + (dx / len) * offset, y: py + (dy / len) * offset };
}

// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------

export function computeToothPositions(teeth: ToothDatum[]): Map<number, ToothPosition> {
  const result = new Map<number, ToothPosition>();

  // Are we in mixed mode? (both permanent AND primary present)
  const hasPermanent = teeth.some((t) => t.dentition === 'permanent');
  const hasPrimary   = teeth.some((t) => t.dentition === 'primary');
  const isMixed = hasPermanent && hasPrimary;

  for (const jaw of ['upper', 'lower'] as const) {
    const { cy, start, end } = ARC[jaw];

    for (const dentition of ['permanent', 'primary'] as const) {
      const subset = teeth.filter((t) => t.arch === jaw && t.dentition === dentition);
      if (subset.length === 0) continue;

      // Choose ellipse radii per dentition:
      //   - standalone primary → same arc as permanent (full size)
      //   - mixed primary      → inner arc (PRIM_RX/RY) so it fits inside the permanent ring
      const rx = dentition === 'permanent' ? ARCH_RX : (isMixed ? PRIM_RX : ARCH_RX);
      const ry = dentition === 'permanent' ? ARCH_RY : (isMixed ? PRIM_RY : ARCH_RY);

      // Screen order: viewer-left (patient right, outer-first) → viewer-right (patient left, inner-first)
      const rightQ = [1, 4, 5, 8]; // patient right → viewer left
      const leftQ  = [2, 3, 6, 7]; // patient left  → viewer right

      const leftScreen = subset
        .filter((t) => rightQ.includes(t.quadrant))
        .sort((a, b) => b.positionInQuadrant - a.positionInQuadrant); // molar→incisor

      const rightScreen = subset
        .filter((t) => leftQ.includes(t.quadrant))
        .sort((a, b) => a.positionInQuadrant - b.positionInQuadrant); // incisor→molar

      const ordered = [...leftScreen, ...rightScreen];
      const n = ordered.length;
      if (n === 0) continue;

      const positions = archPositions(cy, start, end, n, rx, ry);

      ordered.forEach((tooth, i) => {
        const p = positions[i];

        // Rotation: crown (+y in local space) points toward the palate centre
        const dx = CX - p.x;
        const dy = cy - p.y;
        const rot = (Math.atan2(-dx, dy) * 180) / Math.PI;

        // Scale: incisor ~1.16, molar ~1.44
        // primary in mixed → smaller (×0.72) to fit inside permanent ring
        // primary standalone → same size as permanent
        const baseScale = 1.12 + 0.04 * tooth.positionInQuadrant;
        const toothScale = (dentition === 'primary' && isMixed) ? baseScale * 0.72 : baseScale;

        // Label placement:
        //   - permanent: always outward
        //   - primary standalone: outward
        //   - primary in mixed:   inward (toward palate), so it sits
        //     between the two tooth rings without overlapping permanent labels
        const labelInward = dentition === 'primary' && isMixed;
        const labelOffset = labelInward ? PRIM_LABEL_OFFSET : PERM_LABEL_OFFSET;
        const lp = radialOffset(p.x, p.y, cy, labelOffset);

        result.set(tooth.fdi, {
          cx: p.x,
          cy: p.y,
          rotationDeg: rot,
          scale: toothScale,
          labelX: lp.x,
          labelY: lp.y,
          labelInward,
        });
      });
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// Gum / palate paths
// ---------------------------------------------------------------------------

/** Filled horseshoe gum path for the permanent (outer) arch */
export function gumPalatePath(jaw: 'upper' | 'lower'): string {
  const { cy, start, end } = ARC[jaw];
  const PAD = 20;
  const rx = ARCH_RX + PAD;
  const ry = ARCH_RY + PAD;
  const K = 56;
  const pts: Pt[] = [];
  for (let k = 0; k <= K; k++) {
    pts.push(ellipsePtCustom(cy, start + ((end - start) * k) / K, rx, ry));
  }
  const cs = jaw === 'upper' ? 1 : -1;
  const ctrl: Pt = { x: CX, y: cy + cs * 0.22 * ry };
  const arc = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`);
  return `${arc.join(' ')} Q ${ctrl.x.toFixed(1)} ${ctrl.y.toFixed(1)} ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)} Z`;
}

/** Filled horseshoe gum path for the primary arch.
 *  - standalone (primary-only tab): uses full ARCH_RX/RY (same size as permanent)
 *  - mixed: uses PRIM_RX/RY so it sits inside the permanent gum
 */
export function gumPalatePathPrimary(jaw: 'upper' | 'lower', isMixed = false): string {
  const { cy, start, end } = ARC[jaw];
  const PAD = 14;
  const rx = (isMixed ? PRIM_RX : ARCH_RX) + PAD;
  const ry = (isMixed ? PRIM_RY : ARCH_RY) + PAD;
  const K = 56;
  const pts: Pt[] = [];
  for (let k = 0; k <= K; k++) {
    pts.push(ellipsePtCustom(cy, start + ((end - start) * k) / K, rx, ry));
  }
  const cs = jaw === 'upper' ? 1 : -1;
  const ctrl: Pt = { x: CX, y: cy + cs * 0.22 * ry };
  const arc = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`);
  return `${arc.join(' ')} Q ${ctrl.x.toFixed(1)} ${ctrl.y.toFixed(1)} ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)} Z`;
}

/** Decorative palate rugae (faint ridges) for the upper jaw */
export function palateRugae(): string[] {
  const lines: string[] = [];
  const cy = UPPER_CY;
  for (let i = 0; i < 4; i++) {
    const y = cy - 40 + i * 22;
    const w = 36 - i * 4;
    lines.push(`M ${CX - w} ${y} Q ${CX} ${y + 7} ${CX + w} ${y}`);
  }
  return lines;
}
