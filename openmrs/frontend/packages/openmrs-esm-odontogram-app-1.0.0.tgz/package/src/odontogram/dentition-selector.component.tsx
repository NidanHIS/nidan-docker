/**
 * dentition-selector.component.tsx
 *
 * A Carbon ContentSwitcher that lets the clinician toggle between
 * permanent, primary (deciduous), and mixed dentition views.
 *
 * Uses the Carbon `ContentSwitcher` + `Switch` components so it inherits
 * all O3 theme tokens and accessibility behaviour automatically.
 */

import React from 'react';
import { ContentSwitcher, Switch } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import type { DentitionType } from './tooth-data';

interface DentitionSelectorProps {
  value: DentitionType;
  onChange: (mode: DentitionType) => void;
}

const MODES: { key: DentitionType; label: string; i18nKey: string }[] = [
  { key: 'permanent', label: 'Permanent', i18nKey: 'permanent' },
  { key: 'primary', label: 'Primary', i18nKey: 'primary' },
  { key: 'mixed', label: 'Mixed', i18nKey: 'mixed' },
];

const DentitionSelector: React.FC<DentitionSelectorProps> = ({ value, onChange }) => {
  const { t } = useTranslation();

  const selectedIndex = MODES.findIndex((m) => m.key === value);

  return (
    <ContentSwitcher
      selectedIndex={selectedIndex}
      onChange={({ name }) => {
        const mode = name as DentitionType;
        onChange(mode);
      }}
      aria-label={t('dentitionMode', 'Dentition mode')}
    >
      {MODES.map(({ key, label, i18nKey }) => (
        <Switch key={key} name={key} text={t(i18nKey, label)} />
      ))}
    </ContentSwitcher>
  );
};

export default DentitionSelector;
