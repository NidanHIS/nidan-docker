/**
 * tooth-data.ts
 *
 * FDI two-digit notation data for permanent and primary teeth.
 * This module is intentionally free of any React or SVG concerns so that
 * Phase 2 can import these types alongside OpenMRS Obs models without
 * pulling in any rendering dependency.
 *
 * FDI quadrant scheme
 *   Permanent  : Q1 (upper-right) 11-18 | Q2 (upper-left) 21-28
 *                Q3 (lower-left)  31-38 | Q4 (lower-right) 41-48
 *   Primary    : Q5 (upper-right) 51-55 | Q6 (upper-left)  61-65
 *                Q7 (lower-left)  71-75 | Q8 (lower-right) 81-85
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type DentitionType = 'permanent' | 'primary' | 'mixed';

export type Quadrant = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export type Arch = 'upper' | 'lower';

export interface ToothDatum {
  /** FDI two-digit number, e.g. 16, 55 */
  fdi: number;
  /** Human-readable name used for aria-label and tooltips */
  name: string;
  /** Which dentition this tooth belongs to */
  dentition: 'permanent' | 'primary';
  /** Anatomical arch */
  arch: Arch;
  /** FDI quadrant (1-4 permanent, 5-8 primary) */
  quadrant: Quadrant;
  /**
   * Position index within the quadrant, 1 = closest to midline.
   * Permanent: 1-8; Primary: 1-5.
   */
  positionInQuadrant: number;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const PERMANENT_NAMES: Record<number, string> = {
  1: 'Central Incisor',
  2: 'Lateral Incisor',
  3: 'Canine',
  4: 'First Premolar',
  5: 'Second Premolar',
  6: 'First Molar',
  7: 'Second Molar',
  8: 'Third Molar (Wisdom)',
};

const PRIMARY_NAMES: Record<number, string> = {
  1: 'Central Incisor',
  2: 'Lateral Incisor',
  3: 'Canine',
  4: 'First Molar',
  5: 'Second Molar',
};

function makePermanentQuadrant(quadrant: 1 | 2 | 3 | 4, arch: Arch): ToothDatum[] {
  return Array.from({ length: 8 }, (_, i) => {
    const pos = i + 1; // 1 = central incisor … 8 = wisdom tooth
    const fdi = quadrant * 10 + pos;
    return {
      fdi,
      name: `${PERMANENT_NAMES[pos]} (${fdi})`,
      dentition: 'permanent',
      arch,
      quadrant,
      positionInQuadrant: pos,
    } satisfies ToothDatum;
  });
}

function makePrimaryQuadrant(quadrant: 5 | 6 | 7 | 8, arch: Arch): ToothDatum[] {
  return Array.from({ length: 5 }, (_, i) => {
    const pos = i + 1;
    const fdi = quadrant * 10 + pos;
    return {
      fdi,
      name: `Primary ${PRIMARY_NAMES[pos]} (${fdi})`,
      dentition: 'primary',
      arch,
      quadrant,
      positionInQuadrant: pos,
    } satisfies ToothDatum;
  });
}

// ---------------------------------------------------------------------------
// Data sets
// ---------------------------------------------------------------------------

/**
 * All 32 permanent teeth, ordered Q1 → Q2 (upper) then Q4 → Q3 (lower),
 * each quadrant from midline outward.  This ordering drives the arc layout.
 */
export const PERMANENT_TEETH: ToothDatum[] = [
  ...makePermanentQuadrant(1, 'upper'), // 11-18  upper-right
  ...makePermanentQuadrant(2, 'upper'), // 21-28  upper-left
  ...makePermanentQuadrant(4, 'lower'), // 41-48  lower-right
  ...makePermanentQuadrant(3, 'lower'), // 31-38  lower-left
];

/**
 * All 20 primary teeth, same ordering convention as permanent.
 */
export const PRIMARY_TEETH: ToothDatum[] = [
  ...makePrimaryQuadrant(5, 'upper'), // 51-55  upper-right
  ...makePrimaryQuadrant(6, 'upper'), // 61-65  upper-left
  ...makePrimaryQuadrant(8, 'lower'), // 81-85  lower-right
  ...makePrimaryQuadrant(7, 'lower'), // 71-75  lower-left
];

/** Combined look-up map keyed by FDI number */
export const ALL_TEETH_BY_FDI: Map<number, ToothDatum> = new Map([
  ...PERMANENT_TEETH.map((t) => [t.fdi, t] as [number, ToothDatum]),
  ...PRIMARY_TEETH.map((t) => [t.fdi, t] as [number, ToothDatum]),
]);
