/**
 * odontogram.component.tsx
 *
 * Two completely separate horseshoe jaws stacked vertically in a 680×780
 * viewBox, matching the IvanBBaev/dental-psychosomatics reference exactly.
 *
 * Upper arch: filled gum dome + teeth, centred at (340, 230)
 * Lower arch: filled gum dome + teeth, centred at (340, 556)
 *
 * Rendering order per jaw:
 *   1. Background tint rectangles (left/right quadrant colouring)
 *   2. Gum + palate fill path
 *   3. Palate rugae (upper only)
 *   4. Teeth (rotated/scaled)
 *   5. FDI labels (upright, pushed radially outward)
 *
 * Phase 2: add surface polygons inside each <g id="tooth-{fdi}">.
 */

import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';

import { PERMANENT_TEETH, PRIMARY_TEETH, type DentitionType, type ToothDatum } from './tooth-data';
import {
  computeToothPositions,
  gumPalatePath,
  gumPalatePathPrimary,
  palateRugae,
  CX,
  VB_W,
  VB_H,
} from './arc-layout';
import Tooth from './tooth.component';
import styles from './odontogram.module.scss';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface OdontogramProps {
  dentitionMode: DentitionType;
  selectedTooth: number | null;
  onToothSelect: (fdi: number | null) => void;
  /** Set of FDI numbers that already have at least one recorded finding */
  teethWithFindings?: Set<number>;
  className?: string;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

const Odontogram: React.FC<OdontogramProps> = ({
  dentitionMode,
  selectedTooth,
  onToothSelect,
  teethWithFindings,
  className,
}) => {
  const { t } = useTranslation();

  const visibleTeeth = useMemo((): ToothDatum[] => {
    switch (dentitionMode) {
      case 'permanent': return PERMANENT_TEETH;
      case 'primary':   return PRIMARY_TEETH;
      case 'mixed':     return [...PERMANENT_TEETH, ...PRIMARY_TEETH];
    }
  }, [dentitionMode]);

  const positions = useMemo(() => computeToothPositions(visibleTeeth), [visibleTeeth]);

  const handleSelect = (fdi: number) => onToothSelect(selectedTooth === fdi ? null : fdi);

  const selectedName = useMemo(() => {
    if (selectedTooth === null) return null;
    return visibleTeeth.find((t) => t.fdi === selectedTooth)?.name ?? null;
  }, [selectedTooth, visibleTeeth]);

  const isMixed = dentitionMode === 'mixed';
  const showPermanent = dentitionMode === 'permanent' || isMixed;
  const showPrimary   = dentitionMode === 'primary'   || isMixed;

  // Teeth partitioned by jaw for rendering
  const teethByJaw = useMemo(() => ({
    upper: visibleTeeth.filter((t) => t.arch === 'upper'),
    lower: visibleTeeth.filter((t) => t.arch === 'lower'),
  }), [visibleTeeth]);

  const rugae = useMemo(() => palateRugae(), []);
  const upperGum = useMemo(() => gumPalatePath('upper'), []);
  const lowerGum = useMemo(() => gumPalatePath('lower'), []);
  const upperGumPrimary = useMemo(() => gumPalatePathPrimary('upper', isMixed), [isMixed]);
  const lowerGumPrimary = useMemo(() => gumPalatePathPrimary('lower', isMixed), [isMixed]);

  return (
    <div className={[styles.odontogramWrapper, className].filter(Boolean).join(' ')}>
      <div className={styles.svgContainer}>
        <svg
          viewBox={`0 0 ${VB_W} ${VB_H}`}
          className={styles.odontogramSvg}
          role="group"
          aria-label={t('odontogramChart', 'Interactive dental chart')}
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <radialGradient id="gumGrad" cx="50%" cy="42%" r="70%">
  <stop offset="0%" stopColor="#D9F1F7" />
  <stop offset="65%" stopColor="#7FC4D6" />
  <stop offset="100%" stopColor="#0082A8" />
</radialGradient>
            <linearGradient id="toothFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#ece1cb" />
            </linearGradient>
            {/* Blue-tinted gradient for primary teeth in mixed mode */}
            <linearGradient id="toothFillPrimary" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#eef5ff" />
              <stop offset="100%" stopColor="#c8ddf5" />
            </linearGradient>
            <linearGradient id="toothSel" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#dcf4ed" />
              <stop offset="100%" stopColor="#8fd2c1" />
            </linearGradient>
          </defs>

          {/* ── Decorative background (hidden from AT) ── */}
          <g aria-hidden="true">
            {/* Left/right quadrant tints */}
            <rect className={styles.tintLeft}  x={0}    y={0} width={CX}        height={VB_H} />
            <rect className={styles.tintRight} x={CX}   y={0} width={VB_W - CX} height={VB_H} />
            {/* Vertical midline */}
            <line className={styles.axis} x1={CX} y1={60} x2={CX} y2={570} />

            {/* Gum fills */}
            {showPermanent && (
              <>
                <path className={styles.gum} d={upperGum} />
                <path className={styles.gum} d={lowerGum} />
              </>
            )}
            {showPrimary && (
              <>
                <path className={styles.gumPrimary} d={upperGumPrimary} />
                <path className={styles.gumPrimary} d={lowerGumPrimary} />
              </>
            )}

            {/* Palate rugae (upper only) */}
            {rugae.map((d, i) => (
              <path key={i} className={styles.rugae} d={d} />
            ))}

            {/* Jaw labels */}
            <text className={styles.jawLabel} x={CX} y={26}   textAnchor="middle">{t('upperJaw', 'Upper Jaw')}</text>
            <text className={styles.jawLabel} x={CX} y={630}  textAnchor="middle">{t('lowerJaw', 'Lower Jaw')}</text>
            {/* Side labels */}
            <text className={`${styles.axLabel} ${styles.axLabelRose}`} x={20}       y={28}>{t('patientLeft', "Patient's Left")}</text>
            <text className={`${styles.axLabel} ${styles.axLabelBlue}`} x={VB_W - 20} y={28} textAnchor="end">{t('patientRight', "Patient's Right")}</text>
          </g>

          {/* ── Teeth (upper) ── */}
          {teethByJaw.upper.map((tooth) => {
            const pos = positions.get(tooth.fdi);
            if (!pos) return null;
            return (
              <Tooth
                key={tooth.fdi}
                tooth={tooth}
                position={pos}
                isSelected={selectedTooth === tooth.fdi}
                mixedPrimary={isMixed && tooth.dentition === 'primary'}
                hasFinding={teethWithFindings?.has(tooth.fdi) ?? false}
                onSelect={handleSelect}
              />
            );
          })}

          {/* ── Teeth (lower) ── */}
          {teethByJaw.lower.map((tooth) => {
            const pos = positions.get(tooth.fdi);
            if (!pos) return null;
            return (
              <Tooth
                key={tooth.fdi}
                tooth={tooth}
                position={pos}
                isSelected={selectedTooth === tooth.fdi}
                mixedPrimary={isMixed && tooth.dentition === 'primary'}
                hasFinding={teethWithFindings?.has(tooth.fdi) ?? false}
                onSelect={handleSelect}
              />
            );
          })}

          {/* ── FDI labels (upright, outside/inside arch depending on dentition) ── */}
          {visibleTeeth.map((tooth) => {
            const pos = positions.get(tooth.fdi);
            if (!pos) return null;

            const isPrimaryMixed = tooth.dentition === 'primary' && isMixed;
            const labelClass = [
              styles.fdiLabel,
              selectedTooth === tooth.fdi ? styles.fdiLabelSel : '',
              isPrimaryMixed
                ? styles.fdiLabelPrimaryMixed
                : tooth.dentition === 'primary'
                  ? styles.fdiLabelPrimary
                  : '',
            ].filter(Boolean).join(' ');

            return (
              <text
                key={`lbl-${tooth.fdi}`}
                x={pos.labelX.toFixed(1)}
                y={pos.labelY.toFixed(1)}
                textAnchor="middle"
                dominantBaseline="middle"
                className={labelClass}
                aria-hidden="true"
              >
                {tooth.fdi}
              </text>
            );
          })}
        </svg>
      </div>

      {/* Status bar */}
      <p className={styles.statusBar} aria-live="polite">
        {selectedName
          ? t('toothSelected', 'Selected: {{name}}', { name: selectedName })
          : t('noToothSelected', 'Click or press Enter / Space on a tooth to select it')}
      </p>

      {/* Legend */}
      <div className={styles.legend} aria-label={t('odontogramLegend', 'Legend')}>
        {showPermanent && (
          <span className={styles.legendItem}>
            <span className={`${styles.legendSwatch} ${styles.legendSwatchPermanent}`} aria-hidden="true" />
            {t('permanentTooth', 'Permanent')}
          </span>
        )}
        {showPrimary && (
          <span className={styles.legendItem}>
            <span className={`${styles.legendSwatch} ${styles.legendSwatchPrimary}`} aria-hidden="true" />
            {t('primaryTooth', 'Primary (deciduous)')}
          </span>
        )}
        <span className={styles.legendItem}>
          <span className={`${styles.legendSwatch} ${styles.legendSwatchSelected}`} aria-hidden="true" />
          {t('selectedTooth', 'Selected')}
        </span>
      </div>
    </div>
  );
};

export default Odontogram;
