import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import DentalChart from './dental-chart.component';

const Root: React.FC = () => (
  <BrowserRouter basename={window.getOpenmrsSpaBase()}>
    <Routes>
      <Route path="dental-chart" element={<DentalChart />} />
    </Routes>
  </BrowserRouter>
);

export default Root;
