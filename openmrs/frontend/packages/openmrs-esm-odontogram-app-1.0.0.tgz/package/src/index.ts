import { getAsyncLifecycle, getSyncLifecycle, defineConfigSchema } from '@openmrs/esm-framework';
// import { createDashboardLink } from '@openmrs/esm-patient-common-lib';
import { createDashboardLink } from '@openmrs/esm-patient-common-lib';
import { configSchema } from './config-schema';
import DentalObs from './dental-obs.component';
import { moduleName } from './constants';
import { summarydashboardMeta } from './dashboard.meta';
import DentalNoteActionButtonExtension from './odontogram/dental-note-action-button.extension';

const options = {
  featureName: 'odontogram-app',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

// Root component
export const root = getAsyncLifecycle(() => import('./root.component.copy'), options);

export const dentalSummary = getSyncLifecycle(DentalObs, options);

export const dentalDashboardLink = getSyncLifecycle(
  createDashboardLink({
    ...summarydashboardMeta,
  }),
  options,
);

export const dentalNotesActionButton = getSyncLifecycle(DentalNoteActionButtonExtension, options);


// Extensions

// Modals

// Workspaces
export const dentalChartWorkspace = getAsyncLifecycle(
  () => import('./odontogram/dental-chart-form.workspace'),
  options,
);
