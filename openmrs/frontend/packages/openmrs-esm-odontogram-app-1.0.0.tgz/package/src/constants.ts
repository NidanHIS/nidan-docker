export const moduleName = '@openmrs/esm-odontogram-app';
