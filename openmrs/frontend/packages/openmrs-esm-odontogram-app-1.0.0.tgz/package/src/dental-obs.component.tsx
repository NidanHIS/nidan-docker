/**
 * dental-obs.component.tsx
 *
 * Displays a patient's historical dental consultation encounters.
 *
 * Each encounter is shown as a collapsible card. Inside each card a table
 * lists one row per obs group (tooth finding), with columns:
 *   Tooth | Finding | Surface | Procedure | Notes
 *
 * Data flow
 * ---------
 *   useDentalEncounters()  → ParsedDentalEncounter[]
 *   Concept UUIDs and encounterTypeUuid read from config via useConfig()
 *
 * Props
 * -----
 *   patientUuid  – required; passed by the patient-chart slot infrastructure
 */

import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@openmrs/esm-framework';
import {
  InlineLoading,
  InlineNotification,
  Tag,
} from '@carbon/react';
import { ChevronDown } from '@carbon/react/icons';
import { useDentalEncounters } from './odontogram/odontogram.resource';
import type { ParsedDentalEncounter, ParsedDentalFinding } from './odontogram/odontogram.resource';
import type { ConfigSchema } from './config-schema';
import styles from './dental-obs.module.scss';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatDatetime(iso: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

interface FindingsTableProps {
  findings: ParsedDentalFinding[];
}

const FindingsTable: React.FC<FindingsTableProps> = ({ findings }) => {
  const { t } = useTranslation();

  if (findings.length === 0) {
    return (
      <p className={styles.emptyCell} style={{ padding: '1rem 1.25rem' }}>
        {t('noFindingsInEncounter', 'No findings recorded in this encounter.')}
      </p>
    );
  }

  return (
    <table className={styles.findingsTable}>
      <thead>
        <tr>
          <th>{t('tooth', 'Tooth')}</th>
          <th>{t('finding', 'Finding')}</th>
          <th>{t('surface', 'Surface')}</th>
          <th>{t('procedure', 'Procedure')}</th>
          <th>{t('notes', 'Notes')}</th>
        </tr>
      </thead>
      <tbody>
        {findings.map((f) => (
          <tr key={f.obsGroupUuid}>
            <td>
              {f.toothDisplay ? (
                <span className={styles.toothBadge}>{f.toothDisplay}</span>
              ) : (
                <span className={styles.emptyCell}>—</span>
              )}
            </td>
            <td>
              {f.findingType ? (
                <Tag type="teal" size="sm">{f.findingType}</Tag>
              ) : (
                <span className={styles.emptyCell}>—</span>
              )}
            </td>
            <td>
              {f.surface ? (
                <Tag type="blue" size="sm">{f.surface}</Tag>
              ) : (
                <span className={styles.emptyCell}>—</span>
              )}
            </td>
            <td>
              {f.procedure ? (
                <Tag type="purple" size="sm">{f.procedure}</Tag>
              ) : (
                <span className={styles.emptyCell}>—</span>
              )}
            </td>
            <td>
              {f.notes ? (
                <span className={styles.notesText}>{f.notes}</span>
              ) : (
                <span className={styles.emptyCell}>—</span>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

// ---------------------------------------------------------------------------

interface EncounterCardProps {
  encounter: ParsedDentalEncounter;
  defaultOpen?: boolean;
}

const EncounterCard: React.FC<EncounterCardProps> = ({ encounter, defaultOpen = false }) => {
  const { t } = useTranslation();
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className={styles.encounterCard}>
      {/* Header – click to expand/collapse */}
      <div
        className={styles.encounterHeader}
        role="button"
        tabIndex={0}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setOpen((v) => !v);
          }
        }}
      >
        <div className={styles.encounterMeta}>
          <span className={styles.encounterDate}>
            {formatDatetime(encounter.encounterDatetime)}
          </span>
          <span className={styles.encounterSubtitle}>
            {encounter.visitDisplay}
            {encounter.locationDisplay ? ` · ${encounter.locationDisplay}` : ''}
          </span>
        </div>

        <span
          className={styles.encounterBadge}
          aria-label={t('findingCount', '{{n}} finding(s)', { n: encounter.findings.length })}
        >
          {encounter.findings.length}
        </span>

        <ChevronDown
          size={16}
          className={`${styles.chevron}${open ? ` ${styles.open}` : ''}`}
          aria-hidden="true"
        />
      </div>

      {/* Body – findings table */}
      {open && <FindingsTable findings={encounter.findings} />}
    </div>
  );
};

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

interface DentalObsProps {
  patientUuid: string;
}

const DentalObs: React.FC<DentalObsProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const config = useConfig<ConfigSchema>();
  const { concepts, encounterTypeUuid } = config;

  const { encounters, isLoading, error } = useDentalEncounters(
    patientUuid,
    encounterTypeUuid,
    {
      toothConceptUuid:           concepts.toothConceptUuid,
      findingTypeConceptSetUuid:  concepts.findingTypeConceptSetUuid,
      surfaceConceptSetUuid:      concepts.surfaceConceptSetUuid,
      procedureConceptSetUuid:    concepts.procedureConceptSetUuid,
      notesConceptUuid:           concepts.notesConceptUuid,
    },
  );

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>
          {t('dentalConsultations', 'Dental Consultations')}
        </h2>
      </div>

      {/* Loading */}
      {isLoading && (
        <InlineLoading description={t('loadingEncounters', 'Loading dental consultations…')} />
      )}

      {/* Error */}
      {!isLoading && error && (
        <InlineNotification
          kind="error"
          title={t('loadError', 'Could not load dental encounters')}
          subtitle={error.message}
          lowContrast
          hideCloseButton
        />
      )}

      {/* Empty state */}
      {!isLoading && !error && encounters.length === 0 && (
        <p className={styles.emptyState}>
          {t('noDentalEncounters', 'No dental consultations recorded yet.')}
        </p>
      )}

      {/* Encounter cards – most recent first (API returns desc order) */}
      {!isLoading && !error && encounters.map((enc, idx) => (
        <EncounterCard
          key={enc.uuid}
          encounter={enc}
          defaultOpen={idx === 0}
        />
      ))}
    </div>
  );
};

export default DentalObs;
