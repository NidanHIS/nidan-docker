import { type DashboardLinkConfig } from '@openmrs/esm-patient-common-lib';

export const summarydashboardMeta: DashboardLinkConfig & {slot:string} = {
  slot: 'patient-chart-summary-dashboard-slot',
  path: 'dental-chart',
  title: 'Dental Chart',
  icon: 'omrs-icon-report',
};

