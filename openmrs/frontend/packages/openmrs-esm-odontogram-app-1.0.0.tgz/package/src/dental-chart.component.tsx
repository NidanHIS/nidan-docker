/**
 * dental-chart.component.tsx
 *
 * Top-level page that hosts the interactive odontogram.
 *
 * Two rendering modes controlled by config.useO3Form:
 *
 *   false (default)
 *     Classic mode: odontogram left, FindingPanel + FindingsList right.
 *
 *   true  — O3-form mode
 *     1. Clinician clicks teeth to toggle them into a selection set (highlighted
 *        on the SVG with the existing findingDot indicator).
 *     2. A chip row shows the selected teeth with individual remove buttons.
 *     3. "Open form (n)" button mounts FormEngine once with
 *          preFilledQuestions: { toothNumber: [uuid, uuid, …] }
 *        (PreFilledQuestions allows Array<string> values).
 *     4. While the form is open, tooth clicks are ignored — preFilledQuestions
 *        is mount-time-only in form-engine-lib (missing from useEffect deps).
 *     5. Submit / cancel resets the selection so a new session can begin.
 */

import React, { useState, useCallback, useId } from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@openmrs/esm-framework';
import { Button, InlineLoading, InlineNotification, Tag, Tile } from '@carbon/react';
import { FormEngine } from '@openmrs/esm-form-engine-lib';

import { Odontogram, DentitionSelector } from './odontogram/index';
import type { DentitionType } from './odontogram';
import {
  useSurfaces,
  useFindingTypes,
  useProcedures,
  buildToothUuidByFdiMap,
  toEncounterObs,
  createEncounterWithFindings,
} from './odontogram/odontogram.resource';
import FindingPanel from './odontogram/finding-panel.component';
import FindingsList from './odontogram/findings-list.component';
import { ALL_TEETH_BY_FDI } from './odontogram/tooth-data';
import type { DentalObservationGroup, FindingDraft } from './odontogram/types';
import type { ConfigSchema } from './config-schema';

import styles from './nidan-component.scss';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface DentalChartProps {
  patientUuid?: string;
  visitUuid?: string;
  encounterUuid?: string;
  closeWorkspace?: (opts?: { discardUnsavedChanges?: boolean; closeWindow?: boolean }) => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

const DentalChart: React.FC<DentalChartProps> = ({
  patientUuid: propPatientUuid,
  visitUuid: propVisitUuid,
  encounterUuid: propEncounterUuid,
  closeWorkspace,
}) => {
  const { t } = useTranslation();
  const instanceId = useId();
  const config = useConfig<ConfigSchema>();
  const { concepts, permanentTeeth, primaryTeeth, encounterTypeUuid, useO3Form, formUuid } = config;

  // Build FDI → concept UUID map from config (replaces static constants.ts lookup)
  const toothUuidByFdi = React.useMemo(
    () => buildToothUuidByFdiMap(permanentTeeth, primaryTeeth),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    // Config is stable across renders; stringify guards against object-identity churn.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [JSON.stringify(permanentTeeth), JSON.stringify(primaryTeeth)],
  );

  /** Converts a bare FDI number into the full tooth reference shape used in DentalObservationGroup. */
  const toothConceptRef = useCallback(
    (fdi: number): DentalObservationGroup['tooth'] => {
      const datum = ALL_TEETH_BY_FDI.get(fdi);
      const uuid = toothUuidByFdi.get(fdi) ?? fdi.toString();
      return { fdi, uuid, display: datum?.name ?? `Tooth ${fdi}` };
    },
    [toothUuidByFdi],
  );

  // ── Shared state ──────────────────────────────────────────────────────────
  const [dentitionMode, setDentitionMode] = useState<DentitionType>('permanent');

  // Classic mode: single selected tooth drives the panel
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);

  // O3-form mode: set of FDI numbers toggled by the clinician
  const [selectedTeeth, setSelectedTeeth] = useState<Set<number>>(new Set());
  // true once "Open Form" has been clicked — FormEngine is mounted
  const [formOpen, setFormOpen] = useState(false);
  // incrementing key forces a clean FormEngine remount on each new session
  const [formKey, setFormKey] = useState(0);

  // ── Classic-mode state ────────────────────────────────────────────────────
  const [findings, setFindings] = useState<DentalObservationGroup[]>([]);
  const [editingGroup, setEditingGroup] = useState<DentalObservationGroup | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<Error | undefined>();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<Error | undefined>();
  const [savedEncounterUuid, setSavedEncounterUuid] = useState<string | null>(null);

  // ── Concept sets (classic mode only; skipped when useO3Form is true) ──────
  const { members: surfaces, isLoading: surfacesLoading, error: surfacesError } =
    useSurfaces(useO3Form ? '' : concepts.surfaceConceptSetUuid);
  const { members: findingTypes, isLoading: findingTypesLoading, error: findingTypesError } =
    useFindingTypes(useO3Form ? '' : concepts.findingTypeConceptSetUuid);
  const { members: procedures, isLoading: proceduresLoading, error: proceduresError } =
    useProcedures(useO3Form ? '' : concepts.procedureConceptSetUuid);
  const conceptsLoading = surfacesLoading || findingTypesLoading || proceduresLoading;
  const conceptError = surfacesError ?? findingTypesError ?? proceduresError;

  // ── Handlers ──────────────────────────────────────────────────────────────

  const handleModeChange = useCallback((mode: DentitionType) => {
    setDentitionMode(mode);
    setSelectedTooth(null);
    setEditingGroup(null);
    // reset O3-form selection too
    setSelectedTeeth(new Set());
    setFormOpen(false);
  }, []);

  // Classic mode: single-tooth selection
  const handleToothSelectClassic = useCallback((fdi: number | null) => {
    setSelectedTooth(fdi);
    setEditingGroup(null);
    setSaveError(undefined);
  }, []);

  // O3-form mode: toggle tooth in/out of the selection set.
  // When the form is already open, additional clicks are ignored because
  // preFilledQuestions cannot be updated on a mounted FormEngine.
  const handleToothSelectO3 = useCallback((fdi: number | null) => {
    if (!fdi || formOpen) return;
    setSelectedTeeth((prev) => {
      const next = new Set(prev);
      if (next.has(fdi)) next.delete(fdi);
      else next.add(fdi);
      return next;
    });
  }, [formOpen]);

  const handleToothSelect = useO3Form ? handleToothSelectO3 : handleToothSelectClassic;

  // O3-form mode: mount the form with the current selection
  const handleOpenForm = useCallback(() => {
    if (selectedTeeth.size === 0) return;
    setFormOpen(true);
    setFormKey((k) => k + 1);
  }, [selectedTeeth]);

  // O3-form mode: close/reset so a new selection can begin
  const handleFormClose = useCallback(() => {
    setFormOpen(false);
    setSelectedTeeth(new Set());
    closeWorkspace?.({ discardUnsavedChanges: true });
  }, [closeWorkspace]);

  const handleFormSubmit = useCallback(() => {
    setFormOpen(false);
    setSelectedTeeth(new Set());
    closeWorkspace?.({ discardUnsavedChanges: false });
  }, [closeWorkspace]);

  // Classic mode only
  const handleEdit = useCallback((group: DentalObservationGroup) => {
    setSelectedTooth(group.tooth.fdi);
    setEditingGroup(group);
    setSaveError(undefined);
  }, []);

  const handleDelete = useCallback((id: string) => {
    setDeletingId(id);
    setTimeout(() => {
      setFindings((prev) => prev.filter((g) => g.id !== id));
      setDeletingId(null);
    }, 0);
  }, []);

  const handleCancel = useCallback(() => {
    setSelectedTooth(null);
    setEditingGroup(null);
    setSaveError(undefined);
  }, []);

  const handleSubmitEncounter = useCallback(async () => {
    if (findings.length === 0) return;
    setIsSubmitting(true);
    setSubmitError(undefined);
    setSavedEncounterUuid(null);
    try {
      const obsPayloads = toEncounterObs(findings, {
        surfaceConceptSetUuid:     concepts.surfaceConceptSetUuid,
        findingTypeConceptSetUuid: concepts.findingTypeConceptSetUuid,
        procedureConceptSetUuid:   concepts.procedureConceptSetUuid,
        notesConceptUuid:          concepts.notesConceptUuid,
        toothConceptUuid:          concepts.toothConceptUuid,
        findingGroupConceptUuid:   concepts.findingGroupConceptUuid,
      });
      const result = await createEncounterWithFindings({
        patient:           propPatientUuid ?? '',
        visit:             propVisitUuid   ?? '',
        encounterType:     encounterTypeUuid,
        encounterDatetime: new Date().toISOString(),
        obs:               obsPayloads,
      });
      setSavedEncounterUuid(result.uuid);
      setFindings([]);
      if (closeWorkspace) {
        setTimeout(() => closeWorkspace({ discardUnsavedChanges: true }), 1500);
      }
    } catch (err) {
      setSubmitError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setIsSubmitting(false);
    }
  }, [findings, concepts, encounterTypeUuid, propPatientUuid, propVisitUuid, closeWorkspace]);

  const handleSave = useCallback(
    async (draft: FindingDraft) => {
      setIsSaving(true);
      setSaveError(undefined);
      try {
        const surfaceMember   = surfaces.find((s) => s.uuid === draft.surfaceUuid);
        const findingMember   = findingTypes.find((f) => f.uuid === draft.findingTypeUuid);
        const procedureMember = procedures.find((p) => p.uuid === draft.procedureUuid);
        if (!findingMember) throw new Error('Finding type is required');

        const newGroup: DentalObservationGroup = {
          id: editingGroup?.id ?? `${instanceId}-${draft.fdi}-${Date.now()}`,
          tooth: toothConceptRef(draft.fdi),
          surface:   surfaceMember   ? { uuid: surfaceMember.uuid,   display: surfaceMember.display   } : undefined,
          procedure: procedureMember ? { uuid: procedureMember.uuid, display: procedureMember.display } : undefined,
          findingType: { uuid: findingMember.uuid, display: findingMember.display },
          notes: draft.notes || undefined,
          obsGroupUuid: editingGroup?.obsGroupUuid,
        };

        setFindings((prev) => {
          if (editingGroup) return prev.map((g) => (g.id === editingGroup.id ? newGroup : g));
          const existing = prev.findIndex((g) => g.tooth.fdi === draft.fdi);
          if (existing !== -1) {
            const updated = [...prev];
            updated[existing] = newGroup;
            return updated;
          }
          return [...prev, newGroup];
        });
        setSelectedTooth(null);
        setEditingGroup(null);
      } catch (err) {
        setSaveError(err instanceof Error ? err : new Error(String(err)));
      } finally {
        setIsSaving(false);
      }
    },
    [surfaces, findingTypes, procedures, editingGroup, instanceId],
  );

  // ── Derived ───────────────────────────────────────────────────────────────

  // Classic mode
  const teethWithFindings = new Set(findings.map((g) => g.tooth.fdi));

  const initialValues: Partial<FindingDraft> | undefined = editingGroup
    ? {
        fdi:             editingGroup.tooth.fdi,
        surfaceUuid:     editingGroup.surface?.uuid   ?? '',
        procedureUuid:   editingGroup.procedure?.uuid ?? '',
        findingTypeUuid: editingGroup.findingType.uuid,
        notes:           editingGroup.notes           ?? '',
      }
    : undefined;

  const panelFdi       = selectedTooth;
  const panelToothName = panelFdi ? (ALL_TEETH_BY_FDI.get(panelFdi)?.name ?? `Tooth ${panelFdi}`) : '';

  // O3-form mode: array of concept UUIDs for all selected teeth
  const selectedTeethArray  = Array.from(selectedTeeth);
  const selectedToothUuids  = selectedTeethArray.map((fdi) => toothUuidByFdi.get(fdi) ?? String(fdi));
  // PreFilledQuestions type allows Array<string> values
  const preFilledQuestions  = selectedToothUuids.length > 0
    ? { toothNumber: selectedToothUuids }
    : undefined;

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className={styles.container}>
      <Tile className={styles.tile}>
        {/* Dentition mode toggle */}
        <div className={styles.selectorRow}>
          <DentitionSelector value={dentitionMode} onChange={handleModeChange} />
        </div>

        {/* Two-column layout */}
        <div className={styles.chartLayout}>

          {/* LEFT: SVG odontogram (always visible) */}
          <div className={styles.chartCol}>
            <Odontogram
              dentitionMode={dentitionMode}
              // In O3-form mode no "single selected" highlight — use teethWithFindings
              // to light up the multi-selection set instead
              selectedTooth={useO3Form ? null : panelFdi}
              onToothSelect={handleToothSelect}
              teethWithFindings={useO3Form ? selectedTeeth : teethWithFindings}
            />
          </div>

          {/* RIGHT panel */}
          <div className={styles.panelCol}>

            {/* ── O3-form mode ── */}
            {useO3Form && formUuid ? (
              <>
                {/* Selection phase */}
                {!formOpen && (
                  <>
                    {selectedTeeth.size === 0 ? (
                      <p className={styles.emptyPrompt}>
                        {t('selectTeethPrompt', 'Click one or more teeth on the chart, then open the form.')}
                      </p>
                    ) : (
                      <div className={styles.selectionSummary}>
                        <p className={styles.selectionLabel}>
                          {t('selectedTeeth', 'Selected teeth')}
                        </p>
                        <div className={styles.selectionTags}>
                          {selectedTeethArray.map((fdi) => (
                            <Tag
                              key={fdi}
                              type="teal"
                              size="sm"
                              filter
                              onClose={() =>
                                setSelectedTeeth((prev) => {
                                  const next = new Set(prev);
                                  next.delete(fdi);
                                  return next;
                                })
                              }
                            >
                              {ALL_TEETH_BY_FDI.get(fdi)?.name ?? `Tooth ${fdi}`}
                            </Tag>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className={styles.submitBtn}>
                      <Button
                        kind="primary"
                        onClick={handleOpenForm}
                        disabled={selectedTeeth.size === 0 || !propPatientUuid}
                      >
                        {t('openForm', 'Open form ({{n}})', { n: selectedTeeth.size })}
                      </Button>
                    </div>
                  </>
                )}

                {/* Form — mounted once when "Open Form" is clicked.
                    key={formKey} forces a clean remount on each new session. */}
                {formOpen && propPatientUuid && (
                  <div className={styles.formWrapper}>
                    <FormEngine
                      key={formKey}
                      patientUUID={propPatientUuid}
                      formUUID={formUuid}
                      encounterUUID={propEncounterUuid}
                      visit={propVisitUuid ? ({ uuid: propVisitUuid } as any) : undefined}
                      mode={propEncounterUuid ? 'edit' : 'enter'}
                      preFilledQuestions={preFilledQuestions}
                      onSubmit={handleFormSubmit}
                      onCancel={handleFormClose}
                      handleClose={handleFormClose}
                      hidePatientBanner
                    />
                  </div>
                )}
              </>
            ) : (

              /* ── Classic mode ── */
              <>
                {conceptsLoading && !panelFdi && (
                  <InlineLoading description={t('loadingOptions', 'Loading options…')} />
                )}

                {!panelFdi && !conceptsLoading && findings.length === 0 && (
                  <p className={styles.emptyPrompt}>
                    {t('selectToothPrompt', 'Click a tooth on the chart to record a finding.')}
                  </p>
                )}

                {panelFdi !== null && (
                  <FindingPanel
                    fdi={panelFdi}
                    toothName={panelToothName}
                    surfaces={surfaces}
                    findingTypes={findingTypes}
                    procedures={procedures}
                    isLoading={conceptsLoading}
                    conceptError={conceptError}
                    initialValues={initialValues}
                    isSaving={isSaving}
                    saveError={saveError}
                    onSave={handleSave}
                    onCancel={handleCancel}
                  />
                )}

                <FindingsList
                  findings={findings}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  deletingId={deletingId}
                />

                {findings.length > 0 && (
                  <div className={styles.submitArea}>
                    {submitError && (
                      <InlineNotification
                        kind="error"
                        title={t('encounterSaveError', 'Encounter save failed')}
                        subtitle={submitError.message}
                        lowContrast
                        onCloseButtonClick={() => setSubmitError(undefined)}
                      />
                    )}
                    {savedEncounterUuid && (
                      <InlineNotification
                        kind="success"
                        title={t('encounterSaved', 'Encounter saved')}
                        subtitle={t('encounterUuid', 'UUID: {{uuid}}', { uuid: savedEncounterUuid })}
                        lowContrast
                        onCloseButtonClick={() => setSavedEncounterUuid(null)}
                      />
                    )}
                    <div className={styles.submitBtn}>
                      <Button
                        kind="primary"
                        onClick={handleSubmitEncounter}
                        disabled={isSubmitting || findings.length === 0}
                      >
                        {isSubmitting
                          ? <InlineLoading description={t('submittingEncounter', 'Saving encounter…')} />
                          : t('saveEncounter', 'Save to encounter ({{n}})', { n: findings.length })}
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </Tile>
    </div>
  );
};

export default DentalChart;
