import React from 'react';
import { externalAppUrls } from '../../external-app-urls';
import './odoo-dashboard-link.scss';

const PharmacyDashboardLink = () => {
    return (
        <a href={externalAppUrls.pharmacy} className="billingMenuItem">
            <span className="billingMenuContent">
                <span>Billing</span>
            </span>
        </a>
    );
};

export default PharmacyDashboardLink;
