import React from 'react';
import { externalAppUrls } from '../../external-app-urls';
import './orthanc-dashboard-link.scss';

const OrthancDashboardLink = () => {
    return (
        <a href={externalAppUrls.orthanc} className="orthancMenuItem">
            <span className="orthancMenuContent">
                <span>Radiology</span>
            </span>
        </a>
    );
};

export default OrthancDashboardLink;
