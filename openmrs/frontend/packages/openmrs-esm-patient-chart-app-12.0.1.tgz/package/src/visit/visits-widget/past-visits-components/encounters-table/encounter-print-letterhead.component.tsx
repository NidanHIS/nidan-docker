import React from 'react';
import logo from '../../../../logo.png';
import { type ChartConfig } from '../../../../config-schema';
import styles from './encounter-print-template.scss';

interface EncounterPrintLetterheadProps {
  config: ChartConfig;
}

const EncounterPrintLetterhead: React.FC<EncounterPrintLetterheadProps> = ({ config }) => {
  const {
    hospitalName,
    hospitalAddress,
    hospitalContactInfo,
    hospitalLetterheadTopLines,
    hospitalLetterheadBottomLines,
  } = config;

  return (
    <div className={styles.letterhead}>
      <img src={logo} alt="Hospital Logo" className={styles.logo} />
      <div className={styles.hospitalDetails}>
        {hospitalLetterheadTopLines?.map((line, i) => (
          <p key={i} className={styles.topLine}>
            {line}
          </p>
        ))}
        <h2 className={styles.hospitalName}>{hospitalName}</h2>
        {hospitalLetterheadBottomLines?.map((line, i) => (
          <p key={i} className={styles.bottomLine}>
            {line}
          </p>
        ))}
        <p className={styles.address}>{hospitalAddress}</p>
        <p className={styles.contact}>{hospitalContactInfo}</p>
      </div>
      <div />
    </div>
  );
};

export default EncounterPrintLetterhead;
