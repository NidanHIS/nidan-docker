import React from 'react';
import { useTranslation } from 'react-i18next';
import { type Obs, useConfig, DocumentIcon } from '@openmrs/esm-framework';
import styles from './styles.scss';

interface EncounterObservationsProps {
  observations: Array<Obs>;
  formName?: string;
}

const EncounterObservations: React.FC<EncounterObservationsProps> = ({ observations, formName }) => {
  const { t } = useTranslation();
  const { obsConceptUuidsToHide = [] } = useConfig();

  function getAnswerFromDisplay(display: string): string {
    const colonIndex = display.indexOf(':');
    if (colonIndex === -1) {
      return display;
    } else {
      return display.substring(colonIndex + 1).trim();
    }
  }

  const filteredObservations = !!obsConceptUuidsToHide.length
    ? observations?.filter((obs) => {
        return !obsConceptUuidsToHide.includes(obs?.concept?.uuid);
      })
    : observations;

  if (!filteredObservations || filteredObservations.length === 0) {
    return (
      <div className={styles.noObservations}>
        <p>{t('noObservationsFound', 'No observations found')}</p>
      </div>
    );
  }

  return (
    <div className={styles.observationContainer}>
      {formName && (
        <div className={styles.observationHeader}>
          <DocumentIcon size={18} className={styles.headerIcon} />
          <span className={styles.headerTitle}>{formName}</span>
        </div>
      )}
      <div className={styles.observationContent}>
        {filteredObservations?.map((obs, index) => {
          if (obs.groupMembers) {
            return (
              <React.Fragment key={index}>
                <div className={styles.parentConcept}>{obs.concept.display}</div>
                {obs.groupMembers.map((member, mIndex) => (
                  <div key={mIndex} className={styles.childConceptRow}>
                    <div className={styles.conceptName}>{member.concept.display}</div>
                    <div className={styles.value}>{getAnswerFromDisplay(member.display)}</div>
                  </div>
                ))}
              </React.Fragment>
            );
          } else {
            return (
              <div key={index} className={styles.observationRow}>
                <div className={styles.conceptName}>{obs.concept.display}</div>
                <div className={styles.value}>{getAnswerFromDisplay(obs.display)}</div>
              </div>
            );
          }
        })}
      </div>
    </div>
  );
};

export default EncounterObservations;
