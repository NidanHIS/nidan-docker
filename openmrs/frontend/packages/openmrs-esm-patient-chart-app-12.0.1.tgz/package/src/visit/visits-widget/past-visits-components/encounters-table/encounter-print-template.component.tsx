import React, { forwardRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ExtensionSlot, getPatientName, age } from '@openmrs/esm-framework';
import { type MappedEncounter } from './encounters-table.resource';
import { type ChartConfig } from '../../../../config-schema';
import logo from '../../../../logo.png';
import EncounterObservations from '../../encounter-observations';
import styles from './encounter-print-template.scss';

interface EncounterPrintTemplateProps {
  encounter: MappedEncounter;
  patient: any;
  config: ChartConfig;
  enableEmbeddedFormView: boolean;
  supportsEmbeddedFormView: (encounter: MappedEncounter) => boolean;
  patientUuid: string;
  printedBy?: string;
}

const EncounterPrintTemplate = forwardRef<HTMLDivElement, EncounterPrintTemplateProps>(
  ({ encounter, patient, config, enableEmbeddedFormView, supportsEmbeddedFormView, patientUuid, printedBy }, ref) => {
    const { t } = useTranslation();
    const {
      hospitalName,
      hospitalAddress,
      hospitalContactInfo,
      hospitalLetterheadTopLines,
      hospitalLetterheadBottomLines,
    } = config;

    return (
      <div ref={ref}>
        <div className={styles.printContainer}>
          {/* Fixed footer for printing */}
          <div className={styles.fixedFooter}>
            <div className={styles.footerContent}>
              <p>
                {t('printedOn', 'Printed on')}: {new Date().toLocaleString()} {t('printedBy', 'by')} {printedBy}
              </p>
            </div>
          </div>

          <table className={styles.printTable}>
            <thead className={styles.tableHeader}>
              <tr>
                <td className={styles.headerCell}>
                  <div className={styles.letterhead}>
                    <img src={logo} alt="Hospital Logo" className={styles.logo} />
                    <div className={styles.hospitalDetails}>
                      {hospitalLetterheadTopLines?.map((line, i) => (
                        <p key={i} className={styles.topLine}>
                          {line}
                        </p>
                      ))}
                      <h2 className={styles.hospitalName}>{hospitalName}</h2>
                      {hospitalLetterheadBottomLines?.map((line, i) => (
                        <p key={i} className={styles.bottomLine}>
                          {line}
                        </p>
                      ))}
                      <p className={styles.address}>{hospitalAddress}</p>
                      <p className={styles.contact}>{hospitalContactInfo}</p>
                    </div>
                    <div />
                  </div>
                </td>
              </tr>
            </thead>
            <tbody className={styles.tableBody}>
              <tr>
                <td>
                  <div className={styles.patientDetails}>
                    <p className={styles.large}>
                      <strong>{t('patient', 'Patient')}:</strong> {getPatientName(patient)}
                    </p>
                    <p className={styles.medium}>
                      <strong>{t('gender', 'Gender')}:</strong> {patient?.gender || '--'}
                    </p>
                    <p className={styles.fill}>
                      <strong>{t('age', 'Age')}:</strong> {age(patient?.birthDate) || '--'}
                    </p>
                    <p className={styles.large}>
                      <strong>{t('patientId', 'Patient ID')}:</strong> {patient?.identifier?.[0]?.value || '--'}
                    </p>
                    <p className={styles.large}>
                      <strong>{t('date', 'Date')}:</strong> {encounter.datetime}
                    </p>
                  </div>
                  {enableEmbeddedFormView && supportsEmbeddedFormView(encounter) ? (
                    <ExtensionSlot
                      name="form-widget-slot"
                      state={{
                        additionalProps: { mode: 'embedded-view' },
                        visitUuid: encounter.visitUuid ?? null,
                        visitTypeUuid: encounter.visitTypeUuid ?? null,
                        visitStartDatetime: encounter.visitStartDatetime ?? null,
                        visitStopDatetime: encounter.visitStopDatetime ?? null,
                        patientUuid: patientUuid,
                        patient: patient,
                        formUuid: encounter.form.uuid,
                        encounterUuid: encounter.id,
                        promptBeforeClosing: () => { },
                      }}
                    />
                  ) : (
                    <EncounterObservations observations={encounter.obs} formName={encounter.formName} />
                  )}
                </td>
              </tr>
            </tbody>
            <tfoot className={styles.tableFooter}>
              <tr>
                <td>
                  {/* Spacer for fixed footer */}
                  <div className={styles.footerSpacer} />
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    );
  },
);

EncounterPrintTemplate.displayName = 'EncounterPrintTemplate';

export default EncounterPrintTemplate;
