import React, { useCallback, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button, OverflowMenu, OverflowMenuItem, SkeletonText } from '@carbon/react';
import { Add, ChevronDown, ChevronUp, Document, Pin } from '@carbon/react/icons';
import { launchWorkspace2, useConfig } from '@openmrs/esm-framework';
import type { FormEntryConfigSchema } from '../config-schema';
import type { FormFavorite } from './form-favorites.resource';
import { useFormFavoritesActions } from './useFormFavoritesActions';
import styles from './pinned-forms-widget.scss';

// Maximum number of favorites shown as inline buttons before the rest
// collapse into the overflow "More forms" menu.
const VISIBLE_BUTTON_LIMIT = 6;

interface PinnedFormsWidgetProps {
  patientUuid: string;
}

const PinnedFormsWidget: React.FC<PinnedFormsWidgetProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const { enableFormFavorites } = useConfig<FormEntryConfigSchema>();
  const { favorites, isLoading } = useFormFavoritesActions();
  const [overflowOpen, setOverflowOpen] = useState(false);

  const visibleFavorites = useMemo(() => favorites.slice(0, VISIBLE_BUTTON_LIMIT), [favorites]);
  const overflowFavorites = useMemo(() => favorites.slice(VISIBLE_BUTTON_LIMIT), [favorites]);
  const hasOverflow = overflowFavorites.length > 0;

  const openForm = useCallback((favorite: FormFavorite) => {
    launchWorkspace2('patient-form-entry-workspace', {
      form: {
        uuid: favorite.formUuid,
        name: favorite.displayName,
        display: favorite.displayName,
        version: '',
        published: true,
        retired: false,
        resources: [],
      },
      encounterUuid: '',
    });
  }, []);

  const openAllForms = useCallback(() => {
    launchWorkspace2('clinical-forms-workspace');
  }, []);

  if (!enableFormFavorites) {
    return null;
  }

  if (isLoading) {
    return (
      <div className={styles.container}>
        <SkeletonText className={styles.skeleton} width="320px" />
      </div>
    );
  }

  if (favorites.length === 0) {
    return null;
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <Pin size={16} className={styles.pinIcon} />
        <span className={styles.title}>{t('pinnedForms', 'Pinned forms')}</span>
        <span className={styles.subtitle}>{t('pinnedFormsSubtitle', 'Quick access to your most used forms')}</span>
      </div>

      <div className={styles.buttonRow}>
        {visibleFavorites.map((favorite) => (
          <Button
            key={favorite.id}
            kind="tertiary"
            size="sm"
            renderIcon={Document}
            iconDescription={favorite.displayName}
            className={styles.formButton}
            onClick={() => openForm(favorite)}
          >
            {favorite.displayName}
          </Button>
        ))}

        {hasOverflow && (
          <OverflowMenu
            className={styles.overflowMenu}
            renderIcon={() => (
              <span className={styles.overflowTrigger}>
                <Add size={16} />
                {t('moreForms', 'More forms')}
                {overflowOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </span>
            )}
            // renderIcon={Add}
            // renderIcon={() => <Add size={16} />}
            iconDescription={t('moreForms', 'More forms')}
            flipped
            size="sm"
            onOpen={() => setOverflowOpen(true)}
            onClose={() => setOverflowOpen(false)}
          >
            {overflowFavorites.map((favorite) => (
              <OverflowMenuItem
                key={favorite.id}
                itemText={favorite.displayName}
                onClick={() => openForm(favorite)}
              />
            ))}
            <OverflowMenuItem
              itemText={t('allForms', 'All forms')}
              onClick={openAllForms}
              hasDivider
            />
          </OverflowMenu>
        )}

        {!hasOverflow && (
          <Button
            kind="ghost"
            size="sm"
            renderIcon={Add}
            iconDescription={t('moreForms', 'More forms')}
            className={styles.allFormsButton}
            onClick={openAllForms}
          >
            {t('moreForms', 'More forms')}
          </Button>
        )}
      </div>
    </div>
  );
};

export default PinnedFormsWidget;
