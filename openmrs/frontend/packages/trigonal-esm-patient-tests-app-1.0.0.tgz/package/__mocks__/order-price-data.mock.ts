export interface OrderPriceData {
  resourceType: string;
  id: string;
  meta: {
    lastUpdated: string;
  };
  type: string;
  link: {
    relation: string;
    url: string;
  }[];
  entry: {
    resource: {
      resourceType: string;
      id: string;
      name: string;
      status: string;
      date: string;
      propertyGroup: {
        priceComponent: {
          type: string;
          amount: {
            value: number;
            currency: string;
          };
        }[];
      }[];
    };
  }[];
}

export const mockOrderPriceData: OrderPriceData = {
  resourceType: 'Bundle',
  id: 'test-id',
  meta: {
    lastUpdated: '2024-01-01T00:00:00Z',
  },
  type: 'searchset',
  link: [
    {
      relation: 'self',
      url: 'test-url',
    },
  ],
  entry: [
    {
      resource: {
        resourceType: 'ChargeItemDefinition',
        id: 'test-resource-id',
        name: 'Test Item',
        status: 'active',
        date: '2024-01-01',
        propertyGroup: [
          {
            priceComponent: [
              {
                type: 'base',
                amount: {
                  value: 99.99,
                  currency: 'USD',
                },
              },
            ],
          },
        ],
      },
    },
  ],
};
