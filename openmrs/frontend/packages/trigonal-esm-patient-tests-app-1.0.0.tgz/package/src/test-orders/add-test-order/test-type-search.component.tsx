import React, { type ComponentProps, useCallback, useMemo, useRef, useState } from 'react';
import classNames from 'classnames';
import { useTranslation } from 'react-i18next';
import { Button, ButtonSkeleton, Search, Select, SelectItem, SkeletonText, Tag, TextArea, Tile } from '@carbon/react';
import { ShoppingCartArrowUp, Information } from '@carbon/react/icons';
import {
  ArrowRightIcon,
  OpenmrsDatePicker,
  ResponsiveWrapper,
  ShoppingCartArrowDownIcon,
  useDebounce,
  useLayoutType,
  useSession,
  useWorkspace2Context,
  type Visit,
  type Workspace2DefinitionProps,
} from '@openmrs/esm-framework';
import { useOrderBasket, type TestOrderBasketItem, priorityOptions, type OrderUrgency } from '@openmrs/esm-patient-common-lib';
import { prepTestOrderPostData } from '../api';
import { createEmptyLabOrder } from './test-order';
import { useTestTypes, type TestType } from './useTestTypes';
import styles from './test-type-search.scss';

export interface TestTypeSearchProps {
  openLabForm: (searchResult: TestOrderBasketItem) => void;
  orderTypeUuid: string;
  orderableConceptSets: Array<string>;
  closeWorkspace: Workspace2DefinitionProps['closeWorkspace'];
  patient: fhir.Patient;
  visit: Visit;
}

interface TestTypeSearchResultsProps extends TestTypeSearchProps {
  searchTerm: string;
  focusAndClearSearchInput: () => void;
  patient: fhir.Patient;
}

interface TestTypeSearchResultItemProps {
  orderTypeUuid: string;
  testType: TestType;
  openOrderForm: (searchResult: TestOrderBasketItem) => void;
  patient: fhir.Patient;
  visit: Visit;
  closeWorkspace: Workspace2DefinitionProps['closeWorkspace'];
  selectedUrgency: OrderUrgency;
  scheduledDate: Date | null;
  instructions: string;
}

export function TestTypeSearch({
  patient,
  visit,
  openLabForm,
  orderTypeUuid,
  orderableConceptSets,
  closeWorkspace,
}: TestTypeSearchProps) {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm);
  const searchInputRef = useRef(null);
  const abc = useWorkspace2Context();
  console.log('context', abc);

  const focusAndClearSearchInput = useCallback(() => {
    setSearchTerm('');
    searchInputRef.current?.focus();
  }, [setSearchTerm]);

  const handleSearchTermChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(event.target.value ?? '');
    },
    [setSearchTerm],
  );

  return (
    <>
      <ResponsiveWrapper>
        <Search
          autoFocus
          labelText={t('searchFieldPlaceholder', 'Search for a test type')}
          onChange={handleSearchTermChange}
          placeholder={t('searchFieldPlaceholder', 'Search for a test type')}
          ref={searchInputRef}
          size="lg"
          value={searchTerm}
        />
      </ResponsiveWrapper>
      <TestTypeSearchResults
        closeWorkspace={closeWorkspace}
        orderTypeUuid={orderTypeUuid}
        orderableConceptSets={orderableConceptSets}
        focusAndClearSearchInput={focusAndClearSearchInput}
        openLabForm={openLabForm}
        searchTerm={debouncedSearchTerm}
        patient={patient}
        visit={visit}
      />
    </>
  );
}

function TestTypeSearchResults({
  closeWorkspace,
  searchTerm,
  orderTypeUuid,
  orderableConceptSets,
  openLabForm,
  focusAndClearSearchInput,
  patient,
  visit,
}: TestTypeSearchResultsProps) {
  const { t } = useTranslation();
  const isTablet = useLayoutType() === 'tablet';
  const [selectedUrgency, setSelectedUrgency] = useState<OrderUrgency>(priorityOptions[0].value as OrderUrgency);
  const [scheduledDate, setScheduledDate] = useState<Date | null>(null);
  const [instructions, setInstructions] = useState('');
  const { orders, setOrders } = useOrderBasket<TestOrderBasketItem>(patient, orderTypeUuid, prepTestOrderPostData);
  const { testTypes, isLoading, error } = useTestTypes(searchTerm, orderableConceptSets);

  const removeOrder = useCallback(
    (orderToRemove: TestOrderBasketItem) => {
      setOrders(orders.filter((order) => order.testType.conceptUuid !== orderToRemove.testType.conceptUuid));
    },
    [orders, setOrders],
  );

  const handleUrgencyChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value as OrderUrgency;
    if (value !== 'ON_SCHEDULED_DATE') {
      setScheduledDate(null);
    }
    setSelectedUrgency(value);
  }, []);

  if (isLoading) {
    return <TestTypeSearchSkeleton />;
  }

  if (error) {
    return (
      <Tile className={styles.emptyState}>
        <div>
          <h4 className={styles.heading}>
            {t('errorFetchingTestTypes', 'Error fetching results for "{{searchTerm}}"', {
              searchTerm,
            })}
          </h4>
          <p className={styles.bodyShort01}>
            <span>{t('trySearchingAgain', 'Please try searching again')}</span>
          </p>
        </div>
      </Tile>
    );
  }

  if (testTypes?.length) {
    return (
      <>
        <div className={styles.resultsWrapper}>
          <div className={styles.container}>
            {orders.length > 0 && (
              <div className={styles.selectedTestsSection}>
                <p className={styles.selectedTestsHeading}>
                  {t('selectedTestsCount', 'Selected tests ({{count}})', { count: orders.length })}
                </p>
                <div className={styles.selectedTestsTags}>
                  {orders.map((order) => (
                    <Tag
                      key={order.testType.conceptUuid}
                      type="blue"
                      size="md"
                      filter
                      onClose={() => removeOrder(order)}
                    >
                      {order.display || order.testType?.label}
                    </Tag>
                  ))}
                </div>
              </div>
            )}
            <div className={styles.defaultsSection}>
              <div className={styles.defaultsHeader}>
                <p className={styles.defaultsTitle}>
                  {t('defaultForNextSelections', 'Default for next selections')}
                  <Information size={16} className={styles.infoIcon} />
                </p>
                <p className={styles.defaultsHelperText}>
                  {t('defaultForNextSelectionsHelper', 'These settings will be applied to tests you select from now on.')}
                </p>
              </div>
              <div className={styles.defaultsGrid}>
                <div className={styles.priorityWrapper}>
                  <Select
                    id="bulkUrgencySelect"
                    labelText={t('priority', 'Priority')}
                    value={selectedUrgency}
                    onChange={handleUrgencyChange}
                    size={isTablet ? 'md' : 'sm'}
                  >
                    {priorityOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value} text={option.label} />
                    ))}
                  </Select>
                  {selectedUrgency === 'ON_SCHEDULED_DATE' && (
                    <div className={styles.datePickerWrapper}>
                      <OpenmrsDatePicker
                        id="bulkScheduledDate"
                        labelText={t('scheduledDate', 'Scheduled date')}
                        value={scheduledDate}
                        onChange={(date: Date) => setScheduledDate(date)}
                        minDate={new Date()}
                        size={isTablet ? 'md' : 'sm'}
                      />
                    </div>
                  )}
                </div>
                <div className={styles.instructionsWrapper}>
                  <TextArea
                    enableCounter
                    id="bulkAdditionalInstructions"
                    labelText={t('additionalInstructionsOptional', 'Additional instructions (optional)')}
                    placeholder={t('instructionsPlaceholder', 'Enter instructions for newly selected tests...')}
                    maxCount={500}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInstructions(e.target.value)}
                    value={instructions}
                    rows={2}
                  />
                </div>
              </div>
            </div>
            <div className={styles.orderBasketSearchResultsHeader}>
              {searchTerm && (
                <span className={styles.searchResultsCount}>
                  {t('searchResultsMatchesForTerm', '{{count}} results for "{{searchTerm}}"', {
                    count: testTypes?.length,
                    searchTerm,
                  })}
                </span>
              )}

              <div className={styles.headerActions}>
                {searchTerm && (
                  <Button kind="ghost" onClick={focusAndClearSearchInput} size={isTablet ? 'md' : 'sm'}>
                    {t('clearSearchResults', 'Clear results')}
                  </Button>
                )}
              </div>
            </div>
            <div className={styles.resultsContainer}>
              {testTypes.map((testType) => (
                <TestTypeSearchResultItem
                  key={testType.conceptUuid}
                  orderTypeUuid={orderTypeUuid}
                  openOrderForm={openLabForm}
                  testType={testType}
                  closeWorkspace={closeWorkspace}
                  patient={patient}
                  visit={visit}
                  selectedUrgency={selectedUrgency}
                  scheduledDate={scheduledDate}
                  instructions={instructions}
                />
              ))}
            </div>
          </div>
        </div>
        {isTablet && (
          <div className={styles.separatorContainer}>
            <p className={styles.separator}>{t('or', 'or')}</p>
            <Button
              iconDescription="Return to order basket"
              kind="ghost"
              onClick={() => closeWorkspace({ discardUnsavedChanges: true })}
            >
              {t('back', 'Back')}
            </Button>
          </div>
        )}
      </>
    );
  }

  return (
    <Tile className={styles.emptyState}>
      <div>
        <h4 className={styles.heading}>
          {t('noResultsForTestTypeSearch', 'No results to display for "{{searchTerm}}"', {
            searchTerm,
          })}
        </h4>
        <p className={styles.bodyShort01}>
          <span>{t('tryTo', 'Try to')}</span>{' '}
          <span className={styles.link} role="link" tabIndex={0} onClick={focusAndClearSearchInput}>
            {t('searchAgain', 'search again')}
          </span>{' '}
          <span>{t('usingADifferentTerm', 'using a different term')}</span>
        </p>
      </div>
    </Tile>
  );
}

const TestTypeSearchResultItem: React.FC<TestTypeSearchResultItemProps> = ({
  testType,
  openOrderForm,
  orderTypeUuid,
  closeWorkspace,
  patient,
  visit,
  selectedUrgency,
  scheduledDate,
  instructions,
}) => {
  const { t } = useTranslation();
  const isTablet = useLayoutType() === 'tablet';
  const session = useSession();
  const { orders, setOrders } = useOrderBasket<TestOrderBasketItem>(patient, orderTypeUuid, prepTestOrderPostData);

  const testTypeAlreadyInBasket = useMemo(
    () => orders?.some((order) => order.testType.conceptUuid === testType.conceptUuid),
    [orders, testType],
  );

  const createLabOrder = useCallback(
    (orderableConcept: TestType) => {
      return createEmptyLabOrder(orderableConcept, session.currentProvider?.uuid, visit);
    },
    [session.currentProvider.uuid, visit],
  );

  const addToBasket = useCallback(() => {
    const labOrder = createLabOrder(testType);
    labOrder.urgency = selectedUrgency;
    if (selectedUrgency === 'ON_SCHEDULED_DATE' && scheduledDate) {
      labOrder.scheduledDate = scheduledDate;
    }
    if (instructions) {
      labOrder.instructions = instructions;
    }
    setOrders([...orders, labOrder]);
    // closeWorkspace({ discardUnsavedChanges: true });
  }, [orders, setOrders, createLabOrder, testType, closeWorkspace, selectedUrgency, scheduledDate, instructions]);

  const removeFromBasket = useCallback(() => {
    setOrders(orders.filter((order) => order.testType.conceptUuid !== testType.conceptUuid));
  }, [orders, setOrders, testType.conceptUuid]);

  return (
    <Tile
      className={classNames(styles.searchResultTile, {
        [styles.tabletSearchResultTile]: isTablet,
        [styles.selectedTile]: testTypeAlreadyInBasket,
      })}
      role="option"
      aria-selected={testTypeAlreadyInBasket}
      tabIndex={0}
      onClick={testTypeAlreadyInBasket ? removeFromBasket : addToBasket}
      onKeyDown={(e: React.KeyboardEvent) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          testTypeAlreadyInBasket ? removeFromBasket() : addToBasket();
        }
      }}
    >
      <div className={classNames(styles.searchResultTileContent, styles.text02)}>
        <p>
          <span className={styles.heading}>{testType.label}</span>{' '}
        </p>
      </div>
      <div
        className={`${styles.searchResultActions} ${testTypeAlreadyInBasket ? styles.remove : styles.add
          }`}
      >
        {testTypeAlreadyInBasket ? (
          <ShoppingCartArrowUp size={16} />
        ) : (
          <ShoppingCartArrowDownIcon size={16} />
        )}

        {testTypeAlreadyInBasket
          ? t('removeFromBasket', 'Remove')
          : t('directlyAddToBasket', 'Add')}
      </div>
    </Tile>
  );
};

const TestTypeSearchSkeleton = () => {
  const isTablet = useLayoutType() === 'tablet';
  const tileClassName = classNames({
    [styles.tabletSearchResultTile]: isTablet,
    [styles.desktopSearchResultTile]: !isTablet,
    [styles.skeletonTile]: true,
  });
  const buttonSize = isTablet ? 'md' : 'sm';

  return (
    <div className={styles.searchResultSkeletonWrapper}>
      <div className={styles.orderBasketSearchResultsHeader}>
        <SkeletonText className={styles.searchResultCntSkeleton} />
        <ButtonSkeleton size={buttonSize} />
      </div>
      {[...Array(4)].map((_, index) => (
        <Tile key={index} className={tileClassName}>
          <SkeletonText />
        </Tile>
      ))}
    </div>
  );
};
