import React, { type ComponentProps, useMemo, useState, useCallback } from 'react';
import classNames from 'classnames';
import { capitalize } from 'lodash-es';
import { useTranslation } from 'react-i18next';
import { Button, ButtonSet, InlineLoading } from '@carbon/react';
import {
  age,
  ArrowLeftIcon,
  getPatientName,
  formatDate,
  parseDate,
  useLayoutType,
  useConfig,
  Workspace2,
  useSession,
  openmrsFetch,
  restBaseUrl,
  showSnackbar,
  type Visit,
  type Workspace2DefinitionProps,
} from '@openmrs/esm-framework';
import { useOrderType, type OrderBasketItem, type TestOrderBasketItem, useOrderBasket, useMutatePatientOrders, showOrderSuccessToast } from '@openmrs/esm-patient-common-lib';
import { type ConfigObject } from '../../config-schema';
import { LabOrderForm } from './test-order-form.component';
import { TestTypeSearch } from './test-type-search.component';
import { prepTestOrderPostData } from '../api';
import styles from './add-test-order.scss';

export interface AddLabOrderProps {
  initialOrder?: OrderBasketItem;

  /**
   * This field should only be supplied for an existing order saved to the backend
   */
  orderToEditOrdererUuid?: string;
  orderTypeUuid: string;
  patient: fhir.Patient;
  visitContext: Visit;
  closeWorkspace: Workspace2DefinitionProps['closeWorkspace'];
}

const AddLabOrder: React.FC<AddLabOrderProps> = ({
  patient,
  orderToEditOrdererUuid,
  visitContext,
  initialOrder,
  orderTypeUuid,
  closeWorkspace,
}) => {
  const { t } = useTranslation();
  const isTablet = useLayoutType() === 'tablet';
  const session = useSession();
  const [currentLabOrder, setCurrentLabOrder] = useState(initialOrder as TestOrderBasketItem);
  const fullConfig = useConfig<any>();
  const { additionalTestOrderTypes, orders: configOrders } = useConfig<ConfigObject>();
  const { orderType } = useOrderType(orderTypeUuid);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isSavingOrders, setIsSavingOrders] = useState(false);
  const { mutate: mutateOrders } = useMutatePatientOrders(patient?.id);

  const { orders: basketOrders, clearOrders } = useOrderBasket<TestOrderBasketItem>(
    patient,
    orderTypeUuid,
    prepTestOrderPostData
  );

  const handleCancel = useCallback(() => {
    closeWorkspace();
  }, [closeWorkspace]);

  const handleSave = useCallback(async () => {
    setIsSavingOrders(true);
    try {
      const patientId = (patient as any)?.uuid || (patient as any)?.id;
      const orderLocationUuid = session?.sessionLocation?.uuid;
      const orderer = session?.currentProvider?.uuid;
      const orderEncounterType = fullConfig.orderEncounterType || '39da3525-afe4-45ff-8977-c53b7b359158';

      const encounterPayload = {
        patient: patientId,
        encounterType: orderEncounterType,
        visit: (visitContext as any)?.uuid,
        location: orderLocationUuid,
        orders: basketOrders.map(order => prepTestOrderPostData(
          order,
          patientId,
          null as any, // The encounter will be implicitly assigned
          orderToEditOrdererUuid || orderer
        )),
      };

      await openmrsFetch(`${restBaseUrl}/encounter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: encounterPayload,
      });

      showOrderSuccessToast('@trigonal/esm-patient-tests-app', basketOrders as any);
      clearOrders();
      mutateOrders();
      closeWorkspace({ discardUnsavedChanges: true });
    } catch (error) {
      showSnackbar({
        isLowContrast: false,
        kind: 'error',
        title: t('errorSavingLabOrder', 'Error saving lab order'),
        subtitle: error?.message || t('errorSavingLabOrder', 'Error saving lab order'),
      });
      console.error(error);
    } finally {
      setIsSavingOrders(false);
    }
  }, [basketOrders, patient, visitContext, fullConfig, session, clearOrders, mutateOrders, closeWorkspace, orderToEditOrdererUuid, t]);

  const title = useMemo(() => {
    if (orderType) {
      if (initialOrder?.action == 'REVISE') {
        return t(`editOrderableForOrderType`, 'Edit {{orderTypeDisplay}}', {
          orderTypeDisplay: orderType.display.toLocaleLowerCase(),
        });
      } else {
        return t(`addOrderableForOrderType`, 'Add {{orderTypeDisplay}}', {
          orderTypeDisplay: orderType.display.toLocaleLowerCase(),
        });
      }
    } else {
      return '';
    }
  }, [orderType, t, initialOrder?.action]);

  const orderableConceptSets = useMemo(() => {
    const allOrderTypes: ConfigObject['additionalTestOrderTypes'] = [
      {
        label: t('labOrders', 'Lab orders'),
        orderTypeUuid: configOrders.labOrderTypeUuid,
        orderableConceptSets: configOrders.labOrderableConcepts,
      },
      ...additionalTestOrderTypes,
    ];
    return allOrderTypes.find((orderType) => orderType.orderTypeUuid === orderTypeUuid).orderableConceptSets;
  }, [additionalTestOrderTypes, orderTypeUuid, configOrders.labOrderTypeUuid, configOrders.labOrderableConcepts, t]);

  const patientName = patient ? getPatientName(patient) : '';

  return (
    <Workspace2 title={title} hasUnsavedChanges={hasUnsavedChanges}>
      <div className={styles.container}>
        {isTablet && (
          <div className={styles.patientHeader}>
            <span className={styles.bodyShort02}>{patientName}</span>
            <span className={classNames(styles.text02, styles.bodyShort01)}>
              {capitalize(patient?.gender)} &middot; {age(patient?.birthDate)} &middot;{' '}
              <span>{formatDate(parseDate(patient?.birthDate), { mode: 'wide', time: false })}</span>
            </span>
          </div>
        )}
        {!isTablet && (
          <div className={styles.backButton}>
            <Button
              kind="ghost"
              renderIcon={(props: ComponentProps<typeof ArrowLeftIcon>) => <ArrowLeftIcon size={24} {...props} />}
              iconDescription={t('back', 'Back')}
              size="sm"
              onClick={() => closeWorkspace()}
            >
              <span>{t('back', 'Back')}</span>
            </Button>
          </div>
        )}
        <div className={styles.contentContainer}>
          {currentLabOrder ? (
            <LabOrderForm
              initialOrder={currentLabOrder}
              orderToEditOrdererUuid={orderToEditOrdererUuid}
              closeWorkspace={closeWorkspace}
              setHasUnsavedChanges={setHasUnsavedChanges}
              orderTypeUuid={orderTypeUuid}
              orderableConceptSets={orderableConceptSets}
              patient={patient}
            />
          ) : (
            <TestTypeSearch
              orderTypeUuid={orderTypeUuid}
              orderableConceptSets={orderableConceptSets}
              openLabForm={setCurrentLabOrder}
              closeWorkspace={closeWorkspace}
              patient={patient}
              visit={visitContext}
            />
          )}
        </div>
        {!currentLabOrder && (
          <ButtonSet className={styles.buttonSet}>
            <Button className={styles.actionButton} kind="secondary" onClick={handleCancel}>
              {t('cancel', 'Cancel')}
            </Button>
            <Button
              className={styles.actionButton}
              kind="primary"
              onClick={handleSave}
              disabled={isSavingOrders || !basketOrders?.length}
            >
              {isSavingOrders ? (
                <InlineLoading description={t('saving', 'Saving') + '...'} />
              ) : (
                <span>{t('signAndClose', 'Sign and close')}</span>
              )}
            </Button>
          </ButtonSet>
        )}
      </div>
    </Workspace2>
  );
};

export default AddLabOrder;
