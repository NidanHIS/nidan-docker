export const basePath = '/patient/:patientUuid/chart';
export const moduleName = '@trigonal/esm-patient-tests-app';
