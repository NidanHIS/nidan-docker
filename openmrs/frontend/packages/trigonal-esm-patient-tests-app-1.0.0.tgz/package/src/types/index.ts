import type { OrderBasketItem } from "@openmrs/esm-patient-common-lib/src";

export interface TestOrderBasketItem extends OrderBasketItem {
  testType: {
    label: string;
    conceptUuid: string;
  };
  orderReason?: string;
  specimenSource?: string;
}

//todo any
export interface OrderBasketExtensionProps {
  patient: fhir.Patient;
  launchDrugOrderForm(order?: any): void;
  launchLabOrderForm(orderTypeUuid: string, order?: TestOrderBasketItem): void;
  launchGeneralOrderForm(orderTypeUuid: string, order?: OrderBasketItem): void;
  launchImagingOrderForm(orderTypeUuid: string, order?: any): void;
  launchProcedureOrderForm(orderTypeUuid: string, order?: any): void;
  launchMedicalSupplyForm(orderTypeUuid: string, order?: any): void;
}