import { type OpenmrsResource } from '@openmrs/esm-framework';
import { type amPm } from '../helpers';

export enum SearchTypes {
  BASIC = 'basic',
  ADVANCED = 'advanced',
  SEARCH_RESULTS = 'search_results',
  SCHEDULED_VISITS = 'scheduled-visits',
}

export interface AppointmentLocation {
  uuid: string;
  name: string;
}

// Translation keys for these enum values are in src/constants.ts (scanned by extract-translations)
export enum AppointmentStatus {
  REQUESTED = 'Requested',
  SCHEDULED = 'Scheduled',
  CHECKEDIN = 'CheckedIn',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled',
  MISSED = 'Missed',
}

export enum AppointmentKind {
  SCHEDULED = 'Scheduled',
  WALKIN = 'WalkIn',
  VIRTUAL = 'Virtual',
}
// TODO: remove interface elements that aren't actually present on the Appointment object returned from the Appointment API
export interface Appointment {
  appointmentKind: AppointmentKind;
  appointmentNumber: string;
  comments: string;
  endDateTime: number | null;
  location: AppointmentLocation;
  // note: this is not a standard OpenMRS Patient object
  patient: {
    identifier: string;
    name: string;
    uuid: string;
    age?: number;
    gender?: string;
  };
  provider: OpenmrsResource;
  providers: Array<OpenmrsResource>;
  recurring: boolean;
  service: AppointmentService;
  startDateTime: number | null;
  dateAppointmentScheduled: number | null;
  status: AppointmentStatus;
  uuid: string;
  additionalInfo?: string | null;
  serviceTypes?: Array<ServiceTypes> | null;
  voided: boolean;
  extensions: {};
  teleconsultationLink: string | null;
}

export interface AppointmentsFetchResponse {
  data: Array<Appointment>;
}

export interface AppointmentService {
  appointmentServiceId: number;
  creatorName: string;
  description: string;
  durationMins?: number;
  endTime: string;
  initialAppointmentStatus: string;
  location?: OpenmrsResource;
  maxAppointmentsLimit: number | null;
  name: string;
  specialityUuid?: OpenmrsResource | {};
  startTime: string;
  uuid: string;
  serviceTypes?: Array<ServiceTypes>;
  color?: string;
  startTimeTimeFormat?: amPm;
  endTimeTimeFormat?: amPm;
}

export interface ServiceTypes {
  duration: number;
  name: string;
  uuid: string;
}

export interface Observation {
  uuid: string;
  concept: {
    uuid: string;
    display: string;
    conceptClass: {
      uuid: string;
      display: string;
    };
  };
  display: string;
  groupMembers: null | Array<{
    uuid: string;
    concept: {
      uuid: string;
      display: string;
    };
    value: {
      uuid: string;
      display: string;
    };
  }>;
  value: string | number | boolean | OpenmrsResource;
  obsDatetime: string;
}

export interface AppointmentPayload {
  patientUuid: string;
  serviceUuid: string;
  dateAppointmentScheduled: string;
  startDateTime: string;
  endDateTime: string;
  appointmentKind: string;
  providers?: Array<OpenmrsResource>;
  locationUuid: string;
  comments: string;
  status?: string;
  appointmentNumber?: string;
  uuid?: string;
  providerUuid?: string | OpenmrsResource;
  patientEmail?: string;
  providerEmail?: string;
  teleconsultationProvider?: string;
}

export interface AppointmentCountMap {
  allAppointmentsCount: number;
  missedAppointmentsCount: number;
  appointmentDate: number;
  appointmentServiceUuid: string;
}

export interface AppointmentSummary {
  appointmentService: OpenmrsResource;
  appointmentCountMap: Record<string, AppointmentCountMap>;
}

export interface Provider {
  uuid: string;
  display: string;
  comments?: string;
  response?: string;
  person: OpenmrsResource;
  name?: string;
}

export enum DurationPeriod {
  monthly,
  weekly,
  daily,
}

export interface Identifier {
  identifier: string;
  identifierName?: string;
}

export interface DailyAppointmentsCountByService {
  appointmentDate: string;
  services: Array<{
    serviceName: string;
    serviceUuid: string;
    count: number;
  }>;
}

export interface RecurringPattern {
  type: 'DAY' | 'WEEK';
  period: number;
  endDate: string;
  daysOfWeek?: Array<string>; //'MONDAY' | 'TUESDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY' | 'SUNDAY'>;
}

export interface RecurringAppointmentsPayload {
  appointmentRequest: AppointmentPayload;
  recurringPattern: RecurringPattern;
}

export interface PatientDetails {
  dateOfBirth: string;
}

export interface AppointmentsAppContext {
  appointmentForSelectedDateFilteredByServiceTypes: Array<Appointment>;
  isLoading: boolean;
  error: Error | undefined;
}

export interface UnscheduledAppointment {
  name: string;
  age: number;
  gender: string;
  identifier: string;
  phoneNumber?: string;
}
