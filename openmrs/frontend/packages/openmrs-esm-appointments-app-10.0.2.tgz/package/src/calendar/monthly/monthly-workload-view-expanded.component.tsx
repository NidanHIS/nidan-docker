import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Popover, PopoverContent } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import MonthlyWorkloadView, { type MonthlyWorkloadViewProps } from './monthly-workload-view.component';
import styles from './monthly-view-workload.scss';

interface MonthlyWorkloadViewExpandedProps extends MonthlyWorkloadViewProps {
  count: number;
}

const MonthlyWorkloadViewExpanded: React.FC<MonthlyWorkloadViewExpandedProps> = ({
  count,
  events,
  dateTime,
  calendarSelectedDate,
}) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const popoverRef = useRef(null);

  const handleClickOutside = useCallback((event) => {
    if (popoverRef.current && !popoverRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [handleClickOutside]);

  return (
    <Popover open={isOpen} align="top" ref={popoverRef}>
      <button
        className={styles.showMoreItems}
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen((prev) => !prev);
        }}>
        {t('countMore', '{{count}} more', { count })}
      </button>
      <PopoverContent>
        <MonthlyWorkloadView
          events={events}
          dateTime={dateTime}
          calendarSelectedDate={calendarSelectedDate}
          showAllServices={true}
        />
      </PopoverContent>
    </Popover>
  );
};

export default MonthlyWorkloadViewExpanded;
