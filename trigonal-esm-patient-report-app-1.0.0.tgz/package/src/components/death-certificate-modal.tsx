import React from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { useDeathNoteData } from '../hooks/useDeathNoteData';
import DeathCertificateActions from './death-certificate-actions';

interface DeathCertificateModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const DeathCertificateModal: React.FC<DeathCertificateModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const { deathNoteData, isLoading, error } = useDeathNoteData(patientUuid);

    if (isLoading) {
        return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
    }

    if (error) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
                <ModalBody>
                    <p>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    if (!deathNoteData) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
                <ModalBody>
                    <p>{t('noDeathNoteFound', 'No Death Note found for this patient.')}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('deathCertificate', 'Death Certificate')} />
            <ModalBody>
                <div style={{ padding: '1rem' }}>
                    <div style={{ marginBottom: '1rem', borderBottom: '1px solid #ccc', paddingBottom: '0.5rem' }}>
                        <h4 style={{ marginBottom: '0.5rem' }}>{t('patientDetails', 'Patient Details')}</h4>
                        <div><strong>{t('name', 'Name')}:</strong> {deathNoteData.patientName}</div>
                        <div><strong>{t('gender', 'Gender')}:</strong> {deathNoteData.patientGender}</div>
                        <div><strong>{t('age', 'Age')}:</strong> {deathNoteData.patientAge}</div>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                        <h4 style={{ marginBottom: '0.5rem' }}>{t('deathDetails', 'Death Details')}</h4>
                        <div><strong>{t('dateOfDeath', 'Date & Time of Death')}:</strong> {new Date(deathNoteData.dateAndTimeOfDeath!).toLocaleString()}</div>
                        <div><strong>{t('placeOfDeath', 'Place of Death')}:</strong> {deathNoteData.placeOfDeath}</div>
                        <div><strong>{t('causeOfDeath', 'Cause of Death')}:</strong> {deathNoteData.immediateCause || 'N/A'}</div>
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                {/* <Button kind="secondary" onClick={closeModal} style={{ marginRight: '1rem' }}>
                    {t('close', 'Close')}
                </Button> */}
                <DeathCertificateActions
                    deathNoteData={deathNoteData}
                />
            </ModalFooter>
        </>
    );
};

export default DeathCertificateModal;
