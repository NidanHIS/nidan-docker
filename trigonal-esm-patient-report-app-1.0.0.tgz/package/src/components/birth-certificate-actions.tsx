import React from 'react';
import { BlobProvider } from '@react-pdf/renderer';
import { Button } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { BirthCertificateDocument } from './patient-report-document/birth-certificate-document';

interface BirthCertificateActionsProps {
    newbornData: {
        fatherName?: string;
        motherName?: string;
        dateOfDelivery?: string;
        bodyWeight?: number;
        patientName?: string;
    };
    patientGender?: string;
    patientId?: string;
}

interface PDFRenderProps {
    blob: Blob | null;
    url: string | null;
    loading: boolean;
    error: Error | null;
}

const BirthCertificateActions: React.FC<BirthCertificateActionsProps> = ({ newbornData, patientGender, patientId }) => {
    const { t } = useTranslation();

    const translatedTexts = {
        birthCertificateTitle: t('birthCertificateTitle', 'Birth Certificate'),
        hospitalName: t('hospitalName', 'Hospital Name'),
        hospitalAddress: t('hospitalAddress', 'Hospital Address'),
        male: t('male', 'male'),
        female: t('female', 'female'),
        bodyWeightLabel: t('bodyWeightLabel', 'Body weight at birth'),
        dateLabel: t('dateLabel', 'Date'),
        nurseSignature: t('nurseSignature', 'Nurse Signature'),
        doctorSignature: t('doctorSignature', "Doctor's Signature"),
        doctorName: t('doctorName', 'Doctor Name'),
        nmcNumber: t('nmcNumber', 'NMC Number'),
        kg: t('kg', 'kg'),
        certificateNo: t('certificateNo', 'Certificate No'),
        patientNo: t('patientNo', 'Patient No'),
    };

    const handlePreview = (url: string | null) => {
        if (url) {
            window.open(url, '_blank');
        }
    };

    const handleDownload = (url: string | null) => {
        if (url) {
            const link = document.createElement('a');
            link.href = url;
            const cleanName = newbornData.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'birth_certificate';
            const date = new Date().toISOString().split('T')[0];
            link.download = `birth_certificate_${cleanName}_${date}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    return (
        <BlobProvider
            document={
                <BirthCertificateDocument
                    newbornData={newbornData}
                    patientGender={patientGender}
                    translatedTexts={translatedTexts}
                    patientNumber={patientId}
                />
            }
        >
            {({ blob, url, loading, error }: PDFRenderProps) => (
                <>
                    <Button kind="primary" disabled={loading || !!error} onClick={() => url && handlePreview(url)}>
                        {t('previewCertificate', 'Preview Certificate')}
                    </Button>
                    <Button kind="secondary" disabled={loading || !!error} onClick={() => url && handleDownload(url)}>
                        {loading
                            ? `${t('loading', 'Loading')}...`
                            : error
                                ? t('error', 'Error generating PDF')
                                : t('downloadCertificate', 'Download Certificate')}
                    </Button>
                </>
            )}
        </BlobProvider>
    );
};

export default BirthCertificateActions;
