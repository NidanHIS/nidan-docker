import React from 'react';
import { BlobProvider } from '@react-pdf/renderer';
import { Button } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import { DeathCertificateDocument } from './patient-report-document/DeathCertificateDocument';

interface DeathCertificateActionsProps {
    deathNoteData: any;
}

interface PDFRenderProps {
    blob: Blob | null;
    url: string | null;
    loading: boolean;
    error: Error | null;
}

const DeathCertificateActions: React.FC<DeathCertificateActionsProps> = ({ deathNoteData }) => {
    const { t } = useTranslation();

    const translatedTexts = {
        // Add translations as needed, passing empty object for now as document handles most text directly
        // or uses keys if we switch to full i18n later
    };

    const handlePreview = (url: string | null) => {
        if (url) {
            window.open(url, '_blank');
        }
    };

    const handleDownload = (url: string | null) => {
        if (url) {
            const link = document.createElement('a');
            link.href = url;
            const cleanName = deathNoteData.patientName?.replace(/[^a-zA-Z0-9]/g, '_') || 'death_certificate';
            const date = new Date().toISOString().split('T')[0];
            link.download = `death_certificate_${cleanName}_${date}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    return (
        <BlobProvider
            document={
                <DeathCertificateDocument
                    data={deathNoteData}
                    translatedTexts={translatedTexts}
                />
            }
        >
            {({ blob, url, loading, error }: PDFRenderProps) => (
                <>
                    <Button kind="primary" disabled={loading || !!error} onClick={() => url && handlePreview(url)}>
                        {t('previewCertificate', 'Preview Certificate')}
                    </Button>
                    <Button kind="secondary" disabled={loading || !!error} onClick={() => url && handleDownload(url)}>
                        {loading
                            ? `${t('loading', 'Loading')}...`
                            : error
                                ? t('error', 'Error generating PDF')
                                : t('downloadCertificate', 'Download Certificate')}
                    </Button>
                </>
            )}
        </BlobProvider>
    );
};

export default DeathCertificateActions;
