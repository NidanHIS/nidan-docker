import React from 'react';
import { useTranslation } from 'react-i18next';
import { ModalBody, ModalFooter, ModalHeader, InlineLoading, Button } from '@carbon/react';
import { useNewbornAdmissionData } from '../hooks/useNewbornAdmissionData';
import { usePatientInfo } from '../hooks/usePatientInfo';
import BirthCertificateActions from './birth-certificate-actions';
import dayjs from 'dayjs';

interface BirthCertificateModalProps {
    patientUuid: string;
    closeModal: () => void;
}

const BirthCertificateModal: React.FC<BirthCertificateModalProps> = ({ patientUuid, closeModal }) => {
    const { t } = useTranslation();
    const { newbornData, isLoading: isNewbornLoading, error: newbornError } = useNewbornAdmissionData(patientUuid);
    const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);

    const isLoading = isNewbornLoading || isPatientLoading;
    const error = newbornError || patientError;

    const formatDate = (dateString?: string) => {
        if (!dateString) return t('notAvailable', 'N/A');
        return dayjs(dateString).format('MMMM D, YYYY [at] h:mm A');
    };

    if (isLoading) {
        return <InlineLoading description={`${t('loading', 'Loading')} ...`} />;
    }

    if (error) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('birthCertificate', 'Birth Certificate')} />
                <ModalBody>
                    <p>{t('loadingErrorMessage', 'Error loading data')}: {error.message}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    if (!newbornData) {
        return (
            <>
                <ModalHeader closeModal={closeModal} title={t('birthCertificate', 'Birth Certificate')} />
                <ModalBody>
                    <p>{t('noNewbornAdmissionNote', 'No Newborn admission note found for this patient.')}</p>
                </ModalBody>
                <ModalFooter>
                    <Button kind="secondary" onClick={closeModal}>
                        {t('close', 'Close')}
                    </Button>
                </ModalFooter>
            </>
        );
    }

    return (
        <>
            <ModalHeader closeModal={closeModal} title={t('birthCertificate', 'Birth Certificate')} />
            <ModalBody>
                <div style={{ padding: '1rem' }}>
                    <h4 style={{ marginBottom: '1rem' }}>{t('babyInformation', 'Baby Information')}</h4>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('name', 'Name')}:</strong> {newbornData.patientName || t('notAvailable', 'N/A')}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('gender', 'Gender')}:</strong> {patientInfo?.gender || newbornData.patientGender || t('notAvailable', 'N/A')}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('birthdate', 'Birthdate')}:</strong> {formatDate(newbornData.patientBirthdate)}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('dateOfDelivery', 'Date of Delivery')}:</strong> {formatDate(newbornData.dateOfDelivery)}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('gestationalWeek', 'Gestational Week')}:</strong> {newbornData.gestationalWeek || t('notAvailable', 'N/A')}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('bodyWeight', 'Body Weight')}:</strong> {newbornData.bodyWeight ? `${newbornData.bodyWeight} kg` : t('notAvailable', 'N/A')}
                    </div>

                    <h4 style={{ marginTop: '1.5rem', marginBottom: '1rem' }}>{t('parentInformation', 'Parent Information')}</h4>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('motherName', 'Mother Name')}:</strong> {newbornData.motherName || t('notAvailable', 'N/A')}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('motherId', 'Mother ID')}:</strong> {newbornData.motherId || t('notAvailable', 'N/A')}
                    </div>
                    <div style={{ marginBottom: '0.5rem' }}>
                        <strong>{t('fatherName', 'Father Name')}:</strong> {newbornData.fatherName || t('notAvailable', 'N/A')}
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                <BirthCertificateActions
                    newbornData={newbornData}
                    patientGender={patientInfo?.gender}
                    patientId={patientInfo?.patientId}
                />
            </ModalFooter>
        </>
    );
};

export default BirthCertificateModal;
