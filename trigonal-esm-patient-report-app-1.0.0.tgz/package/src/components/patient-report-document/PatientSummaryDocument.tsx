import React from 'react';
import { Document, Page, Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';

import { ReportHeader } from './patient-report-header.component';
import { VitalsBioData } from './patient-vitals-bio.component';
import { ConditionsData } from './patient-conditions-history.component';
import { DiagnosisAndClinicalNotes } from './patient-encounters.components';
import { OrdersData } from './patient-orders.component';

export const PatientSummaryDocument: React.FC<{
  patientInfo: PatientInfo;
  visitDetails: VisitDetails;
  orders: Orders[];
  vitalsData: VitalsData;
  biometricsData: BiometricsData;
  conditionsData: ConditionsData[];
  diagnosisData: DiagnosisData[];
  clinicalNotes: ClinicalNote[];
  printedBy: string;
  translatedTexts: any;
}> = ({
  patientInfo,
  visitDetails,
  orders,
  vitalsData,
  biometricsData,
  conditionsData,
  diagnosisData,
  clinicalNotes,
  printedBy,
  translatedTexts,
}) => {

    return (

      <Document>
        <Page size="A4" style={styles.page}>
          <Text style={styles.title}>{translatedTexts.patientReportTitle}</Text>

          <ReportHeader
            patientInfo={patientInfo}
            visitDetails={visitDetails}
            translatedTexts={translatedTexts}
          />

          <View style={styles.hr} />

          <View style={styles.mainContent}>
            <VitalsBioData
              vitalsData={vitalsData}
              biometricsData={biometricsData}
              translatedTexts={translatedTexts}
            />

            <ConditionsData
              conditionsData={conditionsData}
              translatedTexts={translatedTexts}
            />

            <DiagnosisAndClinicalNotes
              diagnosisData={diagnosisData}
              clinicalNotes={clinicalNotes}
              translatedTexts={translatedTexts}
            />

            <OrdersData
              orders={orders}
              translatedTexts={translatedTexts}
            />
          </View>

          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>
              {translatedTexts.printedByLabel}: {printedBy || '--'}
            </Text>
          </View>
        </Page>
      </Document>
    );
  };
