import React from 'react';
import { Document, Page, Text, View, StyleSheet, Image, Font } from '@react-pdf/renderer';

// Register fonts for professional document appearance
Font.register({
    family: 'Times-Roman',
    src: 'https://cdn.jsdelivr.net/npm/@canvas-fonts/times-new-roman@1.0.4/Times%20New%20Roman.ttf',
});

const hospitalLogoPath = require('../../images/hospital-logo.png');

const styles = StyleSheet.create({
    page: {
        padding: 50,
        paddingTop: 40,
        paddingBottom: 60,
        fontFamily: 'Times-Roman',
        fontSize: 12,
        lineHeight: 1.6,
        color: '#1a1a1a',
    },
    // Header section
    headerContainer: {
        flexDirection: 'row',
        marginBottom: 30,
        paddingBottom: 15,
        borderBottomWidth: 2,
        borderBottomColor: '#333',
    },
    logoContainer: {
        width: 70,
        marginRight: 20,
    },
    logo: {
        width: 60,
        height: 60,
    },
    headerTextContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    hospitalName: {
        fontSize: 20,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        letterSpacing: 3,
        marginBottom: 6,
        textAlign: 'center',
    },
    hospitalAddress: {
        fontSize: 10,
        color: '#444',
        textAlign: 'center',
        letterSpacing: 0.5,
    },
    // Title section
    titleSection: {
        marginTop: 25,
        marginBottom: 30,
        alignItems: 'center',
    },
    certificateTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        letterSpacing: 4,
        paddingBottom: 8,
    },
    // Date section
    dateSection: {
        marginBottom: 15,
        paddingHorizontal: 10,

    },
    dateText: {
        fontSize: 11,
    },
    // Reference numbers section
    referenceSection: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 30,
        paddingHorizontal: 10,
    },
    referenceItem: {
        fontSize: 11,
    },
    // Certificate body
    certificateBody: {
        marginTop: 30,
        marginBottom: 40,
        paddingHorizontal: 15,
    },
    mainText: {
        fontSize: 13,
        textAlign: 'justify',
        lineHeight: 2.5,
        letterSpacing: 0.6,
    },
    bold: {
        fontWeight: 'bold',
    },
    // Data row
    dataSection: {
        marginTop: 20,
        paddingHorizontal: 20,
    },
    dataRow: {
        flexDirection: 'row',
        marginVertical: 6,
    },
    dataLabel: {
        width: '35%',
        fontSize: 12,
        fontWeight: 'bold',
    },
    dataValue: {
        width: '65%',
        fontSize: 12,
    },
    // Footer with signatures
    footer: {
        position: 'absolute',
        bottom: 60,
        left: 50,
        right: 50,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    signatureBlock: {
        width: '40%',
    },
    signatureLine: {
        borderTopWidth: 1,
        borderTopColor: '#000',
        marginTop: 50,
        paddingTop: 8,
    },
    signatureLabel: {
        fontSize: 10,
        fontWeight: 'bold',
        marginBottom: 3,
    },
    signatureSubtext: {
        fontSize: 9,
        color: '#444',
        marginTop: 2,
    },
});

interface BirthCertificateDocumentProps {
    newbornData: {
        fatherName?: string;
        motherName?: string;
        dateOfDelivery?: string;
        bodyWeight?: number;
        patientName?: string;
    };
    patientGender?: string;
    translatedTexts: {
        birthCertificateTitle: string;
        hospitalName: string;
        hospitalAddress: string;
        male: string;
        female: string;
        bodyWeightLabel: string;
        dateLabel: string;
        nurseSignature: string;
        doctorSignature: string;
        doctorName: string;
        nmcNumber: string;
        kg: string;
        certificateNo: string;
        patientNo: string;
    };
    certificateNumber?: string;
    patientNumber?: string;
}

export const BirthCertificateDocument: React.FC<BirthCertificateDocumentProps> = ({
    newbornData,
    patientGender,
    translatedTexts,
    certificateNumber,
    patientNumber,
}) => {
    const formatDate = (dateString?: string) => {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        const day = date.getDate();
        const month = date.toLocaleString('default', { month: 'long' });
        const year = date.getFullYear();
        return `${day} ${month} ${year}`;
    };

    const formatTime = (dateString?: string) => {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    };

    const genderText = patientGender?.toLowerCase() === 'm' || patientGender?.toLowerCase() === 'male'
        ? translatedTexts.male
        : translatedTexts.female;

    const currentDate = formatDate(new Date().toISOString());

    return (
        <Document>
            <Page size="A4" style={styles.page}>
                {/* Header with logo and hospital info */}
                <View style={styles.headerContainer}>
                    <View style={styles.logoContainer}>
                        <Image style={styles.logo} src={hospitalLogoPath} />
                    </View>
                    <View style={styles.headerTextContainer}>
                        <Text style={styles.hospitalName}>{translatedTexts.hospitalName}</Text>
                        <Text style={styles.hospitalAddress}>{translatedTexts.hospitalAddress}</Text>
                    </View>
                    <View style={styles.logoContainer} />
                </View>

                {/* Certificate title */}
                <View style={styles.titleSection}>
                    <Text style={styles.certificateTitle}>{translatedTexts.birthCertificateTitle}</Text>
                </View>

                {/* Date */}
                <View style={styles.dateSection}>
                    <Text style={styles.dateText}>
                        {translatedTexts.dateLabel}: {currentDate}
                    </Text>
                </View>

                {/* Reference numbers */}
                <View style={styles.referenceSection}>
                    <Text style={styles.referenceItem}>
                        {translatedTexts.certificateNo}: {certificateNumber || '_______________'}
                    </Text>
                    <Text style={styles.referenceItem}>
                        {translatedTexts.patientNo}: {patientNumber || '_______________'}
                    </Text>
                </View>

                {/* Certificate body */}
                <View style={styles.certificateBody}>
                    <Text style={styles.mainText}>
                        This is to certify that a <Text style={styles.bold}>{genderText}</Text> child was born to
                        Ms <Text style={styles.bold}>{newbornData.motherName || 'N/A'}</Text> wife of{' '}
                        <Text style={styles.bold}>{newbornData.fatherName || 'N/A'}</Text> on{' '}
                        <Text style={styles.bold}>{formatDate(newbornData.dateOfDelivery)}</Text> at{' '}
                        <Text style={styles.bold}>{formatTime(newbornData.dateOfDelivery)}</Text> at this hospital.
                    </Text>
                </View>

                {/* Data section */}
                <View style={styles.dataSection}>
                    <View style={styles.dataRow}>
                        <Text style={styles.dataLabel}>{translatedTexts.bodyWeightLabel}:</Text>
                        <Text style={styles.dataValue}>
                            {newbornData.bodyWeight ? `${newbornData.bodyWeight} ${translatedTexts.kg}` : 'N/A'}
                        </Text>
                    </View>
                </View>

                {/* Footer with signatures */}
                <View style={styles.footer}>
                    {/* Left - Nurse Signature */}
                    <View style={styles.signatureBlock}>
                        <View style={styles.signatureLine}>
                            <Text style={styles.signatureLabel}>{translatedTexts.nurseSignature}</Text>
                        </View>
                    </View>

                    {/* Right - Doctor Signature */}
                    <View style={styles.signatureBlock}>
                        <View style={styles.signatureLine}>
                            <Text style={styles.signatureLabel}>{translatedTexts.doctorSignature}</Text>
                            <Text style={styles.signatureSubtext}>{translatedTexts.doctorName}: _______________</Text>
                            <Text style={styles.signatureSubtext}>{translatedTexts.nmcNumber}: _______________</Text>
                        </View>
                    </View>
                </View>
            </Page>
        </Document>
    );
};
