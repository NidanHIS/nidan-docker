import React from 'react';
import { Document, Page, Text, View, StyleSheet, Image, Font } from '@react-pdf/renderer';


// Register fonts
Font.register({
    family: 'Times-Roman',
    src: 'https://cdn.jsdelivr.net/npm/@canvas-fonts/times-new-roman@1.0.4/Times%20New%20Roman.ttf',
});

Font.register({
    family: 'Times-Bold',
    src: 'https://cdn.jsdelivr.net/npm/@canvas-fonts/times-new-roman@1.0.4/Times%20New%20Roman%20Bold.ttf',
});

const hospitalLogoPath = require('../../images/hospital-logo.png');

const styles = StyleSheet.create({
    page: {
        padding: 40,
        fontFamily: 'Times-Roman',
        fontSize: 10,
        lineHeight: 1.4,
        color: '#1a1a1a',
    },
    // Header
    headerContainer: {
        alignItems: 'center',
        marginBottom: 20,
        borderBottomWidth: 2,
        borderBottomColor: '#000',
        borderStyle: 'solid',
        paddingBottom: 10,
    },
    hospitalName: {
        fontSize: 18,
        fontFamily: 'Times-Bold',
        textTransform: 'uppercase',
        marginBottom: 5,
    },
    departmentName: {
        fontSize: 12,
        marginBottom: 5,
    },
    documentTitle: {
        fontSize: 14,
        fontFamily: 'Times-Bold',
        textDecoration: 'underline',
        textTransform: 'uppercase',
    },
    // Section styles
    sectionContainer: {
        marginBottom: 15,
        borderWidth: 1,
        borderColor: '#ccc',
        borderStyle: 'solid',
        backgroundColor: '#f9f9f9',
    },
    sectionHeader: {
        backgroundColor: '#e0e0e0',
        padding: 5,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        borderStyle: 'solid',
    },
    sectionTitle: {
        fontFamily: 'Times-Bold',
        fontSize: 11,
        textTransform: 'uppercase',
    },
    row: {
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderBottomColor: '#eee',
        borderStyle: 'solid',
        paddingVertical: 5,
        paddingHorizontal: 5,
    },
    lastRow: {
        borderBottomWidth: 0,
    },
    col: {
        flex: 1,
    },
    label: {
        fontFamily: 'Times-Bold',
        width: 120,
    },
    value: {
        flex: 1,
    },
    // Cause of Death Table
    causeTable: {
        borderWidth: 1,
        borderColor: '#000',
        borderStyle: 'solid',
        marginTop: 5,
    },
    causeRow: {
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderBottomColor: '#000',
        borderStyle: 'solid',
        minHeight: 25,
    },
    causeColLabel: {
        width: 30,
        borderRightWidth: 1,
        borderRightColor: '#000',
        borderStyle: 'solid',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 2,
    },
    causeColContent: {
        flex: 1,
        borderRightWidth: 1,
        borderRightColor: '#000',
        borderStyle: 'solid',
        padding: 5,
    },
    causeColDuration: {
        width: 100,
        padding: 5,
    },
    partHeader: {
        fontFamily: 'Times-Bold',
        backgroundColor: '#f0f0f0',
        padding: 4,
        borderBottomWidth: 1,
        borderBottomColor: '#000',
        borderStyle: 'solid',
    },
    // Signatures
    footer: {
        marginTop: 40,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    signatureBox: {
        width: '40%',
    },
    signatureLine: {
        borderTopWidth: 1,
        borderTopColor: '#000',
        borderStyle: 'solid',
        marginTop: 30,
        paddingTop: 5,
        alignItems: 'center',
    },
    signatureText: {
        marginTop: 5,
    },
});

interface DeathCertificateDocumentProps {
    data: any;
    translatedTexts: any;
}

export const DeathCertificateDocument: React.FC<DeathCertificateDocumentProps> = ({
    data,
    translatedTexts,
}) => {
    const formatDate = (dateString?: string) => {
        if (!dateString) return '';
        return new Date(dateString).toLocaleString();
    };

    return (
        <Document>
            <Page size="A4" style={styles.page}>
                {/* Header */}
                <View style={styles.headerContainer}>
                    <Text style={styles.hospitalName}>Nidan</Text>
                    <Text style={styles.departmentName}>Department of Health Records</Text>
                    <Text style={styles.documentTitle}>MEDICAL CERTIFICATION OF CAUSE OF DEATH</Text>
                </View>

                {/* I. Patient Identification */}
                <View style={styles.sectionContainer}>
                    {/* <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>I. PATIENT IDENTIFICATION</Text>
                    </View> */}
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Full Name:</Text>
                            <Text style={styles.value}>{data.patientName}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Gender:</Text>
                            <Text style={styles.value}>{data.patientGender}</Text>
                        </View>
                    </View>
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Patient ID:</Text>
                            <Text style={styles.value}>{data.patientId}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Age:</Text>
                            <Text style={styles.value}>{data.patientAge}</Text>
                        </View>
                    </View>
                    <View style={[styles.row, styles.lastRow]}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Place of Death:</Text>
                            <Text style={styles.value}>{data.placeOfDeath}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Ward/Unit:</Text>
                            <Text style={styles.value}>{data.wardOrUnit}</Text>
                        </View>
                    </View>
                </View>

                {/* II. Details of Death */}
                <View style={styles.sectionContainer}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>I. DETAILS OF DEATH</Text>
                    </View>
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Date & Time of Death:</Text>
                            <Text style={styles.value}>{formatDate(data.dateAndTimeOfDeath)}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Manner of Death:</Text>
                            <Text style={styles.value}>{data.mannerOfDeath}</Text>
                        </View>
                    </View>
                    <View style={[styles.row, styles.lastRow]}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Brought Dead:</Text>
                            <Text style={styles.value}>{data.broughtDead}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Death Type:</Text>
                            <Text style={styles.value}>{data.deathType}</Text>
                        </View>
                    </View>
                </View>

                {/* III. Cause of Death */}
                <View style={[styles.sectionContainer]}>
                    <View style={[styles.sectionHeader, { borderColor: '#ccc' }]}>
                        <Text style={styles.sectionTitle}>II. CAUSE OF DEATH</Text>
                    </View>

                    <View style={styles.causeTable}>
                        <View style={styles.partHeader}>
                            <Text>Part I: Chain of Events Leading Directly to Death</Text>
                        </View>

                        {/* Immediate Cause */}
                        <View style={styles.causeRow}>
                            <View style={styles.causeColLabel}><Text>a)</Text></View>
                            <View style={styles.causeColContent}>
                                <Text style={styles.label}>Immediate Cause:</Text>
                                <Text>{data.primaryCause}</Text>
                            </View>
                            <View style={styles.causeColDuration}>
                                <Text>Duration: {data.durationImmediate}</Text>
                            </View>
                        </View>

                        {/* Antecedent Cause */}
                        <View style={styles.causeRow}>
                            <View style={styles.causeColLabel}><Text>b)</Text></View>
                            <View style={styles.causeColContent}>
                                <Text style={styles.label}>Due to (Antecedent Cause):</Text>
                                <Text>{data.antecedentCause}</Text>
                            </View>
                            <View style={styles.causeColDuration}>
                                <Text>Duration: {data.durationSecondary}</Text>
                            </View>
                        </View>

                        {/* Underlying Cause */}
                        <View style={[styles.causeRow, { borderBottomWidth: 0 }]}>
                            <View style={styles.causeColLabel}><Text>c)</Text></View>
                            <View style={styles.causeColContent}>
                                <Text style={styles.label}>Due to (Underlying Cause):</Text>
                                <Text>{data.underlyingCause}</Text>
                            </View>
                            <View style={styles.causeColDuration}>
                                <Text>Duration: {data.durationTertiary}</Text>
                            </View>
                        </View>

                        <View style={[styles.partHeader, { borderTopWidth: 1, borderTopColor: '#000' }]}>
                            <Text>Part II: Other Significant Conditions Contributing to Death</Text>
                        </View>
                        <View style={{ padding: 5, minHeight: 30 }}>
                            <Text>{data.otherSignificantConditions}</Text>
                        </View>
                    </View>
                </View>

                {/* IV. Administrative & Legal */}
                <View style={styles.sectionContainer}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>III. ADMINISTRATIVE & LEGAL</Text>
                    </View>
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Medico-Legal Case:</Text>
                            <Text style={styles.value}>{data.medicoLegalCase}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Post-mortem Done:</Text>
                            <Text style={styles.value}>{data.postMortemDone}</Text>
                        </View>
                    </View>
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Maternal Death:</Text>
                            <Text style={styles.value}>{data.maternalDeathStatus}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Post-Operative:</Text>
                            <Text style={styles.value}>{data.postOperativeDeath}</Text>
                        </View>
                    </View>
                    <View style={styles.row}>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>Family Informed:</Text>
                            <Text style={styles.value}>{data.familyInformed}</Text>
                        </View>
                        <View style={[styles.row, { flex: 1 }]}>
                            <Text style={styles.label}>MDGP Notified At:</Text>
                            <Text style={styles.value}>{data.mdgpNotifiedAt}</Text>
                        </View>
                    </View>
                    <View style={[styles.row, styles.lastRow]}>
                        <Text style={styles.label}>Brief Hospital Course:</Text>
                        <Text style={styles.value}>{data.briefHospitalCourse}</Text>
                    </View>
                </View>

                {/* Signatures */}
                <View style={styles.footer}>
                    <View style={styles.signatureBox}>
                        <View style={styles.signatureLine}>
                            <Text style={{ fontFamily: 'Times-Bold' }}>Medical Officer Signature</Text>
                        </View>
                        <Text style={styles.signatureText}>Name: {data.providerName}</Text>
                        <Text style={styles.signatureText}>Qualification: {data.providerQualification}</Text>
                        <Text style={styles.signatureText}>Registration No: {data.providerRegistrationNumber}</Text>
                    </View>
                    <View style={styles.signatureBox}>
                        <View style={styles.signatureLine}>
                            <Text style={{ fontFamily: 'Times-Bold' }}>Date Signed</Text>
                        </View>
                        <Text style={styles.signatureText}>Date: {formatDate(data.dateSigned)}</Text>
                    </View>
                </View>
            </Page>
        </Document>
    );
};
