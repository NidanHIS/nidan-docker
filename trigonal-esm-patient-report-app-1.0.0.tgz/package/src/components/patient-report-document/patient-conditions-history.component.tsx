import React from 'react';
import { Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';

export const ConditionsData = ({ conditionsData, translatedTexts }) => {

  return (
    <View>
      <Text style={styles.sectionTitle}>{translatedTexts.historyOfPresentIllness}</Text>

      <View style={styles.sectionContent}>
        <View style={styles.orderTable}>
          <View style={styles.tableHeader}>
            <Text style={styles.col5}>{translatedTexts.conditionLabel}</Text>
            <Text style={styles.col2}>{translatedTexts.dateOfOnset}</Text>
            <Text style={styles.col2}>{translatedTexts.statusLabel}</Text>
          </View>

          {conditionsData?.map((conditionItem, index) => (
            <View style={styles.tableRow} key={index}>
              <Text style={styles.col5}>{conditionItem.condition || '--'}</Text>
              <Text style={styles.col2}>{conditionItem.onsetDate || '--'}</Text>
              <Text style={styles.col2}>{conditionItem.clinicalStatus || '--'}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
};
