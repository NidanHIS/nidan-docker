import React from 'react';
import { Text, View } from '@react-pdf/renderer';
import { styles } from '../../styles/pdf-styles';

export const OrdersData = ({ orders, translatedTexts }) => {

  return (
    <View>
      {/* Drug Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Drug Order') && (
        <View style={styles.drugOrderSection}>
          <Text style={styles.sectionTitle}>{translatedTexts.medicationsTitle}</Text>
          <View style={styles.sectionContent}>
            <View style={styles.orderTable}>
              <View style={styles.tableHeader}>
                <Text style={styles.col1}>{translatedTexts.startDate}</Text>
                <Text style={styles.col2}>{translatedTexts.medicationLabel}</Text>
                <Text style={styles.col1}>{translatedTexts.doseLabel}</Text>
                <Text style={styles.col1}>{translatedTexts.frequencyLabel}</Text>
                <Text style={styles.col3}>{translatedTexts.instructionsLabel}</Text>
                <Text style={styles.col1}>{translatedTexts.durationLabel}</Text>
                <Text style={styles.col2}>Ordered By</Text>
              </View>
            </View>

            {orders.map((order, index) => {
              if (order.orderType.name === 'Drug Order') {
                return (
                  <View key={index} style={styles.tableRow}>
                    <Text style={styles.col1}>{new Date(order.auditInfo?.dateCreated).toLocaleDateString('en-GB')}</Text>
                    <Text style={styles.col2}>{order.drug.display}</Text>
                    <Text style={styles.col1}>{order.dose} {order.doseUnits.display}</Text>
                    <Text style={styles.col1}>{order.frequency.display}</Text>
                    <Text style={styles.col3}>
                      {order.dosingInstructions || translatedTexts.takeAsDirected} ({order.route.display})
                    </Text>
                    <Text style={styles.col1}>{order?.duration || '--'} {order.durationUnits.display}</Text>
                    <Text style={styles.col2}>{order.orderedBy || '--'}</Text>
                  </View>
                );
              }
              return null;
            })}
          </View>
        </View>
      )}

      {/* Test Orders Section */}
      {orders && orders.some(order => order.orderType.name === 'Test Order') && (
        <View style={styles.drugOrderSection}>
          <Text style={styles.sectionTitle}>{translatedTexts.testOrdersTitle}</Text>
          <View style={styles.sectionContent}>
            <View style={styles.orderTable}>
              <View style={styles.tableHeader}>
                <Text style={styles.col2}>{translatedTexts.dateOfOrder}</Text>
                <Text style={styles.col3}>{translatedTexts.orderType}</Text>
                <Text style={styles.col2}>{translatedTexts.urgencyLabel}</Text>
                <Text style={styles.col1}>{translatedTexts.scheduledDate}</Text>
                <Text style={styles.col2}>{translatedTexts.instructionsLabel}</Text>
                <Text style={styles.col2}>Ordered By</Text>
              </View>
            </View>

            {orders.map((order, index) => {
              if (order.orderType.name === 'Test Order') {
                return (
                  <View key={index} style={styles.tableRow}>
                    <Text style={styles.col2}>{new Date(order.dateActivated).toLocaleDateString('en-GB') || '--'}</Text>
                    <Text style={styles.col3}>{order.display || '--'}</Text>
                    <Text style={styles.col2}>{order.urgency || '--'}</Text>
                    <Text style={styles.col1}>{order.scheduledDate ? (new Date(order.scheduledDate).toLocaleDateString('en-GB')) : '--'}</Text>
                    <Text style={styles.col2}>{order.instructions || '--'}</Text>
                    <Text style={styles.col2}>{order.orderedBy || '--'}</Text>
                  </View>
                );
              }
              return null;
            })}
          </View>
        </View>
      )}
    </View>
  );
};
