import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';

interface NewbornAdmissionData {
    fatherName?: string;
    motherName?: string;
    dateOfDelivery?: string;
    motherId?: string;
    gestationalWeek?: string;
    bodyWeight?: number;
    encounterDatetime?: string;
    patientName?: string;
    patientGender?: string;
    patientBirthdate?: string;
}

export function useNewbornAdmissionData(patientUuid: string) {
    const customRepresentation = 'custom:(uuid,display,diagnoses:(uuid,display,rank,diagnosis,certainty,voided),encounterDatetime,form:(uuid,display,name,description,encounterType,version,resources:(uuid,display,name,valueReference)),encounterType,visit,patient:(uuid,display,person:(uuid,display,gender,birthdate,preferredName:(uuid,display))),obs:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterProviders:(provider:(person)))';

    const fetchEncounters = async (url: string) => {
        const response = await openmrsFetch(url);
        return response.data;
    };

    const { data, error, isLoading } = useSWR(
        patientUuid
            ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRepresentation}&order=desc&limit=20&startIndex=0&totalCount=true`
            : null,
        fetchEncounters
    );

    const newbornData: NewbornAdmissionData | null = useMemo(() => {
        if (!data?.results) {
            console.log('no result bro');
            return null;
        }

        console.log('result', data?.results);

        // Filter for "Newborn admission note" form
        const newbornEncounter = data.results.find(
            (encounter: any) =>
                encounter.form?.name === 'Newborn admission note' ||
                encounter.form?.display === 'Newborn admission note' ||
                encounter.display?.includes('Newborn admission note')
        );
        console.log('Matched Newborn encounter:', newbornEncounter);

        if (!newbornEncounter) return null;

        // Extract data from observations
        const extractObsValue = (conceptUuid: string, conceptDisplay: string) => {
            const obs = newbornEncounter.obs?.find((o: any) =>
                o.concept?.uuid === conceptUuid || o.concept?.display === conceptDisplay
            );
            if (!obs) return undefined;

            // Handle different value types
            if (typeof obs.value === 'object' && obs.value?.display) {
                return obs.value.display;
            }
            return obs.value;
        };

        return {
            fatherName: extractObsValue('a9f4df21-f9a2-4ae6-a584-8252c62c32c1', 'NBA-Father name'),
            motherName: extractObsValue('1ee2d7ab-9d43-486d-b656-8eaeb0ecbc0d', 'NBA-Mother name'),
            dateOfDelivery: extractObsValue('33b344a1-0814-4a69-8ef2-e69b2d8c6f69', 'Date and time of delivery'),
            motherId: extractObsValue('a270e58a-1c95-4ad6-a1df-b5973882df0d', 'Mother ID'),
            gestationalWeek: extractObsValue('557e394a-f224-45aa-9520-4efe71df98c0', 'NBA-Gestational week'),
            bodyWeight: extractObsValue('530973be-6780-4ed3-85e3-bb3d04807a4a', 'NBA-Neonate weight'),
            encounterDatetime: newbornEncounter.encounterDatetime,
            patientName: newbornEncounter.patient?.person?.preferredName?.display,
            patientGender: newbornEncounter.patient?.person?.gender,
            patientBirthdate: newbornEncounter.patient?.person?.birthdate,
        };

    }, [data]);

    return {
        newbornData,
        isLoading,
        error,
    };
}
