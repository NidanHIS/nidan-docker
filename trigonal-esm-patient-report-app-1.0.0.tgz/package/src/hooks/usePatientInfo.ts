import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { usePatient } from '@openmrs/esm-framework';
import { calculateAge } from '../utils';
export function usePatientInfo(patientUuid) {
  const { patient, isLoading, error } = usePatient(patientUuid);
  const { t } = useTranslation();

  const formattedPatientInfo = useMemo(() => {
    if (!patient) return null;
    return {
      name: patient?.name?.[0]?.text || t('unknownValue', 'Unknown'),
      age: calculateAge(patient?.birthDate) || t('unknownValue', 'Unknown'),
      birthDate: patient?.birthDate || t('unknownValue', 'Unknown'),
      gender: patient?.gender || t('unknownValue', 'Unknown'),
      address: patient?.address?.[0]?.extension?.[0]?.extension?.[0]?.valueString || t('unknownValue', 'Unknown'),
      patientId: patient?.identifier?.[0]?.value || t('unknownValue', 'Unknown'),
    };
  }, [patient]);

  return {
    patientInfo: formattedPatientInfo,
    isLoading,
    error
  };
}