import { useState, useEffect } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';
import { useConfig } from '@openmrs/esm-framework';
import { ConfigObject } from '../config-schema';

export function useEncounterData(patientUuid) {
  const [diagnosisData, setDiagnosisData] = useState<DiagnosisData[]>([]);
  const [clinicalNotes, setClinicalNotes] = useState<ClinicalNote[]>([]);
  const { concepts } = useConfig<ConfigObject>();

  const fetchEncounterData = async (url: string): Promise<PatientEncounter> => {
    const response = await openmrsFetch(url);
    return response.data.results;
  };

  const customRepresentation = 'custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,diagnosis),obs:(uuid,concept:(uuid,display),value,obsDatetime),encounterType:(uuid,display)),startDatetime,stopDatetime)';

  const { data: encounter, error, isLoading: isEncounterLoading } = useSWR(
    `${restBaseUrl}/visit?patient=${patientUuid}&v=${customRepresentation}&voided=false&limit=1`,
    fetchEncounterData
  );

  useEffect(() => {
    const tempDiagnosisData: DiagnosisData[] = [];
    const tempClinicalNotes: ClinicalNote[] = [];

    if (encounter?.[0]?.encounters) {
      encounter[0].encounters.forEach((encounter, index) => {
        encounter.diagnoses?.forEach(diagnosis => {
          const diagnosisName = diagnosis.display;
          if (diagnosisName) {
            tempDiagnosisData.push({
              diagnosisName
            });
          }
        });

        encounter.obs?.forEach(observation => {
          if (observation && observation.concept?.uuid === "162169AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" && observation.value) {
            const note = observation.value;
            tempClinicalNotes.push({
              note
            });
          }
        });

      });
      setDiagnosisData(tempDiagnosisData);
      setClinicalNotes(tempClinicalNotes);
    }

  }, [encounter]);

  return {
    diagnosisData,
    clinicalNotes,
    isEncounterLoading,
    error
  };
}
