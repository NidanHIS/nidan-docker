import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';
import useSWR from 'swr';

interface SessionResponse {
  user?: {
    display?: string;
    person?: {
      display?: string;
    };
    username?: string;
  };
  currentProvider?: {
    person?: {
      display?: string;
    };
  };
}

export function usePrintedByData() {
  const fetchSession = async (url: string): Promise<SessionResponse> => {
    const response = await openmrsFetch(url);
    return response.data;
  };

  const { data, error, isLoading } = useSWR(`${restBaseUrl}/session`, fetchSession);

  const printedBy =
    data?.currentProvider?.person?.display ||
    data?.user?.person?.display ||
    data?.user?.display ||
    data?.user?.username ||
    '';

  return {
    printedBy,
    isLoading,
    error,
  };
}
