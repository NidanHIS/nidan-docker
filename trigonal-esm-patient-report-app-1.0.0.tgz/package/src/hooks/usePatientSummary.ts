import { usePatientInfo } from "./usePatientInfo";
import { useVisitDetails } from "./useVisitDetails";
import { useVitalsData } from "./useVitalsData";
import { useBiometricsData } from "./useBiometricsData";
import { useConditionsData } from "./useConditionsData";
import { useEncounterData } from "./useEncounterData";
import { useOrdersData } from "./useOrdersData";
import { usePrintedByData } from "./usePrintedByData";
export function usePatientSummaryData(patientUuid) {
  const { patientInfo, isLoading: isPatientLoading, error: patientError } = usePatientInfo(patientUuid);
  const { visitDetails, isLoading: isVisitLoading, error: visitError } = useVisitDetails(patientUuid);
  const { vitalsData, isLoading: isVitalsLoading, error: vitalsError } = useVitalsData(patientUuid);
  const { biometricsData, isLoading: isBiometricsLoading, error: biometricsError } = useBiometricsData(patientUuid);
  const { conditionsData, isLoading: isConditionsLoading, error: conditionsError } = useConditionsData(patientUuid);
  const { diagnosisData, clinicalNotes, isEncounterLoading: isEncounterLoading, error: encounterError } = useEncounterData(patientUuid);
  const { orders, isLoading: isOrdersLoading, error: ordersError } = useOrdersData(patientUuid);
  const { printedBy, isLoading: isPrintedByLoading, error: printedByError } = usePrintedByData();

  return {
    patientInfo,
    visitDetails,
    vitalsData,
    biometricsData,
    conditionsData,
    diagnosisData,
    clinicalNotes,
    printedBy,
    orders: orders,
    isLoading: isPatientLoading || isVisitLoading || isVitalsLoading || isBiometricsLoading || 
              isConditionsLoading || isEncounterLoading || isOrdersLoading || isPrintedByLoading,
    error: patientError || visitError || vitalsError || biometricsError || 
          conditionsError || encounterError || ordersError || printedByError
  };
}
