import { useMemo } from 'react';
import { restBaseUrl } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import { openmrsFetch } from '@openmrs/esm-framework';

export function useOrdersData(patientUuid) {
  const getOrderedByDisplay = (order): string => {
    return (
      order?.orderer?.display ||
      order?.orderer?.person?.display ||
      order?.auditInfo?.creator?.display ||
      order?.auditInfo?.creator?.person?.display ||
      ''
    );
  };

  const fetchOrders = async (url: string): Promise<Orders[]> => {
    const response = await openmrsFetch(url);
    return response.data.results;
  };
  const { t } = useTranslation();

  const { data: orders, error, isLoading } = useSWR(
    `${restBaseUrl}/order?patient=${patientUuid}&v=full&includeInactive=false`,
    fetchOrders
  );

  const ordersData = useMemo(() => {
    if (!orders) return [];
    
    return orders
      .map(order => {
        if (order.orderType?.name === 'Drug Order') {
          return {
            orderType: { name: 'Drug Order' },
            drug: { display: order.drug?.display || t('unknownValue', 'Unknown') },
            dose: order.dose || '',
            doseUnits: { display: order.doseUnits?.display || '' },
            frequency: { display: order.frequency?.display || '' },
            dosingInstructions: order.dosingInstructions || t('takeAsDirected', 'Take as directed'),
            route: { display: order.route?.display || '' },
            duration: order.duration || '',
            durationUnits: { display: order.durationUnits?.display || '' },
            orderedBy: getOrderedByDisplay(order) || t('unknownValue', 'Unknown'),
            auditInfo: {
              dateCreated: order.auditInfo?.dateCreated || '',
            },
          };
        } else if (order.orderType?.name === 'Test Order') {
          return {
            orderType: { name: 'Test Order' },
            dateActivated: order.dateActivated || '',
            scheduledDate: order.scheduledDate || '',
            display: order.display,
            urgency: order.urgency || t('routineUrgency', 'ROUTINE'),
            instructions: order.instructions || '',
            orderedBy: getOrderedByDisplay(order) || t('unknownValue', 'Unknown'),
          };
        }
        return null;
      })
      .filter(Boolean);
  }, [orders]);

  return {
    orders: ordersData,
    isLoading,
    error
  };
}
