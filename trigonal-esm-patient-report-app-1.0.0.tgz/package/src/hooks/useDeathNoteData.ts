import { useMemo } from 'react';
import useSWR from 'swr';
import { restBaseUrl, openmrsFetch } from '@openmrs/esm-framework';
import dayjs from 'dayjs';

interface DeathNoteData {
    patientName?: string;
    patientGender?: string;
    patientAge?: string;
    patientId?: string;
    placeOfDeath?: string;
    wardOrUnit?: string;
    dateAndTimeOfDeath?: string;
    broughtDead?: string;
    mannerOfDeath?: string;
    deathType?: string;
    immediateCause?: string;
    antecedentCause?: string;
    underlyingCause?: string;
    otherSignificantConditions?: string;
    medicoLegalCase?: string;
    maternalDeathStatus?: string;
    familyInformed?: string;
    briefHospitalCourse?: string;
    postMortemDone?: string;
    postOperativeDeath?: string;
    mdgpNotifiedAt?: string;
    providerName?: string;
    providerQualification?: string;
    providerRegistrationNumber?: string;
    dateSigned?: string;
    encounterDatetime?: string;
}

export function useDeathNoteData(patientUuid: string) {
    const customRepresentation =
        'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),visit:(location:(display)),patient:(uuid,display,identifiers:(display),person:(uuid,display,gender,age,birthdate,preferredName:(display))),obs:(uuid,concept:(uuid,display),value:(uuid,display),display,obsDatetime),encounterProviders:(provider:(person:(display))))';

    const fetchEncounters = async (url: string) => {
        const response = await openmrsFetch(url);
        return response.data;
    };

    const { data, error, isLoading } = useSWR(
        patientUuid
            ? `${restBaseUrl}/encounter?patient=${patientUuid}&v=${customRepresentation}&order=desc&limit=20`
            : null,
        fetchEncounters
    );

    const deathNoteData: DeathNoteData | null = useMemo(() => {
        if (!data?.results) return null;

        // Filter for "Death Note" form
        const deathEncounter = data.results.find(
            (encounter: any) =>
                encounter.form?.name === 'Death Note' ||
                encounter.form?.display === 'Death Note' ||
                encounter.display?.includes('Death Note')
        );

        if (!deathEncounter) return null;

        // Extract data from observations
        // const extractObsValue = (conceptUuid: string) => {
        //     const obs = deathEncounter.obs?.find((o: any) => o.concept?.uuid === conceptUuid);
        //     if (!obs) return undefined;

        //     // Handle different value types
        //     if (typeof obs.value === 'object' && obs.value?.display) {
        //         return obs.value.display;
        //     }
        //     return obs.value;
        // };

        const extractObsValue = (conceptUuid: string, conceptDisplay: string) => {
            const obs = deathEncounter.obs?.find((o: any) =>
                o.concept?.uuid === conceptUuid || o.concept?.display === conceptDisplay
            );
            if (!obs) return undefined;

            // Handle different value types
            if (typeof obs.value === 'object' && obs.value?.display) {
                return obs.value.display;
            }
            return obs.value;
        };

        return {
            patientName: deathEncounter.patient?.person?.preferredName?.display,
            patientGender: deathEncounter.patient?.person?.gender,
            patientAge: deathEncounter.patient?.person?.age,
            patientId: deathEncounter.patient?.identifiers?.[0]?.display?.split('=')?.[1]?.trim(),
            placeOfDeath: 'Hospital', // Default or extracted if needed
            wardOrUnit: deathEncounter.visit?.location?.display,
            dateAndTimeOfDeath: extractObsValue('086be09f-2360-4907-ad02-caa69c0ddb71','Pronounced death date and time') || deathEncounter.encounterDatetime, 
            broughtDead: extractObsValue('fd4662d1-19de-42d1-96d6-69b28d794820', 'Brought dead'), // Brought dead
            mannerOfDeath: extractObsValue('', 'Manner of Death'), // UUID MISSING
            deathType: extractObsValue('6a811193-2c82-4585-a938-d053419f3917', 'Death type'),
            immediateCause: extractObsValue('', 'Primary cause of death'),
            antecedentCause: extractObsValue('', 'Secondary cause of death'),
            underlyingCause: extractObsValue('', 'Tertiary cause of death'),
            otherSignificantConditions: extractObsValue('e7db97e6-89e3-4d19-a21c-6585ea56066f', 'Other co morbidities'),
            medicoLegalCase: extractObsValue('', 'Medico legal / police case'), // UUID MISSING
            maternalDeathStatus: undefined, // UUID MISSING
            familyInformed: extractObsValue('d2cb9d59-6a37-4a35-9c6c-1d6e652311fa', 'Family aware of death'), // Family aware of death
            briefHospitalCourse: extractObsValue('1791b581-a9cc-4ecc-9917-00887672772d', 'Hospital course'), // Hospital course
            postMortemDone: extractObsValue('da3173b7-8f7c-4ffa-b9fa-085274c07655', 'Postmortem done'), // Postmortem done
            postOperativeDeath: extractObsValue('071cf0cc-d5ef-43fe-80e5-00438703cd41', 'Death occured post operative'), // Death occured post operative
            mdgpNotifiedAt: extractObsValue('', 'MDGP notified at'), // UUID MISSING
            providerName: deathEncounter.encounterProviders?.[0]?.provider?.person?.display,
            providerQualification: undefined, // usually not in encounter data directly
            providerRegistrationNumber: undefined, // usually not in encounter data directly
            dateSigned: deathEncounter.encounterDatetime, // using encounter date as signed date
            encounterDatetime: deathEncounter.encounterDatetime,
        };
    }, [data]);

    return {
        deathNoteData,
        isLoading,
        error,
    };
}
