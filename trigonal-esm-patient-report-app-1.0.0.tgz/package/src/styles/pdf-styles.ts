import { StyleSheet } from '@react-pdf/renderer';

export const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#ffffff',
    padding: 30,
    paddingBottom: 35,
    fontFamily: 'Helvetica',
  },
  title: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    marginBottom: 5,
    padding: 10,
    border: '1.2pt solid black',
  },
  leftColumn: {
    flex: 1,
  },
  rightColumn: {
    width: '40%',
    alignItems: 'flex-end'
  },
  row: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  spacing: {
    marginLeft: 30,
  },
  label: {
    fontSize: 12,
    fontFamily: 'Helvetica-Bold',
    marginRight: 5,
  },
  value: {
    fontSize: 12,
  },
  hr: {
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    marginVertical: 10,
  },
  mainContent: {
    marginTop: 10,
  },
  sectionTitle: {
    fontSize: 12,
    fontFamily: 'Helvetica-Bold',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  sectionContent: {
    fontSize: 12,
    marginBottom: 20,
  },
  drugOrderSection: {
    marginTop: 20,
  },
  orderTable: {
    marginTop: 10,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f4f4f4',
    padding: 5,
    borderBottomWidth: 1,
    borderBottomColor: '#000',
  },
  tableRow: {
    flexDirection: 'row',
    padding: 5,
    borderBottomWidth: 0.5,
    borderBottomColor: '#ccc',
  },
  col1: {
    width: '15%',
    fontSize: 10,
    paddingRight: 15,
    textAlign: 'center',
  },
  col2: {
    width: '20%',
    fontSize: 10,
    paddingRight: 15,
    textAlign: 'center',
  },
  col3: {
    width: '25%',
    fontSize: 10,
    paddingRight: 15,
    // textAlign: 'center',
  },
  col4: {
    width: '30%',
    fontSize: 10,
    paddingRight: 15,
    // textAlign: 'center',
  },
  col5: {
    width: '35%',
    fontSize: 10,
    paddingRight: 15,
  },
  vitalRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  right: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  vitalContent: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  bullet: {
    paddingRight: 5,
  },
  abnormalValue: {
    fontFamily: 'Helvetica-Bold',
    color: '#ff0000'
  },
  footer: {
    position: 'absolute',
    bottom: 18,
    left: 30,
    right: 30,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    paddingTop: 6,
  },
  footerText: {
    fontSize: 10,
    textAlign: 'right',
  },
});
